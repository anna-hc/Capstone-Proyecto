import os
from pathlib import Path

from cryptography.fernet import Fernet
from dotenv import load_dotenv

# la Partner API se monta al importar app.main, así que su configuración de pruebas tiene que existir antes
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
for key, value in {
    "APP_NAME": "WellQ test", "APP_ENV": "test", "PORT": "8000", "JWT_SECRET": "test-only-jwt-secret-0123456789abcdef",
    "JWT_ALG": "HS256", "JWT_EXPIRES_MIN": "60", "ACCESS_EXPIRES_MIN": "30", "INVITE_TTL_HOURS": "168",
    "MONGODB_URI": "mongodb://127.0.0.1:1/wellq-test?serverSelectionTimeoutMS=200",
    "MONGO_CENTRAL_URI": "mongodb://127.0.0.1:1/wellq_platform_test?serverSelectionTimeoutMS=200",
    "REDIS_HOST": "127.0.0.1", "REDIS_PORT": "1",
    "PARTNER_API_ENABLED": "true", "PARTNER_TOKEN_SECRET": "test-only-partner-secret-0123456789abcdefghij",
    "PARTNER_ENCRYPTION_KEY": Fernet.generate_key().decode(), "PARTNER_WEBHOOK_ALLOW_PRIVATE": "true",
    "PARTNER_DEV_TOOLS_ENABLED": "true", "PARTNER_DEMO_ENABLED": "true", "PARTNER_ADMIN_TENANT_SLUGS": "clinica-test",
}.items():
    os.environ.setdefault(key, value)
