"""Carga ligera y concurrencia contra una instancia en marcha con herramientas de desarrollo activas.

Uso: python tests/partner_ui/carga_ligera.py http://127.0.0.1:8765 salida.json
"""
import asyncio
import gzip
import json
import statistics
import sys
import time
import uuid

import httpx

BASE = sys.argv[1].rstrip("/") + "/api/v1"
OUT = sys.argv[2] if len(sys.argv) > 2 else "carga.json"


async def setup(client):
    r = await client.post("/partner/developers/register", json={
        "company_name": "Carga", "contact_email": f"carga-{uuid.uuid4().hex[:8]}@acme-wearables.com", "country": "GB",
        "accept_terms": True})
    dev = r.json()
    portal = (await client.post("/partner/developers/verify", json={
        "developer_id": dev["developer_id"], "verification_token": dev["verification_token"]})).json()["portal_token"]
    app = (await client.post("/partner/apps", json={"name": "Carga"}, headers={"Authorization": f"Bearer {portal}"})).json()
    token = (await client.post("/partner/oauth/token", data={"grant_type": "client_credentials", "client_id": app["client_id"],
                                                             "client_secret": app["client_secret"]})).json()["access_token"]
    auth = {"Authorization": f"Bearer {token}"}
    links = []
    for _ in range(5):
        code = (await client.post("/partner/sandbox/patients", json={}, headers=auth)).json()["pairing_code"]
        links.append((await client.post("/partner/links", json={"pairing_code": code, "external_user_id": uuid.uuid4().hex[:10]},
                                        headers=auth)).json()["link_id"])
    return auth, links


def summary(i, day):
    return {"record_id": f"r-{i}-{day}", "local_date": f"2026-09-{day:02d}", "tz_offset_minutes": 0, "device_id": "D",
            "completeness": "final", "steps": 5000 + i, "resting_heart_rate_bpm": 60}


async def timed(coro):
    t = time.perf_counter()
    r = await coro
    return r, (time.perf_counter() - t) * 1000


def stats(latencies):
    latencies = sorted(latencies)
    return {"n": len(latencies), "p50_ms": round(statistics.median(latencies), 1),
            "p95_ms": round(latencies[int(len(latencies) * 0.95) - 1], 1), "max_ms": round(latencies[-1], 1)}


async def main():
    report = {}
    limits = httpx.Limits(max_connections=20)
    async with httpx.AsyncClient(base_url=BASE, timeout=60, limits=limits) as client:
        auth, links = await setup(client)

        batches = [{"summaries": [summary(i * 100 + j, (j % 28) + 1) for j in range(100)]} for i in range(20)]
        t0 = time.perf_counter()
        results = await asyncio.gather(*[timed(client.post(f"/partner/links/{links[i % 5]}/daily-summaries", json=b,
                                                          headers=auth)) for i, b in enumerate(batches)])
        elapsed = time.perf_counter() - t0
        codes = [r.status_code for r, _ in results]
        report["daily_summaries_20x100"] = {**stats([ms for _, ms in results]), "status": sorted(set(codes)),
                                            "registros_por_s": round(2000 / elapsed, 1)}

        series = {"series": [{"metric": "heart_rate", "unit": "bpm", "device_id": "D", "start": "2026-09-01T00:00:00Z",
                              "offsets_ms": list(range(0, 50000 * 1000, 1000)), "values": [60 + (k % 40) for k in range(50000)]}]}
        body = gzip.compress(json.dumps(series).encode())
        results = await asyncio.gather(*[timed(client.post(f"/partner/links/{links[i % 5]}/samples", content=body,
                                                          headers={**auth, "Content-Encoding": "gzip",
                                                                   "Content-Type": "application/json"}))
                                         for i in range(10)])
        report["samples_10x50000_puntos"] = {**stats([ms for _, ms in results]),
                                             "status": sorted({r.status_code for r, _ in results}),
                                             "bytes_gzip": len(body)}
        jobs = [r.json()["job_id"] for r, _ in results if r.status_code == 202]
        t0 = time.perf_counter()
        pending = set(jobs)
        while pending and time.perf_counter() - t0 < 120:
            for job_id in list(pending):
                r = await client.get(f"/partner/ingest/jobs/{job_id}", headers=auth)
                if r.json()["status"] not in ("queued", "processing"):
                    pending.discard(job_id)
            await asyncio.sleep(0.5)
        report["samples_jobs_completados_s"] = round(time.perf_counter() - t0, 1) if not pending else None

        key = str(uuid.uuid4())
        same = {"summaries": [summary(999, 1)]}
        results = await asyncio.gather(*[client.post(f"/partner/links/{links[0]}/daily-summaries", json=same,
                                                     headers={**auth, "Idempotency-Key": key}) for _ in range(50)])
        report["misma_idempotency_key_x50"] = {
            "ejecutadas": sum(1 for r in results if r.status_code == 200 and r.headers.get("Idempotency-Replayed") != "true"),
            "replays": sum(1 for r in results if r.headers.get("Idempotency-Replayed") == "true"),
            "conflictos_409": sum(1 for r in results if r.status_code == 409)}
        same_record = {"summaries": [summary(777, 2)]}
        results = await asyncio.gather(*[client.post(f"/partner/links/{links[1]}/daily-summaries", json=same_record,
                                                     headers=auth) for _ in range(50)])
        statuses = [r.json()["results"][0]["status"] for r in results if r.status_code == 200]
        report["mismo_record_id_x50"] = {"created": statuses.count("created"), "updated": statuses.count("updated"),
                                         "duplicate": statuses.count("duplicate"),
                                         "status_http": sorted({r.status_code for r in results})}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)


asyncio.run(main())
