import pytest
from conftest import make_patient

import app.config as conf
import app.api.v1.routers.patient_metrics as metrics_router


@pytest.fixture
def enqueued(monkeypatch):
    calls = []
    import app.services.task_service as task_service
    monkeypatch.setattr(task_service, "enqueue_metrics", lambda items, timeout=60: calls.append(items) or "job-1")
    return calls


def _body(patient_id):
    return {"from_ts": "2026-09-01T00:00:00Z", "patient_id": patient_id, "provider": "health_connect",
            "sensors": {"steps": {"value": 10, "metric": "steps"}}}


def test_api_key_vacia_falla_cerrado_fuera_de_desarrollo(client, enqueued, monkeypatch):
    monkeypatch.setattr(metrics_router, "API_KEY", "")
    monkeypatch.setattr(conf, "INGEST_API_KEY", "")
    monkeypatch.setattr(conf, "APP_ENV", "production")
    r = client.post("/api/v1/metrics", json=_body("P-000000000001"))
    assert r.status_code == 503 and not enqueued
    monkeypatch.setattr(conf, "APP_ENV", "dev")
    assert client.post("/api/v1/metrics", json=_body("P-000000000001")).status_code == 200


def test_api_key_sigue_funcionando_para_la_app_movil(client, enqueued, monkeypatch):
    monkeypatch.setattr(metrics_router, "API_KEY", "clave-de-prueba")
    monkeypatch.setattr(conf, "APP_ENV", "production")
    assert client.post("/api/v1/metrics", json=_body("P-000000000001"), headers={"X-API-Key": "otra"}).status_code == 401
    r = client.post("/api/v1/metrics", json=_body("P-000000000001"),
                    headers={"X-API-Key": "clave-de-prueba", "Idempotency-Key": "k-1"})
    assert r.status_code == 200 and enqueued[-1][0]["idempotency_key"] == "k-1"
    monkeypatch.setattr(conf, "LEGACY_INGEST_API_KEY_ENABLED", False)
    assert client.post("/api/v1/metrics", json=_body("P-000000000001"),
                       headers={"X-API-Key": "clave-de-prueba"}).status_code == 401


def test_jwt_de_paciente_solo_envia_sus_metricas(client, enqueued, monkeypatch):
    monkeypatch.setattr(metrics_router, "API_KEY", "clave-de-prueba")
    patient = make_patient()
    other = make_patient()
    r = client.post("/api/v1/metrics", json=_body(patient["patient_id"]), headers=patient["headers"])
    assert r.status_code == 200, r.text
    r = client.post("/api/v1/metrics", json=_body(other["patient_id"]), headers=patient["headers"])
    assert r.status_code == 403
