# app/db.py

from datetime import timezone as _tz
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from pymongo.errors import DuplicateKeyError
from pymongo import ASCENDING, DESCENDING

import app.config as conf
from contextvars import ContextVar
from pymongo.database import Database

import logging

import certifi

# Configurar cliente central y tenant con soporte TLS via certifi
def _get_mongo_kwargs(uri: str) -> dict:
    kwargs = {"tz_aware": True, "tzinfo": _tz.utc}
    if uri and ("tls=true" in uri.lower() or "cosmos" in uri.lower() or "+srv" in uri.lower()):
        kwargs["tlsCAFile"] = certifi.where()
    return kwargs

_client = MongoClient(conf.MONGO_URI, **_get_mongo_kwargs(conf.MONGO_URI))

if conf.MONGO_CENTRAL_URI and conf.MONGO_CENTRAL_URI != conf.MONGO_URI:
    _central_client = MongoClient(conf.MONGO_CENTRAL_URI, **_get_mongo_kwargs(conf.MONGO_CENTRAL_URI))
else:
    _central_client = _client

try:
    db = _client.get_default_database()
except Exception:
    db = _client[conf.MONGO_DB]

try:
    central_db = _central_client.get_default_database()
except Exception:
    central_db = _central_client[conf.MONGODB_CENTRAL_DB]


def reset_clients_for_fork() -> None:
    """Recrea `_client`/`_central_client` (y `db`/`central_db`) tras un fork().

    `MongoClient` mantiene hilos de background (monitor/pool) que `fork()` NO
    clona -- un proceso hijo que reutiliza un client ya conectado en el padre
    puede quedar deadlockeado en silencio al hacer una query (pymongo lo
    documenta explícitamente: https://dochub.mongodb.org/core/pymongo-fork-deadlock).
    Confirmado en esta base de código: los jobs de ingesta de RQ (que SÍ
    forkean un proceso por job, ver `app/utils/run_worker.py`) podían fallar
    la validación de paciente en `ensure_pacientes_exist_by_rut_norm` sin
    ninguna excepción visible -- la query simplemente no encontraba nada,
    exactamente el síntoma de un socket/estado de conexión corrupto post-fork.

    Llamar esto SOLO desde un hook `os.register_at_fork(after_in_child=...)`
    registrado ANTES de que el proceso empiece a forkear (ver
    `run_worker.py`) -- nunca desde el proceso padre.

    No reemplaza toda referencia a `db`/`central_db` que algún módulo haya
    capturado con `from app.db import db` a nivel de import (esas quedan con
    el objeto viejo); cubre el patrón dominante en este código, que resuelve
    la base de datos activa vía `_tenant_db.get()` o con un import local
    (`from app.db import _client`) dentro de la función, ambos evaluados en
    el momento de uso y no en el de import.
    """
    global _client, _central_client, db, central_db

    for client in {_client, _central_client}:
        try:
            client.close()
        except Exception:
            pass

    _client = MongoClient(conf.MONGO_URI, tz_aware=True, tzinfo=_tz.utc)
    if conf.MONGO_CENTRAL_URI and conf.MONGO_CENTRAL_URI != conf.MONGO_URI:
        _central_client = MongoClient(conf.MONGO_CENTRAL_URI, tz_aware=True, tzinfo=_tz.utc)
    else:
        _central_client = _client

    try:
        db = _client.get_default_database()
    except Exception:
        db = _client[conf.MONGO_DB]

    try:
        central_db = _central_client.get_default_database()
    except Exception:
        central_db = _central_client[conf.MONGODB_CENTRAL_DB]


_tenant_db: ContextVar[Database] = ContextVar("tenant_db", default=db)
_tenant_bucket: ContextVar[str] = ContextVar("tenant_bucket", default=conf.BUCKET_NAME)
_tenant_gcs_credentials: ContextVar[str] = ContextVar("tenant_gcs_credentials", default=None)
_tenant_azure_container: ContextVar[str] = ContextVar("tenant_azure_container", default=conf.AZURE_DEFAULT_CONTAINER)
_tenant_azure_credentials: ContextVar[str] = ContextVar("tenant_azure_credentials", default=None)

TBL_METRICS = "metrics"
TBL_PATIENTS = "patients"
TBL_CLINICIANS = "clinicians"
TBL_CLINICS = "clinics"
TBL_INTAKES = "intakes"
TBL_CHECKINS = "checkins"
TBL_CONSENTS = "consents"
TBL_DIAGNOSTIC_CODES = "diagnostic_codes"
TBL_MAP_STRUCTINTEG = "body_map"
TBL_PATIENT_COMMITMENTS = "patient_commitments"
TBL_PATIENT_GOALS = "patient_goals"
TBL_SCHEDULED_EXERCISES = "scheduled_exercises"
TBL_SURVEYS = "respuestas_satisfaccion"
TBL_USERS = "users"
TBL_USERS_SESSION = "oauth2_tokens"
TBL_OAUTH2_CLIENTS = "oauth2_clients"
TBL_OAUTH2_CODES = "oauth2_codes"
TBL_PATIENT_HEALTH_PROFILES = "patient_health_profiles"
TBL_CASE_HISTORY = "case_history"
TBL_PATIENT_ROUTINES = "patient_routines"
TBL_PATIENT_WORKOUT_LOGS = "patient_workout_logs"
TBL_PATIENT_CUSTOM_EXERCISES = "patient_custom_exercises"
TBL_PATIENT_WEARABLE_WORKOUTS = "patient_wearable_workouts"
TBL_COMMUNICATIONS = "communications_log"
TBL_CLINICAL_PROGRAMS = "clinical_programs"
TBL_PROGRAM_TEMPLATES = "program_templates"
TBL_PATIENT_PROGRAMS = "patient_programs"
TBL_REPORTS_CONFIG = "reports_config"
TBL_PATIENT_METRICS_DAILY = "patient_metrics_daily"
TBL_PATIENT_METRICS_WEEKLY = "patient_metrics_weekly"
TBL_PATIENT_METRICS_TRACE_LOG = "patient_metrics_trace_log"

# Newly centralized collections
TBL_CAMPAIGNS = "campaigns"
TBL_TICKETS = "ticket"
TBL_TICKET_CATEGORIES = "ticket_categories"
TBL_RESPONDERS = "responder"
TBL_EMAIL_TEMPLATES = "email_template"
TBL_EMAIL_CONFIGS = "email_config"
TBL_EMAIL_INFOTICKETS = "email_infoticket"
TBL_CHANNELS = "channels"
TBL_CREDENTIALS = "credentials"
TBL_LEGAL_DOCS = "legal_docs"
TBL_SPECIALITIES_CATALOG = "specialities_catalog"
TBL_CLINICAS = "clinicas"
TBL_INVITATIONS = "invitations"
TBL_PUSH_TOKENS = "push_tokens"
TBL_CASES = "cases"
TBL_APPOINTMENTS = "appointments"
TBL_CLINICAL_NOTES = "clinical_notes"
TBL_CLINICAL_RECORDING_SESSIONS = "clinical_recording_sessions"
TBL_EXERCISES_CATALOG = "exercises_catalog"
TBL_ENGAGEMENT_SNAPSHOTS = "engagement_daily_snapshots"
TBL_EXERCISES_PATIENT = "exercises_patient"
TBL_ALERTS = "alerts"
TBL_ACTIVITIES_CATALOG = "activities_catalog"
# Definiciones geometricas (angle rules) para el modo guiado de KineIA en la
# app movil, generadas por LLM o medidas sobre video. Por eje_cod, GLOBAL
# (central_db, no por tenant, desde 2026-08 -- un mismo ejercicio real es el
# mismo movimiento sin importar la clinica/paciente; antes de este cambio
# cada tenant regeneraba el mismo eje_cod de forma independiente, con calidad
# distinta cada vez, y una mala tirada del LLM en un tenant no se beneficiaba
# de una buena tirada en otro). Ver docs/architecture/kineia_exercise_definitions.md.
TBL_KINEIA_EXERCISE_DEFINITIONS = "kineia_exercise_definitions"
# Scores de sesiones guiadas subidos desde la app (KineiaScoreStore). Ver
# app/models/kineia_session_score.py.
TBL_KINEIA_SESSION_SCORES = "kineia_session_scores"
TBL_TENANTS = "tenants"




KEY_CARE_CLINICIAN_ID = "care_clinician_id" #"doctor_cabecera_id"
KEY_STATUS = "status" # clinical status of the patient
KEY_STATE  = "state" # state of the patient (active | inactive)
KEY_LAST_NAME = "last_name"
KEY_FIRST_NAME = "first_name"
KEY_CONTACT = "contact"
KEY_PHONE = "contact.phone"
KEY_EMAIL = "contact.email"
KEY_PATIENT_INTERNAL_ID = "patient_id"
KEY_CLINICIAN_INTERNAL_ID = "clinician_id"
KEY_INTERNAL_ID = KEY_PATIENT_INTERNAL_ID  # alias used across the codebase
KEY_AUTHORIZED_CLINICIANS = "authorized_clinicians"


def safe_create_index(collection, keys, name=None, **kwargs):
    """
    Crea un índice solo si no existe ya uno con el mismo nombre.
    Esto evita llamadas redundantes que generan avisos en la consola de GCP / Firestore.
    """
    try:
        if name:
            existing_indexes = collection.list_indexes()
            for index in existing_indexes:
                if index.get("name") == name:
                    return # Ya existe, saltamos
        
        collection.create_index(keys, name=name, **kwargs)
    except Exception as e:
        # Check if the error indicates a broken index that needs repair (Code 86)
        error_msg = str(e)
        if "needs repair" in error_msg:
            # We explicitly do NOT auto-repair here because index rebuilds on large
            # collections (historial_medico) can take minutes and block Uvicorn startup.
            pass
                
        # If it's a different error or repair failed, log it as debug so it doesn't 
        # spam production logs and drastically slow down the synchronous startup hook.
        logging.getLogger("API").debug(f"Index issue {name} in {collection.name}: {e}")


def ensure_indexes(target_db=None):
    """ Crea los índices críticos. Idempotente (safe_create_index salta los que ya existen).

    NO llamar durante el arranque de la aplicación (lifespan de FastAPI): sobre una
    colección grande, `create_index()` puede tardar minutos y colgar el startup —
    eso fue lo que originalmente forzó un `return` incondicional al principio de esta
    función, con el efecto colateral de que dejaron de crearse índices por completo
    para cualquier colección nueva. Ejecutar a demanda en su lugar:

        python -m app.scripts.create_indexes --all
        python -m app.scripts.create_indexes --db wellq-dev-2
    """
    actual_db = target_db if target_db is not None else _tenant_db.get()
    # Clinics
    safe_create_index(actual_db[TBL_CLINICS], "name", name="name_1")
    safe_create_index(actual_db[TBL_CLINICS], "state", name="state_1")

    # Clinicians
    safe_create_index(actual_db[TBL_CLINICIANS], KEY_CLINICIAN_INTERNAL_ID, unique=True, name="ux_clinicians_rut_norm")
    safe_create_index(actual_db[TBL_CLINICIANS], "contact.email", name="ix_clinicians_email")
    safe_create_index(actual_db[TBL_CLINICIANS], [("last_name", 1), ("first_name", 1)], name="ix_clinicians_nombre")
    safe_create_index(actual_db[TBL_CLINICIANS], "clinic_id", name="ix_clinicians_clinica")
    safe_create_index(actual_db[TBL_CLINICIANS], "clinic_ids", name="ix_clinicians_clinic_ids")
    
    # Invitations
    safe_create_index(actual_db["invitations"], "token_hash", unique=True, name="ux_invites_token_hash")
    safe_create_index(actual_db["invitations"], "email_norm", name="ix_invites_email_norm")
    safe_create_index(actual_db["invitations"], "expires_at", name="ix_invites_expires")
    safe_create_index(actual_db["invitations"], [("used", 1), ("expires_at", 1)], name="ix_invites_used_exp")
    
    # Patients
    safe_create_index(actual_db[TBL_PATIENTS], "phone", unique=True, sparse=True, name="ux_patients_phone")
    safe_create_index(actual_db[TBL_PATIENTS], [(KEY_CARE_CLINICIAN_ID, 1), (KEY_STATE, 1)], name="ix_patients_clinician_status")
    safe_create_index(actual_db[TBL_PATIENTS], "patient_id", unique=True, sparse=True, name="ux_patients_patient_id")
    safe_create_index(actual_db[TBL_PATIENTS], "ids.external_id", name="ix_patients_rut")
    
    # Patient Health Profiles
    safe_create_index(actual_db[TBL_PATIENT_HEALTH_PROFILES], "patient_id", unique=True, name="ux_health_profile_patient")
    safe_create_index(actual_db[TBL_PATIENT_HEALTH_PROFILES], "created_at", name="ix_health_profile_created")

    # Case History
    safe_create_index(actual_db[TBL_CASE_HISTORY], "case_id", unique=True, name="ux_case_history_case")
    safe_create_index(actual_db[TBL_CASE_HISTORY], "patient_id", name="ix_case_history_patient")
    safe_create_index(actual_db[TBL_CASE_HISTORY], [("status_current.est_act_nom", 1), ("status_current.est_act_ini", 1)], name="ix_case_hist_status_current")
    safe_create_index(actual_db[TBL_CASE_HISTORY], [("status_historical.est_hist_nom", 1), ("status_historical.est_hist_ini", 1), ("status_historical.est_hist_fin", 1)], name="ix_case_hist_status_hist")
    
    # Catálogo de ejercicios
    safe_create_index(actual_db["exercises_catalog"], "eje_cod", unique=True, name="ux_eje_cod")
    safe_create_index(actual_db["exercises_catalog"], "eje_nom", unique=True, name="ux_eje_nom")
    safe_create_index(actual_db["exercises_catalog"], "tags", name="ix_eje_tags")
    safe_create_index(actual_db["exercises_catalog"], [("eje_nom", "text")], name="tx_eje_nom")

    # Definiciones de KineIA (angle rules), una por eje_cod -- GLOBAL
    # (central_db), no por tenant: NO usar actual_db aca.
    safe_create_index(central_db[TBL_KINEIA_EXERCISE_DEFINITIONS], "eje_cod", unique=True, name="ux_kineia_def_eje_cod")
    safe_create_index(central_db[TBL_KINEIA_EXERCISE_DEFINITIONS], "status", name="ix_kineia_def_status")

    # Scores de sesiones guiadas KineIA subidos desde la app
    safe_create_index(actual_db[TBL_KINEIA_SESSION_SCORES], "patient_id", name="ix_kineia_score_patient")
    safe_create_index(actual_db[TBL_KINEIA_SESSION_SCORES], [("patient_id", 1), ("exercise_id", 1), ("recorded_at", 1)], unique=True, name="ux_kineia_score_patient_exercise_recorded")

    # Consents & Push Tokens
    safe_create_index(actual_db[TBL_CONSENTS], [("paciente_id", 1), (KEY_STATE, 1)], name="ix_consent_paciente_estado")
    safe_create_index(actual_db["push_tokens"], [("user_id", 1), ("fcm_token", 1)], unique=True, name="ux_push_tokens_user_fcm")
    safe_create_index(actual_db["push_tokens"], "user_id", name="ix_push_tokens_user_id")
    safe_create_index(actual_db["push_tokens"], "is_active", name="ix_push_tokens_active")
    safe_create_index(actual_db["push_tokens"], "updated_at", name="ix_push_tokens_updated")

    # TM3-like Clinical Data Models
    safe_create_index(actual_db["cases"], "patient_id", name="ix_cases_patient")
    safe_create_index(actual_db["cases"], "status", name="ix_cases_status")
    safe_create_index(actual_db["cases"], "external_ids.tm3", name="ix_cases_external_tm3")
    safe_create_index(actual_db["appointments"], "patient_id", name="ix_appointments_patient")
    safe_create_index(actual_db["appointments"], "provider_id", name="ix_appointments_provider")
    safe_create_index(actual_db["appointments"], "case_id", name="ix_appointments_case")
    safe_create_index(actual_db["appointments"], [("start_time", 1), ("end_time", 1)], name="ix_appointments_time")
    safe_create_index(actual_db["clinical_notes"], "patient_id", name="ix_notes_patient")
    safe_create_index(actual_db["clinical_notes"], "case_id", name="ix_notes_case")
    safe_create_index(actual_db["clinical_notes"], "appointment_id", name="ix_notes_appointment")
    safe_create_index(actual_db["alerts"], "patient_id", name="ix_alerts_patient")
    safe_create_index(actual_db["alerts"], "alert_type", name="ix_alerts_type")
    safe_create_index(actual_db["alerts"], "read_at", name="ix_alerts_read")
    safe_create_index(actual_db["alerts"], "action_taken", name="ix_alerts_action")
    safe_create_index(actual_db["alerts"], "created_at", name="ix_alerts_created")
    safe_create_index(actual_db[TBL_MAP_STRUCTINTEG], "user_id", name="ix_painmap_sessions_user")
    safe_create_index(actual_db[TBL_MAP_STRUCTINTEG], "session_id", name="ix_painmap_sessions_sid")
    safe_create_index(actual_db[TBL_MAP_STRUCTINTEG], "timestamp", name="ix_painmap_sessions_ts")

    # Check-ins scoped by pain session ("program") — supports session_id
    # stamping at ingest and session-filtered pain/stiffness/PSFS series.
    safe_create_index(actual_db[TBL_CHECKINS], [("user_id", 1), ("session_id", 1), ("timestamp", 1)], name="ix_checkins_user_session_ts")

    # Sync Phase 2 Collections
    safe_create_index(actual_db[TBL_PATIENT_COMMITMENTS], "patient_id", unique=True, name="ux_commitments_patient")
    safe_create_index(actual_db[TBL_PATIENT_GOALS], "patient_id", unique=True, name="ux_goals_patient")
    safe_create_index(actual_db[TBL_SCHEDULED_EXERCISES], "patient_id", name="ix_sched_exec_patient")

    # Sync Phase 3 Collections
    safe_create_index(actual_db[TBL_PATIENT_ROUTINES], "patient_id", name="ix_routines_patient")
    safe_create_index(actual_db[TBL_PATIENT_WORKOUT_LOGS], "patient_id", name="ix_workout_logs_patient")
    safe_create_index(actual_db[TBL_PATIENT_CUSTOM_EXERCISES], "patient_id", name="ix_custom_exec_patient")

    # Wearable workouts (captura fuera del check-in). Índice único = idempotencia.
    safe_create_index(actual_db[TBL_PATIENT_WEARABLE_WORKOUTS], [("patient_id", 1), ("workout_id", 1)], unique=True, name="ux_wearable_workouts_patient_workout")
    safe_create_index(actual_db[TBL_PATIENT_WEARABLE_WORKOUTS], [("patient_id", 1), ("start_at", -1)], name="ix_wearable_workouts_patient_start")

    # Audit Logs
    safe_create_index(actual_db[TBL_COMMUNICATIONS], "recipient", name="ix_comms_recipient")
    safe_create_index(actual_db[TBL_COMMUNICATIONS], "created_at", name="ix_comms_created")

    # Clinical Programs
    safe_create_index(actual_db[TBL_CLINICAL_PROGRAMS], "patient_id", name="ix_clinic_prog_pat")
    safe_create_index(actual_db[TBL_CLINICAL_PROGRAMS], "clinician_id", name="ix_clinic_prog_clin")
    safe_create_index(actual_db[TBL_CLINICAL_PROGRAMS], "wibbi_program_id", name="ix_clinic_prog_wibbi")

    # Program Templates
    safe_create_index(actual_db[TBL_PROGRAM_TEMPLATES], "template_ids.wibbi", name="ix_prog_tpl_wibbi")
    safe_create_index(actual_db[TBL_PROGRAM_TEMPLATES], "clinician_id", name="ix_prog_tpl_clin")
    safe_create_index(actual_db[TBL_PROGRAM_TEMPLATES], "clinic_id", name="ix_prog_tpl_clinic")
    safe_create_index(actual_db[TBL_PROGRAM_TEMPLATES], "tags", name="ix_prog_tpl_tags")
    safe_create_index(actual_db[TBL_PROGRAM_TEMPLATES], [("name", "text")], name="tx_prog_tpl_name")

    # Patient Programs
    safe_create_index(actual_db[TBL_PATIENT_PROGRAMS], "patient_id", name="ix_patient_prog_pat")
    safe_create_index(actual_db[TBL_PATIENT_PROGRAMS], "template_id", name="ix_patient_prog_tpl")
    safe_create_index(actual_db[TBL_PATIENT_PROGRAMS], [("patient_id", 1), ("active_until", 1)], name="ix_patient_prog_active")

    # Reports Config
    safe_create_index(actual_db[TBL_REPORTS_CONFIG], "id", unique=True, name="ux_reports_config_id")

    # --- Índices de las consultas de wearables/evolución sobre `metrics` ---
    # `metrics` (datos crudos de wearables) no tenía NINGÚN índice: get_sleep_window,
    # get_heart_rate_window, get_steps_window (app/queries/patient_evolution.py) y
    # _build_evolution_score_trace (patient_trace.py) filtran por uno de estos tres
    # identificadores + rango de from_ts, con un $or de tres ramas -- cada rama
    # necesita su propio índice para no caer en full scan. Mismo patrón sin índice
    # en exercises_patient (get_exercises_ts_in_range).
    safe_create_index(actual_db[TBL_METRICS], [("patient_id", 1), ("from_ts", 1)], name="ix_metrics_patient_from_ts")
    safe_create_index(actual_db[TBL_METRICS], [("meta.paciente_id", 1), ("from_ts", 1)], name="ix_metrics_meta_paciente_from_ts")
    safe_create_index(actual_db[TBL_METRICS], [("meta.patient_id", 1), ("from_ts", 1)], name="ix_metrics_meta_patient_from_ts")
    # Cuarta rama del mismo $or (legacy field "sen.paciente_id"), usada en
    # get_heart_rate_window/get_steps_window/get_sleep_window, recovery_score_calculator.py
    # y metrics.py -- estaba sin índice, forzando full scan cada vez que esa rama del $or
    # se evaluaba. Encontrado investigando 504s reales en dev en /metric-graph/.../lifestyle
    # y /recovery-score (upstream timed out, 60s+).
    safe_create_index(actual_db[TBL_METRICS], [("sen.paciente_id", 1), ("from_ts", 1)], name="ix_metrics_sen_paciente_from_ts")
    safe_create_index(actual_db[TBL_EXERCISES_PATIENT], [("patient_id", 1), ("ts", 1)], name="ix_exercises_patient_ts")

    # Patient Metrics Daily & Weekly
    safe_create_index(actual_db[TBL_PATIENT_METRICS_DAILY], [("patient_id", 1), ("date", 1)], unique=True, name="ux_patient_metrics_daily")
    safe_create_index(actual_db[TBL_PATIENT_METRICS_WEEKLY], [("patient_id", 1), ("week_key", 1)], unique=True, name="ux_patient_metrics_weekly")
    safe_create_index(actual_db[TBL_PATIENT_METRICS_TRACE_LOG], [("patient_id", 1), ("timestamp", -1)], name="ix_patient_metrics_trace_log")






def users_collection():
    return _tenant_db.get()[TBL_USERS]

def users_session_collection():
    return _tenant_db.get()[TBL_USERS_SESSION]

def clinician_collection():
    return _tenant_db.get()[TBL_CLINICIANS]

def clinics_collection():
    return _tenant_db.get()[TBL_CLINICS]

def invitations_collection():
    return _tenant_db.get()[TBL_INVITATIONS]

def patients_collection():
    return _tenant_db.get()[TBL_PATIENTS]

def metrics_collection():
    return _tenant_db.get()[TBL_METRICS]

def case_history_collection():
    return _tenant_db.get()[TBL_CASE_HISTORY]

def patient_health_profiles_collection():
    return _tenant_db.get()[TBL_PATIENT_HEALTH_PROFILES]

def exercises_catalog_collection():
    return _tenant_db.get()[TBL_EXERCISES_CATALOG]

def kineia_exercise_definitions_collection():
    # GLOBAL desde 2026-08 (ver comentario en TBL_KINEIA_EXERCISE_DEFINITIONS
    # mas arriba) -- deliberadamente central_db, no _tenant_db.get().
    return central_db[TBL_KINEIA_EXERCISE_DEFINITIONS]

def kineia_session_scores_collection():
    return _tenant_db.get()[TBL_KINEIA_SESSION_SCORES]

def diagnostic_code_collection():
    return _tenant_db.get()[TBL_DIAGNOSTIC_CODES]

def patient_exercises_collection():
    return _tenant_db.get()[TBL_EXERCISES_PATIENT]

def checkins_collection():
    return _tenant_db.get()[TBL_CHECKINS]

def engagement_snapshots_collection():
    return _tenant_db.get()[TBL_ENGAGEMENT_SNAPSHOTS]

def reports_config_collection():
    return _tenant_db.get()[TBL_REPORTS_CONFIG]

def patient_metrics_daily_collection():
    return _tenant_db.get()[TBL_PATIENT_METRICS_DAILY]

def patient_metrics_weekly_collection():
    return _tenant_db.get()[TBL_PATIENT_METRICS_WEEKLY]

def patient_metrics_trace_log_collection():
    return _tenant_db.get()[TBL_PATIENT_METRICS_TRACE_LOG]




def specialities_catalog_collection():
    return _tenant_db.get()[TBL_SPECIALITIES_CATALOG]

def surveys_collection():
    return _tenant_db.get()[TBL_SURVEYS]

def intakes_collection():
    return _tenant_db.get()[TBL_INTAKES]

def legal_docs_collection():
    return _tenant_db.get()[TBL_LEGAL_DOCS]

def body_pain_map_collection():
    return _tenant_db.get()[TBL_MAP_STRUCTINTEG]

def consents_collection():
    return _tenant_db.get()[TBL_CONSENTS]

def push_tokens_collection():
    return _tenant_db.get()[TBL_PUSH_TOKENS]

def cases_collection():
    return _tenant_db.get()[TBL_CASES]

def appointments_collection():
    return _tenant_db.get()[TBL_APPOINTMENTS]

def clinical_notes_collection():
    return _tenant_db.get()[TBL_CLINICAL_NOTES]

def clinical_recording_sessions_collection():
    return _tenant_db.get()[TBL_CLINICAL_RECORDING_SESSIONS]

def alerts_collection():
    return _tenant_db.get()[TBL_ALERTS]

def map_structinteg_collection():
    return _tenant_db.get()[TBL_MAP_STRUCTINTEG]

def activities_catalog_collection():
    return _tenant_db.get()[TBL_ACTIVITIES_CATALOG]

def patient_commitments_collection():
    return _tenant_db.get()[TBL_PATIENT_COMMITMENTS]

def patient_goals_collection():
    return _tenant_db.get()[TBL_PATIENT_GOALS]

def scheduled_exercises_collection():
    return _tenant_db.get()[TBL_SCHEDULED_EXERCISES]

def patient_routines_collection():
    return _tenant_db.get()[TBL_PATIENT_ROUTINES]

def patient_workout_logs_collection():
    return _tenant_db.get()[TBL_PATIENT_WORKOUT_LOGS]

def patient_custom_exercises_collection():
    return _tenant_db.get()[TBL_PATIENT_CUSTOM_EXERCISES]

def patient_wearable_workouts_collection():
    return _tenant_db.get()[TBL_PATIENT_WEARABLE_WORKOUTS]

def communications_collection():
    return _tenant_db.get()[TBL_COMMUNICATIONS]

def clinical_programs_collection():
    return _tenant_db.get()[TBL_CLINICAL_PROGRAMS]

def program_templates_collection():
    return _tenant_db.get()[TBL_PROGRAM_TEMPLATES]

def patient_programs_collection():
    return _tenant_db.get()[TBL_PATIENT_PROGRAMS]


def tenants_registry_collection():
    return central_db[TBL_TENANTS]

def oauth2_clients_collection():
    return _tenant_db.get()[TBL_OAUTH2_CLIENTS]

def oauth2_codes_collection():
    return _tenant_db.get()[TBL_OAUTH2_CODES]


# Partner API. Identidad, vínculos y colas viven en central_db (son del fabricante,
# no de una clínica); los datos de salud van a la base del tenant del paciente.
TBL_PARTNER_DEVELOPERS = "partner_developers"
TBL_PARTNER_EMAIL_VERIFICATIONS = "partner_email_verifications"
TBL_PARTNER_APPS = "partner_apps"
TBL_PARTNER_PROMOTION_REQUESTS = "partner_promotion_requests"
TBL_PARTNER_DEVICE_MODELS = "partner_device_models"
TBL_PAIRING_CODES = "pairing_codes"
TBL_PARTNER_LINKS = "partner_links"
TBL_INGEST_JOBS = "ingest_jobs"
TBL_PARTNER_INGEST_PAYLOADS = "partner_ingest_payloads"
TBL_WEBHOOK_SUBSCRIPTIONS = "webhook_subscriptions"
TBL_WEBHOOK_DELIVERIES = "webhook_deliveries"
TBL_PARTNER_AUDIT_LOG = "partner_audit_log"
TBL_PARTNER_IDEMPOTENCY = "partner_idempotency_keys"
TBL_PARTNER_DELETION_REQUESTS = "partner_deletion_requests"
TBL_PARTNER_SANDBOX_PATIENTS = "partner_sandbox_patients"
TBL_MSK_MEASUREMENTS = "msk_measurements"
TBL_DEVICE_EVENTS = "device_events"

PARTNER_CENTRAL_TABLES = (
    TBL_PARTNER_DEVELOPERS, TBL_PARTNER_EMAIL_VERIFICATIONS, TBL_PARTNER_APPS,
    TBL_PARTNER_PROMOTION_REQUESTS, TBL_PARTNER_DEVICE_MODELS, TBL_PAIRING_CODES,
    TBL_PARTNER_LINKS, TBL_INGEST_JOBS, TBL_PARTNER_INGEST_PAYLOADS, TBL_WEBHOOK_SUBSCRIPTIONS,
    TBL_WEBHOOK_DELIVERIES, TBL_PARTNER_AUDIT_LOG, TBL_PARTNER_IDEMPOTENCY,
    TBL_PARTNER_DELETION_REQUESTS, TBL_PARTNER_SANDBOX_PATIENTS,
)


def partner_collection(name: str):
    if name not in PARTNER_CENTRAL_TABLES:
        raise ValueError(f"colección partner desconocida: {name}")
    return central_db[name]


def ensure_partner_indexes(central=None):
    c = central if central is not None else central_db
    safe_create_index(c[TBL_PARTNER_DEVELOPERS], "developer_id", unique=True, name="ux_pdev_id")
    safe_create_index(c[TBL_PARTNER_DEVELOPERS], "contact_email_norm", unique=True, name="ux_pdev_email")
    safe_create_index(c[TBL_PARTNER_EMAIL_VERIFICATIONS], "token_hash", unique=True, name="ux_pver_token")
    safe_create_index(c[TBL_PARTNER_EMAIL_VERIFICATIONS], "expires_at", expireAfterSeconds=0, name="ttl_pver_exp")
    safe_create_index(c[TBL_PARTNER_APPS], "app_id", unique=True, name="ux_papp_id")
    safe_create_index(c[TBL_PARTNER_APPS], "client_id", unique=True, name="ux_papp_client")
    safe_create_index(c[TBL_PARTNER_APPS], "developer_id", name="ix_papp_dev")
    safe_create_index(c[TBL_PARTNER_PROMOTION_REQUESTS], "request_id", unique=True, name="ux_ppromo_id")
    safe_create_index(c[TBL_PARTNER_PROMOTION_REQUESTS], [("status", 1), ("created_at", 1)], name="ix_ppromo_status")
    safe_create_index(c[TBL_PARTNER_DEVICE_MODELS], [("app_id", 1), ("model_code", 1)], unique=True, name="ux_pdm_app_model")
    safe_create_index(c[TBL_PAIRING_CODES], "code_hash", unique=True, name="ux_pair_hash")
    safe_create_index(c[TBL_PAIRING_CODES], "expires_at", expireAfterSeconds=0, name="ttl_pair_exp")
    safe_create_index(c[TBL_PARTNER_LINKS], "link_id", unique=True, name="ux_plink_id")
    safe_create_index(c[TBL_PARTNER_LINKS], [("app_id", 1), ("external_user_id", 1), ("status", 1)], name="ix_plink_app_ext")
    safe_create_index(c[TBL_PARTNER_LINKS], "active_key", unique=True, sparse=True, name="ux_plink_active")
    safe_create_index(c[TBL_PARTNER_LINKS], [("app_id", 1), ("link_id", 1)], name="ix_plink_app_cursor")
    safe_create_index(c[TBL_PARTNER_LINKS], [("tenant_db", 1), ("patient_id", 1)], name="ix_plink_patient")
    safe_create_index(c[TBL_INGEST_JOBS], "job_id", unique=True, name="ux_ijob_id")
    safe_create_index(c[TBL_INGEST_JOBS], [("app_id", 1), ("received_at", -1)], name="ix_ijob_app")
    safe_create_index(c[TBL_INGEST_JOBS], [("status", 1), ("lease_until", 1)], name="ix_ijob_status")
    safe_create_index(c[TBL_PARTNER_INGEST_PAYLOADS], "job_id", unique=True, name="ux_ipay_job")
    safe_create_index(c[TBL_PARTNER_INGEST_PAYLOADS], "expires_at", expireAfterSeconds=0, name="ttl_ipay_exp")
    safe_create_index(c[TBL_WEBHOOK_SUBSCRIPTIONS], "webhook_id", unique=True, name="ux_whs_id")
    safe_create_index(c[TBL_WEBHOOK_SUBSCRIPTIONS], [("app_id", 1), ("status", 1)], name="ix_whs_app")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], "delivery_id", unique=True, name="ux_whd_id")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], [("webhook_id", 1), ("created_at", -1)], name="ix_whd_webhook")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], [("status", 1), ("next_retry_at", 1)], name="ix_whd_due")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], "expires_at", expireAfterSeconds=0, name="ttl_whd_30d")
    safe_create_index(c[TBL_PARTNER_AUDIT_LOG], [("app_id", 1), ("ts", -1)], name="ix_paudit_app_ts")
    safe_create_index(c[TBL_PARTNER_AUDIT_LOG], "ts", expireAfterSeconds=365 * 86400, name="ttl_paudit_12m")
    safe_create_index(c[TBL_PARTNER_IDEMPOTENCY], [("app_id", 1), ("key", 1)], unique=True, name="ux_pidem_app_key")
    safe_create_index(c[TBL_PARTNER_IDEMPOTENCY], "created_at", expireAfterSeconds=86400, name="ttl_pidem_24h")
    safe_create_index(c[TBL_PARTNER_DELETION_REQUESTS], "request_id", unique=True, name="ux_pdel_id")
    safe_create_index(c[TBL_PARTNER_DELETION_REQUESTS], [("status", 1), ("next_attempt_at", 1)], name="ix_pdel_due")
    safe_create_index(c[TBL_PARTNER_SANDBOX_PATIENTS], "patient_id", unique=True, name="ux_psbx_patient")


def ensure_partner_tenant_indexes(target_db):
    # el filtro parcial deja fuera los documentos legados de metrics, que no traen link_id
    only_partner = {"partialFilterExpression": {"link_id": {"$exists": True}}}
    safe_create_index(target_db[TBL_METRICS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_metrics_link_record", **only_partner)
    safe_create_index(target_db[TBL_METRICS], [("link_id", 1), ("metric_date", 1)], name="ix_metrics_link_date", **only_partner)
    safe_create_index(target_db[TBL_PATIENT_WEARABLE_WORKOUTS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_wearable_workouts_link_record", **only_partner)
    safe_create_index(target_db[TBL_MSK_MEASUREMENTS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_msk_link_record")
    safe_create_index(target_db[TBL_MSK_MEASUREMENTS], [("patient_id", 1), ("timestamp", 1)], name="ix_msk_patient_ts")
    safe_create_index(target_db[TBL_MSK_MEASUREMENTS], "body_region", name="ix_msk_body_region")
    safe_create_index(target_db[TBL_DEVICE_EVENTS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_devev_link_record")
    safe_create_index(target_db[TBL_DEVICE_EVENTS], [("patient_id", 1), ("timestamp", 1)], name="ix_devev_patient_ts")
    safe_create_index(target_db[TBL_DEVICE_EVENTS], [("link_id", 1), ("timestamp", -1)], name="ix_devev_link_ts")
