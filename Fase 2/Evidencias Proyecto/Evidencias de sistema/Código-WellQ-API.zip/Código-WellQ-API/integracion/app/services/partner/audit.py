from datetime import datetime, timezone

from fastapi import Request

from app.repositories import partner as repo


def client_ip(request: Request) -> str:
    # detrás de nginx la IP real llega en X-Real-IP; X-Forwarded-For puede venir falseado por el cliente
    real = request.headers.get("x-real-ip")
    if real and len(real) <= 45:
        return real
    return request.client.host if request.client else ""


def record_call(request: Request, path_template: str, status: int, trace_id: str, size: int,
                ctx: dict, duration_ms: int) -> None:
    repo.append_audit({
        "ts": datetime.now(timezone.utc),
        "actor": ctx.get("actor", "partner" if ctx.get("app_id") else "anonymous"),
        "app_id": ctx.get("app_id"),
        "developer_id": ctx.get("developer_id"),
        "link_id": ctx.get("link_id") or request.path_params.get("link_id"),
        "method": request.method,
        "path": path_template,
        "status": status,
        "ip": client_ip(request),
        "user_agent": (request.headers.get("user-agent") or "")[:200],
        "trace_id": trace_id,
        "bytes": size,
        "duration_ms": duration_ms,
        "event": ctx.get("event"),
        "scope": ctx.get("audit_scope"),
    })


def record_event(event: str, trace_id: str | None = None, **fields) -> None:
    repo.append_audit({"ts": datetime.now(timezone.utc), "event": event, "trace_id": trace_id,
                       "actor": fields.pop("actor", "system"), **fields})
