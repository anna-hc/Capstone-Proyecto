from datetime import timezone
from typing import Optional

from bson import ObjectId
from fastapi import Depends, Header, Request

import app.config as conf
from app.repositories import partner as repo
from app.services.partner import ratelimit
from app.services.partner.audit import client_ip
from app.services.partner.problems import PartnerProblem, add_response_headers, set_audit
from app.services.partner.security import ACCESS_AUDIENCE, PORTAL_AUDIENCE, decode_token
import app.db as dbmod
from app.services.partner.tenancy import SANDBOX_TENANT, sandbox_db


def _bearer(authorization: Optional[str]) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise PartnerProblem(401, slug="unauthorized", detail="Falta el token Bearer",
                             headers={"WWW-Authenticate": "Bearer"})
    return authorization.split(" ", 1)[1].strip()


def _as_utc(value):
    if value is not None and value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def public_rate_limit(bucket: str, per_minute: Optional[int] = None):
    def dependency(request: Request) -> None:
        headers = ratelimit.enforce(f"pub:{bucket}:{client_ip(request)}", per_minute or conf.PARTNER_PUBLIC_RPM_PER_IP)
        add_response_headers(headers)
    return dependency


def current_partner_app(authorization: Optional[str] = Header(None)) -> dict:
    payload = decode_token(_bearer(authorization), ACCESS_AUDIENCE, "partner_access")
    if not payload:
        raise PartnerProblem(401, slug="invalid-token", detail="Token inválido o expirado",
                             headers={"WWW-Authenticate": 'Bearer error="invalid_token"'})
    app_doc = repo.apps().find_one({"app_id": payload["app_id"]}, {"_id": 0})
    if not app_doc or app_doc.get("client_id") != payload["sub"]:
        raise PartnerProblem(401, slug="invalid-token", detail="Token inválido o expirado")
    # token_generation sube al revocar (rotación sin gracia, promoción, suspensión) e invalida los tokens anteriores
    if app_doc.get("environment") != payload.get("env") or payload.get("gen") != int(app_doc.get("token_generation", 0)):
        raise PartnerProblem(401, slug="invalid-token", detail="Token revocado")
    if app_doc.get("status") != "active":
        raise PartnerProblem(403, slug="app-inactive", detail="La app no está activa")
    limit = int((app_doc.get("rate_limit") or {}).get("requests_per_minute") or conf.PARTNER_DEFAULT_RPM)
    add_response_headers(ratelimit.enforce(f"app:{app_doc['app_id']}", limit))
    app_doc["_scopes"] = set(payload.get("scope", "").split())
    set_audit(app_id=app_doc["app_id"], developer_id=app_doc.get("developer_id"), actor="partner")
    return app_doc


def require_scopes(*any_of: str):
    def dependency(app_doc: dict = Depends(current_partner_app)) -> dict:
        if not app_doc["_scopes"].intersection(any_of):
            raise PartnerProblem(403, slug="insufficient-scope", title="Insufficient scope",
                                 detail=f"El token no incluye ninguno de: {' '.join(any_of)}",
                                 required_scope=" ".join(any_of))
        return app_doc
    return dependency


def portal_developer(authorization: Optional[str] = Header(None)) -> dict:
    payload = decode_token(_bearer(authorization), PORTAL_AUDIENCE, "partner_portal")
    if not payload:
        raise PartnerProblem(401, slug="invalid-token", detail="Portal token inválido o expirado")
    developer = repo.developers().find_one({"developer_id": payload["sub"]}, {"_id": 0})
    if not developer or developer.get("status") != "verified":
        raise PartnerProblem(403, slug="developer-not-verified", detail="Cuenta de desarrollador no verificada")
    add_response_headers(ratelimit.enforce(f"portal:{developer['developer_id']}", conf.PARTNER_DEFAULT_RPM))
    set_audit(developer_id=developer["developer_id"], actor="developer")
    return developer


def owned_app(app_id: str, developer: dict) -> dict:
    app_doc = repo.apps().find_one({"app_id": app_id, "developer_id": developer["developer_id"]}, {"_id": 0})
    if not app_doc:
        raise PartnerProblem(404, detail="App no encontrada")
    set_audit(app_id=app_id)
    return app_doc


def portal_or_partner_app(app_id: str, authorization: Optional[str] = Header(None)) -> dict:
    token = _bearer(authorization)
    portal = decode_token(token, PORTAL_AUDIENCE, "partner_portal")
    if portal:
        return owned_app(app_id, portal_developer(authorization))
    app_doc = current_partner_app(authorization)
    if app_doc["app_id"] != app_id:
        raise PartnerProblem(404, detail="App no encontrada")
    return app_doc


def _jwt_payload(authorization: Optional[str]) -> dict:
    from app.security import decode_jwt
    payload, ok = decode_jwt(_bearer(authorization))
    if not ok:
        raise PartnerProblem(401, slug="invalid-token", detail="Token inválido o expirado")
    roles = payload.get("roles") or ((payload.get("resource_access") or {}).get("wellq-app") or {}).get("roles") or []
    payload["roles"] = roles
    return payload


def current_patient(request: Request, authorization: Optional[str] = Header(None)) -> dict:
    payload = _jwt_payload(authorization)
    if "patient" not in payload["roles"] or payload.get("type", "access") != "access":
        raise PartnerProblem(403, detail="Se requiere sesión de paciente")
    if payload.get("scope") and payload["scope"] != "mobile":
        raise PartnerProblem(403, detail="Token de paciente no válido para esta operación")
    slug = payload.get("tenant_slug")
    if slug == SANDBOX_TENANT:
        tdb = sandbox_db()
    else:
        # el slug del token manda: una cabecera x-tenant distinta no puede llevar al paciente a otra clínica
        resolved = getattr(request.state, "tenant_slug", None)
        if slug and slug != resolved:
            raise PartnerProblem(403, slug="tenant-mismatch", detail="El tenant del token no coincide")
        tdb = dbmod._tenant_db.get()
        slug = slug or resolved
    try:
        poid = ObjectId(payload.get("sub"))
    except Exception:
        raise PartnerProblem(401, slug="invalid-token", detail="Token de paciente inválido") from None
    patient = repo.tenant_collection(tdb, "patients").find_one(
        {"_id": poid}, {"_id": 1, "patient_id": 1, "ids.patient_id": 1, "state": 1})
    if not patient or patient.get("state") == "inactive":
        raise PartnerProblem(401, detail="Paciente no encontrado")
    patient_id = patient.get("patient_id") or (patient.get("ids") or {}).get("patient_id") or str(poid)
    set_audit(actor="patient")
    return {"oid": poid, "patient_id": patient_id, "tenant_slug": slug, "tenant_db": tdb.name, "db": tdb,
            "sandbox": slug == SANDBOX_TENANT}


def current_staff(*roles: str):
    def dependency(authorization: Optional[str] = Header(None)) -> dict:
        payload = _jwt_payload(authorization)
        normalized = {"clinadmin" if r == "admin" else r for r in payload["roles"]}
        if not normalized.intersection(roles):
            raise PartnerProblem(403, detail="Operación no permitida")
        set_audit(actor="staff")
        payload["_authorization"] = authorization
        return payload
    return dependency


def clinician_patient(request: Request, patient_id: str, authorization: Optional[str] = Header(None),
                      staff: dict = Depends(current_staff("clinician", "clinadmin", "itadmin"))) -> dict:
    from app.db import KEY_CARE_CLINICIAN_ID, KEY_STATE
    from app.utils.authaa_utils import get_clinician_oid_from_token
    clinician_oid = get_clinician_oid_from_token(authorization)
    slug = staff.get("tenant_slug")
    if slug == SANDBOX_TENANT:
        tdb = sandbox_db()
    else:
        resolved = getattr(request.state, "tenant_slug", None)
        if slug and slug != resolved:
            raise PartnerProblem(403, slug="tenant-mismatch", detail="El tenant del token no coincide")
        tdb = dbmod._tenant_db.get()
        slug = slug or resolved
    ident = {"_id": ObjectId(patient_id)} if ObjectId.is_valid(patient_id) and len(patient_id) == 24 else \
        {"$or": [{"patient_id": patient_id}, {"ids.patient_id": patient_id}]}
    # mismo criterio que maindash: solo pacientes asignados o con acceso explícito del clínico
    crit = {"$and": [ident, {"$or": [{KEY_CARE_CLINICIAN_ID: clinician_oid}, {"authorized_clinicians": clinician_oid}]},
                     {KEY_STATE: {"$ne": "inactive"}}]}
    patient = repo.tenant_collection(tdb, "patients").find_one(crit, {"_id": 1, "patient_id": 1, "ids.patient_id": 1})
    if not patient:
        raise PartnerProblem(404, detail="Paciente no encontrado")
    pid = patient.get("patient_id") or (patient.get("ids") or {}).get("patient_id") or str(patient["_id"])
    return {"oid": patient["_id"], "patient_id": pid, "tenant_slug": slug, "tenant_db": tdb.name, "db": tdb,
            "sandbox": slug == SANDBOX_TENANT}


def dev_tools_enabled() -> bool:
    return conf.PARTNER_DEV_TOOLS_ENABLED and (conf.APP_ENV or "").lower() in conf.DEV_APP_ENVS


def demo_enabled() -> bool:
    return conf.PARTNER_DEMO_ENABLED and (conf.APP_ENV or "").lower() in conf.DEV_APP_ENVS
