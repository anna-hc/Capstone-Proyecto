import app.config as conf
import app.db as dbmod
from app.services.partner.problems import PartnerProblem

SANDBOX_TENANT = "partner-sandbox"
_db_cache: dict[str, object] = {}
_override = None


def use_tenant_resolver(fn) -> None:
    global _override
    _override = fn
    _db_cache.clear()


def sandbox_db():
    if _override is not None:
        return _override(SANDBOX_TENANT, conf.PARTNER_SANDBOX_DB)
    return dbmod._central_client[conf.PARTNER_SANDBOX_DB]


def tenant_db_for(tenant_slug: str | None, tenant_db_name: str):
    if _override is not None:
        return _override(tenant_slug, tenant_db_name)
    if tenant_slug == SANDBOX_TENANT:
        return sandbox_db()
    key = f"{tenant_slug}|{tenant_db_name}"
    if key in _db_cache:
        return _db_cache[key]
    from app.middleware.tenant_middleware import get_tenant_client, resolve_tenant_database
    from app.repositories import tenant_repo
    cfg = tenant_repo.get_by_mongo_db(tenant_db_name, active_only=True)
    if cfg:
        database = resolve_tenant_database(get_tenant_client(cfg), cfg["mongo_db"])
    elif tenant_db_name == conf.MONGO_DB:
        database = resolve_tenant_database(dbmod._client, tenant_db_name)
    else:
        raise PartnerProblem(409, slug="tenant-unavailable", detail="El tenant del vínculo no está activo")
    _db_cache[key] = database
    return database


def link_db(link: dict):
    return tenant_db_for(link.get("tenant_slug"), link["tenant_db"])
