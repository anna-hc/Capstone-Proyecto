from datetime import date, timedelta
from statistics import mean, pstdev

ACTIVE_MINUTES_REFERENCE = 30
FULL_WEAR_MINUTES = 1380


def _clamp(v: float) -> int:
    return max(0, min(100, int(round(v))))


def pick_daily(day: str, summaries: list[dict]) -> dict | None:
    # varias fuentes el mismo día: gana la de mayor source_quality (final y más horas de uso)
    todays = [s for s in summaries if s.get("metric_date") == day]
    if not todays:
        return None
    todays.sort(key=lambda s: (s.get("source_quality") or 0, s.get("completeness") == "final"), reverse=True)
    return todays[0].get("partner_summary") or {}


def _sleep_hours_score(hours: float) -> float:
    if 7.0 <= hours <= 9.0:
        return 100
    if 6.0 <= hours < 7.0 or 9.0 < hours <= 10.0:
        return 70
    return 40


def sleep_score(summary: dict | None) -> int | None:
    if not summary or summary.get("sleep_total_minutes") is None:
        return None
    score = _sleep_hours_score(summary["sleep_total_minutes"] / 60.0)
    efficiency = summary.get("sleep_efficiency_pct")
    if efficiency is not None:
        score *= 0.9 + 0.1 * min(efficiency / 85.0, 1.0)
    return _clamp(score)


def activity_score(summary: dict | None, steps_target: int) -> int | None:
    if not summary or (summary.get("steps") is None and summary.get("active_minutes") is None):
        return None
    active = 100 * min((summary.get("active_minutes") or 0) / ACTIVE_MINUTES_REFERENCE, 1.0)
    if summary.get("steps") is None:
        return _clamp(active)
    steps = 100 * min(summary["steps"] / max(steps_target, 1), 1.0)
    return _clamp(0.7 * steps + 0.3 * active)


def adherence_score(summary: dict | None, sessions_today: int, weekly_target: int | None,
                    wear_status: str) -> int | None:
    if wear_status == "not_worn" and not sessions_today:
        return None
    target = weekly_target if weekly_target is not None else 3
    exercise = 100.0 if target <= 0 else 100 * min(sessions_today / (target / 7.0), 1.0)
    if summary and summary.get("wear_time_minutes") is not None:
        wear = 100 * min(summary["wear_time_minutes"] / FULL_WEAR_MINUTES, 1.0)
    elif summary is not None or wear_status == "worn":
        wear = 100.0
    else:
        return None
    return _clamp(0.6 * exercise + 0.4 * wear)


def stability_score(summaries: list[dict], day: str, window_days: int = 7) -> int | None:
    days = sorted({s["metric_date"] for s in summaries if s.get("metric_date", "") <= day})[-window_days:]
    rhrs, hrvs = [], []
    for d in days:
        s = pick_daily(d, summaries) or {}
        if s.get("resting_heart_rate_bpm") is not None:
            rhrs.append(s["resting_heart_rate_bpm"])
        if s.get("hrv_rmssd_ms") is not None:
            hrvs.append(s["hrv_rmssd_ms"])
    if len(rhrs) < 2:
        return None
    stability = 100 * max(0.0, 1 - (pstdev(rhrs) / mean(rhrs)) / 0.15)
    if len(hrvs) >= 2:
        stability = 0.5 * stability + 50 * max(0.0, 1 - (pstdev(hrvs) / mean(hrvs)) / 0.30)
    return _clamp(stability)


def wear_status_for_day(day: str, events: list[dict], has_summary: bool) -> str:
    start = date.fromisoformat(day)
    end = start + timedelta(days=1)
    worn_flags = []
    before = None
    for ev in sorted(events, key=lambda e: e["timestamp"]):
        ts = ev["timestamp"].date() if hasattr(ev["timestamp"], "date") else date.fromisoformat(str(ev["timestamp"])[:10])
        if ev["event_type"] not in ("worn", "removed"):
            continue
        if ts < start:
            before = ev["event_type"]
        elif start <= ts < end:
            worn_flags.append(ev["event_type"])
    if "worn" in worn_flags:
        return "worn"
    if worn_flags or before == "removed":
        return "not_worn" if not has_summary else "worn"
    return "worn" if has_summary else ("unknown" if before is None else ("worn" if before == "worn" else "not_worn"))


def daily_scores(day: str, summaries: list[dict], workouts: list[dict], events: list[dict], goals: dict,
                 wanted: set[str], steps_target: int) -> dict:
    summary = pick_daily(day, summaries)
    sessions_today = sum(1 for w in workouts if str(w.get("start_at", ""))[:10] == day)
    wear = wear_status_for_day(day, events, summary is not None)
    out = {"local_date": day}
    if "activity" in wanted:
        out["activity"] = activity_score(summary, steps_target)
    if "sleep" in wanted:
        out["sleep"] = sleep_score(summary)
    if "adherence" in wanted:
        out["adherence"] = adherence_score(summary, sessions_today, goals.get("exercise_target_count_week"), wear)
    if "stability" in wanted:
        out["stability"] = stability_score(summaries, day)
    out["data_status"] = "ok" if summary is not None else ("not_worn" if wear == "not_worn" else "no_data")
    return out
