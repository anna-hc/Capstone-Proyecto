from datetime import datetime, timedelta, timezone

import app.db as dbmod
from app.logging_conf import get_logger
from app.repositories import partner as repo
from app.services.partner import catalog, webhooks
from app.services.partner.audit import record_event
from app.services.partner.problems import PartnerProblem, trace_id_var
from app.services.partner.tenancy import link_db

log = get_logger("PARTNER")
DELETION_RETRY = [60, 300, 1800, 3600, 6 * 3600, 24 * 3600]
LINK_PUBLIC_FIELDS = ("link_id", "status", "external_user_id", "device_id", "model_code", "timezone",
                      "granted_scopes", "consent", "created_at", "revoked_at", "revoked_by")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def public_link(link: dict) -> dict:
    out = {k: link.get(k) for k in LINK_PUBLIC_FIELDS}
    out["ingest_config"] = effective_config(link)
    return out


def effective_config(link: dict) -> dict:
    from app.services.partner.ingest import effective_intervals
    overrides = (link.get("ingest_config") or {}).get("intervals", {})
    intervals = effective_intervals(link)
    return {"intervals": [{"metric": m, "interval_seconds": s, "source": "wellq" if m in overrides else "device_model"}
                          for m, s in sorted(intervals.items())]}


def get_owned_link(app_doc: dict, link_id: str) -> dict:
    link = repo.links().find_one({"link_id": link_id, "app_id": app_doc["app_id"],
                                  "environment": app_doc.get("environment")}, {"_id": 0})
    if not link:
        raise PartnerProblem(404, detail="Vínculo no encontrado")
    return link


def require_active(link: dict) -> None:
    if link.get("status") != "active":
        raise PartnerProblem(403, slug="link-revoked", title="Link revoked",
                             detail="El vínculo no está activo", link_id=link["link_id"])


_indexed_dbs: set[str] = set()


def ensure_tenant_indexes(link: dict) -> None:
    # los índices únicos de idempotencia por registro deben existir antes de la primera ingesta en ese tenant
    try:
        tdb = link_db(link)
        if tdb.name not in _indexed_dbs:
            dbmod.ensure_partner_tenant_indexes(tdb)
            _indexed_dbs.add(tdb.name)
    except Exception as exc:
        log.error("[PARTNER][INDEXES][TENANT_FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})


def require_patient_active(link: dict) -> None:
    patient = repo.tenant_collection(link_db(link), dbmod.TBL_PATIENTS).find_one(
        {"patient_id": link["patient_id"]}, {"state": 1})
    if not patient or patient.get("state") == "inactive":
        raise PartnerProblem(403, slug="link-revoked", title="Link revoked",
                             detail="El paciente del vínculo ya no está activo", link_id=link["link_id"])


def revoke(link: dict, by: str, delete_data: bool, actor_detail: str | None = None) -> dict | None:
    now = _now()
    updated = repo.find_one_and_update(repo.links(), {"link_id": link["link_id"], "status": "active"},
                                       {"$set": {"status": "revoked", "revoked_at": now, "revoked_by": by},
                                        "$unset": {"active_key": ""}})
    request = None
    if updated:
        webhooks.dispatch(link["app_id"], "link.revoked", {
            "link_id": link["link_id"], "external_user_id": link["external_user_id"], "revoked_by": by,
            "delete_data_requested": delete_data})
        try:
            repo.tenant_collection(link_db(link), dbmod.TBL_PATIENTS).update_one(
                {"patient_id": link["patient_id"]}, {"$pull": {"wearable_links": link["link_id"]}})
        except PartnerProblem:
            pass
        record_event("link.revoked", trace_id_var.get() or None, actor=by, app_id=link["app_id"],
                     link_id=link["link_id"], delete_data=delete_data)
    if delete_data:
        request = request_deletion(link, by)
    return request


def request_deletion(link: dict, by: str) -> dict:
    existing = repo.deletion_requests().find_one({"link_id": link["link_id"], "status": {"$in": ["pending", "done"]}},
                                                 {"_id": 0})
    if existing:
        return existing
    from app.services.partner.security import new_id
    request = {"request_id": new_id("del"), "link_id": link["link_id"], "app_id": link["app_id"],
               "requested_by": by, "status": "pending", "attempts": 0, "requested_at": _now(),
               "next_attempt_at": _now(), "deleted": {}}
    repo.deletion_requests().insert_one(dict(request))
    webhooks.dispatch(link["app_id"], "patient.data_deletion_requested", {
        "link_id": link["link_id"], "external_user_id": link["external_user_id"], "request_id": request["request_id"]})
    record_event("patient.data_deletion_requested", trace_id_var.get() or None, actor=by, app_id=link["app_id"],
                 link_id=link["link_id"], request_id=request["request_id"])
    try:
        return run_deletion(request["request_id"])
    except Exception as exc:
        log.error("[PARTNER][DELETE][DEFERRED] request=%s err=%s", request["request_id"], type(exc).__name__,
                  extra={"tag": "PARTNER"})
        return request


def run_deletion(request_id: str) -> dict:
    request = repo.deletion_requests().find_one({"request_id": request_id}, {"_id": 0})
    if not request or request["status"] == "done":
        return request
    link = repo.links().find_one({"link_id": request["link_id"]}, {"_id": 0})
    deleted = dict(request.get("deleted") or {})
    try:
        tdb = link_db(link)
        # cada colección se borra por separado y se anota, así un reintento continúa donde quedó
        for name in (dbmod.TBL_METRICS, dbmod.TBL_PATIENT_WEARABLE_WORKOUTS, dbmod.TBL_MSK_MEASUREMENTS,
                     dbmod.TBL_DEVICE_EVENTS):
            result = repo.tenant_collection(tdb, name, majority=True).delete_many({"link_id": link["link_id"]})
            deleted[name] = deleted.get(name, 0) + result.deleted_count
            repo.deletion_requests().update_one({"request_id": request_id}, {"$set": {f"deleted.{name}": deleted[name]}})
        job_ids = [j["job_id"] for j in repo.ingest_jobs().find({"link_id": link["link_id"]}, {"job_id": 1})]
        deleted["partner_ingest_payloads"] = repo.ingest_payloads().delete_many({"job_id": {"$in": job_ids}}).deleted_count
        deleted["partner_idempotency_keys"] = repo.idempotency().delete_many({"link_id": link["link_id"]}).deleted_count
        repo.ingest_jobs().update_many({"link_id": link["link_id"]}, {"$set": {"errors": [], "data_deleted": True}})
        leftovers = sum(repo.tenant_collection(tdb, n).count_documents({"link_id": link["link_id"]})
                        for n in (dbmod.TBL_METRICS, dbmod.TBL_PATIENT_WEARABLE_WORKOUTS,
                                  dbmod.TBL_MSK_MEASUREMENTS, dbmod.TBL_DEVICE_EVENTS))
        if leftovers:
            raise RuntimeError(f"quedan {leftovers} documentos")
    except Exception as exc:
        attempts = request.get("attempts", 0) + 1
        delay = DELETION_RETRY[min(attempts - 1, len(DELETION_RETRY) - 1)]
        repo.deletion_requests().update_one({"request_id": request_id}, {"$set": {
            "status": "pending", "attempts": attempts, "last_error": type(exc).__name__,
            "next_attempt_at": _now() + timedelta(seconds=delay)}})
        record_event("partner.deletion_failed", trace_id_var.get() or None, link_id=link["link_id"],
                     request_id=request_id, attempts=attempts)
        raise
    # una escritura en vuelo puede llegar después del borrado: se programa una segunda pasada
    second_pass = request.get("sweeps", 0) < 1
    repo.deletion_requests().update_one({"request_id": request_id}, {"$set": {
        "status": "pending" if second_pass else "done", "completed_at": _now(), "deleted": deleted,
        "attempts": request.get("attempts", 0) + 1, "sweeps": request.get("sweeps", 0) + 1,
        "next_attempt_at": _now() + timedelta(minutes=10)}})
    record_event("partner.data_deleted", trace_id_var.get() or None, app_id=link["app_id"], link_id=link["link_id"],
                 request_id=request_id, deleted=deleted)
    return repo.deletion_requests().find_one({"request_id": request_id}, {"_id": 0})


def run_due_deletions(limit: int = 20) -> int:
    done = 0
    for req in repo.deletion_requests().find({"status": "pending", "next_attempt_at": {"$lte": _now()}},
                                             {"request_id": 1}).limit(limit):
        try:
            run_deletion(req["request_id"])
            done += 1
        except Exception:
            log.info("[PARTNER][DELETE][RETRY_LATER] request=%s", req["request_id"], extra={"tag": "PARTNER"})
    return done


def patient_link_view(link: dict, include_sync: bool = False) -> dict:
    app_doc = repo.apps().find_one({"app_id": link["app_id"]}, {"name": 1, "logo_url": 1}) or {}
    model = repo.device_models().find_one({"app_id": link["app_id"], "model_code": link.get("model_code")},
                                          {"display_name": 1, "form_factor": 1}) or {}
    last_sync = link.get("last_sync_at")
    wear_status = "unknown"
    try:
        last = repo.tenant_collection(link_db(link), dbmod.TBL_DEVICE_EVENTS).find_one(
            {"link_id": link["link_id"], "event_type": {"$in": ["worn", "removed"]}}, {"event_type": 1},
            sort=[("timestamp", -1)])
        if last:
            wear_status = "worn" if last["event_type"] == "worn" else "not_worn"
    except PartnerProblem:
        log.warning("[PARTNER][LINK_VIEW] tenant no disponible link=%s", link["link_id"], extra={"tag": "PARTNER"})
    view = {
        "link_id": link["link_id"], "partner_name": app_doc.get("name"), "partner_logo_url": app_doc.get("logo_url"),
        "model_display_name": model.get("display_name"), "form_factor": model.get("form_factor"),
        "status": link["status"], "granted_scopes": link.get("granted_scopes", []),
        "linked_at": link.get("created_at"), "last_sync_at": last_sync, "wear_status": wear_status,
    }
    if include_sync:
        view["source_quality"] = link.get("source_quality", 0.5)
        view["last_received"] = {k: v.get("latest_timestamp") for k, v in (link.get("last_received") or {}).items()}
        view["ingest_config"] = effective_config(link)
        view["revoked_at"] = link.get("revoked_at")
    return view


def scope_labels(scopes: list[str]) -> list[dict]:
    return [{"scope": s, "label": catalog.SCOPE_DESCRIPTIONS_ES.get(s, s)} for s in scopes]
