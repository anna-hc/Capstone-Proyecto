import gzip
import time
import uuid
import zlib
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Callable

from fastapi import HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from starlette.concurrency import run_in_threadpool

import app.config as conf
from app.logging_conf import get_logger

log = get_logger("PARTNER")

PROBLEM_BASE = "https://developers.wellq.co.uk/problems/"
trace_id_var: ContextVar[str] = ContextVar("partner_trace_id", default="")
audit_ctx: ContextVar[dict] = ContextVar("partner_audit_ctx", default=None)

_TITLES = {
    400: "Bad request", 401: "Unauthorized", 403: "Forbidden", 404: "Not found",
    405: "Method not allowed", 409: "Conflict", 413: "Payload too large", 415: "Unsupported media type",
    422: "Validation failed", 429: "Too many requests", 500: "Internal error", 503: "Service unavailable",
}
_SLUGS = {400: "bad-request", 401: "unauthorized", 403: "forbidden", 404: "not-found", 405: "method-not-allowed",
          409: "conflict", 413: "payload-too-large", 415: "unsupported-media-type", 422: "validation",
          429: "rate-limited", 500: "internal", 503: "unavailable"}


class PartnerProblem(Exception):
    def __init__(self, status: int, slug: str | None = None, detail: str | None = None,
                 title: str | None = None, headers: dict | None = None, **extra: Any):
        self.status = status
        self.slug = slug or _SLUGS.get(status, "error")
        self.detail = detail
        self.title = title or _TITLES.get(status, "Error")
        self.headers = headers or {}
        self.extra = extra
        super().__init__(detail or self.title)


def problem_response(status: int, slug: str, title: str, detail: str | None = None,
                     headers: dict | None = None, **extra: Any) -> JSONResponse:
    body = {"type": PROBLEM_BASE + slug, "title": title, "status": status}
    if detail:
        body["detail"] = detail
    body.update({k: v for k, v in extra.items() if v is not None})
    body["trace_id"] = trace_id_var.get() or uuid.uuid4().hex
    return JSONResponse(body, status_code=status, media_type="application/problem+json", headers=headers)


def _validation_errors(exc: RequestValidationError) -> list[dict]:
    out = []
    for err in exc.errors()[:50]:
        loc = [str(p) for p in err.get("loc", []) if p not in ("body",)]
        path = ""
        for part in loc:
            path += f"[{part}]" if part.isdigit() else (("." if path else "") + part)
        out.append({"path": path, "message": err.get("msg", "invalid")})
    return out


def _inflate(raw: bytes, max_decompressed: int) -> tuple[bytes, bool]:
    inflater = zlib.decompressobj(16 + zlib.MAX_WBITS)
    out = inflater.decompress(raw, max_decompressed + 1)
    return out, bool(inflater.unconsumed_tail)


async def read_bounded_body(request: Request, max_bytes: int, max_decompressed: int) -> bytes:
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > max_bytes:
        raise PartnerProblem(413, detail=f"El cuerpo supera {max_bytes} bytes")
    chunks, size = [], 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > max_bytes:
            raise PartnerProblem(413, detail=f"El cuerpo supera {max_bytes} bytes")
        chunks.append(chunk)
    raw = b"".join(chunks)
    encoding = (request.headers.get("content-encoding") or "identity").strip().lower()
    if encoding in ("identity", ""):
        return raw
    if encoding != "gzip":
        raise PartnerProblem(415, detail="Content-Encoding admitido: gzip")
    # descompresión acotada: corta antes de inflar más de max_decompressed (gzip bomb)
    try:
        out, tail = await run_in_threadpool(_inflate, raw, max_decompressed)
    except zlib.error:
        raise PartnerProblem(400, slug="invalid-gzip", detail="gzip inválido") from None
    if len(out) > max_decompressed or tail:
        raise PartnerProblem(413, slug="decompressed-too-large",
                             detail=f"El cuerpo descomprimido supera {max_decompressed} bytes")
    return out


class PartnerRoute(APIRoute):
    # convierte errores a problem+json, limita el body y deja traza de auditoría solo en rutas partner
    max_body_bytes: int | None = None

    def get_route_handler(self) -> Callable:
        original = super().get_route_handler()
        limit = getattr(self.endpoint, "partner_max_body", None) or conf.PARTNER_MAX_BODY_BYTES
        raw_body = getattr(self.endpoint, "partner_raw_body", False)
        route_path = self.path_format

        async def handler(request: Request) -> Response:
            trace_id = request.headers.get("x-request-id") or uuid.uuid4().hex
            if len(trace_id) > 64 or not trace_id.replace("-", "").isalnum():
                trace_id = uuid.uuid4().hex
            token = trace_id_var.set(trace_id)
            ctx_token = audit_ctx.set({})
            started = time.monotonic()
            status = 500
            size = 0
            try:
                if request.method in ("POST", "PUT", "PATCH") and not raw_body:
                    body = await read_bounded_body(request, limit, conf.PARTNER_MAX_DECOMPRESSED_BYTES)
                    request._body = body
                    size = len(body)
                response = await original(request)
            except PartnerProblem as p:
                response = problem_response(p.status, p.slug, p.title, p.detail, p.headers, **p.extra)
            except RequestValidationError as exc:
                response = problem_response(422, "validation", "Validation failed", errors=_validation_errors(exc))
            except HTTPException as exc:
                detail = exc.detail if isinstance(exc.detail, str) else None
                response = problem_response(exc.status_code, _SLUGS.get(exc.status_code, "error"),
                                            _TITLES.get(exc.status_code, "Error"), detail, exc.headers)
            except Exception as exc:
                log.error("[PARTNER][UNHANDLED] trace=%s path=%s err=%s", trace_id, route_path, type(exc).__name__,
                          exc_info=True, extra={"tag": "PARTNER"})
                response = problem_response(500, "internal", "Internal error",
                                            "Error interno; indica el trace_id si contactas con soporte")
            finally:
                trace_id_var.reset(token)
            status = response.status_code
            for name, value in ((audit_ctx.get() or {}).get("_headers") or {}).items():
                response.headers.setdefault(name, value)
            response.headers["X-Trace-Id"] = trace_id
            response.headers.setdefault("Cache-Control", "no-store")
            response.headers.setdefault("X-Content-Type-Options", "nosniff")
            try:
                from app.services.partner.audit import record_call
                # la escritura en Mongo va al threadpool: un Mongo lento no debe congelar el event loop
                await run_in_threadpool(record_call, request, route_path, status, trace_id,
                                        size or int(request.headers.get("content-length") or 0),
                                        audit_ctx.get() or {}, int((time.monotonic() - started) * 1000))
            except Exception:
                log.warning("[PARTNER][AUDIT][FAIL] trace=%s", trace_id, extra={"tag": "PARTNER"})
            finally:
                audit_ctx.reset(ctx_token)
            return response

        return handler


def set_audit(**fields: Any) -> None:
    ctx = audit_ctx.get()
    if ctx is not None:
        ctx.update({k: v for k, v in fields.items() if v is not None})


def add_response_headers(headers: dict) -> None:
    ctx = audit_ctx.get()
    if ctx is not None:
        ctx.setdefault("_headers", {}).update(headers)


def body_limit(max_bytes: int, raw: bool = False):
    def deco(fn):
        fn.partner_max_body = max_bytes
        fn.partner_raw_body = raw
        return fn
    return deco


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def gzip_bytes(data: bytes) -> bytes:
    return gzip.compress(data, compresslevel=5)
