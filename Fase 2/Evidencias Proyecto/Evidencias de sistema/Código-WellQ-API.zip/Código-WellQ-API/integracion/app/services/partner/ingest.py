import hashlib
import json
import statistics
from datetime import datetime, time as dtime, timedelta, timezone
from typing import Any, Iterable

from pymongo import ReplaceOne
from pymongo.errors import BulkWriteError

import app.db as dbmod
from app.repositories import partner as repo
from app.services.partner import catalog
from app.services.partner.tenancy import link_db

METRIC_FAMILY = {"resting_heart_rate": "heart_rate", "max_heart_rate": "heart_rate", "hrv_sdnn": "hrv_rmssd",
                 "calories_total": "calories_active", "floors_climbed": "steps", "active_minutes": "steps"}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _hash(doc: dict) -> str:
    return hashlib.sha256(json.dumps(doc, sort_keys=True, default=str).encode()).hexdigest()


def _err(path: str, message: str) -> dict:
    return {"path": path, "message": message}


def effective_scopes(app_doc: dict, link: dict) -> set[str]:
    return set(app_doc.get("_scopes", set())) & set(link.get("granted_scopes", []))


def declared_metrics(link: dict) -> set[str] | None:
    if not link.get("model_code"):
        return None
    model = repo.device_models().find_one({"app_id": link["app_id"], "model_code": link["model_code"]},
                                          {"capabilities": 1})
    if not model:
        return None
    return {c["metric"] for c in model.get("capabilities", [])}


def _declared(metric: str, declared: set[str] | None) -> bool:
    return declared is None or metric in declared or METRIC_FAMILY.get(metric) in declared


def effective_intervals(link: dict) -> dict[str, int]:
    out = {}
    if link.get("model_code"):
        model = repo.device_models().find_one({"app_id": link["app_id"], "model_code": link["model_code"]},
                                              {"capabilities": 1})
        for cap in (model or {}).get("capabilities", []):
            if cap.get("typical_interval_seconds"):
                out[cap["metric"]] = int(cap["typical_interval_seconds"])
    for metric, seconds in (link.get("ingest_config") or {}).get("intervals", {}).items():
        if seconds:
            out[metric] = int(seconds)
    return out


def _base(link: dict, kind: str, record_id: str, record_key: str, device_id: str) -> dict:
    now = _now()
    return {
        "patient_id": link["patient_id"], "meta": {"paciente_id": link["patient_id"]},
        "source": "partner", "provider": link.get("provider_slug") or f"partner_{link['app_id']}",
        "link_id": link["link_id"], "partner_app_id": link["app_id"], "device_id": device_id,
        "model_code": link.get("model_code"), "record_id": record_id, "record_key": record_key,
        "partner_kind": kind, "source_quality": link.get("source_quality", 0.5),
        "received_at": now, "updated_at": now,
    }


def _upsert(collection, link_id: str, prepared: list[tuple[int, str, dict]], results: list) -> dict:
    counts = {"created": 0, "updated": 0, "duplicate": 0}
    if not prepared:
        return counts
    keys = [doc["record_key"] for _, _, doc in prepared]
    existing = {d["record_key"]: d for d in collection.find({"link_id": link_id, "record_key": {"$in": keys}},
                                                           {"record_key": 1, "payload_hash": 1, "created_at": 1})}
    ops, pending, statuses = [], [], {}
    for idx, record_id, doc in prepared:
        prev = existing.get(doc["record_key"])
        if prev and prev.get("payload_hash") == doc["payload_hash"]:
            statuses[idx] = (record_id, "duplicate")
            continue
        doc["created_at"] = (prev or {}).get("created_at") or doc["received_at"]
        statuses[idx] = (record_id, "updated" if prev else "created")
        flt = {"link_id": link_id, "record_key": doc["record_key"]}
        pending.append((flt, doc))
        ops.append(ReplaceOne(flt, doc, upsert=True))
    if ops:
        try:
            collection.bulk_write(ops, ordered=False)
        except BulkWriteError as bwe:
            # carrera con otra petición del mismo record_key: el índice único dejó un solo documento
            for error in bwe.details.get("writeErrors", []):
                flt, doc = pending[error["index"]]
                if error.get("code") == 11000:
                    collection.replace_one(flt, doc, upsert=False)
                else:
                    raise
    for idx in sorted(statuses):
        record_id, status = statuses[idx]
        counts[status] += 1
        results[idx] = {"record_id": record_id, "status": status}
    return counts


def _finish(results: list, counts: dict, rejected: int) -> dict:
    return {"accepted": counts["created"] + counts["updated"], "rejected": rejected,
            "duplicates": counts["duplicate"], "results": [r for r in results if r is not None]}


def _touch_link(link: dict, kind: str, latest: datetime | None) -> None:
    if latest is None:
        return
    now = _now()
    repo.links().update_one({"link_id": link["link_id"]}, {
        "$max": {f"last_received.{kind}.latest_timestamp": latest},
        "$set": {f"last_received.{kind}.received_at": now, "last_sync_at": now},
    })


def ingest_daily_summaries(app_doc: dict, link: dict, summaries: list) -> dict:
    scopes = effective_scopes(app_doc, link)
    declared = declared_metrics(link)
    tdb = link_db(link)
    results: list = [None] * len(summaries)
    prepared, rejected, latest = [], 0, None
    for i, item in enumerate(summaries):
        record = item.model_dump(exclude_none=True)
        errors = []
        sensors = {}
        for field, (scope, sensor_key, unit, metric) in catalog.DAILY_FIELDS.items():
            if field not in record:
                continue
            path = f"summaries[{i}].{field}"
            if scope not in scopes:
                errors.append(_err(path, f"insufficient-scope: el vínculo no concede {scope}"))
                continue
            if not _declared(metric, declared):
                errors.append(_err(path, f"métrica {metric} no declarada en el device-model {link.get('model_code')}"))
                continue
            lo, hi = catalog.PLAUSIBLE_RANGES[field]
            if not lo <= record[field] <= hi:
                errors.append(_err(path, f"must be between {lo} and {hi}"))
                continue
            value = record[field]
            if sensor_key == "sleep":
                sensors["sleep"] = {"metric": "sleep", "duration": int(value * 60), "value": round(value / 60, 3),
                                    "unit": "h"}
            else:
                sensors[sensor_key] = {"metric": sensor_key, "value": value, "unit": unit}
        if not sensors and not errors:
            errors.append(_err(f"summaries[{i}]", "el resumen no trae ninguna métrica"))
        if errors:
            rejected += 1
            results[i] = {"record_id": record["record_id"], "status": "rejected", "errors": errors}
            continue
        local_date = record["local_date"]
        start = datetime.combine(local_date, dtime(0), tzinfo=timezone.utc) - timedelta(minutes=record["tz_offset_minutes"])
        doc = _base(link, "daily_summary", record["record_id"], f"ds:{record['device_id']}:{local_date.isoformat()}",
                    record["device_id"])
        canonical = {k: v for k, v in record.items() if k in catalog.DAILY_FIELDS}
        doc.update({
            "from_ts": start, "to_ts": start + timedelta(days=1), "metric_date": local_date.isoformat(),
            "tz_offset_minutes": record["tz_offset_minutes"], "completeness": record.get("completeness", "partial"),
            "sensors": sensors, "partner_summary": canonical,
            "partner_informational": {k: record[k] for k in catalog.INFORMATIONAL_FIELDS if k in record},
        })
        doc["source_quality"] = _source_quality(link, record)
        doc["payload_hash"] = _hash({"s": canonical, "i": doc["partner_informational"], "c": doc["completeness"],
                                     "r": record["record_id"], "tz": record["tz_offset_minutes"]})
        prepared.append((i, record["record_id"], doc))
        latest = max(latest, start) if latest else start
    counts = _upsert(repo.tenant_collection(tdb, dbmod.TBL_METRICS), link["link_id"], prepared, results)
    _touch_link(link, "daily_summary", latest)
    return _finish(results, counts, rejected)


def _source_quality(link: dict, record: dict) -> float:
    # prioridad entre fuentes del mismo día: final > partial y más horas de uso
    score = 0.5 + (0.3 if record.get("completeness") == "final" else 0.0)
    wear = record.get("wear_time_minutes")
    if wear is not None:
        score += 0.2 * min(wear / 1380.0, 1.0)
    return round(min(score, 1.0), 3)


def ingest_sessions(app_doc: dict, link: dict, sessions: list) -> dict:
    scopes = effective_scopes(app_doc, link)
    declared = declared_metrics(link)
    tdb = link_db(link)
    results: list = [None] * len(sessions)
    sleep_docs, workout_docs, rejected, latest = [], [], 0, None
    for i, item in enumerate(sessions):
        record = item.model_dump(exclude_none=True)
        kind = record["session_type"]
        needed = "ingest:sleep" if kind == "sleep" else "ingest:activity"
        errors = []
        if needed not in scopes:
            errors.append(_err(f"sessions[{i}]", f"insufficient-scope: el vínculo no concede {needed}"))
        elif not _declared("sleep" if kind == "sleep" else "exercise", declared):
            errors.append(_err(f"sessions[{i}]", f"sesiones de {kind} no declaradas en el device-model"))
        if record["end"] <= record["start"]:
            errors.append(_err(f"sessions[{i}].end", "debe ser posterior a start"))
        elif record["end"] - record["start"] > timedelta(hours=24 if kind == "sleep" else 12):
            errors.append(_err(f"sessions[{i}].end", "duración de sesión no plausible"))
        for j, stage in enumerate(record.get("stages") or []):
            if stage["end"] <= stage["start"] or stage["start"] < record["start"] or stage["end"] > record["end"]:
                errors.append(_err(f"sessions[{i}].stages[{j}]", "fase fuera de la sesión"))
                break
        if errors:
            rejected += 1
            results[i] = {"record_id": record["record_id"], "status": "rejected", "errors": errors}
            continue
        duration = int((record["end"] - record["start"]).total_seconds())
        if kind == "sleep":
            doc = _base(link, "sleep_session", record["record_id"], f"ss:{record['record_id']}", record["device_id"])
            doc.update({
                "from_ts": record["start"], "to_ts": record["end"],
                "metric_date": (record["end"] + timedelta(minutes=record.get("tz_offset_minutes") or 0)).date().isoformat(),
                "sensors": {"sleep_session": {"metric": "sleep_session", "duration": duration,
                                              "is_nap": record.get("is_nap", False),
                                              "stages": record.get("stages") or [],
                                              "summary": record.get("summary") or {}}},
            })
            doc["payload_hash"] = _hash({k: v for k, v in record.items()})
            sleep_docs.append((i, record["record_id"], doc))
        else:
            summary = record.get("summary") or {}
            doc = _base(link, "exercise_session", record["record_id"], f"ex:{record['record_id']}", record["device_id"])
            doc.pop("meta", None)
            doc.update({
                "workout_id": f"partner:{link['link_id']}:{record['record_id']}",
                "workout_type": record["activity_type"], "workout_name": record["activity_type"].replace("_", " "),
                "start_at": record["start"], "end_at": record["end"],
                "duration_seconds": summary.get("duration_seconds") or duration,
                "provider_slug": doc["provider"], "calories_burned": summary.get("calories_kcal"),
                "avg_heart_rate": summary.get("avg_heart_rate_bpm"), "max_heart_rate": summary.get("max_heart_rate_bpm"),
                "metrics": {"distance_m": summary.get("distance_m"), "hr_zones_seconds": summary.get("hr_zones_seconds")},
                "sets": record.get("sets") or [], "wellq_exercise_code": record.get("wellq_exercise_code"),
                "entry": record.get("source", "auto_detected"),
            })
            doc["payload_hash"] = _hash({k: v for k, v in record.items()})
            workout_docs.append((i, record["record_id"], doc))
        latest = max(latest, record["end"]) if latest else record["end"]
    counts_s = _upsert(repo.tenant_collection(tdb, dbmod.TBL_METRICS), link["link_id"], sleep_docs, results)
    counts_w = _upsert(repo.tenant_collection(tdb, dbmod.TBL_PATIENT_WEARABLE_WORKOUTS), link["link_id"],
                       workout_docs, results)
    _touch_link(link, "session", latest)
    counts = {k: counts_s[k] + counts_w[k] for k in counts_s}
    return _finish(results, counts, rejected)


def ingest_msk(app_doc: dict, link: dict, measurements: list) -> dict:
    scopes = effective_scopes(app_doc, link)
    declared = declared_metrics(link)
    tdb = link_db(link)
    results: list = [None] * len(measurements)
    prepared, rejected, latest = [], 0, None
    for i, item in enumerate(measurements):
        record = item.model_dump(exclude_none=True)
        errors = []
        mtype = record["measurement_type"]
        if "ingest:msk" not in scopes:
            errors.append(_err(f"measurements[{i}]", "insufficient-scope: el vínculo no concede ingest:msk"))
        elif not _declared(mtype, declared) and mtype != "vendor_specific":
            errors.append(_err(f"measurements[{i}].measurement_type", f"{mtype} no declarada en el device-model"))
        if record["body_region"] not in catalog.BODY_REGIONS:
            errors.append(_err(f"measurements[{i}].body_region", "región no reconocida en el catálogo de WellQ"))
        expected_unit, value_range = catalog.MSK_TYPE_UNITS[mtype]
        unit = record["unit"]
        value = record["value"]
        if expected_unit is not None:
            conv = catalog.MSK_UNITS.get(unit)
            if not conv or conv[0] != expected_unit:
                errors.append(_err(f"measurements[{i}].unit", f"unidad no válida para {mtype}; se espera {expected_unit}"))
            else:
                value = round(value * conv[1], 4)
                unit = expected_unit
                if not value_range[0] <= value <= value_range[1]:
                    errors.append(_err(f"measurements[{i}].value", f"must be between {value_range[0]} and {value_range[1]}"))
        if errors:
            rejected += 1
            results[i] = {"record_id": record["record_id"], "status": "rejected", "errors": errors}
            continue
        doc = _base(link, "msk", record["record_id"], f"msk:{record['record_id']}", record["device_id"])
        doc.pop("meta", None)
        doc.update({k: record.get(k) for k in ("timestamp", "measurement_type", "body_region", "side", "context",
                                               "wellq_exercise_code", "protocol", "confidence", "vendor_specific")})
        doc.update({"value": value, "unit": unit, "original_value": record["value"], "original_unit": record["unit"]})
        doc["payload_hash"] = _hash(record)
        prepared.append((i, record["record_id"], doc))
        latest = max(latest, record["timestamp"]) if latest else record["timestamp"]
    counts = _upsert(repo.tenant_collection(tdb, dbmod.TBL_MSK_MEASUREMENTS), link["link_id"], prepared, results)
    _touch_link(link, "msk_measurement", latest)
    return _finish(results, counts, rejected)


def ingest_device_events(app_doc: dict, link: dict, events: list) -> dict:
    scopes = effective_scopes(app_doc, link)
    tdb = link_db(link)
    results: list = [None] * len(events)
    prepared, rejected, latest = [], 0, None
    for i, item in enumerate(events):
        record = item.model_dump(exclude_none=True)
        if "ingest:device" not in scopes:
            rejected += 1
            results[i] = {"record_id": record["record_id"], "status": "rejected",
                          "errors": [_err(f"events[{i}]", "insufficient-scope: el vínculo no concede ingest:device")]}
            continue
        doc = _base(link, "device_event", record["record_id"], f"ev:{record['record_id']}", record["device_id"])
        doc.pop("meta", None)
        doc.update({"timestamp": record["timestamp"], "event_type": record["event_type"],
                    "details": record.get("details") or {}})
        doc["payload_hash"] = _hash(record)
        prepared.append((i, record["record_id"], doc))
        latest = max(latest, record["timestamp"]) if latest else record["timestamp"]
    counts = _upsert(repo.tenant_collection(tdb, dbmod.TBL_DEVICE_EVENTS), link["link_id"], prepared, results)
    _touch_link(link, "device_event", latest)
    return _finish(results, counts, rejected)


def validate_series(i: int, series: dict, scopes: set[str], declared: set[str] | None,
                    intervals: dict[str, int]) -> tuple[list[dict], dict | None]:
    metric = series["metric"]
    spec = catalog.SAMPLE_METRICS.get(metric)
    if not spec:
        return [_err(f"series[{i}].metric", f"métrica de serie no admitida: {metric}")], None
    scope, canonical_unit, (lo, hi), conversions = spec
    if scope not in scopes:
        return [_err(f"series[{i}]", f"insufficient-scope: el vínculo no concede {scope}")], None
    if not _declared(metric, declared):
        return [_err(f"series[{i}].metric", f"{metric} no declarada en el device-model")], None
    factor = conversions.get(series["unit"])
    if factor is None:
        return [_err(f"series[{i}].unit", f"unidad no admitida para {metric}: {series['unit']}")], None
    values = [round(v * factor, 4) for v in series["values"]]
    bad = sum(1 for v in values if not lo <= v <= hi)
    if bad:
        return [_err(f"series[{i}].values", f"{bad} muestras fuera de rango [{lo}, {hi}]")], None
    interval = intervals.get(metric)
    offsets = series["offsets_ms"]
    if interval and len(offsets) > 2:
        gaps = [b - a for a, b in zip(offsets, offsets[1:], strict=False) if b > a]
        if gaps and statistics.median(gaps) < interval * 1000 * 0.5:
            return [_err(f"series[{i}].offsets_ms",
                         f"frecuencia mayor que la configurada para {metric} ({interval} s entre muestras)")], None
    return [], {**series, "values": values, "unit": canonical_unit}


def write_series(link: dict, job_id: str, series_list: Iterable[tuple[int, dict]]) -> int:
    tdb = link_db(link)
    prepared, latest = [], None
    for i, series in series_list:
        start = series["start"] if isinstance(series["start"], datetime) else datetime.fromisoformat(
            str(series["start"]).replace("Z", "+00:00"))
        key = series.get("record_id") or f"{series['device_id']}:{series['metric']}:{start.isoformat()}"
        doc = _base(link, "samples", series.get("record_id") or key, f"sm:{key}", series["device_id"])
        offsets = series["offsets_ms"]
        end = start + timedelta(milliseconds=offsets[-1] + ((series.get("durations_ms") or [0])[-1]))
        doc.update({
            "from_ts": start, "to_ts": end, "metric_date": start.date().isoformat(), "job_id": job_id,
            "sensors": {series["metric"]: {"metric": series["metric"], "unit": series["unit"],
                                           "values": series["values"], "offsets": [o / 1000.0 for o in offsets],
                                           "durations_ms": series.get("durations_ms"), "quality": series.get("quality")}},
        })
        doc["payload_hash"] = _hash({"v": series["values"], "o": offsets, "u": series["unit"]})
        prepared.append((i, doc["record_id"], doc))
        latest = max(latest, end) if latest else end
    results: list = [None] * (max((i for i, _, _ in prepared), default=-1) + 1)
    _upsert(repo.tenant_collection(tdb, dbmod.TBL_METRICS), link["link_id"], prepared, results)
    _touch_link(link, "samples", latest)
    return sum(len(doc["sensors"][next(iter(doc["sensors"]))]["values"]) for _, _, doc in prepared)


def partner_docs(collection, link_ids: list[str], extra: dict | None = None, projection: dict | None = None,
                 sort: list | None = None, limit: int = 5000) -> list[dict]:
    flt: dict[str, Any] = {"link_id": {"$in": link_ids}}
    flt.update(extra or {})
    cursor = collection.find(flt, projection or {"_id": 0})
    if sort:
        cursor = cursor.sort(sort)
    return list(cursor.limit(limit))

