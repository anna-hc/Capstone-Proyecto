import base64
import hashlib
import hmac
import secrets
import time
import uuid
from datetime import datetime, timedelta, timezone

import jwt
from cryptography.fernet import Fernet, InvalidToken

import app.config as conf

ACCESS_AUDIENCE = "wellq-partner-api"
PORTAL_AUDIENCE = "wellq-partner-portal"
TOKEN_ALG = "HS256"  # noqa: S105
ACCESS_TTL_SECONDS = 3600
PORTAL_TTL_SECONDS = 3600
PAIRING_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
PAIRING_LENGTH = 8


class PartnerConfigError(RuntimeError):
    pass


def configuration_errors() -> list[str]:
    errors = []
    if len(conf.PARTNER_TOKEN_SECRET or "") < 32:
        errors.append("PARTNER_TOKEN_SECRET ausente o con menos de 32 caracteres")
    try:
        Fernet((conf.PARTNER_ENCRYPTION_KEY or "").encode())
    except Exception:
        errors.append("PARTNER_ENCRYPTION_KEY no es una clave Fernet válida")
    return errors


def _token_secret() -> str:
    secret = conf.PARTNER_TOKEN_SECRET or ""
    if len(secret) < 32:
        raise PartnerConfigError("PARTNER_TOKEN_SECRET no configurado")
    return secret


def _derived_key(purpose: str) -> bytes:
    return hmac.new(_token_secret().encode(), purpose.encode(), hashlib.sha256).digest()


def new_client_secret() -> str:
    return "wqs_" + secrets.token_urlsafe(32)


def hash_secret(value: str) -> str:
    # los secretos son de 256 bits aleatorios, así que basta un HMAC rápido con pimienta
    return hmac.new(_derived_key("client-secret"), value.encode(), hashlib.sha256).hexdigest()


def secret_matches(candidate: str, stored_hashes: list[dict], now: datetime | None = None) -> bool:
    now = now or datetime.now(timezone.utc)
    candidate_hash = hash_secret(candidate)
    matched = False
    for entry in stored_hashes or []:
        valid_until = entry.get("valid_until")
        if valid_until is not None:
            if valid_until.tzinfo is None:
                valid_until = valid_until.replace(tzinfo=timezone.utc)
            if valid_until < now:
                continue
        # se recorren todas para no filtrar por tiempo cuál coincide
        matched |= hmac.compare_digest(candidate_hash, entry.get("hash", ""))
    return matched


def _fernet() -> Fernet:
    try:
        return Fernet((conf.PARTNER_ENCRYPTION_KEY or "").encode())
    except Exception as exc:
        raise PartnerConfigError("PARTNER_ENCRYPTION_KEY no configurada") from exc


def encrypt_secret(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()


def decrypt_secret(token: str) -> str:
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken as exc:
        raise PartnerConfigError("no se pudo descifrar el secreto del webhook") from exc


def new_webhook_secret() -> str:
    return "whsec_" + secrets.token_urlsafe(32)


def sign_webhook(secret: str, body: bytes, timestamp: int) -> str:
    return hmac.new(secret.encode(), str(timestamp).encode() + b"." + body, hashlib.sha256).hexdigest()


def verify_webhook_signature(secret: str, body: bytes, header: str, now: int, tolerance: int = 300) -> bool:
    parts = dict(p.split("=", 1) for p in header.split(",") if "=" in p)
    try:
        ts = int(parts.get("t", ""))
    except ValueError:
        return False
    if abs(now - ts) > tolerance:
        return False
    return hmac.compare_digest(sign_webhook(secret, body, ts), parts.get("v1", ""))


def issue_access_token(app_doc: dict, scopes: list[str]) -> tuple[str, int]:
    now = datetime.now(timezone.utc)
    payload = {
        "iss": conf.PARTNER_TOKEN_ISSUER,
        "aud": ACCESS_AUDIENCE,
        "sub": app_doc["client_id"],
        "app_id": app_doc["app_id"],
        "env": app_doc.get("environment", "sandbox"),
        "gen": int(app_doc.get("token_generation", 0)),
        "scope": " ".join(sorted(scopes)),
        "typ": "partner_access",
        "iat": int(now.timestamp()),
        "nbf": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=ACCESS_TTL_SECONDS)).timestamp()),
        "jti": uuid.uuid4().hex,
    }
    return jwt.encode(payload, _token_secret(), algorithm=TOKEN_ALG), ACCESS_TTL_SECONDS


def issue_portal_token(developer_id: str) -> tuple[str, int]:
    now = datetime.now(timezone.utc)
    payload = {
        "iss": conf.PARTNER_TOKEN_ISSUER,
        "aud": PORTAL_AUDIENCE,
        "sub": developer_id,
        "typ": "partner_portal",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(seconds=PORTAL_TTL_SECONDS)).timestamp()),
        "jti": uuid.uuid4().hex,
    }
    return jwt.encode(payload, _token_secret(), algorithm=TOKEN_ALG), PORTAL_TTL_SECONDS


def decode_token(token: str, audience: str, typ: str) -> dict | None:
    try:
        payload = jwt.decode(
            token, _token_secret(), algorithms=[TOKEN_ALG], audience=audience, issuer=conf.PARTNER_TOKEN_ISSUER,
            options={"require": ["exp", "iat", "jti", "aud", "iss", "sub"]},
        )
    except jwt.PyJWTError:
        return None
    if payload.get("typ") != typ:
        return None
    return payload


def new_pairing_code() -> str:
    raw = "".join(secrets.choice(PAIRING_ALPHABET) for _ in range(PAIRING_LENGTH))
    return f"WQ-{raw[:4]}-{raw[4:]}"


def normalize_pairing_code(code: str) -> str | None:
    cleaned = "".join(ch for ch in (code or "").upper() if ch.isalnum())
    if cleaned.startswith("WQ") and len(cleaned) == PAIRING_LENGTH + 2:
        cleaned = cleaned[2:]
    if len(cleaned) != PAIRING_LENGTH or any(ch not in PAIRING_ALPHABET for ch in cleaned):
        return None
    return cleaned


def hash_pairing_code(normalized: str) -> str:
    return hmac.new(_derived_key("pairing-code"), normalized.encode(), hashlib.sha256).hexdigest()


def new_verification_token() -> str:
    return secrets.token_urlsafe(32)


def hash_opaque(value: str, purpose: str) -> str:
    return hmac.new(_derived_key(purpose), value.encode(), hashlib.sha256).hexdigest()


def fingerprint(value: str) -> str:
    return base64.urlsafe_b64encode(hashlib.sha256(value.encode()).digest()[:9]).decode()


def new_id(prefix: str) -> str:
    # prefijo temporal: los ids se ordenan por creación y sirven de cursor de paginación
    return f"{prefix}_{int(time.time() * 1000):012x}{secrets.token_hex(6)}"
