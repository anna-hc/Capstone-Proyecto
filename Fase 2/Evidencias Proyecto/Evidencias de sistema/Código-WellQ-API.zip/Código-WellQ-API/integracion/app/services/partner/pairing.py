from datetime import datetime, timedelta, timezone

from pymongo.errors import DuplicateKeyError

from app.repositories import partner as repo
from app.services.partner.problems import PartnerProblem
from app.services.partner.security import hash_pairing_code, new_pairing_code, normalize_pairing_code

CODE_TTL = timedelta(minutes=10)


def create_code(patient: dict, environment: str, scopes: list[str], consent_doc_version: str,
                app_id: str | None, consent_doc_verified: bool) -> dict:
    now = datetime.now(timezone.utc)
    for _ in range(5):
        code = new_pairing_code()
        try:
            repo.pairing_codes().insert_one({
                "code_hash": hash_pairing_code(normalize_pairing_code(code)), "environment": environment,
                "app_id": app_id, "patient_id": patient["patient_id"], "patient_oid": str(patient["oid"]),
                "tenant_slug": patient.get("tenant_slug"), "tenant_db": patient["tenant_db"],
                "scopes": sorted(set(scopes)), "consent_doc_version": consent_doc_version,
                "consent_doc_verified": consent_doc_verified, "created_at": now, "expires_at": now + CODE_TTL,
                "used_at": None, "used_by_app_id": None,
            })
            return {"pairing_code": code, "expires_at": (now + CODE_TTL).isoformat().replace("+00:00", "Z"),
                    "qr_payload": f"wellq://pair?code={code}"}
        except DuplicateKeyError:
            continue
    raise PartnerProblem(503, detail="No se pudo generar el código, reintenta")
