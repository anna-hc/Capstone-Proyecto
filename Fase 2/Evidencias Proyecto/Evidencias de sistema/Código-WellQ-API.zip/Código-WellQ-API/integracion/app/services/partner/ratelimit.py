import threading
import time

from app.logging_conf import get_logger
from app.services.partner.problems import PartnerProblem

log = get_logger("PARTNER")

_redis = None
_redis_checked_at = 0.0
_memory: dict[str, tuple[int, float]] = {}
_lock = threading.Lock()


def set_backend(client) -> None:
    global _redis, _redis_checked_at
    _redis = client
    _redis_checked_at = time.time() if client is not None else 0.0


def _backend():
    global _redis, _redis_checked_at
    if _redis is not None or time.time() - _redis_checked_at < 30:
        return _redis
    _redis_checked_at = time.time()
    try:
        # cliente propio con timeouts cortos y sin reintentos: si Redis cae, la petición no debe quedarse esperando
        from redis import Redis
        from redis.backoff import NoBackoff
        from redis.retry import Retry
        import app.config as conf
        client = Redis(host=conf.REDIS_HOST, port=int(conf.REDIS_PORT or 6379), username=conf.REDIS_USER or None,
                       password=conf.REDIS_PASS or None, db=int(conf.REDIS_DB or 0), socket_connect_timeout=0.5,
                       socket_timeout=0.5, retry=Retry(NoBackoff(), 0), decode_responses=True)
        client.ping()
        _redis = client
    except Exception:
        _redis = None
        log.warning("[PARTNER][RATELIMIT] Redis no disponible, contadores en memoria del proceso", extra={"tag": "PARTNER"})
    return _redis


def redis_available() -> bool:
    return _backend() is not None


def hit(bucket: str, limit: int, window_seconds: int, cost: int = 1) -> tuple[int, int, int]:
    now = time.time()
    window_start = int(now // window_seconds) * window_seconds
    reset = int(window_start + window_seconds - now) or 1
    key = f"partner:rl:{bucket}:{window_start}"
    client = _backend()
    if client is not None:
        try:
            pipe = client.pipeline()
            pipe.incrby(key, cost)
            pipe.expire(key, window_seconds + 5)
            count = int(pipe.execute()[0])
            return count, max(0, limit - count), reset
        except Exception:
            log.warning("[PARTNER][RATELIMIT] fallo de Redis, uso memoria", extra={"tag": "PARTNER"})
    with _lock:
        count, expires = _memory.get(key, (0, now + window_seconds))
        count += cost
        _memory[key] = (count, expires)
        if len(_memory) > 50_000:
            for k in [k for k, (_, exp) in _memory.items() if exp < now]:
                _memory.pop(k, None)
    return count, max(0, limit - count), reset


def enforce(bucket: str, limit: int, window_seconds: int = 60, cost: int = 1, slug: str = "rate-limited",
            detail: str | None = None) -> dict:
    count, remaining, reset = hit(bucket, limit, window_seconds, cost)
    headers = {"RateLimit-Limit": str(limit), "RateLimit-Remaining": str(remaining), "RateLimit-Reset": str(reset)}
    if count > limit:
        headers["Retry-After"] = str(reset)
        raise PartnerProblem(429, slug=slug, title="Too many requests",
                             detail=detail or f"Límite de {limit} peticiones por {window_seconds} s superado",
                             headers=headers)
    return headers


def peek(bucket: str, window_seconds: int) -> int:
    now = time.time()
    window_start = int(now // window_seconds) * window_seconds
    key = f"partner:rl:{bucket}:{window_start}"
    client = _backend()
    if client is not None:
        try:
            return int(client.get(key) or 0)
        except Exception:
            log.warning("[PARTNER][RATELIMIT] fallo de Redis al leer, uso memoria", extra={"tag": "PARTNER"})
    with _lock:
        return _memory.get(key, (0, 0))[0]


def reset_memory() -> None:
    with _lock:
        _memory.clear()
