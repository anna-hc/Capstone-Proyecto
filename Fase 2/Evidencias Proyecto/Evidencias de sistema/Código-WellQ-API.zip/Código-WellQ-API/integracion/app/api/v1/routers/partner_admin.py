from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Body, Depends, Query

import app.config as conf
from app.logging_conf import get_logger
from app.models.partner import PromotionDecision
from app.repositories import partner as repo
from app.services.partner import catalog, webhooks
from app.services.partner.audit import record_event
from app.services.partner.deps import current_staff
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit, trace_id_var

log = get_logger("PARTNER")
router = APIRouter(prefix="/partner/admin", tags=["Partner Admin (internal)"], route_class=PartnerRoute)
_staff = current_staff("itadmin", "partner_admin_dev")


def itadmin(staff: dict = Depends(_staff)) -> dict:
    # el rol itadmin existe en cada tenant: solo vale el personal de los tenants de plataforma configurados
    from app.services.partner.deps import dev_tools_enabled
    if "partner_admin_dev" in staff["roles"]:
        if not dev_tools_enabled():
            raise PartnerProblem(403, detail="Operación no permitida")
        return staff
    if staff.get("tenant_slug") not in conf.PARTNER_ADMIN_TENANT_SLUGS:
        raise PartnerProblem(403, detail="Solo personal de plataforma de WellQ")
    return staff


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _notify_developer(app_doc: dict, subject: str, text: str) -> None:
    try:
        dev = repo.developers().find_one({"developer_id": app_doc["developer_id"]}, {"contact_email": 1})
        if dev and dev.get("contact_email"):
            from app.services.mailer import send_email_html
            send_email_html(subject, dev["contact_email"], f"<p>{text}</p>", text)
    except Exception as exc:
        log.warning("[PARTNER][ADMIN][MAIL_FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})


@router.get("/promotion-requests")
def list_promotion_requests(status: Optional[Literal["under_review", "approved", "rejected"]] = "under_review",
                            limit: int = Query(default=50, ge=1, le=200), staff: dict = Depends(itadmin)):
    return list(repo.promotion_requests().find({"status": status} if status else {}, {"_id": 0, "dpa_ip": 0})
                .sort("created_at", 1).limit(limit))


def _decide(request_id: str, staff: dict, approve: bool, notes: Optional[str]) -> dict:
    req = repo.find_one_and_update(repo.promotion_requests(), {"request_id": request_id, "status": "under_review"},
                                   {"$set": {"status": "approved" if approve else "rejected", "decided_at": _now(),
                                             "decided_by": staff.get("sub"), "decision_notes": notes}})
    if not req:
        raise PartnerProblem(404, detail="Solicitud no encontrada o ya resuelta")
    app_doc = repo.apps().find_one({"app_id": req["app_id"]}, {"_id": 0})
    set_audit(app_id=req["app_id"], actor="staff", event="partner.promotion_" + ("approved" if approve else "rejected"))
    if not approve:
        repo.apps().update_one({"app_id": req["app_id"]}, {"$set": {"promotion_status": "rejected"}})
        _notify_developer(app_doc, "WellQ: solicitud de producción rechazada", notes or "Revisa la solicitud.")
        return {"request_id": request_id, "status": "rejected"}
    # las credenciales de sandbox dejan de valer; las de producción se obtienen una sola vez rotando el secreto
    # se conceden los scopes revisados en la solicitud, no los que la app tenga ahora
    granted = sorted(set(req.get("requested_scopes") or catalog.CONSENT_SCOPES)) + list(catalog.APP_LEVEL_SCOPES)
    repo.apps().update_one({"app_id": req["app_id"]}, {"$set": {
        "environment": "production", "status": "active", "promotion_status": "approved", "promoted_at": _now(),
        "granted_scopes": granted, "client_secret_hashes": [], "production_credentials_pending": True},
        "$inc": {"token_generation": 1}})
    webhooks.dispatch(req["app_id"], "app.promoted", {"app_id": req["app_id"], "environment": "production"})
    record_event("app.promoted", trace_id_var.get() or None, actor="staff", app_id=req["app_id"],
                 staff_sub=staff.get("sub"))
    _notify_developer(app_doc, "WellQ: app aprobada para producción",
                      "Tu app fue aprobada. Rota el secreto desde el portal para obtener las credenciales de producción.")
    return {"request_id": request_id, "status": "approved", "environment": "production"}


@router.post("/promotion-requests/{request_id}/approve")
def approve(request_id: str, data: Optional[PromotionDecision] = Body(default=None), staff: dict = Depends(itadmin)):
    return _decide(request_id, staff, True, (data or PromotionDecision()).notes)


@router.post("/promotion-requests/{request_id}/reject")
def reject(request_id: str, data: Optional[PromotionDecision] = Body(default=None), staff: dict = Depends(itadmin)):
    return _decide(request_id, staff, False, (data or PromotionDecision()).notes)


@router.post("/apps/{app_id}/suspend")
def suspend_app(app_id: str, data: Optional[PromotionDecision] = Body(default=None), staff: dict = Depends(itadmin)):
    app_doc = repo.find_one_and_update(repo.apps(), {"app_id": app_id, "status": {"$ne": "suspended"}},
                                       {"$set": {"status": "suspended", "suspended_at": _now(),
                                                 "suspension_notes": (data or PromotionDecision()).notes},
                                        "$inc": {"token_generation": 1}})
    if not app_doc:
        raise PartnerProblem(404, detail="App no encontrada o ya suspendida")
    set_audit(app_id=app_id, actor="staff", event="app.suspended")
    webhooks.dispatch(app_id, "app.suspended", {"app_id": app_id})
    _notify_developer(app_doc, "WellQ: app suspendida", "Tu app fue suspendida. Contacta con WellQ.")
    return {"app_id": app_id, "status": "suspended"}


@router.post("/apps/{app_id}/reactivate")
def reactivate_app(app_id: str, staff: dict = Depends(itadmin)):
    app_doc = repo.find_one_and_update(repo.apps(), {"app_id": app_id, "status": "suspended"},
                                       {"$set": {"status": "active", "reactivated_at": _now()}})
    if not app_doc:
        raise PartnerProblem(404, detail="App no encontrada o no suspendida")
    set_audit(app_id=app_id, actor="staff", event="app.reactivated")
    return {"app_id": app_id, "status": "active"}
