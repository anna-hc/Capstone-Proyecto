from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Query, Response

import app.db as dbmod
from app.models.partner import LinkScopesUpdate, PairingCodeCreate
from app.repositories import partner as repo
from app.services.partner import links as link_service, pairing, ratelimit, webhooks
from app.services.partner.deps import current_patient
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit

router = APIRouter(prefix="/wearables", tags=["Patient App (internal)"], route_class=PartnerRoute)
WEARABLE_CONSENT_TYPES = ("wearable_sharing", "wearable-sharing", "wearables")


def _patient_link(patient: dict, link_id: str) -> dict:
    link = repo.links().find_one({"link_id": link_id, "patient_id": patient["patient_id"],
                                  "tenant_db": patient["tenant_db"]}, {"_id": 0})
    if not link:
        raise PartnerProblem(404, detail="Vínculo no encontrado")
    set_audit(link_id=link_id, app_id=link["app_id"])
    return link


def _consent_verified(patient: dict, version: str) -> bool:
    docs = repo.tenant_collection(patient["db"], dbmod.TBL_LEGAL_DOCS)
    known = list(docs.find({"type": {"$in": list(WEARABLE_CONSENT_TYPES)}}, {"version": 1}).limit(50))
    if not known:
        if patient["sandbox"]:
            return False
        raise PartnerProblem(409, slug="consent-document-missing",
                             detail="La clínica no tiene publicado el documento de consentimiento de wearables")
    if version not in {str(d.get("version")) for d in known}:
        raise PartnerProblem(422, slug="unknown-consent-version",
                             detail="consent_doc_version no corresponde a un documento legal vigente")
    return True


def _visible_app(app_id: str, patient: dict) -> dict:
    env = "sandbox" if patient["sandbox"] else "production"
    app_doc = repo.apps().find_one({"app_id": app_id, "status": "active", "environment": env},
                                   {"_id": 0, "app_id": 1, "name": 1, "logo_url": 1, "privacy_policy_url": 1,
                                    "requested_scopes": 1, "granted_scopes": 1})
    if not app_doc:
        raise PartnerProblem(404, detail="Fabricante no encontrado")
    return app_doc


@router.get("/partners")
def list_partners(patient: dict = Depends(current_patient)):
    env = "sandbox" if patient["sandbox"] else "production"
    return [{"app_id": a["app_id"], "name": a.get("name"), "logo_url": a.get("logo_url"),
             "privacy_policy_url": a.get("privacy_policy_url")}
            for a in repo.apps().find({"status": "active", "environment": env},
                                      {"_id": 0, "app_id": 1, "name": 1, "logo_url": 1, "privacy_policy_url": 1})
            .sort("name", 1).limit(200)]


@router.get("/consent-info")
def consent_info(app_id: Optional[str] = Query(default=None, max_length=128), patient: dict = Depends(current_patient)):
    if app_id:
        app_doc = _visible_app(app_id, patient)
        scopes = [s for s in app_doc.get("requested_scopes", []) if s in app_doc.get("granted_scopes", [])]
        partner = {"app_id": app_id, "name": app_doc.get("name"), "logo_url": app_doc.get("logo_url"),
                   "privacy_policy_url": app_doc.get("privacy_policy_url")}
    else:
        from app.services.partner.catalog import CONSENT_SCOPES
        scopes, partner = list(CONSENT_SCOPES), None
    docs = repo.tenant_collection(patient["db"], dbmod.TBL_LEGAL_DOCS).find(
        {"type": {"$in": list(WEARABLE_CONSENT_TYPES)}}, {"_id": 0, "version": 1, "path": 1, "created_at": 1}
    ).sort("created_at", -1).limit(1)
    latest = next(iter(docs), None)
    return {"partner": partner, "scopes": link_service.scope_labels(scopes),
            "consent_doc": {"version": str(latest["version"]), "path": latest.get("path")} if latest else None}


@router.post("/pairing-codes", status_code=201)
def create_pairing_code(data: PairingCodeCreate, patient: dict = Depends(current_patient)):
    ratelimit.enforce(f"pair-create:{patient['tenant_db']}:{patient['patient_id']}", 10, 3600,
                      detail="Demasiados códigos generados; espera antes de pedir otro")
    partner = None
    scopes = set(data.scopes)
    if not data.app_id and not patient["sandbox"]:
        raise PartnerProblem(422, slug="partner-required",
                             detail="El consentimiento debe nombrar al fabricante (app_id)")
    if data.app_id:
        app_doc = _visible_app(data.app_id, patient)
        partner = {"app_id": data.app_id, "name": app_doc.get("name"), "logo_url": app_doc.get("logo_url"),
                   "privacy_policy_url": app_doc.get("privacy_policy_url")}
        unknown = scopes - set(app_doc.get("requested_scopes", []))
        if unknown:
            raise PartnerProblem(422, slug="scope-not-requested",
                                 detail=f"El fabricante no solicita: {', '.join(sorted(unknown))}")
    verified = _consent_verified(patient, data.consent_doc_version)
    code = pairing.create_code(patient, "sandbox" if patient["sandbox"] else "production", sorted(scopes),
                               data.consent_doc_version, data.app_id, verified)
    set_audit(event="pairing_code.created")
    return {**code, "partner": partner, "scopes": link_service.scope_labels(sorted(scopes))}


@router.get("/links")
def list_patient_links(patient: dict = Depends(current_patient)):
    docs = repo.links().find({"patient_id": patient["patient_id"], "tenant_db": patient["tenant_db"]}, {"_id": 0}) \
        .sort("created_at", -1).limit(100)
    return [link_service.patient_link_view(link) for link in docs]


@router.patch("/links/{link_id}")
def update_link_scopes(link_id: str, data: LinkScopesUpdate, patient: dict = Depends(current_patient)):
    link = _patient_link(patient, link_id)
    link_service.require_active(link)
    new_scopes = sorted(set(data.scopes))
    if not set(new_scopes) <= set(link.get("granted_scopes", [])):
        raise PartnerProblem(422, slug="scope-expansion",
                             detail="Solo se pueden retirar permisos; para concederlos de nuevo vincula otra vez")
    if new_scopes != sorted(link.get("granted_scopes", [])):
        repo.links().update_one({"link_id": link_id}, {"$set": {"granted_scopes": new_scopes,
                                                               "scopes_changed_at": datetime.now(timezone.utc)}})
        webhooks.dispatch(link["app_id"], "link.scopes_changed", {
            "link_id": link_id, "external_user_id": link["external_user_id"], "granted_scopes": new_scopes,
            "removed_scopes": sorted(set(link["granted_scopes"]) - set(new_scopes))})
        link["granted_scopes"] = new_scopes
    return link_service.patient_link_view(link)


@router.delete("/links/{link_id}", status_code=204)
def revoke_patient_link(link_id: str, delete_data: bool = Query(default=False), patient: dict = Depends(current_patient)):
    link = _patient_link(patient, link_id)
    if link["status"] == "active" or delete_data:
        link_service.revoke(link, "patient", delete_data)
    return Response(status_code=204)
