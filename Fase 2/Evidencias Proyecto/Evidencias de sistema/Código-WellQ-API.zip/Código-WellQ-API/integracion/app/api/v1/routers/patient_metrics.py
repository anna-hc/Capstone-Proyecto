# app/api/v1/routers/patient_metrics.py
from fastapi import APIRouter, Body, HTTPException, Header, Query
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Union, Set, Optional, Any, Dict
from datetime import datetime
import hmac, hashlib, re

from app.db import db
from app.repositories import metrics_repo
import app.config as conf
from app.utils.search_utils import (
    require_ingest_api_key,
    resolve_rut_norm_from_any,
    ensure_pacientes_exist_by_rut_norm
)
from app.dependencies import RoleChecker
from fastapi import Depends

# Re-export for backward compatibility (painmap.py imports PSFSItemIn from here)
from app.models.patient_checkins import PSFSItemIn  # noqa: F401

import logging
from app.logging_conf import get_logger
log = get_logger("API/METRICS")

router = APIRouter(prefix="/metrics", tags=["metrics"])

API_KEY = conf.INGEST_API_KEY

# ---------- Helpers de validación ----------
_STRIP_NON_ALNUM = re.compile(r"[^A-Za-z0-9]")

def _normalize_rut(r: str) -> str:
    return _STRIP_NON_ALNUM.sub("", (r or "").strip()).upper()

def _extract_pacientes_ids(docs: List["MetricIn"]) -> Set[str]:
    ids: Set[str] = set()
    for d in docs:
        user_id = resolve_rut_norm_from_any(d.patient_id)
        if user_id:
            ids.add(user_id)
    return ids

def _ensure_pacientes_existen(paciente_ids: Set[str]) -> None:
    ensure_pacientes_exist_by_rut_norm(paciente_ids)

def _safelog(label: str, value: str | None):
    # No exponer secretos: sólo longitud y hash truncado
    v = value or ""
    sha = hashlib.sha256(v.encode("utf-8")).hexdigest()
    log.info("[API][TS][KEY][%s] len=%d sha256=%s", label, len(v), sha[:12], extra={"tag": "API"})

def _require_api_key(x_api_key: str | None):
    if not conf.LEGACY_INGEST_API_KEY_ENABLED:
        raise HTTPException(status_code=401, detail="API key deshabilitada; usa el token del paciente.")
    if not API_KEY:
        # sin clave configurada solo se tolera en desarrollo: fuera de él la ingesta falla cerrada
        if (conf.APP_ENV or "").lower() in conf.DEV_APP_ENVS:
            return
        log.error("[API][TS][INGEST][DENY] INGEST_API_KEY no configurada", extra={"tag": "API"})
        raise HTTPException(status_code=503, detail="Ingesta no configurada.")
    if not x_api_key:
        log.warning("[API][TS][INGEST][DENY] missing api-key", extra={"tag": "API"})
        raise HTTPException(status_code=401, detail="API key inválida.")
    # Comparación constante + strip en ambos lados
    if not hmac.compare_digest(x_api_key.strip(), API_KEY):
        log.warning("[API][TS][INGEST][DENY] bad api-key", extra={"tag": "API"})
        raise HTTPException(status_code=401, detail="API key inválida.")


def _format_ts(ts: datetime) -> str:
    return ts.isoformat(timespec='milliseconds' if ts.microsecond!=0.0 else 'seconds').replace('+00:00', 'Z')


def _safe_parse_iso(ts_str: str | None) -> datetime | None:
    if not ts_str:
        return None
    try:
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    except ValueError:
        log.warning("[API][METRICS][PARSE_ERR] invalid isoformat: %s", ts_str, extra={"tag": "API"})
        return None


# ---------- Modelos ----------
class MetricMeta(BaseModel):
    paciente_id: str = Field(..., description="ID normalizado (A-Z/0-9), sin separadores. Ej: CL12345678K o UKJOHNDOE19900817SW1A1AA")
    metric: str = Field(..., min_length=2)
    unidad: str = Field(..., min_length=1)
    model_config = ConfigDict(extra='allow') #Campos adicionales si es que existen

def _meta_additional_fields(meta: "MetricMeta") -> dict:
    """
    Retorna los campos adicionales en meta (distintos de paciente_id, metric, unidad).
    Soporta Pydantic v2 (usa __pydantic_extra__ y/o model_dump).
    """
    base_keys = {"healthkit_device"}
    extra = {}

    # 1) Extra oficial de Pydantic v2
    if hasattr(meta, "__pydantic_extra__") and meta.__pydantic_extra__:
        extra.update(dict(meta.__pydantic_extra__))

    # 2) Por si acaso, dumpeamos y restamos los campos base
    for k, v in meta.model_dump(exclude_none=True).items():
        if k not in base_keys:
            extra[k] = v
    return extra

class MetricIn_old(BaseModel):
    ts: str = Field(..., description="ISO8601 con Z. Ej: 2025-09-25T17:00:00Z")
    meta: MetricMeta
    value: float

    def to_doc(self) -> dict:
        user_id = resolve_rut_norm_from_any(self.meta.paciente_id)
        if not user_id:
            raise ValueError("Invalid paciente_id (expected 'P-XXXXXXXXXXXX' or resolvable _id)")
        extras = _meta_additional_fields(self.meta)
        if extras:
            logging.getLogger(__name__).info(
                "[API][TS][META_EXTRA] paciente_id=%s keys=%s",
                user_id, sorted(list(extras.keys())), extra={"tag": "API"}
            )

        meta_doc = {
            "paciente_id": user_id,                       
            "metric": self.meta.metric.strip().lower(),
            "unidad": self.meta.unidad.strip(),
            **extras,                               
        }
        return {
            "ts": datetime.fromisoformat(self.ts.replace("Z", "+00:00")),
            "meta": meta_doc,
            "value": float(self.value),
        }

class MetricIn(BaseModel):
    from_ts: str = Field(..., description="ISO8601 con Z. Ej: 2025-09-25T17:00:00Z")
    to_ts: Optional[str] = Field(None, description="ISO8601 con Z. Ej: 2025-09-25T17:00:00Z")
    patient_id: str = Field(..., description="ID normalizado (A-Z/0-9), sin separadores. Ej: CL12345678K o UKJOHNDOE19900817SW1A1AA")
    provider: str = Field(..., description="Provider name")
    sensors: Dict[str, Any] = Field(..., description="Sensor data")
    # Total diario canónico (ver health_batch_service._sendDailyStepsDoc en la app):
    # `metric_date` = día local YYYY-MM-DD; `idempotency_key` permite hacer upsert
    # para que los reenvíos del mismo día/provider reemplacen en vez de duplicar.
    metric_date: Optional[str] = Field(None, description="Día local YYYY-MM-DD del total diario")
    idempotency_key: Optional[str] = Field(None, description="Clave para upsert de totales diarios")

    def to_doc(self) -> Optional[dict]:
        user_id = resolve_rut_norm_from_any(self.patient_id)
        if not user_id:
            log.error("[API][METRICS][TO_DOC_ERR] Invalid patient_id: %s", self.patient_id, extra={"tag": "API"})
            return None

        from_dt = _safe_parse_iso(self.from_ts)
        if not from_dt:
            # from_ts is mandatory for a valid record
            log.error("[API][METRICS][TO_DOC_ERR] Invalid from_ts for patient=%s: %s", user_id, self.from_ts, extra={"tag": "API"})
            return None

        doc = {
            "from_ts": from_dt,
            "to_ts": _safe_parse_iso(self.to_ts),
            "provider": self.provider,
            "sensors": self.sensors,
            "patient_id": user_id,
            "meta": {
                "paciente_id": user_id,
            }
        }
        if self.metric_date:
            doc["metric_date"] = self.metric_date
        if self.idempotency_key:
            # Namespaced con el patient_id normalizado para evitar colisiones.
            doc["idempotency_key"] = f"{user_id}|{self.idempotency_key}"
        return doc

class IngestOut(BaseModel):
    ok: bool
    inserted: int
    ids: List[str] = []

def _coerce(payload: Union[MetricIn, List[MetricIn], MetricIn_old, List[MetricIn_old]]) -> Union[List[MetricIn], List[MetricIn_old]]:
    return payload if isinstance(payload, list) else [payload]

class LastMetricsOut(BaseModel):
    body_weight: Optional[dict] = None
    heart_rate: Optional[dict] = None
    steps: Optional[dict] = None
    body_height: Optional[dict] = None
    blood_oxygen: Optional[dict] = None

# ---------- Endpoint ----------
@router.post("", response_model=IngestOut, summary="Ingesta de métricas (single o batch)")
def ingest_metrics(
    payload: Union[MetricIn, List[MetricIn], MetricIn_old, List[MetricIn_old]] = Body(...),
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    authorization: str | None = Header(default=None),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key") ):
    docs_in = _coerce(payload)
    if not docs_in:
        raise HTTPException(status_code=400, detail="Payload vacío")

    if x_api_key is None and authorization and authorization.lower().startswith("bearer "):
        # credencial por cliente: con el JWT del paciente solo puede enviar sus propias métricas
        from app.utils.authaa_utils import get_patient_from_token
        _poid, pac = get_patient_from_token(authorization)
        own_id = resolve_rut_norm_from_any(pac.get("patient_id") or (pac.get("ids") or {}).get("patient_id") or str(_poid))
        for item in docs_in:
            item_pid = item.patient_id if isinstance(item, MetricIn) else item.meta.paciente_id
            if resolve_rut_norm_from_any(item_pid) != own_id:
                raise HTTPException(status_code=403, detail="patient_id no coincide con el token")
    else:
        _require_api_key(x_api_key)

    if idempotency_key and len(docs_in) == 1 and isinstance(docs_in[0], MetricIn) and not docs_in[0].idempotency_key:
        docs_in[0].idempotency_key = idempotency_key[:128]

    # Encolar el trabajo en RQ (no ejecutamos inserción dentro del request)
    from app.services.task_service import enqueue_metrics
    items = [m.model_dump() for m in docs_in]
    job_id = enqueue_metrics(items)

    # Devolvemos 202 + job_id (sin bloquear al cliente)
    return IngestOut(ok=True, inserted=0, ids=[job_id])


@router.get("/peek", dependencies=[Depends(RoleChecker(["clinadmin", "itadmin"]))])
def debug_peek( paciente_id: str | None = Query(default=None),
    metric: str | None = Query(default=None) ):
    q = {}
    if paciente_id:
        user_id = resolve_rut_norm_from_any(paciente_id)
        if user_id:
            q["patient_id"] = user_id
    if metric: 
        q[f"sensors.{metric.strip()}"] = {"$exists": True}

    total = metrics_repo.count(q)
    last_doc = metrics_repo.find_one(q, sort=[("from_ts", -1)])

    if last_doc and "_id" in last_doc:
        last_doc["_id"] = str(last_doc["_id"])

    return {
        "db": db.name,
        "collections": sorted(db.list_collection_names()),
        "query": q,
        "count": total,
        "last": last_doc
    }


@router.get("/metrics_history/steps", summary="Fetch historical steps metrics for the authenticated patient")
def get_steps_history( page: int = Query(1, ge=1), limit: int = Query(50, ge=1, le=500),
    since: Optional[datetime] = Query(None, description="ISO timestamp to filter records"),
    authorization: Optional[str] = Header(None, alias="Authorization") ):
    from app.utils.authaa_utils import get_patient_from_token
    _patient_oid, pac_doc = get_patient_from_token(authorization)

    rut_norm = resolve_rut_norm_from_any(pac_doc.get("patient_id") or pac_doc.get("rut_norm") or pac_doc.get("ids", {}).get("patient_id"))
    if not rut_norm:
        raise HTTPException(status_code=401, detail="Patient missing rut_norm")

    query = {"patient_id": rut_norm}
    if since:
        query["from_ts"] = {"$gte": since}

    cursor = metrics_repo.find_many(query, sort_field=[("from_ts", -1)])
    
    items = []
    for doc in cursor:
        val = None
        sensors = doc.get("sensors") or {}
        if "steps" in sensors:
            val = sensors["steps"]
        else:
            for provider_key, provider_data in sensors.items():
                if isinstance(provider_data, dict) and provider_data.get("metric") == "steps":
                    val = provider_data
                    break
        if val is not None:
            items.append({
                "from_ts": _format_ts(doc["from_ts"]),
                "to_ts": _format_ts(doc["to_ts"]) if doc.get("to_ts") else None,
                "provider": doc.get("provider"),
                "steps": val
            })
            
    total = len(items)
    start_idx = (page - 1) * limit
    end_idx = start_idx + limit
    paginated_items = items[start_idx:end_idx]
    
    return {
        "items": paginated_items,
        "total": total,
        "page": page,
        "limit": limit
    }


@router.get("/metrics_history/heart_rate", summary="Fetch historical heart rate metrics for the authenticated patient")
def get_heart_rate_history( page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=500), since: Optional[datetime] = Query(None, description="ISO timestamp to filter records"),
    authorization: Optional[str] = Header(None, alias="Authorization") ):
    from app.utils.authaa_utils import get_patient_from_token
    _patient_oid, pac_doc = get_patient_from_token(authorization)

    rut_norm = resolve_rut_norm_from_any(pac_doc.get("patient_id") or pac_doc.get("rut_norm") or pac_doc.get("ids", {}).get("patient_id"))
    if not rut_norm:
        raise HTTPException(status_code=401, detail="Patient missing rut_norm")

    query = {
        "$or": [
            {"patient_id": rut_norm},
            {"sen.paciente_id": rut_norm},
            {"meta.paciente_id": rut_norm},
            {"meta.patient_id": rut_norm}
        ]
    }
    if since:
        query = {
            "$and": [
                {
                    "$or": [
                        {"patient_id": rut_norm},
                        {"sen.paciente_id": rut_norm},
                        {"meta.paciente_id": rut_norm},
                        {"meta.patient_id": rut_norm}
                    ]
                },
                {
                    "$or": [
                        {"from_ts": {"$gte": since}},
                        {"ts": {"$gte": since}}
                    ]
                }
            ]
        }

    cursor = metrics_repo.find_many(query, sort_field=[("from_ts", -1), ("ts", -1)])
    
    items = []
    for doc in cursor:
        hr = None
        sensors = doc.get("sensors") or {}
        if "heart_rate" in sensors:
            hr = sensors["heart_rate"]
        else:
            for provider_key, provider_data in sensors.items():
                if isinstance(provider_data, dict) and provider_data.get("metric") == "heart_rate":
                    hr = provider_data
                    break
        if hr is None:
            if "heart_rate" in doc:
                hr = doc["heart_rate"]
            elif isinstance(doc.get("meta"), dict):
                meta = doc["meta"]
                if meta.get("metric") == "heart_rate":
                    hr = {"value": doc.get("value")}
                elif "heart_rate" in meta:
                    hr = meta["heart_rate"]
                    
        if hr is not None:
            ts = doc.get("from_ts") or doc.get("ts")
            items.append({
                "from_ts": _format_ts(ts) if ts else None,
                "to_ts": _format_ts(doc["to_ts"]) if doc.get("to_ts") else None,
                "provider": doc.get("provider"),
                "heart_rate": hr
            })
            
    total = len(items)
    start_idx = (page - 1) * limit
    end_idx = start_idx + limit
    paginated_items = items[start_idx:end_idx]
    
    return {
        "items": paginated_items,
        "total": total,
        "page": page,
        "limit": limit
    }


@router.get( "/metrics_history/{metric_type}", summary="Return the history of metrics")
def get_metrics_history(metric_type: str, page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=500), since: Optional[datetime] = Query(None, description="ISO timestamp to filter records"),
    authorization: Optional[str] = Header(None, alias="Authorization") ):
    from app.utils.authaa_utils import get_patient_from_token
    _patient_oid, pac_doc = get_patient_from_token(authorization)
    rut_norm = resolve_rut_norm_from_any(pac_doc.get("patient_id") or pac_doc.get("rut_norm") or pac_doc.get("ids", {}).get("patient_id"))
    
    # 4) traer los últimos datos de cada metrica 
    metrics = ['body_weight', 'heart_rate', 'steps', 'body_height', 'sleep', 'blood_oxygen']

    if metrics.count(metric_type) ==  0:
        raise HTTPException(status_code=500, detail=f"Error querying not existant metric {metric_type} type")
    
    query = {"patient_id": rut_norm}
    if since:
        query["from_ts"] = {"$gte": since}
        
    cursor = metrics_repo.find_many(query, sort_field=[("from_ts", -1)])

    items = []
    for doc in cursor:
        val = None
        sensors = doc.get("sensors") or {}
        if metric_type in sensors:
            val = sensors[metric_type]
        else:
            for provider_key, provider_data in sensors.items():
                if isinstance(provider_data, dict) and provider_data.get("metric") == metric_type:
                    val = provider_data
                    break
        if val is not None:
            items.append({
                "from_ts": _format_ts(doc["from_ts"]),
                "to_ts": _format_ts(doc["to_ts"]) if doc.get("to_ts") else None,
                "provider": doc.get("provider"),
                metric_type: val
            })
            
    total = len(items)
    start_idx = (page - 1) * limit
    end_idx = start_idx + limit
    paginated_items = items[start_idx:end_idx]
    
    return {
        "items": paginated_items,
        "total": total,
        "page": page,
        "limit": limit
    }


@router.get( "/last_checkins", response_model=LastMetricsOut, response_model_exclude_none=True, 
    summary="Return the last check-ins for the metrics" )
def get_last_checkins( paciente_id: str | None = Query(default=None),
    x_api_key: str | None = Header(default=None, alias="X-API-Key") ) -> LastMetricsOut:
    # require_ingest_api_key(x_api_key)

    rut_norm = resolve_rut_norm_from_any(paciente_id)
    if not rut_norm:
        raise HTTPException(status_code=400, detail="Missing or invalid user_id (rut_norm)")

    ensure_pacientes_exist_by_rut_norm({rut_norm})

    try:
        from app.queries import patient_evolution_query_service
        results_list = patient_evolution_query_service.get_last_checkins(rut_norm)
        if not results_list:
            raise HTTPException(status_code=404, detail="No metrics found for the patient")
        
        values = {result["_id"]: {"timestamp": _format_ts(result["ts_recent"])} for result in results_list}
    except HTTPException:
        raise
    except Exception as e:
        log.exception("[API][CHKIN][ERROR] %s", e, extra={"tag": "API"})
        raise HTTPException(status_code=500, detail="Error querying the last metrics")

    log.info(f"[API][CHKIN][OK] rut={rut_norm}", extra={"tag":"API"})
    return LastMetricsOut(**values)

