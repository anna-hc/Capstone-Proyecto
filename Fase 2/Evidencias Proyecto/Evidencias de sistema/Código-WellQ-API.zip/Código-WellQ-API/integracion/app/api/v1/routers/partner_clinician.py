from datetime import datetime, timezone

from fastapi import APIRouter, Depends

from app.models.partner import IngestConfigUpdate
from app.repositories import partner as repo
from app.services.partner import catalog, links as link_service, webhooks
from app.services.partner.deps import clinician_patient
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit

router = APIRouter(prefix="/maindash/patient/{patient_id}/wearables", tags=["Patient App (internal)"],
                   route_class=PartnerRoute)


def _links(patient: dict) -> list[dict]:
    return list(repo.links().find({"patient_id": patient["patient_id"], "tenant_db": patient["tenant_db"]}, {"_id": 0})
                .sort("created_at", -1).limit(100))


@router.get("")
def get_patient_wearables(patient: dict = Depends(clinician_patient)):
    return [link_service.patient_link_view(link, include_sync=True) for link in _links(patient)]


@router.put("/{link_id}/ingest-config")
def update_ingest_config(link_id: str, data: IngestConfigUpdate, patient: dict = Depends(clinician_patient)):
    link = repo.links().find_one({"link_id": link_id, "patient_id": patient["patient_id"],
                                  "tenant_db": patient["tenant_db"]}, {"_id": 0})
    if not link:
        raise PartnerProblem(404, detail="Vínculo no encontrado")
    link_service.require_active(link)
    unknown = sorted(set(data.intervals) - catalog.KNOWN_METRICS)
    if unknown:
        raise PartnerProblem(422, slug="validation", title="Validation failed",
                             errors=[{"path": "intervals", "message": f"métricas no reconocidas: {', '.join(unknown)}"}])
    intervals = dict((link.get("ingest_config") or {}).get("intervals", {}))
    for metric, seconds in data.intervals.items():
        if seconds is None:
            intervals.pop(metric, None)
        else:
            intervals[metric] = seconds
    repo.links().update_one({"link_id": link_id}, {"$set": {"ingest_config": {
        "intervals": intervals, "updated_at": datetime.now(timezone.utc)}}})
    link["ingest_config"] = {"intervals": intervals}
    config = link_service.effective_config(link)
    set_audit(link_id=link_id, app_id=link["app_id"], event="link.config_changed")
    webhooks.dispatch(link["app_id"], "link.config_changed", {"link_id": link_id,
                                                              "external_user_id": link["external_user_id"],
                                                              "ingest_config": config})
    return {"link_id": link_id, "ingest_config": config}
