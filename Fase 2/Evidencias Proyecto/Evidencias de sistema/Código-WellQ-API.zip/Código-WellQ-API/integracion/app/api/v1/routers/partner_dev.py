from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import jwt
from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Request
from fastapi.responses import FileResponse, RedirectResponse

import app.config as conf
from app.models.partner import DevPatientSession
from app.repositories import partner as repo
from app.services.partner.deps import demo_enabled, dev_tools_enabled
from app.services.partner.problems import PartnerProblem, PartnerRoute
from app.services.partner.tenancy import SANDBOX_TENANT, sandbox_db

DEMO_DIR = Path(__file__).resolve().parents[3] / "partner_demo"
DEMO_FILES = {"index.html": "text/html; charset=utf-8", "demo.js": "text/javascript; charset=utf-8",
              "demo.css": "text/css; charset=utf-8"}
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")


def _require_dev() -> None:
    # doble barrera: aunque el router se haya montado, cada petición vuelve a mirar el flag y el entorno
    if not dev_tools_enabled():
        raise PartnerProblem(404, detail="No encontrado")


def _require_demo() -> None:
    if not demo_enabled():
        raise HTTPException(status_code=404)


dev_router = APIRouter(prefix="/partner-dev", tags=["Partner dev tools"], route_class=PartnerRoute,
                       dependencies=[Depends(_require_dev)], include_in_schema=False)
demo_router = APIRouter(prefix="/partner-demo", tags=["Partner demo"], dependencies=[Depends(_require_demo)],
                        include_in_schema=False)


def _wellq_jwt(sub: str, extra: dict, minutes: int = 60) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": sub, "iat": int(now.timestamp()), "exp": int((now + timedelta(minutes=minutes)).timestamp()),
               "iss": "WELLQ", "type": "access", "tenant_slug": SANDBOX_TENANT, "dev_tools": True, **extra}
    return jwt.encode(payload, conf.JWT_SECRET, algorithm=conf.JWT_ALG)


@dev_router.post("/patient-session")
def dev_patient_session(data: Optional[DevPatientSession] = Body(default=None)):
    from app.api.v1.routers.partner_sandbox import create_sandbox_patient
    data = data or DevPatientSession()
    existing = repo.sandbox_patients().find_one({"external_ref": data.external_ref}) if data.external_ref else None
    if existing:
        patient = {"oid": ObjectId(existing["patient_oid"]), "patient_id": existing["patient_id"]}
    else:
        patient = create_sandbox_patient("generic", None)
        if data.external_ref:
            repo.sandbox_patients().update_one({"patient_id": patient["patient_id"]},
                                               {"$set": {"external_ref": data.external_ref}})
    token = _wellq_jwt(str(patient["oid"]), {"roles": ["patient"], "scope": "mobile", "patient_id": patient["patient_id"]})
    return {"patient_id": patient["patient_id"], "access_token": token, "token_type": "Bearer", "expires_in": 3600}


@dev_router.post("/clinician-session")
def dev_clinician_session(patient_id: str = Body(..., embed=True, max_length=64)):
    clinician_oid = ObjectId()
    result = repo.tenant_collection(sandbox_db(), "patients").update_one(
        {"patient_id": patient_id, "metadata.source": "partner_sandbox"},
        {"$addToSet": {"authorized_clinicians": clinician_oid}})
    if not result.matched_count:
        raise PartnerProblem(404, detail="Paciente sintético no encontrado")
    token = _wellq_jwt(str(clinician_oid), {"roles": ["clinician"], "subject": {"kind": "clinician", "id": str(clinician_oid)}})
    return {"access_token": token, "token_type": "Bearer", "expires_in": 3600}


_sink: deque = deque(maxlen=50)


@dev_router.post("/webhook-sink")
async def webhook_sink(request: Request):
    body = (await request.body())[:65536]
    _sink.append({"received_at": datetime.now(timezone.utc).isoformat(), "event": request.headers.get("x-wellq-event"),
                  "signature": request.headers.get("x-wellq-signature"), "body": body.decode("utf-8", "replace")})
    return {"received": True}


@dev_router.get("/webhook-sink")
def webhook_sink_list():
    return list(_sink)


@dev_router.post("/admin-session")
def dev_admin_session():
    # rol propio, desconocido para el resto de la app: este token no sirve en ninguna ruta de administración existente
    token = _wellq_jwt("partner-dev-admin", {"roles": ["partner_admin_dev"]}, minutes=30)
    return {"access_token": token, "token_type": "Bearer", "expires_in": 1800}


@demo_router.get("")
def demo_root():
    return RedirectResponse(url="partner-demo/", status_code=307)


@demo_router.get("/{name}")
@demo_router.get("/", name="partner_demo_index")
def demo_file(name: str = "index.html"):
    if name not in DEMO_FILES:
        raise HTTPException(status_code=404)
    return FileResponse(DEMO_DIR / name, media_type=DEMO_FILES[name], headers={
        "Content-Security-Policy": CSP, "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer", "Cache-Control": "no-store",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()"})
