from datetime import date, datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Query

import app.config as conf
import app.db as dbmod
from app.repositories import partner as repo
from app.services.partner import ingest, links as link_service, scoring
from app.services.partner.deps import require_scopes
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit
from app.services.partner.tenancy import link_db

router = APIRouter(prefix="/partner/links", tags=["Read (scoped)"], route_class=PartnerRoute)
SCORE_TYPES = {"activity", "sleep", "adherence", "stability"}


def _readable_link(app_doc: dict, link_id: str, scope: str) -> dict:
    link = link_service.get_owned_link(app_doc, link_id)
    link_service.require_active(link)
    link_service.require_patient_active(link)
    if scope not in link.get("granted_scopes", []):
        raise PartnerProblem(403, slug="insufficient-scope", title="Insufficient scope",
                             detail=f"Link {link_id} does not grant {scope}", required_scope=scope)
    set_audit(link_id=link_id)
    return link


def patient_goals(tdb, patient_id: str) -> dict:
    goals_doc = repo.tenant_collection(tdb, dbmod.TBL_PATIENT_GOALS).find_one(
        {"patient_id": patient_id}, {"health_goals": 1, "metric_goals": 1, "updated_at": 1}) or {}
    health = goals_doc.get("health_goals") or {}
    return {
        "health_goals": {
            "exercise_target_count_week": health.get("exercise_target_count_week"),
            "sleep_target_hours_night": health.get("sleep_target_hours_night"),
            "steps_target_day": health.get("steps_target_day") or conf.PARTNER_DEFAULT_STEPS_TARGET,
        },
        "metric_goals": [{"metric_type": g.get("metric_type"), "target_exercises_per_week": g.get("target_exercises_per_week")}
                         for g in (goals_doc.get("metric_goals") or [])[:50] if isinstance(g, dict)],
        "updated_at": goals_doc.get("updated_at"),
    }


def prescribed_exercises(tdb, patient_id: str) -> list[dict]:
    now = datetime.now(timezone.utc)
    programs = list(repo.tenant_collection(tdb, dbmod.TBL_PATIENT_PROGRAMS).find(
        {"patient_id": patient_id, "$or": [{"active_until": None}, {"active_until": {"$gt": now}}]},
        {"template_ids": 1}).limit(10))
    template_ids = [t for p in programs for t in (p.get("template_ids") or [])][:20]
    if not template_ids:
        return []
    out, codes = [], []
    for tpl in repo.tenant_collection(tdb, dbmod.TBL_PROGRAM_TEMPLATES).find(
            {"template_id": {"$in": template_ids}}, {"exercises": 1}).limit(20):
        for ex in (tpl.get("exercises") or [])[:100]:
            code = ex.get("eje_cod") or ex.get("exercise_id")
            if code:
                codes.append(code)
                out.append({"wellq_exercise_code": code, "target_sets": ex.get("sets"), "target_reps": ex.get("reps")})
    names = {c["eje_cod"]: c for c in repo.tenant_collection(tdb, dbmod.TBL_EXERCISES_CATALOG).find(
        {"eje_cod": {"$in": codes}}, {"eje_cod": 1, "eje_nom": 1, "primary_zone": 1})}
    for item in out:
        cat = names.get(item["wellq_exercise_code"], {})
        item["name"] = cat.get("eje_nom") or item["wellq_exercise_code"]
        item["body_region"] = cat.get("primary_zone")
        item["target_sessions_per_week"] = None
    return out[:100]


@router.get("/{link_id}/goals")
def get_goals(link_id: str, app_doc: dict = Depends(require_scopes("read:goals"))):
    link = _readable_link(app_doc, link_id, "read:goals")
    tdb = link_db(link)
    goals = patient_goals(tdb, link["patient_id"])
    return {"link_id": link_id, "health_goals": goals["health_goals"], "metric_goals": goals["metric_goals"],
            "prescribed_exercises": prescribed_exercises(tdb, link["patient_id"]), "updated_at": goals["updated_at"]}


def compute_scores(link_ids: list[str], tdb, patient_id: str, from_date: date, to_date: date, wanted: set[str]) -> list[dict]:
    window_start = (from_date - timedelta(days=7)).isoformat()
    summaries = ingest.partner_docs(repo.tenant_collection(tdb, dbmod.TBL_METRICS), link_ids,
                                    {"partner_kind": "daily_summary",
                                     "metric_date": {"$gte": window_start, "$lte": to_date.isoformat()}},
                                    {"_id": 0, "metric_date": 1, "partner_summary": 1, "source_quality": 1,
                                     "completeness": 1})
    start_dt = datetime.combine(from_date - timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc)
    end_dt = datetime.combine(to_date + timedelta(days=2), datetime.min.time(), tzinfo=timezone.utc)
    workouts = ingest.partner_docs(repo.tenant_collection(tdb, dbmod.TBL_PATIENT_WEARABLE_WORKOUTS), link_ids,
                                   {"start_at": {"$gte": start_dt, "$lt": end_dt}}, {"_id": 0, "start_at": 1})
    events = ingest.partner_docs(repo.tenant_collection(tdb, dbmod.TBL_DEVICE_EVENTS), link_ids,
                                 {"timestamp": {"$lt": end_dt}, "event_type": {"$in": ["worn", "removed"]}},
                                 {"_id": 0, "timestamp": 1, "event_type": 1}, sort=[("timestamp", -1)], limit=2000)
    goals = patient_goals(tdb, patient_id)["health_goals"]
    days, current = [], from_date
    while current <= to_date:
        days.append(scoring.daily_scores(current.isoformat(), summaries, workouts, events, goals, wanted,
                                         int(goals["steps_target_day"])))
        current += timedelta(days=1)
    return days


def parse_range(from_date: date, to_date: date, max_days: int = 90) -> None:
    if to_date < from_date:
        raise PartnerProblem(422, slug="validation", title="Validation failed",
                             errors=[{"path": "to_date", "message": "debe ser igual o posterior a from_date"}])
    if (to_date - from_date).days + 1 > max_days:
        raise PartnerProblem(422, slug="range-too-large", detail=f"Máximo {max_days} días por consulta")


@router.get("/{link_id}/scores")
def get_scores(link_id: str, from_date: date = Query(...), to_date: date = Query(...),
               types: Optional[str] = Query(default=None, max_length=64),
               app_doc: dict = Depends(require_scopes("read:scores"))):
    parse_range(from_date, to_date)
    wanted = set(types.split(",")) if types else set(SCORE_TYPES)
    if not wanted <= SCORE_TYPES:
        raise PartnerProblem(422, slug="validation", title="Validation failed",
                             errors=[{"path": "types", "message": f"valores admitidos: {', '.join(sorted(SCORE_TYPES))}"}])
    link = _readable_link(app_doc, link_id, "read:scores")
    return {"link_id": link_id,
            "days": compute_scores([link_id], link_db(link), link["patient_id"], from_date, to_date, wanted)}
