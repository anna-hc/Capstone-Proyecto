from fastapi import APIRouter, Depends, Form

from app.repositories import partner as repo
from app.services.partner import ratelimit
from app.services.partner.deps import public_rate_limit
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit
from app.services.partner.security import issue_access_token, secret_matches

router = APIRouter(prefix="/partner/oauth", tags=["OAuth"], route_class=PartnerRoute)


@router.post("/token", dependencies=[Depends(public_rate_limit("token", 60))])
def get_token(grant_type: str = Form(..., max_length=32), client_id: str = Form(..., max_length=128),
              client_secret: str = Form(..., max_length=256), scope: str = Form(default="", max_length=512)):
    if grant_type != "client_credentials":
        raise PartnerProblem(400, slug="unsupported-grant-type", detail="grant_type debe ser client_credentials")
    ratelimit.enforce(f"token-client:{client_id}", 30, 60)
    app_doc = repo.apps().find_one({"client_id": client_id}, {"_id": 0})
    if not app_doc or not secret_matches(client_secret, app_doc.get("client_secret_hashes", [])):
        raise PartnerProblem(401, slug="invalid-client", detail="Credenciales inválidas",
                             headers={"WWW-Authenticate": "Basic"})
    set_audit(app_id=app_doc["app_id"], developer_id=app_doc.get("developer_id"), actor="partner")
    if app_doc.get("status") != "active":
        raise PartnerProblem(403, slug="app-inactive", detail="La app no está activa")
    granted = set(app_doc.get("granted_scopes", []))
    requested = set(scope.split()) if scope.strip() else granted
    if not requested.issubset(granted):
        raise PartnerProblem(400, slug="invalid-scope", detail="Se pidieron scopes no concedidos a la app",
                             invalid_scopes=sorted(requested - granted))
    token, expires_in = issue_access_token(app_doc, sorted(requested))
    return {"access_token": token, "token_type": "Bearer", "expires_in": expires_in, "scope": " ".join(sorted(requested))}
