from datetime import datetime, timezone
from typing import Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends

import app.db as dbmod
from app.models.partner import SandboxPatientCreate
from app.repositories import partner as repo
from app.services.partner import catalog, pairing
from app.services.partner.deps import require_scopes
from app.services.partner.problems import PartnerProblem, PartnerRoute
from app.services.partner.security import new_id
from app.services.partner.tenancy import SANDBOX_TENANT, sandbox_db

router = APIRouter(prefix="/partner/sandbox", tags=["Sandbox"], route_class=PartnerRoute)

PROFILE_GOALS = {
    "knee_rehab": {"exercise_target_count_week": 4, "sleep_target_hours_night": 8.0},
    "lower_back": {"exercise_target_count_week": 3, "sleep_target_hours_night": 7.5},
    "shoulder": {"exercise_target_count_week": 3, "sleep_target_hours_night": 8.0},
    "generic": {"exercise_target_count_week": 3, "sleep_target_hours_night": 8.0},
}


def create_sandbox_patient(profile: str, owner_app_id: str | None) -> dict:
    tdb = sandbox_db()
    oid = ObjectId()
    patient_id = "P-SBX" + new_id("x")[-9:].upper()
    now = datetime.now(timezone.utc)
    repo.tenant_collection(tdb, dbmod.TBL_PATIENTS).insert_one({
        "_id": oid, "patient_id": patient_id, "first_name": "Paciente", "last_name": "Sintético", "state": "active",
        "metadata": {"source": "partner_sandbox", "profile": profile, "owner_app_id": owner_app_id}, "created_at": now})
    repo.tenant_collection(tdb, dbmod.TBL_PATIENT_GOALS).update_one(
        {"patient_id": patient_id}, {"$set": {"health_goals": PROFILE_GOALS[profile], "updated_at": now},
                                     "$setOnInsert": {"created_at": now}}, upsert=True)
    repo.sandbox_patients().insert_one({"patient_id": patient_id, "patient_oid": str(oid), "profile": profile,
                                        "owner_app_id": owner_app_id, "created_at": now})
    return {"oid": oid, "patient_id": patient_id, "tenant_slug": SANDBOX_TENANT, "tenant_db": tdb.name}


@router.post("/patients", status_code=201)
def create_sandbox_patient_route(data: Optional[SandboxPatientCreate] = Body(default=None),
                                 app_doc: dict = Depends(require_scopes("links:manage"))):
    if app_doc.get("environment") != "sandbox":
        raise PartnerProblem(403, slug="sandbox-only", detail="Solo disponible para apps en sandbox")
    data = data or SandboxPatientCreate()
    if repo.sandbox_patients().count_documents({"owner_app_id": app_doc["app_id"]}) >= 1000:
        raise PartnerProblem(409, detail="Límite de 1000 pacientes sintéticos por app")
    patient = create_sandbox_patient(data.profile, app_doc["app_id"])
    scopes = list(data.scopes) or list(catalog.CONSENT_SCOPES)
    # el código queda atado a esta app: otra app de sandbox no puede canjearlo
    code = pairing.create_code(patient, "sandbox", scopes, "wearable-sharing-v1", app_doc["app_id"], True)
    return {"sandbox_patient_id": patient["patient_id"], "pairing_code": code["pairing_code"],
            "expires_at": code["expires_at"], "scopes": sorted(set(scopes))}
