import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from bunnet import init_bunnet
from zoneinfo import ZoneInfo
import traceback

import app.config as conf
import app.db as dbmod
from app.logging_conf import setup_logging
# clinical model imports for Bunnet initialization
from app.models.clinical import Patient, Clinician, Clinic, Case, Appointment, ClinicalNote, BodyChart, Intake, DiagnosticCode, DiagnosticSection, PatientProgram
from app.models.ticket import Ticket, TicketCategory, Responder, EmailTemplate, EmailConfig, EmailInfoTicket, Channel
from app.models.alerts import Alert
from app.models.log_models import Action
from app.models.credentials import Credentials
from app.models.media import Media
from app.models.state_rules import StateRuleConfig
from app.models.communications import CommunicationLog, ScheduledRecall
from app.repositories import tenant_repo
from app.tasks.reclassify_job import reclassify_all_tenants
from app.tasks.wibbi_sync_job import sync_missing_wibbi
from app.jobs.metrics_tasks import run_organisation_metrics_sync_job

from app.db import KEY_STATE

log = setup_logging()


def sync_tenant_programs_by_db(tenant_db_name: str):
    from app.jobs.tm3_tasks import sync_tm3_patient_programs_job
    log.info("[SCHEDULER] Running programs sync for database: %s", tenant_db_name)
    try:
        sync_tm3_patient_programs_job({
            "all_tm3_patients": True,
            "tenant_db_name": tenant_db_name
        })
    except Exception as e:
        log.error("[SCHEDULER] Failed to sync programs for database %s: %s", tenant_db_name, e)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ──────────────────────────────────────────────────────────────
    log.info("[STARTUP] App iniciada.", extra={"tag": "API"})
    try:
        models = [
            Patient, Clinician, Clinic, Case, Appointment, ClinicalNote, BodyChart, 
            Intake, DiagnosticCode, DiagnosticSection, Alert, Action, Ticket, 
            TicketCategory, Responder, EmailTemplate, EmailConfig, EmailInfoTicket, 
            Channel, Credentials, Media, StateRuleConfig, PatientProgram,
            CommunicationLog, ScheduledRecall
        ]
        
        # Initialize default DB explicitly
        log.info("[STARTUP] START initialized bunnet", extra={"tag": "API"})
        init_bunnet(database=dbmod.db, document_models=models)
        log.info("[STARTUP] DONE initialized bunnet", extra={"tag": "API"})
        
        # ensure_indexes() ya NO se llama aqui: sobre colecciones grandes la creacion
        # de indices tarda y puede colgar el arranque del servidor. Ejecutar a demanda:
        #   python -m app.scripts.create_indexes --all
        log.info(f"[STARTUP] Default Bunnet initialized with {len(models)} models.", extra={"tag": "API"})
        
        # Iterate over all active tenants and run init_bunnet for index creation.
        # Bunnet's global DB binding will be overridden repeatedly, but it will
        # generate indexes in each tenant DB. Runtime routing uses TenantDocument override.
        log.info("[STARTUP] START tenants registry read", extra={"tag": "API"})
        tenants = tenant_repo.list_active()
        log.info(f"[STARTUP] DONE tenants registry read. Found {len(tenants)} active tenants", extra={"tag": "API"})
        for t in tenants:
            if "mongo_db" in t:
                # Same cluster connection but specific db or tenant-specific client if configured
                from app.middleware.tenant_middleware import get_tenant_client, resolve_tenant_database
                tenant_client = get_tenant_client(t)
                # Ojo: para los tenants sin `mongo_uri` propia se comparte `_client`, cuya
                # cadena de conexion lleva embebida OTRA base por defecto. En ese caso
                # get_default_database() NO lanza excepcion: devuelve la base equivocada
                # en silencio. Por eso hay que comparar el nombre explicitamente.
                tdb = resolve_tenant_database(tenant_client, t["mongo_db"])
                init_bunnet(database=tdb, document_models=models)
                # ensure_indexes() ya NO se llama aqui, ver comentario mas arriba.
                log.info(f"[STARTUP] Init bunnet for tenant: {t.get('slug')}", extra={"tag": "API"})

        # Immediate verification
        try:
            Appointment.get_settings()
            log.info("[STARTUP] Appointment model verification successful.", extra={"tag": "API"})
        except Exception as ve:
             log.error(f"[STARTUP] Appointment model verification FAILED: {ve}", extra={"tag": "API"})
    except Exception as e:
        log.error(f"[STARTUP] Initialization failed: {e}", extra={"tag": "API"})
        traceback.print_exc()

    # ── APScheduler: Database-Driven Scheduler with Memory Fallback ──────────
    use_mongodb_scheduler = False
    try:
        from apscheduler.jobstores.mongodb import MongoDBJobStore
        from app.scheduler.scheduler_manager import scheduler_event_listener, sync_scheduler_jobs
        from apscheduler.events import EVENT_JOB_MISSED
        
        # Check if we can reach central DB and collection has config
        from app.db import _central_client, central_db
        config_coll = central_db["scheduled_jobs_config"]
        
        # Try to find at least one configuration to verify DB readiness
        _ = config_coll.find_one()
        
        # Initialize MongoDB JobStore
        jobstores = {
            'default': MongoDBJobStore(client=_central_client, database=conf.MONGODB_CENTRAL_DB, collection="apscheduler_jobs")
        }
        scheduler = BackgroundScheduler(jobstores=jobstores, timezone="UTC")
        scheduler.add_listener(scheduler_event_listener, EVENT_JOB_MISSED)
        
        # Sync jobs from DB
        sync_scheduler_jobs(scheduler)

        # Add system-wide metrics aggregation job
        scheduler.add_job(
            run_organisation_metrics_sync_job,
            trigger=CronTrigger(hour=3, minute=0),  # Daily at 03:00 UTC
            id="run_organisation_metrics_sync_job",
            name="Run dynamic metrics aggregation for all organisations (daily)",
            replace_existing=True
        )

        # Wake up mobile apps (silent FCM push) to sync wearable data in
        # background, 2x/day. Primary mechanism for iOS (no reliable local
        # background timer there); on Android this complements
        # android_alarm_manager_plus (mobile repo).
        from app.tasks.health_sync_push_job import send_health_sync_push_all_tenants
        scheduler.add_job(
            send_health_sync_push_all_tenants,
            trigger=CronTrigger(hour=0, minute=0),  # Daily at 00:00 UTC
            id="health_sync_push_primary",
            name="Silent push to trigger background health sync (daily 00:00 UTC)",
            replace_existing=True,
        )
        scheduler.add_job(
            send_health_sync_push_all_tenants,
            trigger=CronTrigger(hour=6, minute=0),  # Daily at 06:00 UTC, fallback
            id="health_sync_push_fallback",
            name="Silent push to trigger background health sync (daily 06:00 UTC fallback)",
            replace_existing=True,
        )

        scheduler.start()
        app.state.scheduler = scheduler

        use_mongodb_scheduler = True
        log.info("[STARTUP] APScheduler started successfully with MongoDBJobStore.", extra={"tag": "API"})
        
    except Exception as e:
        log.warning(
            f"[STARTUP] Could not initialize MongoDB APScheduler job store ({e}). Falling back to in-memory scheduler.",
            extra={"tag": "API"}
        )

    if not use_mongodb_scheduler:
        scheduler = BackgroundScheduler(timezone="UTC")
        scheduler.add_job(
            reclassify_all_tenants,
            trigger=CronTrigger(hour="6,14,22", minute=0),   # 06:00, 14:00, 22:00 UTC
            id="periodic_reclassify",
            name="Patient status reclassification (every 8h)",
            replace_existing=True,
        )
        from app.tasks.health_sync_push_job import send_health_sync_push_all_tenants
        scheduler.add_job(
            send_health_sync_push_all_tenants,
            trigger=CronTrigger(hour=0, minute=0),  # Daily at 00:00 UTC
            id="health_sync_push_primary",
            name="Silent push to trigger background health sync (daily 00:00 UTC)",
            replace_existing=True,
        )
        scheduler.add_job(
            send_health_sync_push_all_tenants,
            trigger=CronTrigger(hour=6, minute=0),  # Daily at 06:00 UTC, fallback
            id="health_sync_push_fallback",
            name="Silent push to trigger background health sync (daily 06:00 UTC fallback)",
            replace_existing=True,
        )
        scheduler.add_job(
            run_organisation_metrics_sync_job,
            trigger=CronTrigger(hour=3, minute=0),  # Daily at 03:00 UTC
            id="run_organisation_metrics_sync_job",
            name="Run dynamic metrics aggregation for all organisations (daily)",
            replace_existing=True
        )
        scheduler.add_job(
            sync_missing_wibbi,
            trigger=CronTrigger(hour="3", minute=0),   # 03:00 UTC
            id="sync_missing_wibbi",
            name="Sync missing Wibbi exercises from catalog (daily)",
            replace_existing=True,
        )
        scheduler.add_job(
            sync_tenant_programs_by_db,
            trigger=CronTrigger(hour=20, minute=45, timezone=ZoneInfo("Europe/London")),
            args=["wellq-mayfair"],
            id="sync_programs_mayfair",
            name="Sync TM3/Wibbi programs for wellq-mayfair (daily at 20:45)",
            replace_existing=True,
        )
        scheduler.add_job(
            sync_tenant_programs_by_db,
            trigger=CronTrigger(hour=21, minute=15, timezone=ZoneInfo("Europe/London")),
            args=["wellq-prd-1"],
            id="sync_programs_prod",
            name="Sync TM3/Wibbi programs for wellq-prod (daily at 21:15)",
            replace_existing=True,
        )
        scheduler.add_job(
            sync_tenant_programs_by_db,
            trigger=CronTrigger(hour=21, minute=30, timezone=ZoneInfo("Europe/London")),
            args=["wellq-dev-2"],
            id="sync_programs_dev",
            name="Sync TM3/Wibbi programs for wellq-dev (daily at 21:30)",
            replace_existing=True,
        )
        if conf.APP_ENV not in ("dev", "development"):
            from app.tasks.process_recalls import process_scheduled_recalls
            scheduler.add_job(
                process_scheduled_recalls,
                trigger=CronTrigger(hour=8, minute=0, timezone=ZoneInfo("Europe/London")),
                id="process_scheduled_recalls",
                name="Process scheduled recalls (daily at 8 AM UK)",
                replace_existing=True,
            )
        scheduler.start()
        app.state.scheduler = scheduler
        recalls_log_str = " | scheduled recalls daily at 08:00 Europe/London" if conf.APP_ENV not in ("dev", "development") else ""
        log.info(
            f"[STARTUP] In-memory APScheduler started — reclassify at 06:00, 14:00, 22:00 UTC | wibbi sync at 03:00 UTC{recalls_log_str}.",
            extra={"tag": "API"},
        )

    # Daily engagement snapshot — freezes per-state patient counts + check-ins each day
    # so the Reports "Engagement over time" chart reads stable historical values.
    try:
        from app.tasks.engagement_snapshot import snapshot_all_tenants, retry_missed_tenants
        scheduler.add_job(
            snapshot_all_tenants,
            trigger=CronTrigger(hour=1, minute=0),   # 01:00 UTC — snapshot the previous day
            id="engagement_daily_snapshot",
            name="Engagement daily snapshot (per-state counts + check-ins)",
            replace_existing=True,
        )
        # Second chance a few hours later: only touches tenants still missing
        # yesterday's snapshot (primary run failed/missed), skips the rest.
        scheduler.add_job(
            retry_missed_tenants,
            trigger=CronTrigger(hour=5, minute=0),
            id="engagement_daily_snapshot_retry",
            name="Engagement daily snapshot retry (05:00 UTC, tenants missed at 01:00)",
            replace_existing=True,
        )
        log.info("[STARTUP] Engagement daily snapshot scheduled at 01:00 UTC (retry at 05:00 UTC).", extra={"tag": "API"})
    except Exception as e:
        log.warning(f"[STARTUP] Could not schedule engagement snapshot job: {e}", extra={"tag": "API"})

    # Partner API: entregas de webhooks, jobs de ingesta, supresiones y detección de huecos
    try:
        from app.api.v1.partner_registry import register_partner_scheduler
        register_partner_scheduler(scheduler)
    except Exception as e:
        log.warning(f"[STARTUP] Could not schedule Partner API jobs: {e}", extra={"tag": "API"})

    # WHOOP Direct heart-rate sync — previously only ever run by hand, never
    # scheduled (the actual cause of "Whoop stopped syncing" reports, not a
    # Whoop-side block).
    try:
        from app.tasks.whoop_sync_job import sync_whoop_heart_rate_all_tenants
        scheduler.add_job(
            sync_whoop_heart_rate_all_tenants,
            trigger=CronTrigger(hour=4, minute=0),   # Daily at 04:00 UTC
            id="sync_whoop_heart_rate_all_tenants",
            name="Sync WHOOP Direct heart rate for all tenants (daily)",
            replace_existing=True,
        )
        log.info("[STARTUP] WHOOP Direct heart rate sync scheduled at 04:00 UTC.", extra={"tag": "API"})
    except Exception as e:
        log.warning(f"[STARTUP] Could not schedule WHOOP Direct sync job: {e}", extra={"tag": "API"})

    # KineIA exercise definition generation — drains the `queued` backlog
    # created by GET /kineia/exercises/{eje_cod}/definition on first miss.
    # Without this scheduled, definitions enqueued that way never leave
    # status=queued (see docs/architecture/kineia_exercise_definitions.md).
    try:
        from app.tasks.kineia_definition_generation_job import process_queue_all_tenants
        scheduler.add_job(
            process_queue_all_tenants,
            trigger=CronTrigger(hour="*/2", minute=30),   # Every 2 hours at :30
            id="kineia_process_definition_queue",
            name="Generate/measure queued KineIA exercise definitions (every 2h)",
            replace_existing=True,
        )
        log.info("[STARTUP] KineIA definition queue processing scheduled every 2h.", extra={"tag": "API"})
    except Exception as e:
        log.warning(f"[STARTUP] Could not schedule KineIA definition generation job: {e}", extra={"tag": "API"})

    yield

    # ── Shutdown ──────────────────────────────────────────────────────────────
    scheduler.shutdown(wait=False)
    log.info("[SHUTDOWN] APScheduler stopped.", extra={"tag": "API"})
    log.debug("[SHUTDOWN] App detenida.", extra={"tag": "API"})

app = FastAPI( title=conf.APP_NAME, lifespan=lifespan,
        docs_url=None,    # Disable default /docs
        redoc_url=None,   # Disable default /redoc
        openapi_url=None  # Disable default /openapi.json
    )

from app.middleware.tenant_middleware import TenantMiddleware
app.add_middleware(TenantMiddleware)

def _init_db():
    # Verifica conectividad (Central)
    dbmod.central_db.command("ping")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=conf.CORS_ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],  # GET, POST, PUT, DELETE, OPTIONS...
    allow_headers=["*"],  # Content-Type, Authorization, etc.
    expose_headers=["*"], # si luego expones headers custom
)

# Red de seguridad para cualquier excepcion no capturada por un endpoint.
# El cliente nunca ve el detalle interno (mensaje generico + un id que puede
# reportar); el detalle completo (traceback, ruta, error_id) queda en el log
# server-side bajo el tag ERROR_ID, para que el equipo lo busque. Sin esto,
# un error de un endpoint especifico ya no tumba el proceso (eso lo evita
# FastAPI por si solo para errores DURANTE una request), pero sin este
# handler el cliente veia un 500 con detalle interno de Python/Mongo/etc.
@app.exception_handler(Exception)
async def _unhandled_exception_handler(request, exc: Exception):
    import uuid
    error_id = uuid.uuid4().hex[:12]
    log.error(
        "[ERROR_ID:%s] Unhandled exception on %s %s: %s",
        error_id, request.method, request.url.path, exc,
        exc_info=True, extra={"tag": "UNHANDLED"},
    )
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Something went wrong on our end. Please try again, and "
                       "include this reference if you report it.",
            "error_id": error_id,
        },
    )

# Routers are imported after Bunnet initialization verification
from app.api.v1.routers.auth import router as auth_router
from app.api.v1.routers.auth_phone import router as phone_auth_router
from app.api.v1.routers.keycloak_compat import router as keycloak_router
from app.api.v1.routers.patient_metrics import router as metrics_router
from app.api.v1.routers import lookups as lookups_router
from app.api.v1.routers.topbar import router as topbar_router
from app.api.v1.routers.maindash import router as maindash_router
from app.api.v1.routers import invitations as invitations_router
from app.api.v1.routers.VideoProcess import router as video_router
from app.api.v1.routers.admin_patients import router as admin_patients_router
from app.api.v1.routers import admin_clinicians_crud
from app.api.v1.routers import admin_patients_crud
from app.api.v1.routers import admin_reports
from app.api.v1.routers import patient_wearables
from app.api.v1.routers import admin_specialties
from app.api.v1.routers.diagnoses import router as admin_catalog_router
from app.api.v1.routers.program_templates import router as program_templates_router
from app.api.v1.routers.exercises import router as exercises_router, router_exe
from app.api.v1.routers.exercises import router_shared as exercises_router_shared, router_open as exercises_router_open
from app.api.v1.routers.exercises import router_painmap as exercises_router_painmap
from app.api.v1.routers.exercises import router_body as exercises_router_body
from app.api.v1.routers.kineia_exercises import router as kineia_exercises_router
from app.api.v1.routers.kineia_exercises import router_clinical as kineia_exercises_router_clinical
from app.api.v1.routers.kineia_session_scores import router as kineia_session_scores_router
from app.api.v1.routers import admin_clinic
from app.api.v1.routers.patient_chart_body import router as painmap_router
from app.api.v1.routers.patient_chart_body import router_body as body_router
from app.api.v1.routers.patient_edit import router as editprofile_router
from app.api.v1.routers.notifications import router as notifications_router
from app.api.v1.routers.ActivityLog import router as activity_log_router
from app.api.v1.routers.ActionLog import router as action_log_router
from app.api.v1.routers import patient_metrics_graph
from app.api.v1.routers import cases
from app.api.v1.routers import appointments
from app.api.v1.routers import recall
from app.api.v1.routers import clinical_notes, activities, alerts
from app.api.v1.routers import recording_sessions
from app.api.v1.routers import patients
from app.api.v1.routers import patient_state
from app.api.v1.routers import patient_checkins
from app.api.v1.routers import patient_commitment
from app.api.v1.routers import patient_goals
from app.api.v1.routers import patient_calendar
from app.api.v1.routers import patient_routines
from app.api.v1.routers import patient_workout_logs
from app.api.v1.routers import patient_custom_exercises
from app.api.v1.routers import patient_wearable_workouts
from app.api.v1.routers import patient_exercise_sessions
from app.api.v1.routers import admin_patients_batch
from app.api.v1.routers import intake
from app.api.v1.routers import information
from app.api.v1.routers import clinician_schedule
from app.api.v1.routers import admin_collections, admin_clinicians, admin_clinics
from app.api.v1.routers.ticket import router as ticket_router
from app.api.v1.routers.whoop import router as whoop_router
from app.api.v1.routers.rtm_pose import router as rtm_pose_router
from app.api.v1.routers.tm3_sync import router as tm3_sync_router
from app.api.v1.routers.cliniko_sync import router as cliniko_sync_router
from app.api.v1.routers.pms_sync import router as pms_sync_router
from app.api.v1.routers.state_rules import router as state_rules_router
from app.api.v1.routers.patient_trace import router as patient_trace_router
from app.api.v1.routers import admin_tenants
from app.api.v1.routers.docs_serving import router as docs_serving_router

from fastapi.openapi.utils import get_openapi
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from app.repositories import user_repo
from app.security import verify_password

security = HTTPBasic(realm="WellQ Admin")

def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    email = credentials.username.strip().lower()
    
    # 1. Buscar usuario en BD
    try:
        user = user_repo.find_one({"email_norm": email})
    except Exception as e:
        # En caso de error de conexión, fallamos seguro
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed",
            headers={"WWW-Authenticate": 'Basic realm="WellQ Admin"'},
        )

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": 'Basic realm="WellQ Admin"'},
        )

    # 2. Validar password
    stored_hash = user.get("password_hash")
    if not stored_hash or not verify_password(credentials.password, stored_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": 'Basic realm="WellQ Admin"'},
        )

    # 3. Validar estado y Rol Admin
    if user.get(KEY_STATE) in ("inactive", "created"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Inactive user",
            headers={"WWW-Authenticate": 'Basic realm="WellQ Admin"'},
        )
    
    roles = user.get("roles") or []
    if "admin" not in roles and "clinadmin" not in roles and "itadmin" not in roles:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, # 403 para indicar falta de permisos aunque el login sea OK
            detail="Admin privileges required",
            headers={"WWW-Authenticate": 'Basic realm="WellQ Admin"'},
        )

    return email


@app.get("/docs", include_in_schema=False)
async def get_public_documentation():
    return get_swagger_ui_html(
        openapi_url="/openapi.json", 
        title="Public API Docs",
        swagger_ui_parameters={"defaultModelsExpandDepth": -1}
    )

@app.get("/openapi.json", include_in_schema=False)
async def get_public_openapi():
    if app.openapi_schema:
        # If cache exists but we want to confirm it is the public one?
        # Actually, standard app.openapi() generates the FULL schema.
        # We must generate a subset manually here.
        pass

    # Generate full schema first to get basics
    full_schema = get_openapi(
        title=app.title + " (Public)",
        version=app.version,
        routes=app.routes,
    )

    # 1. Define Security Scheme if missing
    if "components" not in full_schema:
        full_schema["components"] = {}
    if "securitySchemes" not in full_schema["components"]:
        full_schema["components"]["securitySchemes"] = {}
    
    full_schema["components"]["securitySchemes"]["BearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT"
    }
    
    # 2. Apply it globally (Optional, but ensures button is useful)
    # Or just having it in components triggers the button in some versions,
    # but usually you need 'security' at root or path level.
    full_schema["security"] = [{"BearerAuth": []}]
    
    # Filter paths: Keep only those tagged with 'auth' or 'auth/mobile'
    public_paths = {}
    for path, methods in full_schema.get("paths", {}).items():
        # Check if any method in this path has a public tag
        is_public = False
        for method_data in methods.values():
            if isinstance(method_data, dict):
                tags = method_data.get("tags", [])
                if "auth" in tags or "auth/mobile" in tags:
                    is_public = True
                    break
        
        if is_public:
            public_paths[path] = methods

    # Inject x-tenant header parameter into all public endpoints
    tenant_param = {
        "name": "x-tenant",
        "in": "header",
        "required": False,
        "schema": {
            "title": "X-Tenant",
            "type": "string"
        },
        "description": "Tenant slug (e.g., demo-dev, wellq-dev-2, wellq-mayfair)"
    }
    for path, path_item in public_paths.items():
        if not path.startswith("/api/"):
            continue
        for method, operation in path_item.items():
            if isinstance(operation, dict):
                if "parameters" not in operation:
                    operation["parameters"] = []
                existing_names = [p.get("name").lower() for p in operation["parameters"] if isinstance(p, dict) and "name" in p]
                if "x-tenant" not in existing_names:
                    operation["parameters"].append(tenant_param)

    full_schema["paths"] = public_paths
    return JSONResponse(full_schema)


@app.get("/admin/docs", include_in_schema=False)
async def get_admin_documentation(username: str = Depends(get_current_username)):
    base_html = get_swagger_ui_html(
        openapi_url="/admin/openapi.json", 
        title="Admin API Docs",
        swagger_ui_parameters={"defaultModelsExpandDepth": -1}
    )
    
    # Custom JS to inject
    custom_js = """
    <script>
    window.addEventListener('load', function() {
        var checkInterval = setInterval(function() {
            var topbar = document.querySelector('.topbar-wrapper');
            if (topbar) {
                clearInterval(checkInterval);
                var LinkContainer = document.createElement('div');
                LinkContainer.style.cssText = 'display: flex; align-items: center; margin-left: auto;';
                
                var logoutLink = document.createElement('a');
                logoutLink.innerText = 'Logout';
                logoutLink.style.cssText = 'color: white; font-weight: bold; margin-left: 20px; text-decoration: none; cursor: pointer;';
                logoutLink.title = 'Logout from Admin Docs';
                
                logoutLink.onclick = function() {
                    // "Logout" hack for Basic Auth:
                    // 1. Fetch current URL with bad credentials
                    var currentUrl = window.location.href;
                    fetch(currentUrl, {
                        method: 'GET',
                        headers: { 'Authorization': 'Basic ' + window.btoa('logout:logout') }
                    }).then(function() {
                        // 2. Redirect to /admin/logout which reinforces the 401 with SAME Realm
                        window.location.href = '/api/v1/admin/logout'; 
                    }).catch(function() {
                        window.location.href = '/api/v1/admin/logout';
                    });
                    
                    return false;
                };
                
                topbar.appendChild(logoutLink);
            }
        }, 100);
    });
    </script>
    """
    
    # Inject before end body
    body_str = base_html.body.decode("utf-8")
    new_body = body_str.replace("</body>", f"{custom_js}</body>")
    
    return HTMLResponse(content=new_body)

@app.get("/admin/openapi.json", include_in_schema=False)
async def get_admin_openapi(username: str = Depends(get_current_username)):
    # Return full schema with Security
    schema = get_openapi(
        title=app.title + " (Admin)",
        version=app.version,
        routes=app.routes,
    )
    
    if "components" not in schema:
        schema["components"] = {}
    if "securitySchemes" not in schema["components"]:
        schema["components"]["securitySchemes"] = {}
    
    schema["components"]["securitySchemes"]["BearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT"
    }
    schema["security"] = [{"BearerAuth": []}]

    # Inject x-tenant header parameter into all admin API endpoints
    tenant_param = {
        "name": "x-tenant",
        "in": "header",
        "required": False,
        "schema": {
            "title": "X-Tenant",
            "type": "string"
        },
        "description": "Tenant slug (e.g., demo-dev, wellq-dev-2, wellq-mayfair)"
    }
    for path, path_item in schema.get("paths", {}).items():
        if not path.startswith("/api/"):
            continue
        for method, operation in path_item.items():
            if isinstance(operation, dict):
                if "parameters" not in operation:
                    operation["parameters"] = []
                existing_names = [p.get("name").lower() for p in operation["parameters"] if isinstance(p, dict) and "name" in p]
                if "x-tenant" not in existing_names:
                    operation["parameters"].append(tenant_param)
    
    return JSONResponse(schema)

from fastapi import Response

@app.get("/admin/logout", include_in_schema=False)
def admin_logout():
    """
    Simulates logout by forcing a 401 Unauthorized response.
    This prompts the browser to drop the cached Basic Auth credentials.
    """
    return Response(
        status_code=status.HTTP_401_UNAUTHORIZED,
        content="Logged out. Refresh to log in again.",
        headers={"WWW-Authenticate": 'Basic realm="WellQ Admin"'},
    )

# --- End Custom Docs ---

# Routers v1
app.include_router(keycloak_router)
app.include_router(auth_router,  prefix="/api/v1")
app.include_router(phone_auth_router, prefix="/api/v1")
app.include_router(metrics_router, prefix="/api/v1")
app.include_router(lookups_router.router, prefix="/api/v1")
app.include_router(topbar_router, prefix="/api/v1")
app.include_router(maindash_router, prefix="/api/v1")
app.include_router(invitations_router.router, prefix="/api/v1")
app.include_router(video_router, prefix="/api/v1")
app.include_router(admin_patients_router, prefix="/api/v1")
app.include_router(admin_clinicians.router, prefix="/api/v1")
app.include_router(admin_clinicians.router2, prefix="/api/v1")
app.include_router(admin_specialties.router, prefix="/api/v1")
app.include_router(admin_catalog_router, prefix="/api/v1")
app.include_router(program_templates_router, prefix="/api/v1")
app.include_router(exercises_router, prefix="/api/v1")
app.include_router(kineia_exercises_router, prefix="/api/v1")
app.include_router(kineia_exercises_router_clinical, prefix="/api/v1")
app.include_router(kineia_session_scores_router, prefix="/api/v1")
app.include_router(router_exe, prefix="/api/v1")
app.include_router(exercises_router_shared, prefix="/api/v1")
app.include_router(exercises_router_open, prefix="/api/v1")
app.include_router(exercises_router_painmap, prefix="/api/v1")
app.include_router(exercises_router_body, prefix="/api/v1")
app.include_router(admin_clinic.router, prefix="/api/v1")
app.include_router(painmap_router, prefix="/api/v1")
app.include_router(body_router, prefix="/api/v1")
app.include_router(editprofile_router, prefix="/api/v1")
app.include_router(notifications_router, prefix="/api/v1")
app.include_router(activity_log_router, prefix="/api/v1")
app.include_router(patient_metrics_graph.router, prefix="/api/v1")
app.include_router(action_log_router, prefix="/api/v1")
app.include_router(cases.router, prefix="/api/v1")
app.include_router(appointments.router, prefix="/api/v1")
app.include_router(recall.router, prefix="/api/v1")
app.include_router(clinical_notes.router, prefix="/api/v1")
app.include_router(recording_sessions.router, prefix="/api/v1")
app.include_router(recording_sessions.webhook_router, prefix="/api/v1")
app.include_router(activities.router, prefix="/api/v1")
app.include_router(alerts.router, prefix="/api/v1")
app.include_router(patient_checkins.router, prefix="/api/v1")
app.include_router(patient_checkins.router_metrics, prefix="/api/v1")
app.include_router(patient_commitment.router, prefix="/api/v1")
app.include_router(patient_goals.router, prefix="/api/v1")
app.include_router(patient_calendar.router, prefix="/api/v1")
app.include_router(patient_routines.router, prefix="/api/v1")
app.include_router(patient_workout_logs.router, prefix="/api/v1")
app.include_router(patient_custom_exercises.router, prefix="/api/v1")
app.include_router(patient_wearable_workouts.router, prefix="/api/v1")
app.include_router(patient_exercise_sessions.router, prefix="/api/v1")
app.include_router(admin_patients_batch.router, prefix="/api/v1")
app.include_router(admin_collections.router, prefix="/api/v1")
app.include_router(admin_clinicians_crud.router, prefix="/api/v1")
app.include_router(admin_patients_crud.router, prefix="/api/v1")
app.include_router(admin_reports.router, prefix="/api/v1")
app.include_router(patient_wearables.router, prefix="/api/v1")
app.include_router(admin_clinics.router, prefix="/api/v1")
app.include_router(patients.router, prefix="/api/v1")
app.include_router(patient_state.router, prefix="/api/v1")
app.include_router(intake.router, prefix="/api/v1")
app.include_router(information.router, prefix="/api/v1")
app.include_router(clinician_schedule.router, prefix="/api/v1")
if conf.WHOOP_DIRECT_ENABLED:
    app.include_router(whoop_router, prefix="/api/v1")
app.include_router(rtm_pose_router, prefix="/api/v1")
app.include_router(tm3_sync_router, prefix="/api/v1")
app.include_router(cliniko_sync_router, prefix="/api/v1")
app.include_router(pms_sync_router, prefix="/api/v1")
app.include_router(state_rules_router, prefix="/api/v1")
app.include_router(patient_trace_router, prefix="/api/v1")
app.include_router(ticket_router, prefix="/api/v1/ticket")
app.include_router(admin_tenants.router, prefix="/api/v1")
app.include_router(docs_serving_router, prefix="/api/v1")

# Partner API de fabricantes de wearables: solo se monta con PARTNER_API_ENABLED=true
from app.api.v1.partner_registry import include_partner_routers
include_partner_routers(app)

@app.get("/health", tags=["health"], include_in_schema=False)
@app.get("/api/v1/health", tags=["health"], include_in_schema=False)
async def health():
    """ Health check endpoint moved to main to avoid router logging bloat.

    Registrado en las dos rutas a propósito:
      - /health         : histórica, pero nginx la sirve con try_files y NO llega aquí.
      - /api/v1/health  : la única que nginx proxea a uvicorn (`location /api`), y por
                          tanto la única que sirve como healthcheck real del contenedor.

    Es `async def` y no toca la base de datos, así que responde en microsegundos salvo que
    el event loop esté bloqueado. Eso lo convierte en el canario exacto del fallo del
    incidente: durante la caída, este endpoint también devolvió 504.
    """
    return {"status": "ok"}


import os
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse

# Define potential paths for static files (compiled SPA)
static_candidates = [
    os.path.join(os.getcwd(), "dist"),
    # os.path.join(os.path.dirname(os.getcwd()), "wellq_api", "dist"), # Specifically mentioned by user
    os.path.join(os.getcwd(), "static"),
    "/app/static" # Docker standard
]

STATIC_DIR = None
for candidate in static_candidates:
    if os.path.exists(candidate) and os.path.isdir(candidate):
        STATIC_DIR = candidate
        break

if STATIC_DIR:
    log.debug(f"[STATIC] Serving frontend from {STATIC_DIR}")
    # Mount assets (JS/CSS generated by Vite)
    assets_dir = os.path.join(STATIC_DIR, "assets")
    if os.path.exists(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")
    
    # Mount images folder if exists
    img_dir = os.path.join(STATIC_DIR, "img")
    if os.path.exists(img_dir):
        app.mount("/img", StaticFiles(directory=img_dir), name="img")

    # Explicit route for the root /
    @app.get("/", include_in_schema=False)
    async def serve_index():
        index_path = os.path.join(STATIC_DIR, "index.html")
        if os.path.exists(index_path):
             return FileResponse(index_path)
        return HTMLResponse(content="<h1>Frontend index.html not found</h1>", status_code=404)

    # Catch-all route for SPA (Must be defined LAST to avoid shadowing API routes)
    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_frontend(full_path: str):
        # 1. Check if specific file exists (e.g., favicon.ico, robot.txt)
        file_path = os.path.join(STATIC_DIR, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        
        # 2. Otherwise, return index.html for SPA routing
        index_path = os.path.join(STATIC_DIR, "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
        
        return HTMLResponse(content="<h1>Frontend index.html not found</h1>", status_code=404)
else:
    log.warning("[STATIC] No static directory found among candidates.")
    # Fallback for development (without static build)
    @app.get("/", include_in_schema=False)
    async def root():
        return HTMLResponse(content="<h1><center>WellQ API (Frontend not found)</center></h1>")
