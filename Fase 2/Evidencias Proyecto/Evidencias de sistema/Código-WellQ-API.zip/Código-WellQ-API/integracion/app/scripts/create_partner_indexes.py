"""Crea los índices de la Partner API (idempotente).

python -m app.scripts.create_partner_indexes            # base central, sandbox y todos los tenants activos
python -m app.scripts.create_partner_indexes --db X     # solo el tenant X
"""
import argparse

import app.config as conf
import app.db as dbmod


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", help="nombre de la base de un tenant")
    args = parser.parse_args()
    if args.db:
        dbmod.ensure_partner_tenant_indexes(dbmod._client[args.db])
        print(f"índices partner creados en {args.db}")
        return
    dbmod.ensure_partner_indexes(dbmod.central_db)
    dbmod.ensure_partner_tenant_indexes(dbmod._central_client[conf.PARTNER_SANDBOX_DB])
    from app.middleware.tenant_middleware import get_tenant_client, resolve_tenant_database
    for tenant in dbmod.tenants_registry_collection().find({"status": "active"}):
        if tenant.get("mongo_db"):
            tdb = resolve_tenant_database(get_tenant_client(tenant), tenant["mongo_db"])
            dbmod.ensure_partner_tenant_indexes(tdb)
            print(f"índices partner creados en {tdb.name}")
    print("índices partner creados en la base central y en el sandbox")


if __name__ == "__main__":
    main()
