import os
import urllib.parse
from dotenv import load_dotenv
from pathlib import Path

# Carga .env si existe
_ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
if _ENV_PATH.exists():
    load_dotenv(_ENV_PATH)

APP_NAME = os.getenv("APP_NAME")
APP_ENV = os.getenv("APP_ENV")
HOST = os.getenv("HOST")
PORT = int(os.getenv("PORT"))
LOG_LEVEL = os.getenv("LOG_LEVEL")
LOG_DIR = os.getenv("LOG_DIR")
LOG_FILE = os.getenv("LOG_FILE")
LOG_CICLE = os.getenv("LOG_CICLE")

VIDEO_DIR = os.getenv("VIDEO_DIR")
KEYPOINTS_DIR = os.getenv("KEYPOINTS_DIR")
RECOD_DIR = os.getenv("RECOD_DIR")


# PUNTOS DE LIMITE PARA ALERTAS
SOFT = 0.15
HARD = 0.30

# CORS
CORS_ALLOW_ORIGINS = [
    o.strip()
    for o in os.getenv(
        "CORS_ALLOW_ORIGINS",
        ",".join([
            "http://35.209.91.198:9551",
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "https://wellq-dev.alloxentric.com"
        ]),
    ).split(",")
    if o.strip()
]

# Force allow local development origins strictly
_dev_origins = [
    "http://localhost:5173", 
    "http://127.0.0.1:5173", 
    "http://localhost:3000", 
    "http://127.0.0.1:3000",
    "http://localhost:9551",       # Frontend Docker container
    "http://127.0.0.1:9551",       # Frontend Docker container
    "http://35.209.91.198:9551",   # Frontend Docker container (external IP)
    "https://wellq-dev.alloxentric.com",  # Production frontend
]
for _o in _dev_origins:
    if _o not in CORS_ALLOW_ORIGINS:
        CORS_ALLOW_ORIGINS.append(_o)

# Configuraciones para login
_MONGO_URI_RAW = os.getenv("MONGODB_URI")
MONGO_DB = os.getenv("MONGODB_DB", "wellq-dev-1") # Fallback to default tenant
TENANT_DB_ENCRYPTION_KEY = os.getenv("TENANT_DB_ENCRYPTION_KEY", "")

MONGO_CENTRAL_URI = os.getenv("MONGO_CENTRAL_URI") or _MONGO_URI_RAW
MONGODB_CENTRAL_DB = os.getenv("MONGODB_CENTRAL_DB", "wellq_platform")

# Hotfix to compensate for a typo in the local shell environment
if MONGODB_CENTRAL_DB == "wellq-dev-central-":
    MONGODB_CENTRAL_DB = "wellq-dev-central-1"


# Check for individual components as an alternative
_MONGO_USER = os.getenv("MONGODB_USER")
_MONGO_PASS = os.getenv("MONGODB_PASS")
_MONGO_HOST = os.getenv("MONGODB_HOST")
_MONGO_OPTS = os.getenv("MONGODB_OPTIONS", "loadBalanced=true&tls=true&authMechanism=SCRAM-SHA-256&retryWrites=false")

if _MONGO_USER and _MONGO_PASS and _MONGO_HOST:
    # Construct URI from components with proper escaping
    _esc_user = urllib.parse.quote_plus(_MONGO_USER)
    _esc_pass = urllib.parse.quote_plus(_MONGO_PASS)
    MONGO_URI = f"mongodb://{_esc_user}:{_esc_pass}@{_MONGO_HOST}/{MONGO_DB}?{_MONGO_OPTS}"
else:
    MONGO_URI = _MONGO_URI_RAW

# Auth / JWT
JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALG = os.getenv("JWT_ALG")
JWT_EXPIRES_MIN = int(os.getenv("JWT_EXPIRES_MIN"))
PWD_HASH_SCHEME = os.getenv("PWD_HASH_SCHEME")

# Configuración para correo
SMTP_SERVER = os.getenv("SMTP_SERVER", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_SENDER_EMAIL = os.getenv("SMTP_SENDER_EMAIL", "")
SMTP_SENDER_NAME = os.getenv("SMTP_SENDER_NAME", "WELLQ")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"

# Link base del frontend (para armar el botón de reset)
FRONTEND_BASE_URL = os.getenv("FRONTEND_BASE_URL", "https://wellq.example.com")
PLAYSTORE_APP_LINK=os.getenv("PLAYSTORE_APP_LINK")

# CONFIGURACION DE REGISTRO DE PACIENTES
SUPPORT_NOTIF_EMAIL = os.getenv("SUPPORT_NOTIF_EMAIL")
INVITE_TTL_HOURS = int(os.getenv("INVITE_TTL_HOURS"))
INVITE_REGISTER_PATH = os.getenv("INVITE_REGISTER_PATH")

# API-KEY para inserción de métricas
_INGEST = os.getenv("INGEST_API_KEY")
INGEST_API_KEY = _INGEST.strip() if _INGEST else ""

# === Health trend lookbacks (horas) ALL PATIENTS ===

def _as_int(env_name: str, default: int) -> int:
    try:
        return int(os.getenv(env_name, str(default)))
    except Exception:
        return default

LOOKBACKS_HOURS = {
    "vitals": _as_int("LOOKBACK_VITALS_HOURS", 48),
    "activity": _as_int("LOOKBACK_ACTIVITY_HOURS", 72),
    "nutrition": _as_int("LOOKBACK_NUTRITION_HOURS", 168),
    "sleep": _as_int("LOOKBACK_SLEEP_HOURS", 96),
    "energy_metabolism": _as_int("LOOKBACK_ENERGY_METABOLISM_HOURS", 72),
    "medication": _as_int("LOOKBACK_MEDICATION_HOURS", 168),
}

# === Mobile activity logging ===
MOBILE_ACTIVITY_DIR = os.getenv("MOBILE_ACTIVITY_DIR", "app/assets/logs_mobile")
MOBILE_ACTIVITY_RETENTION_DAYS = _as_int("MOBILE_ACTIVITY_RETENTION_DAYS", 180)

# === 5,3,8 Framework Configurations ===
MIN_SESSION_DURATION_SECS = _as_int("MIN_SESSION_DURATION_SECS", 900)

# === Web activity logging ===
WEB_ACTIVITY_DIR = os.getenv("WEB_ACTIVITY_DIR", "app/assets/logs_web")
WEB_ACTIVITY_RETENTION_DAYS = _as_int("WEB_ACTIVITY_RETENTION_DAYS", 180)

# === SMS Provider Twilio) and mauth configuration ===
SMS_PROVIDER=os.getenv("SMS_PROVIDER")
TWILIO_ACCOUNT_SID=os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN=os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_FROM_NUMBER=os.getenv("TWILIO_FROM_NUMBER")

# === TextMagic SMS Provider ===
TEXTMAGIC_USERNAME=os.getenv("TEXTMAGIC_USERNAME")
TEXTMAGIC_API_KEY=os.getenv("TEXTMAGIC_API_KEY")

REFRESH_EXPIRES_DAYS=int(os.getenv("REFRESH_EXPIRES_DAYS", 180))
REFRESH_ROTATE_ON_USE=os.getenv("REFRESH_ROTATE_ON_USE")
ACCESS_EXPIRES_MIN=int(os.getenv("ACCESS_EXPIRES_MIN"))

# === Redis configuration ===
REDIS_HOST=os.getenv("REDIS_HOST")
REDIS_PORT=os.getenv("REDIS_PORT")
REDIS_PASS=os.getenv("REDIS_PASS")
REDIS_USER=os.getenv("REDIS_USER")
REDIS_DB=os.getenv("REDIS_DB")

# === OTP Configuration ===
OTP_LENGTH = _as_int("OTP_LENGTH", 6)
OTP_EXPIRES_MIN = _as_int("OTP_EXPIRES_MIN", 5)
OTP_MAX_ATTEMPTS = _as_int("OTP_MAX_ATTEMPTS", 5)
OTP_RATE_LIMIT_PER_PHONE = _as_int("OTP_RATE_LIMIT_PER_PHONE", 3)
OTP_RATE_LIMIT_WINDOW_SEC = _as_int("OTP_RATE_LIMIT_WINDOW_SEC", 300)

def _parse_otp_test_numbers(raw: str) -> dict:
    """OTP_TEST_NUMBERS="+56912345678:123456,+56987654321:111111" -> {phone: code}"""
    result = {}
    for pair in (raw or "").split(","):
        pair = pair.strip()
        if not pair or ":" not in pair:
            continue
        phone, code = pair.split(":", 1)
        if phone.strip() and code.strip():
            result[phone.strip()] = code.strip()
    return result

# Test phone whitelist: predefined OTP codes, SMS never sent (keep empty in production)
OTP_TEST_NUMBERS = _parse_otp_test_numbers(os.getenv("OTP_TEST_NUMBERS", ""))

# === Firebase/FCM Configuration ===
FIREBASE_TYPE = os.getenv("FIREBASE_TYPE", "service_account")
FIREBASE_PROJECT_ID = os.getenv("FIREBASE_PROJECT_ID")
FIREBASE_PRIVATE_KEY_ID = os.getenv("FIREBASE_PRIVATE_KEY_ID")
FIREBASE_PRIVATE_KEY = os.getenv("FIREBASE_PRIVATE_KEY", "").replace('\\n', '\n')  # Convertir \n a saltos reales
FIREBASE_CLIENT_EMAIL = os.getenv("FIREBASE_CLIENT_EMAIL")
FIREBASE_CLIENT_ID = os.getenv("FIREBASE_CLIENT_ID")
FIREBASE_AUTH_URI = os.getenv("FIREBASE_AUTH_URI", "https://accounts.google.com/o/oauth2/auth")
FIREBASE_TOKEN_URI = os.getenv("FIREBASE_TOKEN_URI", "https://oauth2.googleapis.com/token")
FIREBASE_AUTH_PROVIDER_CERT_URL = os.getenv("FIREBASE_AUTH_PROVIDER_CERT_URL")
FIREBASE_CLIENT_CERT_URL = os.getenv("FIREBASE_CLIENT_CERT_URL")
FCM_MAX_TOKENS_PER_USER = int(os.getenv("FCM_MAX_TOKENS_PER_USER", "5"))
FCM_NOTIFICATION_MAX_DATA_SIZE = int(os.getenv("FCM_NOTIFICATION_MAX_DATA_SIZE", "4000"))

# === Google Identity Platform / Firebase Auth (Phone Login) ===
GOOGLE_IDP_PROJECT_ID = os.getenv("GOOGLE_IDP_PROJECT_ID") or FIREBASE_PROJECT_ID

# ELEVENLABS CONFIG
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")
ELEVENLABS_VOICE_ID = os.getenv("ELEVENLABS_VOICE_ID")
ELEVENLABS_MODEL_ID = os.getenv("ELEVENLABS_MODEL_ID")

# GCS / STORAGE CONFIG
BUCKET_NAME = os.getenv("BUCKET_NAME")
BUCKET_PROJECT_ID = os.getenv("BUCKET_PROJECT_ID")

# WHOOP CONFIG
WHOOP_ENCRYPTION_KEY = os.getenv("WHOOP_ENCRYPTION_KEY")
# WHOOP Direct (unofficial username/password integration) was disabled after
# being assumed blocked by Whoop; a live diagnostic (Aug 2026) found no
# evidence of a block, so it's back on by default as the primary Whoop path,
# with Spike as automatic fallback on the client if it fails.
WHOOP_DIRECT_ENABLED = os.getenv("WHOOP_DIRECT_ENABLED", "true").lower() == "true"

# AZURE STORAGE CONFIG
AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
AZURE_DEFAULT_CONTAINER = os.getenv("AZURE_DEFAULT_CONTAINER")

# CLINICAL RECORDING PIPELINE (Speechmatics + DeepSeek)
# Publicly reachable base URL for this API, used to build the Speechmatics
# webhook notification_url. Falls back to the incoming request's base_url
# (useful behind a reverse proxy that already sets the right Host).
API_BASE_URL = os.getenv("API_BASE_URL")
SPEECHMATICS_API_KEY = os.getenv("SPEECHMATICS_API_KEY")
SPEECHMATICS_BASE_URL = os.getenv("SPEECHMATICS_BASE_URL", "https://asr.api.speechmatics.com/v2")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
RECORDING_WEBHOOK_SECRET = os.getenv("RECORDING_WEBHOOK_SECRET")

# === Azure Application Insights (logging) ===
APPLICATIONINSIGHTS_CONNECTION_STRING = os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")
ENABLE_GCP_LOGGING = os.getenv("ENABLE_GCP_LOGGING", "false").lower() == "true"


telephone_mock_list = [
    "+440123456789", "+440987654321","+440000000000","+441111111111",
    "+442222222222","+443333333333","+444444444444","+445555555555",
    "+446666666666","+447777777777","+448888888888","+449999999999",
    "+441234567890","+449876543210","+440987654321","+441234567890"]

# === Partner API (fabricantes de wearables) ===
# todo apagado por defecto: sin PARTNER_API_ENABLED=true no se monta ninguna ruta partner
PARTNER_API_ENABLED = os.getenv("PARTNER_API_ENABLED", "false").lower() == "true"
PARTNER_TOKEN_SECRET = os.getenv("PARTNER_TOKEN_SECRET", "")
PARTNER_ENCRYPTION_KEY = os.getenv("PARTNER_ENCRYPTION_KEY", "")
PARTNER_TOKEN_ISSUER = os.getenv("PARTNER_TOKEN_ISSUER", "wellq-partner")
PARTNER_SANDBOX_DB = os.getenv("PARTNER_SANDBOX_DB", "wellq_partner_sandbox")
PARTNER_DEFAULT_RPM = _as_int("PARTNER_DEFAULT_RPM", 600)
PARTNER_DEFAULT_SAMPLES_PER_DAY = _as_int("PARTNER_DEFAULT_SAMPLES_PER_DAY", 5_000_000)
PARTNER_PUBLIC_RPM_PER_IP = _as_int("PARTNER_PUBLIC_RPM_PER_IP", 20)
PARTNER_MAX_BODY_BYTES = _as_int("PARTNER_MAX_BODY_BYTES", 1_048_576)
PARTNER_MAX_SAMPLES_BODY_BYTES = _as_int("PARTNER_MAX_SAMPLES_BODY_BYTES", 5_242_880)
PARTNER_MAX_DECOMPRESSED_BYTES = _as_int("PARTNER_MAX_DECOMPRESSED_BYTES", 26_214_400)
PARTNER_DEFAULT_STEPS_TARGET = _as_int("PARTNER_DEFAULT_STEPS_TARGET", 7000)
PARTNER_PORTAL_BASE_URL = os.getenv("PARTNER_PORTAL_BASE_URL", "")
# solo para desarrollo local: ademas exigen APP_ENV de desarrollo, si no quedan apagados
PARTNER_DEMO_ENABLED = os.getenv("PARTNER_DEMO_ENABLED", "false").lower() == "true"
PARTNER_DEV_TOOLS_ENABLED = os.getenv("PARTNER_DEV_TOOLS_ENABLED", "false").lower() == "true"
PARTNER_WEBHOOK_ALLOW_PRIVATE = os.getenv("PARTNER_WEBHOOK_ALLOW_PRIVATE", "false").lower() == "true"
LEGACY_INGEST_API_KEY_ENABLED = os.getenv("LEGACY_INGEST_API_KEY_ENABLED", "true").lower() == "true"
DEV_APP_ENVS = ("dev", "development", "local", "test")
# tenants cuyo personal itadmin puede aprobar o suspender fabricantes; vacío = nadie (falla cerrado)
PARTNER_ADMIN_TENANT_SLUGS = [s.strip() for s in os.getenv("PARTNER_ADMIN_TENANT_SLUGS", "").split(",") if s.strip()]
