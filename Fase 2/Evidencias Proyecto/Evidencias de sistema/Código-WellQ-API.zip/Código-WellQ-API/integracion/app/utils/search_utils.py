# app/utils/search_utils.py
from __future__ import annotations

import json
import re, jwt, hashlib, secrets, bcrypt, hmac, os, base64, mimetypes
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, Tuple, List, Iterable
from bson import ObjectId
from fastapi import Response, HTTPException
from statistics import mean
import hashlib, base64
import secrets, string

import app.config as conf
from app.db import (
    users_collection, case_history_collection, patient_health_profiles_collection,
    patients_collection as _pac_coll,
    patient_exercises_collection, checkins_collection,
    surveys_collection, legal_docs_collection,
    body_pain_map_collection, consents_collection as _cons_coll,
    TBL_PATIENTS, TBL_METRICS, KEY_STATE,
    KEY_FIRST_NAME, KEY_LAST_NAME, KEY_PHONE, KEY_INTERNAL_ID, 
    KEY_PATIENT_INTERNAL_ID, KEY_CLINICIAN_INTERNAL_ID,
    TBL_PATIENT_HEALTH_PROFILES, TBL_CASE_HISTORY
    )

MAX_DAYS_FOR_DATA = 90

from app.logging_conf import get_logger
log = get_logger("UTILS/SEARCH")

# --- Patient light projection + serializer (para listados compactos del dashboard) ---
_VERSION_RX = re.compile(r"^v(\d+)$")

PATIENT_LIGHT_PROJ = {
    "_id": 1,
    KEY_FIRST_NAME: 1,
    KEY_LAST_NAME: 1,
    KEY_INTERNAL_ID: 1,
    "ids.patient_id": 1,
    "contact.email": 1,
}

_NOTIF_MAP = {
    "improving": {"type": "congratulation", "message": "Your clinician congratulated you! Keep it up."},
    "declining": {"type": "alert", "message": "Your clinician sent you an alert: your metrics are trending down."},
    "at_risk": {"type": "urgent", "message": "Your clinician is concerned and would like you to contact them."},
}


_LEGAL_NAMEDOC_RX = re.compile(r"^([a-z0-9]+)_(v\d+)\.pdf$", re.IGNORECASE)

# === ID de paciente "P-XXXXXXXXXXXX" (12 alfanuméricos) ===
_PATIENT_ID_FULL_RX = re.compile(r"^P-[A-Z0-9]{12}$")
_PATIENT_ID_PREFIX_RX = re.compile(r"^P-[A-Z0-9]{0,12}$")
_CLINICIAN_ID_FULL_RX = re.compile(r"^M-[A-Z0-9]{12}$")
_CLINICIAN_ID_PREFIX_RX = re.compile(r"^M-[A-Z0-9]{0,12}$")

# ---- Sanitizers / helpers ----
def safe_str(s: Optional[str]) -> str:
    return (s or "").strip()

def safe_int(s: Optional[str | None | int]) -> int:
    if not s:
        return 0
    if type(s) == str:
        match = re.search(r'\d+', s)
        if match:
            number = int(match.group())
        else:
            number = 0
    else:
        try:
            number = int(s)
        except:
            log.error(f"Error al convertir {s} a int")
            number = 0
    return number


def ci_regex(s: str) -> Dict[str, Any]:
    """ Regex case-insensitive escapando la entrada."""
    return {"$regex": re.escape(s), "$options": "i"}


def startswith_ci_regex(prefix: str) -> Dict[str, Any]:
    """Regex case-insensitive con anclaje de prefijo (^)."""
    return {"$regex": "^" + re.escape(prefix), "$options": "i"}


def page_params(page: int, page_size: int) -> tuple[int, int]:
    page = max(1, page)
    page_size = min(100, max(1, page_size))
    skip = (page - 1) * page_size
    return skip, page_size

# ---- ID genérico (id_norm: solo A-Z/0-9, sin separadores) ----

from app.domain.validation import (
    is_valid_patient_id,
    is_valid_email,
    is_valid_person_name,
    is_valid_phone,
    _rut_checksum_ok,
    split_street_number,
    is_valid_platform,
    is_valid_fcm_token
)


def build_rut_norm_filter(user_input: str, key: str = KEY_INTERNAL_ID) -> Optional[Dict[str, Any]]:
    """ Filtro por 'rut_norm' para IDs tipo 'P-XXXXXXXXXXXX' o 'M-XXXXXXXXXXXX'.
    Soporta match exacto y prefijo (útil para autocompletar).
    Acepta entrada con o sin guion; reconstruye el formato correcto si es posible.
    """
    s = safe_str(user_input).upper()
    if not s:
        return None

    # Prefijos válidos P-... o M-...
    if _PATIENT_ID_PREFIX_RX.match(s) or _CLINICIAN_ID_PREFIX_RX.match(s):
        return {key: {"$regex": f"^{re.escape(s)}"}}

    # Variante sin guion: PXXXXXXXXXXXX o MXXXXXXXXXXXX (prefijo o completo)
    s_nodash = re.sub(r"[^A-Z0-9]", "", s)
    if s_nodash and s_nodash[0] in ("P", "M"):
        rebuilt = s_nodash[0] + "-" + s_nodash[1:]
        if (_PATIENT_ID_PREFIX_RX.match(rebuilt) or _CLINICIAN_ID_PREFIX_RX.match(rebuilt)):
            return {key: {"$regex": f"^{re.escape(rebuilt)}"}}
    return None


# ---- Serialiers ----

def get_patient_id(doc: Dict[str, Any]) -> str:
    """ Extrae el ID de paciente. Prioriza root 'patient_id' (post-migration),
    luego fallback a 'ids.patient_id' (legacy) y 'rut_norm' (legacy).
    """
    if not doc:
        return ""
    # 1) Root patient_id (post-migration)
    if val := doc.get("patient_id"):
        return safe_str(val)
    # 2) Legacy nested path
    ids = doc.get("ids") or {}
    if val := ids.get("patient_id"):
        return safe_str(val)
    # 3) Fallback legacy
    return safe_str(doc.get("rut_norm"))


def serialize_id(doc: Dict[str, Any]) -> Dict[str, Any]:
    if doc and "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return doc


def serialize_objectid_field(doc: Dict[str, Any], field: str) -> Dict[str, Any]:
    if doc and field in doc and isinstance(doc[field], ObjectId):
        doc[field] = str(doc[field])
    return doc



# ---- Email ----

def to_email_norm(s: str) -> Optional[str]:
    s = safe_str(s).lower()
    return s or None


# ---- País/Región/Ciudad/Localidad: no vacíos ----
def nonempty(s: str) -> bool:
    return bool(safe_str(s))


def to_patient_light(doc: Dict[str, Any]) -> Dict[str, Any]:
    """ Normaliza un documento de paciente a un shape ligero para UI.
    Nota: el 'status' ya no vive en 'pacientes'. Si el caller hizo lookup a
    'historial_medico', puede inyectarlo como '_hstatus' y aquí lo exponemos.
    """
    if not doc:
        return {}
    status = (doc.get("_hstatus") or doc.get("status") or "")  # prioridad al estado inyectado

    # Extract patient_id: root field (post-migration), then legacy fallbacks
    patient_id = doc.get("patient_id") or (doc.get("ids") or {}).get("patient_id") or doc.get("rut_norm") or ""

    return {
        "id": str(doc.get("_id")),
        "first_name": doc.get(KEY_FIRST_NAME) or "",
        "last_name": doc.get(KEY_LAST_NAME) or "",
        "full_name": f"{doc.get(KEY_FIRST_NAME,'')} {doc.get(KEY_LAST_NAME,'')}".strip(),
        "patient_id": patient_id,
        "status": status,
        "email": ((doc.get("contact") or {}).get("email") or ""),
        "metric_label": "NO DATA",
        "metric_tone": "neutral",
    }


def parse_csv_list(raw: str | None) -> List[str]:
    """ Convierte 'a,b, c' -> ['a','b','c'] (sin vacíos, trim).
    """
    if not raw:
        return []
    return [s.strip() for s in str(raw).split(",") if s.strip()]


def catalog_text_filter(q: str | None) -> dict | None:
    """ Filtro de texto para catálogos:
    - si q es corto, usa prefijo case-insensitive en *_nom
    - si q contiene espacios/palabras, usa $text (requiere índice de texto)
    """
    q = safe_str(q)
    if not q:
        return None

    # Heurística: prefijo si es corto (<=3), texto si >3 o tiene espacio
    if len(q) <= 3 and " " not in q:
        return {"$or": [
            {"diag_name": startswith_ci_regex(q)},  # para diagnósticos
            {"eje_nom": startswith_ci_regex(q)},   # para ejercicios
        ]}

    # Fallback a $text. Requiere índices de texto creados.
    return {"$text": {"$search": q}}


def _safelog(label: str, value: str | None):
    """ Secure Log of sensitive values (API keys, etc.) with length and truncated hash. """
    v = value or ""
    sha = hashlib.sha256(v.encode("utf-8")).hexdigest()
    log.info("[API][KEY][%s] len=%d sha256=%s", label, len(v), sha[:12], extra={"tag": "API"})


def require_ingest_api_key(x_api_key: Optional[str]):
    """ Exige la API key global de ingesta (INGEST_API_KEY). Mismo criterio de /metrics.
    - Tolera 'dev' sin key (si conf.INGEST_API_KEY vacío).
    - Log seguro (longitud + hash truncado).
    """
    api_key = conf.INGEST_API_KEY
    if not api_key:
        # sin clave configurada solo se tolera en desarrollo; fuera de él falla cerrado
        if (conf.APP_ENV or "").lower() in getattr(conf, "DEV_APP_ENVS", ("dev", "development")):
            return
        from fastapi import HTTPException
        raise HTTPException(status_code=503, detail="Ingesta no configurada.")

    if not x_api_key:
        log.warning("[API][DENY] missing api-key", extra={"tag":"API"})
        from fastapi import HTTPException
        raise HTTPException(status_code=401, detail="API key inválida.")
    if not hmac.compare_digest(x_api_key.strip(), api_key):
        log.warning("[API][DENY] bad api-key", extra={"tag":"API"})
        from fastapi import HTTPException
        raise HTTPException(status_code=401, detail="API key inválida.")


def make_signed_url_gcs(client, bucket: str, key: str, ttl_minutes: int) -> str:
    """ Genera una URL firmada (v4) para GET sobre un objeto GCS privado.
    - client: instancia google.cloud.storage.Client (ya autenticada)
    - bucket: nombre del bucket
    - key: objeto dentro del bucket
    - ttl_minutes: minutos de validez
    """
    try:
        b = client.bucket(bucket)
        blob = b.blob(key)
        url = blob.generate_signed_url(
            version="v4",
            expiration=timedelta(minutes=max(1, int(ttl_minutes))),
            method="GET",
        )
        return url
    except Exception as e:
        log.exception("[GCS][SIGNED_URL_ERR] %s", e, extra={"tag":"API"})
        raise


def resolve_rut_norm_from_any(patient_id: str) -> Optional[str]:
    """ Acepta:
      - ID de paciente 'P-XXXXXXXXXXXX' (retorna tal cual, upper)
      - Variante sin guion (normaliza a 'P-...') si encaja
      - ObjectId de Mongo (24 hex): hace lookup y retorna 'patient_id'
    """
    raw = safe_str(patient_id)
    if not raw:
        return None

    s = raw.upper()

    # 1) Caso ideal: ya viene como P-XXXXXXXXXXXX o formato P-TM3
    if is_valid_patient_id(s) or s.startswith("P-"):
        return s

    # 2) Variante sin guion u otros separadores: normalizar si cabe
    s_nodash = re.sub(r"[^A-Z0-9]", "", s)
    if s_nodash.startswith("P") and len(s_nodash) == 13:
        candidate = "P-" + s_nodash[1:]
        if is_valid_patient_id(candidate):
            return candidate

    # 3) ObjectId -> buscar en pacientes
    looks_hex24 = (len(raw) == 24 and all(ch in "0123456789abcdefABCDEF" for ch in raw))
    if looks_hex24:
        try:
            oid = ObjectId(raw)
            p = _pac_coll().find_one({"_id": oid}, {KEY_INTERNAL_ID: 1, "ids.patient_id": 1})
            if not p:
                return None
            user_id = p.get(KEY_INTERNAL_ID) or (p.get("ids") or {}).get("patient_id")
            if user_id and is_valid_patient_id(str(user_id).upper()):
                return str(user_id).upper()
        except Exception as e:
            log.exception("[RESOLVE_RUT] %s", e, extra={"tag":"API"})
            pass
    return None


def _normalize_patient_or_404(patient_id: str) -> str:
    """ Normalizes the patient ID or raises a 404 error if not found.\n
    :param str patient_id: The patient identifier (RUT, ObjectId, etc.).
    :return: The normalized RUT.
    """
    user_id = resolve_rut_norm_from_any(patient_id)  # P-XXXXXXXXXXXX, ObjectId o variante
    if not user_id:
        raise HTTPException(status_code=404, detail="Patient not found")
    # valida existencia/estado activo (no lanza si user_id está OK)
    ensure_pacientes_exist_by_rut_norm({user_id})
    return user_id


def patient_id_to_nodash(patient_id: str) -> str:
    """ Normalizes a patient id like 'P-XXXXXXXXXXXX' to 'PXXXXXXXXXXXX' (no dash).
    Returns empty string for invalid/empty input.
    """
    user_id = safe_str(patient_id).upper()
    if not user_id:
        return ""
    return user_id.replace("-", "")


def iso_to_video_minute_suffix(recorded_at: str) -> str:
    """ Converts an ISO-8601 datetime string into 'YYYYMMDDHHmm' in UTC.
    This matches the suffix used in video filenames, e.g.:
    2025-11-12T13:15:31.716Z -> '202511121315'
    """
    dt = parse_iso8601_utc(recorded_at)
    return dt.strftime("%Y%m%d%H%M")


def parse_iso8601_utc(s: str) -> datetime:
    """ Convierte '2025-10-20T10:00:00Z' (o con tz) a datetime aware UTC.
    """
    dt = datetime.fromisoformat((s or "").replace("Z", "+00:00"))
    return dt.astimezone(timezone.utc) if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def ensure_pacientes_exist_by_rut_norm(ids: set[str]) -> None:
    """ Valida que todos los 'patient_id' (formato P-XXXXXXXXXXXX) existan y no estén inactivos.
    Lanza HTTP 400 si faltan.
    """
    norm_ids = []
    for i in (ids or set()):
        user_id = resolve_rut_norm_from_any(i)
        if user_id:
            norm_ids.append(user_id)
    if not norm_ids:
        return

    cur = _pac_coll().find({KEY_INTERNAL_ID: {"$in": norm_ids}, KEY_STATE: {"$ne": "inactive"}}, {KEY_INTERNAL_ID: 1, "_id": 0})

    encontrados = {(d.get(KEY_INTERNAL_ID) or (d.get("ids") or {}).get("patient_id") or "").upper() for d in cur}
    faltantes = sorted(set(norm_ids) - encontrados)
    if faltantes:
        raise HTTPException(status_code=400, detail={"code": "UNKNOWN_PATIENTS", "missing": faltantes})
    return


def iso_z(dt: datetime | str | None) -> str | None:
    """ Serializa datetime a ISO-8601 terminado en 'Z' (UTC). Retorna None si dt es falsy.
    Also accepts ISO string values (e.g. from MongoDB documents that stored timestamps as strings).
    """
    if not dt:
        return None

    # Production DB may store timestamps as ISO strings instead of BSON Date — parse them first
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except Exception:
            return dt  # Return the raw string if unparseable rather than crashing

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def day_bounds_utc(yyyy_mm_dd: str) -> tuple[datetime, datetime]:
    """ Devuelve (start,end) UTC para un día calendario (incluye todo el día).
    - start: YYYY-MM-DDT00:00:00Z
    - end  : YYYY-MM-DDT23:59:59Z
    """
    y, m, d = map(int, yyyy_mm_dd.split("-"))
    start = datetime(y, m, d, 0, 0, 0, tzinfo=timezone.utc)
    end   = start + timedelta(days=1) - timedelta(seconds=1)
    return start, end


def start_end_n_days_bounds(start_dt: datetime|None=None, end_dt: datetime|None=None,
                            n_days: int|None=None) -> tuple[datetime, datetime, int]:
    """ Set the bounds of the search range in UTC.\n
    - If both start_dt and end_dt are None, use the last n_days (default 30).
    - If end_dt is not None, start_dt is set to end_dt - (n_days - 1) or MAX_DAYS_FOR_DATA days before end_dt if n_days is None.
    - If start_dt is not None, end_dt is set to start_dt + (n_days - 1) or MAX_DAYS_FOR_DATA days after start_dt if n_days is None.
    """
    if start_dt is None and end_dt is None:
        now_utc = datetime.now(timezone.utc)
        if n_days is None:
            n_days = MAX_DAYS_FOR_DATA
        start_dt, end_dt = last_n_days_bounds_utc(n_days, now_utc)
    elif end_dt is not None:
        if start_dt is not None:
            n_days = (end_dt - start_dt).days + 1
        elif n_days is not None:
            start_dt = end_dt - timedelta(days=max(1, n_days) - 1)
        else:
            n_days = MAX_DAYS_FOR_DATA
            start_dt = end_dt - timedelta(days=max(1, n_days) - 1)
    elif start_dt is not None:
        if n_days is not None:
            end_dt = start_dt + timedelta(days=max(1, n_days) - 1)
        else:
            end_dt = min(datetime.now(timezone.utc), start_dt + timedelta(days=MAX_DAYS_FOR_DATA))
            n_days = (end_dt - start_dt).days + 1
    return start_dt, end_dt, n_days 


def last_n_days_bounds_utc(n: int, now_utc: datetime | None = None) -> tuple[datetime, datetime]:
    """ Rango [start,end] de los últimos N días completos (hoy incluido), en UTC.
    """
    now_utc = now_utc or datetime.now(timezone.utc)
    end = datetime(now_utc.year, now_utc.month, now_utc.day, 23, 59, 59, tzinfo=timezone.utc)
    start = end - timedelta(days=max(1, n) - 1)
    start = datetime(start.year, start.month, start.day, 0, 0, 0, tzinfo=timezone.utc)
    return start, end


def serialize_checkin_doc(d: dict) -> dict:
    """ Normaliza un documento de check-in a la forma pública del API:
    - Datetimes -> ISO Z
    - Mantiene nombres/estructura exacta del esquema
    """
    if not d:
        return {}
    out = {
        "id": str(d.get("_id")) if d.get("_id") else None,
        "check_in_id": d.get("check_in_id"),
        "user_id": d.get("user_id"),  # rut_norm
        "timestamp": iso_z(d.get("timestamp")),
        "mood": d.get("mood"),
        "pain_level": d.get("pain_level"),
        "stiffness_level": d.get("stiffness_level"),
        "type": d.get("type"),
        "health_metrics": d.get("health_metrics"),
        "weight": None,
        "sleep_sessions": None,
        "exercise_sessions": None,
        "program_sessions": None,
        "notes": d.get("notes") if d.get("notes") not in ("", None) else None,
    }

    w = d.get("weight")
    if isinstance(w, dict):
        out["weight"] = {"value": w.get("value"), "unit": w.get("unit")}

    ss = d.get("sleep_sessions") or []
    if isinstance(ss, list):
        out["sleep_sessions"] = [
            {
                "session_id": s.get("session_id"),
                "start_time": iso_z(s.get("start_time")),
                "end_time": iso_z(s.get("end_time")),
                "source": s.get("source"),
            } for s in ss
        ]
    es = d.get("exercise_sessions") or []
    if isinstance(es, list):
        out["exercise_sessions"] = [
            {
                "session_id": e.get("session_id"),
                "exercise_type": e.get("exercise_type"),
                "sets": e.get("sets"),
                "reps": e.get("reps"),
                "duration_seconds": e.get("duration_seconds"),
                "timestamp": iso_z(e.get("timestamp")),
            } for e in es
        ]
    ps = d.get("program_sessions") or []
    if isinstance(ps, list):
        out["program_sessions"] = [
            {
                "session_id": p.get("session_id"),
                "program_id": p.get("program_id"),
                "template_id": p.get("template_id"),
                "program_name": p.get("program_name"),
                "status": p.get("status"),
                "timestamp": iso_z(p.get("timestamp")),
            } for p in ps
        ]
    return out





def parse_legal_namedoc(namedoc: str) -> tuple[str, str] | None:
    """ Extrae (type, version) desde '<type>_<vN>.pdf'. Retorna None si no calza.
    Ej: 'tcon_v2.pdf' -> ('tcon', 'v2')
    """
    s = safe_str(namedoc)
    m = _LEGAL_NAMEDOC_RX.match(s)
    if not m:
        log.warning("[CONSENT][PARSE_NAMEDOC][BAD] name=%s", s, extra={"tag":"API"})
        return None

    return m.group(1).lower(), m.group(2).lower()


def build_consent_observation(rut_norm: str, doc_type: str, version: str, when_iso: str) -> str:
    """ Genera el texto descriptivo (en inglés) para 'observaciones'.
    """
    user_id = safe_str(rut_norm)
    t  = safe_str(doc_type)
    v  = safe_str(version)
    w  = safe_str(when_iso)
    return f"Patient {user_id} accepted {t} document, version {v} on {w}."


# ---- FCM/Push Tokens Utils ----

# is_valid_platform and is_valid_fcm_token imported from app.domain.validation


def sanitize_device_info(device_info: dict | None) -> dict:
    """ Sanitiza la información del dispositivo para almacenamiento seguro."""
    if not device_info or not isinstance(device_info, dict):
        return {}

    # Lista de campos permitidos para evitar almacenar datos sensibles
    allowed_fields = [
        "model", "brand", "os_version", "app_version", 
        "device_type", "screen_resolution", "timezone"
    ]

    sanitized = {}
    for field in allowed_fields:
        if field in device_info:
            value = device_info[field]
            # Convertir a string y sanitizar
            if isinstance(value, (str, int, float)):
                sanitized[field] = safe_str(str(value))[:100]  # Limitar longitud
    return sanitized


def validate_notification_data(data: dict | None) -> dict:
    """ Valida y sanitiza los datos adicionales de la notificación."""
    if not data or not isinstance(data, dict):
        return {}

    # Limitar el tamaño total de los datos
    try:
        data_str = json.dumps(data)
        if len(data_str) > 4000:  # Límite de FCM es ~4KB
            return {"error": "Data payload too large"}
    except (TypeError, ValueError):
        return {"error": "Invalid data format"}
    return data


def build_fcm_token_filter(user_id: str, active_only: bool = True) -> dict:
    """ Construye el filtro para buscar tokens FCM de un usuario."""
    filter_dict = {"user_id": safe_str(user_id)}
    if active_only:
        filter_dict["is_active"] = True
    return filter_dict
