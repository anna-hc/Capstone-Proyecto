import { http } from "./http";
import type { DailyStatisticsRow, PatientWearableLink, TimeseriesPoint } from "../types/partnerWearables";

const base = (patientId: string) => `/maindash/patient/${encodeURIComponent(patientId)}/wearables`;

export async function fetchPatientWearables(patientId: string, signal?: AbortSignal): Promise<PatientWearableLink[]> {
  const res = await http.get<PatientWearableLink[]>(base(patientId), { signal });
  return res.data;
}

export async function fetchDailyStatistics(patientId: string, fromDate: string, toDate: string,
  signal?: AbortSignal): Promise<DailyStatisticsRow[]> {
  const res = await http.get<{ items: DailyStatisticsRow[] }>(`${base(patientId)}/data/statistics/daily`, {
    params: { from_date: fromDate, to_date: toDate, types: "steps,heart_rate_resting,sleep_duration" },
    signal,
  });
  return res.data.items;
}

export async function fetchHeartRate(patientId: string, fromTs: string, toTs: string,
  signal?: AbortSignal): Promise<TimeseriesPoint[]> {
  const res = await http.get<{ points: TimeseriesPoint[] }>(`${base(patientId)}/data/timeseries`, {
    params: { metric: "heart_rate", from_timestamp: fromTs, to_timestamp: toTs },
    signal,
  });
  return res.data.points;
}
