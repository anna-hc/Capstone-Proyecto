// src/pages/clinician/PatientDetails.tsx
import { useEffect, useMemo, useState, useRef } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import ClinicianShell from "../../layouts/ClinicianShell";
import { http } from "../../services/http";
import { patientDetailsPath, displayPatientName, initialsFor, type Trend } from "../../utils/utils"; //timeAgo, 
import { X, PhoneCall, Activity, CalendarClock, ChevronDown } from "lucide-react";
import AssignDxExModal, { type AssignPayloadExtended } from "./AssignDxExModal";
import VideosPanel from "./msk/VideosPanel";
import DiagnosesPanel from "./msk/DiagnosesPanel";
import AssignExPanel from "./msk/AssignExPanel";
import PainMapPanel from './msk/PainMapPanel';
import PillarGoalsPanel from './msk/PillarGoalsPanel';
import OnboardingViewer from "./msk/OnboardingViewer";
import ClinicalNotesPanel from "./msk/ClinicalNotesPanel";
import CasesPanel from "./msk/CasesPanel";

import NotificationsModal from "./NotificationsModal";
import ManageClinicsModal from "../../components/admin/ManageClinicsModal";
import ManageViewersModal from "../../components/admin/ManageViewersModal";
import MetricsGraph from "./MetricsGraph";
import PatientHeaderCard from "./PatientHeaderCard";
// import IndividualComplianceCard from "./IndividualComplianceCard";
// import RecentActivityCard from "./RecentActivityCard";
import TreatmentPlanTabs from "./TreatmentPlanTabs";
import PatientFlowsheetSection from "./tabs/PatientFlowsheetSection";
import PartnerWearablesPanel from "./components/PartnerWearablesPanel";
import { type RecoveryResponse } from "./MetricsGraph";

type NavState = {
    patient?: { id: string; full_name?: string; first_name?: string; last_name?: string; patient_id?: string; rut_norm?: string; ids?: { patient_id?: string } };
    patients?: Array<{ id: string; full_name?: string; first_name?: string; last_name?: string; patient_id?: string; rut_norm?: string; ids?: { patient_id?: string } }>;
    activeId?: string;
};

type MetricItem = {
    value?: number | null;
    avg?: number | null;
    trend?: Trend;
    unit?: string;
    ts?: string;
};

type ApiResponse = {
    patient: {
        id: string;
        patient_id?: string;
        ids?: { patient_id?: string };
        full_name: string;
        age: number | null;
        status: string;
        last_activity: string;
        overall_compliance: number; // 0..1
        active_alerts: string[];
        treatment_goals?: string[];
        device?: string | null;
        onboarding_summary?: {
            sleep?: string | null;
            stress?: string | null;
            treatment_goal?: string | null;
            sessions_per_week?: number | null;
            exercises_per_week?: number | null;
            reminders_enabled?: boolean;
            submitted_at?: string | null;
        } | null;
    };
    metrics: {
        weight: MetricItem;
        height: MetricItem;
        heart_rate: MetricItem;
    };
    lookbacks_hours: Record<string, number>;
};

type AlertItem = { label: string; tone: "amber" | "red"; pct?: number };

// Commented out until RecentActivityCard is re-enabled
// type RecentActivityItem = {
//     kind: "video" | "checkin";
//     title: string;
//     subtitle?: string | null;
//     ts_iso: string;                // ISO Z desde el back
//     status: "completed" | "missed"; // de momento siempre "completed"
// };

type AssignedExercise = {
    name: string;
    frequency: number;   // times per week
    sets: number;
    repetitions: number;
};

type TreatmentPlanPT = {
    title: string;
    subtitle_lines: string[];  // varias líneas (una por ejercicio)
    exercises?: AssignedExercise[];  // structured exercise data for cards
    done: number;
    total: number;
    unit: "sessions";
};
type TreatmentPlanEP = {
    title: string;
    subtitle: string;
    done: number;
    total: number;
    unit: "days";
};

// Same clinical status vocabulary shown on PatientHeaderCard/PatientGridCard/
// AllPatients (case_history.status_current.est_act_nom via reclassify_job),
// reused here instead of a static "Moderate Risk" label that never changed.
const RISK_BADGE_LABELS: Record<string, string> = {
    stable: "Stable",
    improving: "Improving",
    declining: "Declining",
    at_risk: "At Risk",
};
const RISK_BADGE_STYLES: Record<string, string> = {
    stable: "border-slate-300/60 text-slate-700 dark:text-slate-300 dark:border-slate-400/40 bg-slate-50 dark:bg-slate-900/20",
    improving: "border-emerald-300/60 text-emerald-700 dark:text-emerald-300 dark:border-emerald-400/40 bg-emerald-50 dark:bg-emerald-900/20",
    declining: "border-amber-300/60 text-amber-700 dark:text-amber-300 dark:border-amber-400/40 bg-amber-50 dark:bg-amber-900/20",
    at_risk: "border-red-300/60 text-red-700 dark:text-red-300 dark:border-red-400/40 bg-red-50 dark:bg-red-900/20",
    default: "border-neutral-300/60 text-neutral-600 dark:text-neutral-400 dark:border-neutral-500/40 bg-neutral-50 dark:bg-neutral-900/20",
};

export default function PatientDetails() {
    const navigate = useNavigate();
    const { id = "" } = useParams();
    const location = useLocation();
    const state = (location.state || {}) as NavState;
    const fallbackName = displayPatientName(state.patient);

    const tabs = useMemo(() => {
        const list = Array.isArray(state.patients) && state.patients.length > 0
            ? state.patients
            : (state.patient && (state.patient.patient_id || state.patient.rut_norm || state.patient.ids?.patient_id) ? [state.patient] : [{ id, full_name: fallbackName }]);

        // de-dup por id por seguridad
        const seen = new Set<string>();
        return list.filter(t => {
            if (!t?.id || seen.has(t.id)) return false;
            seen.add(t.id);
            return true;
        });
    }, [state.patients, state.patient, id, fallbackName]);

    const activeTabId = state.activeId || id;

    const [showReturnModal, setShowReturnModal] = useState(false);
    const [returnReason, setReturnReason] = useState("");
    const reasonValid = returnReason.trim().length > 0 && returnReason.trim().length <= 150;
    const [alerts, setAlerts] = useState<AlertItem[]>([]);
    const [tpPT, setTpPT] = useState<TreatmentPlanPT | null>(null);
    // const [tpEP, setTpEP] = useState<TreatmentPlanEP | null>(null);
    const [showNotif, setShowNotif] = useState(false);
    const [showClinics, setShowClinics] = useState(false);
    const [showViewers, setShowViewers] = useState(false);
    // const [openQuickActions, setOpenQuickActions] = useState(false);
    const [openAssign, setOpenAssign] = useState(false);
    const [, setAssignTab] = useState<"dx">("dx");
    const [focusAppointments, setFocusAppointments] = useState(false);
    const [activeDxCodes, setActiveDxCodes] = useState<string[]>([]);
    const treatmentPlanRef = useRef<HTMLDivElement | null>(null);
    const [sendingSnapshot, setSendingSnapshot] = useState(false);

    async function handleSendSnapshotTM3() {
        if (sendingSnapshot || !id) return;
        setSendingSnapshot(true);

        // Create a loading toast
        const toast = document.createElement("div");
        toast.className = "fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-neutral-900 text-white text-sm px-4 py-3 rounded-xl shadow-lg border border-neutral-800 transition-all";
        
        const spinner = document.createElement("div");
        spinner.className = "w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin flex-shrink-0";
        
        const textSpan = document.createElement("span");
        textSpan.textContent = "Sending patient snapshot to TM3...";
        
        toast.appendChild(spinner);
        toast.appendChild(textSpan);
        document.body.appendChild(toast);

        try {
            await http.post(`/sync/tm3/patient/send-snapshot-tm3/${id}`);
            
            // Update toast to success state
            toast.replaceChildren();
            
            const checkIcon = document.createElement("div");
            checkIcon.className = "flex-shrink-0 text-emerald-500 font-bold";
            checkIcon.textContent = "✓";
            toast.appendChild(checkIcon);
            
            const successText = document.createElement("span");
            successText.textContent = "Snapshot sent to TM3 successfully";
            toast.appendChild(successText);
            
            toast.className = "fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-emerald-600 text-white text-sm px-4 py-3 rounded-xl shadow-lg transition-all";
            
            setTimeout(() => {
                toast.classList.add("opacity-0");
                setTimeout(() => toast.remove(), 500);
            }, 3000);
        } catch (e: any) {
            // Update toast to error state
            toast.replaceChildren();
            
            const crossIcon = document.createElement("div");
            crossIcon.className = "flex-shrink-0 text-rose-500 font-bold";
            crossIcon.textContent = "✗";
            toast.appendChild(crossIcon);
            
            const errorText = document.createElement("span");
            const errorMessage = e?.response?.data?.detail || e?.message || "Unknown error";
            errorText.textContent = `Failed to send snapshot: ${errorMessage}`;
            toast.appendChild(errorText);
            
            toast.className = "fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-rose-600 text-white text-sm px-4 py-3 rounded-xl shadow-lg transition-all";
            
            setTimeout(() => {
                toast.classList.add("opacity-0");
                setTimeout(() => toast.remove(), 500);
            }, 4000);
        } finally {
            setSendingSnapshot(false);
        }
    }

    function scrollToAppointments() {
        setFocusAppointments(true);
        setTimeout(() => {
            treatmentPlanRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 50);
    }

    useEffect(() => {
        let alive = true;
        if (!openAssign) return;

        (async () => {
            try {
                // GET activos
                const { data } = await http.get<{ items: Array<{ diag_id: string; diag_name: string; ini?: string }> }>(
                    `/maindash/patient/${id}/diagnoses/active`
                );
                if (!alive) return;
                const codes = (data?.items || []).map((it) => it.diag_id).filter(Boolean);
                setActiveDxCodes(codes);
            } catch {
                // opcional: toast/alert
            }
        })();

        return () => { alive = false; };
    }, [openAssign, id]);




    const [data, setData] = useState<ApiResponse | null>(null);

    useEffect(() => {
        let alive = true;
        (async () => {
            try {
                const { data } = await http.get<ApiResponse>(`/maindash/patient-header/${id}`);
                const body = data as ApiResponse;
                if (alive) setData(body);
            } catch (e: any) {
                console.warn("[PatientDetails][header] failed:", e?.message || e);
            }
        })();
        return () => {
            alive = false;
        };
    }, [id]);

    useEffect(() => {
        let alive = true;
        (async () => {
            try {
                const { data } = await http.get<{ items: AlertItem[] }>(`/maindash/patient/${id}/alerts`);
                if (!alive) return;
                setAlerts(Array.isArray(data?.items) ? data.items : []);
            } catch (e: any) {
                console.warn("[PatientDetails][alerts] failed:", e?.message || e);
                setAlerts([]);
            }
        })();
        return () => { alive = false; };
    }, [id]);

    // Commented out until RecentActivityCard is re-enabled
    // useEffect(() => {
    //     let alive = true;
    //     (async () => {
    //         try {
    //             const { data } = await http.get<{ items: RecentActivityItem[] }>(`/maindash/patient/${id}/recent-activity?limit=5`);
    //             if (!alive) return;
    //             setRecent(Array.isArray(data?.items) ? data.items : []);
    //         } catch (e: any) {
    //             console.warn("[PatientDetails][recent-activity] failed:", e?.message || e);
    //             setRecent([]);
    //         }
    //     })();
    //     return () => { alive = false; };
    // }, [id]);

    useEffect(() => {
        let alive = true;
        (async () => {
            try {
                const { data } = await http.get<{ physical_therapy: TreatmentPlanPT; exercise_program: TreatmentPlanEP }>(
                    `/maindash/patient/${id}/treatment-plan`
                );
                if (!alive) return;
                setTpPT(data?.physical_therapy || null);
                // setTpEP(data?.exercise_program || null);
            } catch (e: any) {
                console.warn("[PatientDetails][treatment-plan] failed:", e?.message || e);
                setTpPT(null);
                // setTpEP(null);
            }
        })();
        return () => { alive = false; };
    }, [id]);

    const [recoveryData, setRecoveryData] = useState<RecoveryResponse | null>(null);
    const [recoveryLoading, setRecoveryLoading] = useState(false);
    const [recoveryRange, setRecoveryRange] = useState<string>("7d");

    useEffect(() => {
        let alive = true;
        (async () => {
            if (!id) return;
            setRecoveryLoading(true);
            try {
                const { data } = await http.get<RecoveryResponse>(
                    `/metric-graph/patient/${id}/recovery-score`,
                    { params: { range: recoveryRange } }
                );
                if (!alive) return;
                setRecoveryData(data?.ok ? data : null);
            } catch (e) {
                console.warn("[PatientDetails][recovery] failed:", e);
                if (alive) setRecoveryData(null);
            } finally {
                if (alive) setRecoveryLoading(false);
            }
        })();
        return () => { alive = false; };
    }, [id, recoveryRange]);

    const name = data?.patient.full_name || fallbackName || "Patient";
    const age = data?.patient.age ?? null;
    // Fallback robusto para obtener el identificador nacional del paciente
    const patientRutSafe = useMemo(() => {
        const rut = (data?.patient?.patient_id || data?.patient?.ids?.patient_id || "").trim();
        return rut || (id || "").trim();
    }, [data?.patient?.patient_id, data?.patient?.ids?.patient_id, id]);

    // --- Barras de cumplimiento Individual Compliance Metrics (commented out for now)
    // const [exerciseCompletion, setExerciseCompletion] = useState<number>(0);
    // const [recent, setRecent] = useState<RecentActivityItem[]>([]);

    // --- MSK Tracker tab controlado desde fuera (para navegar desde el gráfico) ---
    const [mskTab, setMskTab] = useState<"body" | "intake" | "goals" | "diagnoses" | "assignment" | "videos" | "cases" | "notes" | "evolution">("body");
    const [preselectedCaseId, setPreselectedCaseId] = useState<string | null>(null);
    const mskSectionRef = useRef<HTMLDivElement | null>(null);

    function scrollToMskSection() {
        if (mskSectionRef.current) {
            mskSectionRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    }


    async function submitReturnPatient() {
        if (!reasonValid) return;
        try {
            await http.post("/admin/patients/return", {
                patient_id: id,        // acepta ObjectId o P-...
                reason: returnReason.trim(),
            });
            // Toast simple
            const toast = document.createElement("div");
            toast.textContent = "Patient returned successfully.";
            toast.className = "fixed bottom-4 right-4 bg-rose-600 text-white text-sm px-4 py-2 rounded-full shadow-md";
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 2200);

            // Volver al maindashboard
            navigate("/");
        } catch (e: any) {
            alert(e?.response?.data?.detail || "Failed to return patient.");
        }
    }

    async function handleSaveAssignments(payload: AssignPayloadExtended) {
        try {
            const dxDiff = payload?.dxDiff || { add: [], remove: [] };
            await http.post(`/maindash/patient/${id}/diagnoses/save`, dxDiff);

            const { data } = await http.get<{ items: Array<{ diag_id: string; diag_name: string; ini?: string }> }>(
                `/maindash/patient/${id}/diagnoses/active`
            );
            const codes = (data?.items || []).map((it) => it.diag_id).filter(Boolean);
            setActiveDxCodes(codes);
        } catch (e: any) {
            alert(`No se pudieron guardar los cambios: ${e?.message || "Error desconocido"}`);
        }
    }

    return (
        <ClinicianShell title="" subtitle="">

            {/* --- Barra de pestañas (sticky, translúcida, con scroll horizontal) --- */}
            {tabs.length > 1 && (
                <div className="sticky top-0 z-30 border-b border-neutral-200 dark:border-neutral-800 bg-white/70 dark:bg-neutral-900/60 backdrop-blur supports-[backdrop-filter]:backdrop-blur">
                    <div className="overflow-x-auto">
                        <div className="flex items-stretch gap-2 px-3 py-2 min-h-[48px]">
                            {tabs.map(tp => {
                                const label =
                                    tp.full_name?.trim() ||
                                    displayPatientName(tp) ||
                                    tp.id;

                                const isActive = (tp.id === activeTabId);
                                return (
                                    <button
                                        key={tp.id}
                                        onClick={() => {
                                            navigate(patientDetailsPath(tp.id), {
                                                state: { patients: tabs, activeId: tp.id }
                                            });
                                        }}
                                        className={`shrink-0 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border transition
              ${isActive
                                                ? "bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-50 border-neutral-300 dark:border-neutral-700 shadow-sm"
                                                : "bg-neutral-100/70 dark:bg-neutral-800/40 text-neutral-700 dark:text-neutral-200 border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800"}`}
                                        title={label}
                                    >
                                        <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-neutral-200 dark:bg-neutral-700 text-xs font-semibold">
                                            {initialsFor(label)}
                                        </span>
                                        <span className="max-w-[220px] truncate">{label}</span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                </div>
            )}

            {/* Barra superior con Back a la izquierda y botones a la derecha */}
            <div className="mt-4 mb-4 flex items-center justify-between gap-3">
                <button
                    onClick={() => navigate("/allpatients")}
                    className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-neutral-300 dark:border-neutral-700 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                >
                    ‹ Back
                </button>

                <div className="flex items-center gap-2">
                    <TopAction icon={<PhoneCall className="w-4 h-4" />} label="Call" />
                    {/* <TopAction icon={<MessageSquare className="w-4 h-4" />} label="Message" /> */}
                    <TopAction icon={<Activity className="w-4 h-4" />} label="MSK Tracker" onClick={scrollToMskSection} />
                    <TopPrimary
                        icon={<CalendarClock className="w-4 h-4" />}
                        label="Schedule"
                        onClick={scrollToAppointments}
                    />

                    {/* Nuevo botón de acciones rápidas */}
                    <QuickActionsMenu
                        onAssign={() => {
                            setOpenAssign(true);
                        }}
                        onNotify={() => setShowNotif(true)}
                        onManageClinics={() => setShowClinics(true)}
                        onManageViewers={() => setShowViewers(true)}
                        onSchedule={() => scrollToAppointments()}
                        onScheduleUrgent={() => scrollToAppointments()}
                        onSendSnapshotTM3={handleSendSnapshotTM3}
                    />
                </div>
            </div>

            {/* Cabecera: card izquierda (resumen paciente) + card derecha (métricas) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* ——— Izquierda: Resumen del paciente ——— */}
                <PatientHeaderCard
                    name={name}
                    age={age}
                    status={data?.patient.status || ""}
                    lastActivity={data?.patient.last_activity || ""}
                    overallCompliance={data?.patient.overall_compliance ?? 0}
                    alerts={alerts}
                    device={data?.patient.device}
                    recoveryData={recoveryData}
                    recoveryLoading={recoveryLoading}
                    recoveryRange={recoveryRange}
                    setRecoveryRange={setRecoveryRange}
                    treatmentGoals={data?.patient.treatment_goals || []}
                    onboardingSummary={data?.patient.onboarding_summary}
                    onReturnPatient={() => setShowReturnModal(true)}
                    patientId={id}
                />

                <div className="lg:col-span-2">
                    <MetricsGraph
                        patientId={id!}
                        patientRut={patientRutSafe}
                        onNavigateToDailyExercise={() => {
                            setMskTab("diagnoses");
                            scrollToMskSection();
                        }}
                        onNavigateToExerciseVideos={() => {
                            setMskTab("videos");
                            scrollToMskSection();
                        }}
                    />
                </div>
            </div>
            {/* ======== Sección 2: Compliance + Activity ========
            <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <IndividualComplianceCard exerciseCompletion={exerciseCompletion} />
                <RecentActivityCard activities={recent} timeAgo={timeAgo} />
            </div>  */}

            <div ref={treatmentPlanRef} className="mt-6">
                <TreatmentPlanTabs
                    patientId={id!}
                    patientRut={patientRutSafe}
                    patientName={name}
                    tpPT={tpPT}
                    // tpEP={tpEP}
                    focusAppointments={focusAppointments}
                    onFocusHandled={() => setFocusAppointments(false)}
                />
            </div>

            {/* ======== Sección 4: MSK Tracker & Body Chart ======== */}
            <section
                ref={mskSectionRef}
                className="mt-6 rounded-2xl border bg-white shadow-sm border-neutral-200 dark:bg-neutral-900 dark:border-neutral-800"
            >
                <header className="px-5 py-4 border-b border-neutral-200 dark:border-neutral-800 rounded-t-2xl flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-neutral-900 dark:text-neutral-50 flex items-center gap-2">
                        <Activity className="w-5 h-5" />
                        MSK Tracker, Body Chart &amp; Exercises </h2>
                    <span
                        className={`inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold ${RISK_BADGE_STYLES[data?.patient.status || ""] || RISK_BADGE_STYLES.default}`}
                        data-testid="badge-risk-level"
                    >
                        {RISK_BADGE_LABELS[data?.patient.status || ""] || "Status unknown"}
                    </span>
                </header>

                <div className="p-5">
                    <MskTabs
                        patientRut={patientRutSafe}
                        patientId={id}
                        activeTab={mskTab}
                        onChangeTab={setMskTab}
                        activeDxCodes={activeDxCodes}
                        preselectedCaseId={preselectedCaseId}
                        onClearPreselectedCase={() => setPreselectedCaseId(null)}
                        onManageDiagnoses={(caseId) => {
                            setPreselectedCaseId(caseId);
                            setMskTab("diagnoses");
                            scrollToMskSection();
                        }}
                        onOpenAssignExercises={() => {
                            setAssignTab("dx");
                            setOpenAssign(true);
                        }}
                    />
                </div>
            </section>

            {/* Wibbi Flowsheet, Compliance & Evolution Analytics.
            The Flowsheet log table itself is hidden inside PatientFlowsheetSection
            (redundant with the "Videos" tab above); this banner (Commitment,
            Evolution Trajectory, Check-in Synchronization) stays visible. */}
            <div className="mt-6">
                <PatientFlowsheetSection patientId={id!} />
            </div>

            <div className="mt-6">
                <PartnerWearablesPanel patientId={id!} />
            </div>

            {/* Modal de asignación */}
            <AssignDxExModal
                open={openAssign}
                onClose={() => setOpenAssign(false)}
                initialDiagnoses={activeDxCodes}
                onSave={handleSaveAssignments}
            />
            {/* Modal de agendación */}


            {/* Modal de notificaciones */}
            {showNotif && (
                <NotificationsModal
                    patientId={patientRutSafe}
                    patientStatus={data?.patient.status}
                    onClose={() => setShowNotif(false)}
                />
            )}

            {showClinics && (
                <ManageClinicsModal
                    patientId={data?.patient.id || id}
                    patientName={name}
                    onClose={() => setShowClinics(false)}
                />
            )}

            {showViewers && (
                <ManageViewersModal
                    patientId={data?.patient.id || id}
                    patientName={name}
                    onClose={() => setShowViewers(false)}
                />
            )}

            {showReturnModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center">
                    {/* ... resto del modal de Return Patient ... */}
                </div>
            )}

            {showReturnModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center">
                    <div className="absolute inset-0 bg-black/40" onClick={() => setShowReturnModal(false)} />
                    <div className="relative w-[95%] max-w-lg rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-xl">
                        <div className="p-5 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                            <div className="text-lg font-semibold">Return Patient</div>
                            <button onClick={() => setShowReturnModal(false)} className="p-1 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800">
                                <X className="w-4 h-4" />
                            </button>
                        </div>
                        <div className="p-5 space-y-2">
                            <label className="block text-sm text-neutral-600 dark:text-neutral-300">Reason (max 150 chars)</label>
                            <textarea
                                value={returnReason}
                                onChange={(e) => setReturnReason(e.target.value.slice(0, 150))}
                                placeholder="Describe why you are returning this patient..."
                                className="w-full min-h-[110px] rounded-xl border border-neutral-300 dark:border-neutral-700 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-400 dark:bg-neutral-800 dark:text-neutral-100"
                            />
                            {!reasonValid && (
                                <div className="text-xs text-rose-600 dark:text-rose-400">Reason is required (1–150 characters).</div>
                            )}
                        </div>
                        <div className="p-5 pt-0 flex items-center justify-end gap-3">
                            <button
                                onClick={() => setShowReturnModal(false)}
                                className="px-4 py-2 rounded-full text-sm font-medium border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={submitReturnPatient}
                                disabled={!reasonValid}
                                className={`px-4 py-2 rounded-full text-sm font-medium text-white shadow transition ${reasonValid ? "bg-rose-600 hover:bg-rose-700" : "bg-neutral-400 cursor-not-allowed"}`}
                            >
                                Confirm Return
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </ClinicianShell>
    );
}

/* ——— UI subcomponents ——— */


function TopAction({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick?: () => void }) {
    return (
        <button
            onClick={onClick}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-neutral-300 dark:border-neutral-700 text-sm
                    text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"
        >
            {icon}
            {label}
        </button>
    );
}

function TopPrimary({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick?: () => void }) {
    return (
        <button
            onClick={onClick}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm"
        >
            {icon}
            {label}
        </button>
    );
}

function QuickActionsMenu({
    onAssign,
    onNotify,
    onManageClinics,
    onManageViewers,
    onSchedule,
    onScheduleUrgent,
    onSendSnapshotTM3,
}: {
    onAssign: () => void;
    onNotify: () => void;
    onManageClinics: () => void;
    onManageViewers: () => void;
    onSchedule: () => void;
    onScheduleUrgent: () => void;
    onSendSnapshotTM3: () => void;
}) {
    const [open, setOpen] = useState(false);

    function handle(action: () => void) {
        action();
        setOpen(false);
    }

    return (
        <div className="relative">
            <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-neutral-300 dark:border-neutral-700 text-sm
                    text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800"
            >
                Quick Actions
                <ChevronDown className="w-4 h-4" />
            </button>

            {open && (
                <div
                    className="absolute right-0 mt-2 w-64 rounded-xl border border-neutral-200 dark:border-neutral-800
                               bg-white dark:bg-neutral-900 shadow-lg z-40"
                >
                    <div className="py-1">
                        <button
                            onClick={() => handle(onAssign)}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        >
                            Diagnostic Assignment
                        </button>
                        <button
                            onClick={() => handle(onNotify)}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        >
                            Send notification
                        </button>
                        <button
                            onClick={() => handle(onManageClinics)}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        >
                            Manage clinic assignment
                        </button>
                        <button
                            onClick={() => handle(onManageViewers)}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        >
                            Manage secondary clinicians
                        </button>
                        <button
                            onClick={() => handle(onSchedule)}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        >
                            Schedule appointment
                        </button>
                        <button
                            onClick={() => handle(onScheduleUrgent)}
                            className="w-full px-4 py-2 text-left text-sm text-rose-600 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-900/20"
                        >
                            Schedule urgent visit
                        </button>
                        <button
                            onClick={() => handle(onSendSnapshotTM3)}
                            className="w-full px-4 py-2 text-left text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 border-t border-neutral-100 dark:border-neutral-800"
                        >
                            Send Snapshot to TM3
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}


/* ===================== MSK Tabs Section ===================== */

function MskTabs({
    patientRut,
    patientId,
    activeTab,
    onChangeTab,
    activeDxCodes,
    preselectedCaseId,
    onClearPreselectedCase,
    onManageDiagnoses,
    // onOpenAssignExercises,
}: {
    patientRut: string;
    patientId: string;
    activeTab: "body" | "intake" | "goals" | "diagnoses" | "assignment" | "videos" | "cases" | "notes" | "evolution";
    onChangeTab: (tab: "body" | "intake" | "goals" | "diagnoses" | "assignment" | "videos" | "cases" | "notes" | "evolution") => void;
    onOpenAssignExercises: (exerciseCodes?: string[], initialTab?: "dx" | "ex" | "recs") => void;
    activeDxCodes: string[];
    preselectedCaseId: string | null;
    onClearPreselectedCase: () => void;
    onManageDiagnoses: (caseId: string) => void;
}) {
    return (
        <div className="w-full">
            {/* Tabs header */}
            <div className="grid grid-cols-4 md:grid-cols-8 h-auto md:h-10 items-center rounded-md bg-neutral-100 dark:bg-neutral-800/50 p-1 text-neutral-500 dark:text-neutral-300 gap-1">
                <TabButton active={activeTab === "intake"} onClick={() => onChangeTab("intake")}>Onboarding</TabButton>
                <TabButton active={activeTab === "body"} onClick={() => onChangeTab("body")}>Body Chart</TabButton>
                <TabButton active={activeTab === "diagnoses"} onClick={() => onChangeTab("diagnoses")}>Diagnoses</TabButton>
                <TabButton active={activeTab === "assignment"} onClick={() => onChangeTab("assignment")}>Assignment</TabButton>
                <TabButton active={activeTab === "goals"} onClick={() => onChangeTab("goals")}>Health Metrics</TabButton>
                <TabButton active={activeTab === "videos"} onClick={() => onChangeTab("videos")}>Videos</TabButton>
                <TabButton active={activeTab === "cases"} onClick={() => onChangeTab("cases")}>Cases</TabButton>
                <TabButton active={activeTab === "notes"} onClick={() => onChangeTab("notes")}>Notes</TabButton>
            </div>

            {/* Panels */}
            {activeTab === "body" && (
                patientRut && patientRut.trim()
                    ? (
                        <PainMapPanel
                            patientRut={patientRut}
                        />
                    )
                    : <div className="text-sm text-neutral-500 dark:text-neutral-400">Loading patient identifier…</div>
            )}
            {activeTab === "intake" && (
                patientRut && patientRut.trim()
                    ? <OnboardingViewer patientRut={patientRut} />
                    : <div className="text-sm text-neutral-500 dark:text-neutral-400 min-h-[100px] flex items-center justify-center">Loading patient identifier…</div>
            )}
            {activeTab === "goals" && <PillarGoalsPanel patientRut={patientRut} patientId={patientId} />}
            {activeTab === "diagnoses" && (
                <DiagnosesPanel
                    patientId={patientId}
                    preselectedCaseId={preselectedCaseId}
                    onClearPreselectedCase={onClearPreselectedCase}
                />
            )}
            {activeTab === "assignment" && <AssignExPanel patientId={patientId} patientRut={patientRut} activeDxCodes={activeDxCodes} />}
            {activeTab === "videos" && <VideosPanel patientRut={patientRut} />}
            {activeTab === "cases" && (
                <CasesPanel
                    patientId={patientId}
                    onManageDiagnoses={onManageDiagnoses}
                />
            )}
            {activeTab === "notes" && <ClinicalNotesPanel patientId={patientId} />}
        </div>
    );
}

function TabButton({
    active,
    onClick,
    children,
}: {
    active: boolean;
    onClick: () => void;
    children: React.ReactNode;
}) {
    return (
        <button
            type="button"
            onClick={onClick}
            className={`inline-flex items-center justify-center whitespace-nowrap rounded-sm px-2 py-1.5 text-sm font-medium transition-all
      focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500
      ${active ? "bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-50 shadow-sm" : ""}`}
        >
            {children}
        </button>
    );
}
