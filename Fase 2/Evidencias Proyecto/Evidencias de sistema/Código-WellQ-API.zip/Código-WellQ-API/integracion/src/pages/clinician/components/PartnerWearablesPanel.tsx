import { useEffect, useMemo, useState } from "react";
import { isAxiosError } from "axios";
import { Loader2, RefreshCw, Watch } from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { fetchDailyStatistics, fetchHeartRate, fetchPatientWearables } from "../../../services/partnerWearables";
import type { DailyStatisticsRow, PatientWearableLink, TimeseriesPoint } from "../../../types/partnerWearables";

interface Props {
  patientId: string;
}

type LoadState = "loading" | "ready" | "error" | "hidden";

const WEAR_LABEL: Record<string, string> = { worn: "Worn", not_worn: "Not worn", unknown: "Unknown" };
const STATUS_STYLE: Record<string, string> = {
  active: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800",
  revoked: "bg-neutral-100 text-neutral-600 border-neutral-200 dark:bg-neutral-800 dark:text-neutral-300 dark:border-neutral-700",
  suspended: "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800",
};

const isoDay = (d: Date) => d.toISOString().slice(0, 10);
const formatDate = (value?: string | null) => (value ? new Date(value).toLocaleString() : "—");

export default function PartnerWearablesPanel({ patientId }: Props) {
  const [state, setState] = useState<LoadState>("loading");
  const [links, setLinks] = useState<PatientWearableLink[]>([]);
  const [daily, setDaily] = useState<DailyStatisticsRow[]>([]);
  const [heartRate, setHeartRate] = useState<TimeseriesPoint[]>([]);
  const [reload, setReload] = useState(0);

  useEffect(() => {
    if (!patientId) return;
    const controller = new AbortController();
    const now = new Date();
    const from = new Date(now.getTime() - 13 * 86400000);
    setState("loading");
    (async () => {
      try {
        const items = await fetchPatientWearables(patientId, controller.signal);
        setLinks(items);
        if (items.length === 0) {
          setState("ready");
          return;
        }
        const [rows, points] = await Promise.all([
          fetchDailyStatistics(patientId, isoDay(from), isoDay(now), controller.signal),
          fetchHeartRate(patientId, new Date(now.getTime() - 86400000).toISOString(), now.toISOString(), controller.signal),
        ]);
        setDaily(rows);
        setHeartRate(points);
        setState("ready");
      } catch (err) {
        if (controller.signal.aborted) return;
        // 404: la Partner API no está activa o el clínico no tiene acceso; el panel no se muestra
        if (isAxiosError(err) && err.response?.status === 404) setState("hidden");
        else setState("error");
      }
    })();
    return () => controller.abort();
  }, [patientId, reload]);

  const hrSeries = useMemo(
    () => heartRate.map((p) => ({ time: new Date(p.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), bpm: p.value })),
    [heartRate],
  );
  const dailySeries = useMemo(
    () => daily.map((d) => ({ day: d.local_date.slice(5), steps: d.steps ?? null, rhr: d.heart_rate_resting ?? null })),
    [daily],
  );

  if (state === "hidden") return null;

  return (
    <section className="rounded-2xl border bg-white shadow-sm border-neutral-200 dark:bg-neutral-900 dark:border-neutral-800"
      aria-labelledby="partner-wearables-title">
      <header className="px-5 py-4 border-b border-neutral-200 dark:border-neutral-800 rounded-t-2xl flex items-center justify-between gap-3">
        <h2 id="partner-wearables-title" className="text-lg font-semibold text-neutral-900 dark:text-neutral-50 flex items-center gap-2">
          <Watch className="w-5 h-5" aria-hidden="true" />
          Connected devices
        </h2>
        <button type="button" onClick={() => setReload((n) => n + 1)} disabled={state === "loading"}
          className="inline-flex items-center gap-1 rounded-md border border-neutral-200 px-2.5 py-1 text-sm text-neutral-700 hover:bg-neutral-50 disabled:opacity-50 dark:border-neutral-700 dark:text-neutral-200 dark:hover:bg-neutral-800">
          <RefreshCw className="w-4 h-4" aria-hidden="true" /> Refresh
        </button>
      </header>
      <div className="p-5 space-y-5">
        {state === "loading" && (
          <p className="flex items-center gap-2 text-sm text-neutral-500" role="status">
            <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> Loading devices…
          </p>
        )}
        {state === "error" && (
          <p className="text-sm text-red-600 dark:text-red-400" role="alert">Could not load the patient's devices. Try again later.</p>
        )}
        {state === "ready" && links.length === 0 && (
          <p className="text-sm text-neutral-500">No manufacturer devices linked to this patient.</p>
        )}
        {state === "ready" && links.length > 0 && (
          <>
            <ul className="grid gap-3 md:grid-cols-2">
              {links.map((link) => (
                <li key={link.link_id} className="rounded-xl border border-neutral-200 p-4 dark:border-neutral-800">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-medium text-neutral-900 dark:text-neutral-50 truncate">{link.partner_name ?? "Unknown manufacturer"}</p>
                      <p className="text-sm text-neutral-500 truncate">{link.model_display_name ?? link.form_factor ?? "Device"}</p>
                    </div>
                    <span className={`shrink-0 rounded-md border px-2 py-0.5 text-xs font-semibold ${STATUS_STYLE[link.status] ?? STATUS_STYLE.revoked}`}>
                      {link.status}
                    </span>
                  </div>
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                    <dt className="text-neutral-500">Last sync</dt><dd className="text-neutral-800 dark:text-neutral-200">{formatDate(link.last_sync_at)}</dd>
                    <dt className="text-neutral-500">Wear status</dt><dd className="text-neutral-800 dark:text-neutral-200">{WEAR_LABEL[link.wear_status] ?? link.wear_status}</dd>
                    <dt className="text-neutral-500">Source reliability</dt>
                    <dd className="text-neutral-800 dark:text-neutral-200">{link.source_quality !== undefined ? `${Math.round(link.source_quality * 100)}%` : "—"}</dd>
                    {Object.entries(link.last_received ?? {}).map(([kind, ts]) => (
                      <div key={kind} className="contents">
                        <dt className="text-neutral-500">Last {kind.replace(/_/g, " ")}</dt>
                        <dd className="text-neutral-800 dark:text-neutral-200">{formatDate(ts)}</dd>
                      </div>
                    ))}
                  </dl>
                </li>
              ))}
            </ul>
            <div className="grid gap-5 lg:grid-cols-2">
              <figure>
                <figcaption className="mb-2 text-sm font-medium text-neutral-700 dark:text-neutral-200">Steps and resting heart rate (14 days)</figcaption>
                {dailySeries.some((d) => d.steps !== null || d.rhr !== null) ? (
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={dailySeries} margin={{ top: 5, right: 10, bottom: 0, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                        <YAxis yAxisId="steps" tick={{ fontSize: 11 }} width={44} />
                        <YAxis yAxisId="rhr" orientation="right" tick={{ fontSize: 11 }} width={34} />
                        <Tooltip />
                        <Line yAxisId="steps" type="monotone" dataKey="steps" name="Steps" stroke="#2b59c3" dot={false} connectNulls />
                        <Line yAxisId="rhr" type="monotone" dataKey="rhr" name="Resting HR" stroke="#b3261e" dot={false} connectNulls />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : <p className="text-sm text-neutral-500">No daily data in this period.</p>}
              </figure>
              <figure>
                <figcaption className="mb-2 text-sm font-medium text-neutral-700 dark:text-neutral-200">Heart rate (last 24 h)</figcaption>
                {hrSeries.length > 0 ? (
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={hrSeries} margin={{ top: 5, right: 10, bottom: 0, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="time" tick={{ fontSize: 11 }} minTickGap={24} />
                        <YAxis tick={{ fontSize: 11 }} width={34} domain={["auto", "auto"]} />
                        <Tooltip />
                        <Line type="monotone" dataKey="bpm" name="bpm" stroke="#b3261e" dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : <p className="text-sm text-neutral-500">No heart-rate samples in the last 24 hours.</p>}
              </figure>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
