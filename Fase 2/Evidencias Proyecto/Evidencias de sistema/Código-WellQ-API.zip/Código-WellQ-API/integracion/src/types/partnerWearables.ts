// Tipos de la Partner API que consume el panel clínico

export type WearStatus = "worn" | "not_worn" | "unknown";
export type LinkStatus = "active" | "revoked" | "suspended";

export interface IngestInterval {
  metric: string;
  interval_seconds: number;
  source: "device_model" | "wellq";
}

export interface PatientWearableLink {
  link_id: string;
  partner_name: string | null;
  partner_logo_url: string | null;
  model_display_name: string | null;
  form_factor: string | null;
  status: LinkStatus;
  granted_scopes: string[];
  linked_at: string | null;
  last_sync_at: string | null;
  wear_status: WearStatus;
  source_quality?: number;
  last_received?: Record<string, string | null>;
  ingest_config?: { intervals: IngestInterval[] };
  revoked_at?: string | null;
}

export interface DailyStatisticsRow {
  local_date: string;
  steps?: number | null;
  heart_rate_resting?: number | null;
  sleep_duration?: number | null;
}

export interface TimeseriesPoint {
  timestamp: string;
  value: number;
  provider: string;
}
