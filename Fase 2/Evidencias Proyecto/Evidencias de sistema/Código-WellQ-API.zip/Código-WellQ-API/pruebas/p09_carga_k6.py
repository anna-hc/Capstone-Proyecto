"""Pruebas de rendimiento y carga con k6.

Prepara K6_APPS apps de pruebas (cada una con su vínculo y su límite de 600 peticiones/min), escribe sus
credenciales en un archivo temporal de la ejecución y lanza pruebas/k6/carga.js con el perfil elegido.

    python pruebas/p09_carga_k6.py                    # perfil de K6_PERFIL (humo por defecto)
    python pruebas/p09_carga_k6.py carga              # humo | carga | estres | pico | resistencia
    K6_VUS=50 K6_DURACION=10m python pruebas/p09_carga_k6.py carga

Resultados: resumen_k6.md (latencias p50/p95/p99 y umbrales) y resumen_k6.json en la carpeta de evidencias.
Si no se cumple algún umbral, k6 sale con código 99 y la suite queda en FALLO.
"""
from __future__ import annotations

import json
import os
import sys

import sandbox
from comun import (DIR_PRUEBAS, ClienteAPI, Informe, cargar_config, ejecutar, exigir_api, exigir_no_produccion,
                   herramienta)

PERFILES = ("humo", "carga", "estres", "pico", "resistencia")


def main() -> int:
    cfg = cargar_config()
    perfil = next((a for a in sys.argv[1:] if a in PERFILES), cfg["K6_PERFIL"] or "humo")
    informe = Informe("09_carga_k6", f"Rendimiento y carga (k6, perfil {perfil})")
    exigir_no_produccion(cfg, "La prueba de carga")
    k6 = herramienta("k6")
    if not k6:
        informe.registrar("K6-00", "k6 instalado", False,
                          "instálalo: winget install k6 --source winget · brew install k6 · https://grafana.com/docs/k6/latest/set-up/install-k6/")
        return informe.cerrar()
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    carpeta = informe.carpeta

    num_apps = int(cfg.get("K6_APPS") or {"humo": 1, "carga": 2, "estres": 4, "pico": 4, "resistencia": 2}[perfil])

    def preparar():
        estado = sandbox.preparar(cfg, api)
        creds = [{k: estado[k] for k in ("client_id", "client_secret", "access_token", "link_id", "device_id")}]
        for i in range(1, num_apps):
            if not estado.get("portal_token"):
                break
            app = sandbox.crear_app(api, estado["portal_token"], f"QA carga {i} {os.environ['WELLQ_RUN_ID']}")
            tok = sandbox.obtener_token(api, app["client_id"], app["client_secret"], sandbox.SCOPES_TOKEN)
            sandbox.declarar_modelo(api, tok, app["app_id"])
            vinc = sandbox.nuevo_vinculo(api, tok)
            creds.append({"client_id": app["client_id"], "client_secret": app["client_secret"], "access_token": tok,
                          "link_id": vinc["link_id"], "device_id": sandbox.DISPOSITIVO})
        return creds
    creds = informe.verificar("K6-01", f"Preparar {num_apps} apps con vínculo para repartir la carga", preparar)
    if not creds:
        return informe.cerrar()
    archivo = carpeta / "credenciales_k6.json"  # se borra al terminar
    archivo.write_text(json.dumps(creds), encoding="utf-8")
    try:
        env = {"WELLQ_API": cfg.api, "K6_CREDENCIALES": str(archivo), "K6_PERFIL": perfil,
               "K6_SALIDA": str(carpeta).replace("\\", "/"), "K6_VUS": cfg["K6_VUS"], "K6_DURACION": cfg["K6_DURACION"]}
        codigo = ejecutar([k6, "run", "--quiet", str(DIR_PRUEBAS / "k6" / "carga.js")], carpeta, "salida_k6.txt",
                          env=env, timeout=4 * 3600)
    finally:
        archivo.unlink(missing_ok=True)

    resumen = carpeta / "resumen_k6.json"
    if resumen.exists():
        datos = json.loads(resumen.read_text(encoding="utf-8"))
        for metrica, val in datos.get("metrics", {}).items():
            for umbral, res in (val.get("thresholds") or {}).items():
                informe.registrar("K6", f"{metrica} {umbral}", bool(res.get("ok")))
        reqs = datos["metrics"].get("http_reqs", {}).get("values", {})
        print(f"    {int(reqs.get('count', 0))} peticiones, {reqs.get('rate', 0):.1f}/s")
    informe.registrar("K6-99", "k6 terminó y se cumplen todos los umbrales", codigo == 0,
                      {99: "algún umbral no se cumplió"}.get(codigo, f"código {codigo}"))
    return informe.cerrar({"perfil": perfil, "apps": num_apps})


if __name__ == "__main__":
    sys.exit(main())
