// Prueba de rendimiento y carga de la WellQ Partner API con k6.
//
// No se ejecuta a mano: lo lanza pruebas/p09_carga_k6.py, que prepara las apps y vínculos de pruebas y
// pasa sus credenciales en el archivo indicado por K6_CREDENCIALES. Variables:
//   K6_PERFIL   humo | carga | estres | pico | resistencia   (por defecto humo)
//   K6_VUS      usuarios virtuales máximos (sobrescribe el perfil)
//   K6_DURACION duración de la meseta, p. ej. 5m (sobrescribe el perfil)
//   WELLQ_API   URL base con /api/v1
import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Counter, Rate, Trend } from 'k6/metrics';
import exec from 'k6/execution';

const API = __ENV.WELLQ_API;
const CREDENCIALES = JSON.parse(open(__ENV.K6_CREDENCIALES));
const PERFIL = __ENV.K6_PERFIL || 'humo';
const VUS = parseInt(__ENV.K6_VUS || '0', 10);
const DURACION = __ENV.K6_DURACION || '';

const PERFILES = {
  humo: [{ duration: '30s', target: VUS || 2 }],
  carga: [
    { duration: '1m', target: VUS || 20 },
    { duration: DURACION || '5m', target: VUS || 20 },
    { duration: '30s', target: 0 },
  ],
  estres: [
    { duration: '1m', target: Math.round((VUS || 100) * 0.2) },
    { duration: '2m', target: Math.round((VUS || 100) * 0.5) },
    { duration: '2m', target: VUS || 100 },
    { duration: DURACION || '3m', target: VUS || 100 },
    { duration: '1m', target: 0 },
  ],
  pico: [
    { duration: '30s', target: 5 },
    { duration: '10s', target: VUS || 100 },
    { duration: DURACION || '1m', target: VUS || 100 },
    { duration: '10s', target: 5 },
    { duration: '1m', target: 5 },
  ],
  resistencia: [
    { duration: '2m', target: VUS || 10 },
    { duration: DURACION || '30m', target: VUS || 10 },
    { duration: '1m', target: 0 },
  ],
};

const limitados = new Rate('wellq_rate_limited');       // proporción de 429
const rechazados = new Counter('wellq_registros_rechazados');
const latIngesta = new Trend('wellq_latencia_ingesta', true);
const latLectura = new Trend('wellq_latencia_lectura', true);

export const options = {
  scenarios: {
    fabricantes: { executor: 'ramping-vus', startVUs: 1, stages: PERFILES[PERFIL], gracefulRampDown: '30s' },
  },
  thresholds: {
    // Criterios de aceptación (ajústalos al SLO acordado). Si no se cumplen, k6 sale con código 99.
    http_req_failed: ['rate<0.01'],
    checks: ['rate>0.99'],
    wellq_latencia_ingesta: ['p(95)<800', 'p(99)<2000'],
    wellq_latencia_lectura: ['p(95)<400', 'p(99)<1000'],
    wellq_rate_limited: [PERFIL === 'estres' || PERFIL === 'pico' ? 'rate<0.5' : 'rate<0.05'],
  },
  // 429 es una respuesta esperada bajo presión: se mide aparte y no cuenta como fallo HTTP.
  // 401 aparece si el token caduca en una prueba larga: se renueva y no cuenta como fallo.
  setupTimeout: '60s',
  summaryTrendStats: ['avg', 'min', 'med', 'p(90)', 'p(95)', 'p(99)', 'max'],
};

http.setResponseCallback(http.expectedStatuses({ min: 200, max: 299 }, 401, 429));

const tokens = {};

function credencial() {
  const c = CREDENCIALES[(exec.vu.idInTest - 1) % CREDENCIALES.length];
  if (!tokens[c.client_id] || Date.now() - tokens[c.client_id].en > 40 * 60 * 1000) {
    // Sin `scope`: el token recibe los scopes concedidos a la app. Pedir una lista fija fallaba (400 invalid_scope)
    // cuando otra suite (p05/p07) había reducido los scopes de la app compartida.
    const r = http.post(`${API}/partner/oauth/token`, {
      grant_type: 'client_credentials', client_id: c.client_id, client_secret: c.client_secret,
    }, { tags: { name: 'oauth_token' } });
    if (r.status === 200) tokens[c.client_id] = { token: r.json('access_token'), en: Date.now() };
    else {
      console.warn(`oauth/token respondió ${r.status}: ${String(r.body).slice(0, 200)}`);
      if (!tokens[c.client_id]) tokens[c.client_id] = { token: c.access_token, en: Date.now() };
    }
  }
  return { ...c, token: tokens[c.client_id].token };
}

function hoyMenos(dias) {
  const d = new Date(Date.now() - dias * 86400000);
  return d.toISOString().slice(0, 10);
}

function id() {
  return `k6-${exec.vu.idInTest}-${exec.vu.iterationInScenario}-${Math.random().toString(36).slice(2, 8)}`;
}

function registrar(r, nombre, trend, c) {
  limitados.add(r.status === 429);
  if (r.status === 401) { delete tokens[c.client_id]; return; }
  if (r.status === 429) { sleep(Math.min(parseInt(r.headers['Retry-After'] || '1', 10), 10)); return; }
  trend.add(r.timings.duration);
  // deja en la salida el motivo de cada respuesta no 2xx para no tener que adivinarlo (defecto D-07)
  if (r.status < 200 || r.status >= 300) console.warn(`${nombre} respondió ${r.status}: ${String(r.body).slice(0, 300)}`);
  check(r, { [`${nombre}: 2xx`]: (x) => x.status >= 200 && x.status < 300 });
  if (r.status === 200 && r.body && r.body.includes('"rejected"')) {
    const n = r.json('rejected');
    if (n) rechazados.add(n);
  }
}

function cabeceras(c, extra = {}) {
  return { headers: { Authorization: `Bearer ${c.token}`, 'Content-Type': 'application/json', ...extra } };
}

export default function () {
  const c = credencial();
  const base = `${API}/partner/links/${c.link_id}`;
  const azar = Math.random();

  if (azar < 0.45) {
    group('ingesta daily-summaries (lote de 10)', () => {
      const summaries = Array.from({ length: 10 }, (_, i) => ({
        record_id: id() + `-${i}`, local_date: hoyMenos(1 + (i % 7)), tz_offset_minutes: 0,
        device_id: c.device_id, completeness: 'partial', steps: 5000 + i * 100, resting_heart_rate_bpm: 60,
        sleep_total_minutes: 420,
      }));
      const r = http.post(`${base}/daily-summaries`, JSON.stringify({ summaries }),
        { ...cabeceras(c, { 'Idempotency-Key': crypto.randomUUID() }), tags: { name: 'daily-summaries' } });
      registrar(r, 'daily-summaries', latIngesta, c);
    });
  } else if (azar < 0.65) {
    group('ingesta samples (gzip, 1 h de pulso)', () => {
      // D-07: el modelo de pruebas (sandbox.declarar_modelo) declara typical_interval_seconds=60, así que una
      // muestra por segundo se rechazaba con 422 («frecuencia mayor que la configurada»). Una muestra por minuto.
      const n = 60;
      const serie = {
        metric: 'heart_rate', unit: 'bpm', device_id: c.device_id,
        start: new Date(Date.now() - 3 * 3600000).toISOString().replace(/\.\d+Z$/, 'Z'),
        offsets_ms: Array.from({ length: n }, (_, i) => i * 60000),
        values: Array.from({ length: n }, () => 55 + Math.floor(Math.random() * 40)),
      };
      const r = http.post(`${base}/samples`, JSON.stringify({ series: [serie] }),
        { ...cabeceras(c), compression: 'gzip', tags: { name: 'samples' } });
      registrar(r, 'samples', latIngesta, c);
    });
  } else if (azar < 0.75) {
    group('ingesta sessions', () => {
      const ini = Date.now() - 9 * 3600000;
      const r = http.post(`${base}/sessions`, JSON.stringify({ sessions: [{
        session_type: 'sleep', record_id: id(), device_id: c.device_id,
        start: new Date(ini).toISOString(), end: new Date(ini + 7 * 3600000).toISOString(),
        summary: { total_sleep_minutes: 400 },
      }] }), { ...cabeceras(c), tags: { name: 'sessions' } });
      registrar(r, 'sessions', latIngesta, c);
    });
  } else if (azar < 0.80) {
    group('ingesta device-events', () => {
      const r = http.post(`${base}/device-events`, JSON.stringify({ events: [{
        record_id: id(), device_id: c.device_id, timestamp: new Date().toISOString(), event_type: 'sync_completed',
      }] }), { ...cabeceras(c), tags: { name: 'device-events' } });
      registrar(r, 'device-events', latIngesta, c);
    });
  } else if (azar < 0.92) {
    group('lectura sync-state', () => {
      registrar(http.get(`${base}/sync-state`, { ...cabeceras(c), tags: { name: 'sync-state' } }), 'sync-state', latLectura, c);
    });
  } else {
    group('lectura scores y goals', () => {
      registrar(http.get(`${base}/scores?from_date=${hoyMenos(30)}&to_date=${hoyMenos(0)}`,
        { ...cabeceras(c), tags: { name: 'scores' } }), 'scores', latLectura, c);
      registrar(http.get(`${base}/goals`, { ...cabeceras(c), tags: { name: 'goals' } }), 'goals', latLectura, c);
    });
  }
  sleep(1 + Math.random()); // un servidor de fabricante real no envía en bucle cerrado
}

export function handleSummary(data) {
  const m = data.metrics;
  const val = (k, s) => (m[k] && m[k].values[s] !== undefined ? m[k].values[s] : null);
  const fmt = (x) => (x === null ? '—' : Math.round(x * 100) / 100);
  const umbrales = Object.entries(m).flatMap(([k, v]) =>
    Object.entries(v.thresholds || {}).map(([t, r]) => `| ${k} | \`${t}\` | ${r.ok ? 'OK' : 'FALLO'} |`));
  const md = [
    `# Carga k6 · perfil ${PERFIL}`, '',
    `Peticiones: ${fmt(val('http_reqs', 'count'))} · ${fmt(val('http_reqs', 'rate'))}/s · ` +
    `fallos HTTP: ${fmt((val('http_req_failed', 'rate') || 0) * 100)} % · 429: ${fmt((val('wellq_rate_limited', 'rate') || 0) * 100)} %`, '',
    '| Métrica | p50 (ms) | p95 (ms) | p99 (ms) | máx (ms) |', '|---|---|---|---|---|',
    ...['wellq_latencia_ingesta', 'wellq_latencia_lectura', 'http_req_duration'].map((k) =>
      `| ${k} | ${fmt(val(k, 'med'))} | ${fmt(val(k, 'p(95)'))} | ${fmt(val(k, 'p(99)'))} | ${fmt(val(k, 'max'))} |`),
    '', '| Métrica | Umbral | Resultado |', '|---|---|---|', ...umbrales, '',
  ].join('\n');
  return {
    [`${__ENV.K6_SALIDA}/resumen_k6.json`]: JSON.stringify(data, null, 2),
    [`${__ENV.K6_SALIDA}/resumen_k6.md`]: md,
    stdout: md + '\n',
  };
}
