"""Pruebas de contrato: la API en marcha cumple el OpenAPI (Schemathesis, pruebas basadas en propiedades).

Genera peticiones válidas e inválidas para cada operación y comprueba que no hay errores 5xx, que los códigos,
cabeceras, Content-Type y cuerpos coinciden con el contrato y que los datos inválidos se rechazan.
Usa las credenciales del fabricante de pruebas (portal_token y access_token) y el link_id/app_id reales.

No se fuzzean las operaciones destructivas o con límites fijos (registro, verificación, token, rotación,
revocación, borrado de webhooks, promoción): las cubren p04 y p05.

    python pruebas/p08_contrato_schemathesis.py              # 50 ejemplos por operación
    python pruebas/p08_contrato_schemathesis.py --rapido     # 10 ejemplos, sin fase stateful
    python pruebas/p08_contrato_schemathesis.py -- --include-tag Ingest   # extra para schemathesis
"""
from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET

import sandbox
from comun import ClienteAPI, Informe, cargar_config, ejecutar, exigir_api, exigir_no_produccion, herramienta

CODIGOS = {
    "ST101": "error 5xx del servidor", "ST102": "5xx con un Content-Type no declarado",
    "ST103": "código de estado no documentado en el OpenAPI", "ST104": "falta Content-Type",
    "ST105": "Content-Type no documentado", "ST106": "media type malformado",
    "ST107": "faltan cabeceras obligatorias de respuesta", "ST108": "la respuesta no cumple el esquema",
    "ST109": "JSON de respuesta no válido", "ST110": "contenido no deserializable",
    "ST111": "discriminador desconocido", "ST112": "tiempo de respuesta > 10 s",
    "ST201": "acepta una petición que viola el esquema", "ST202": "rechaza una petición válida según el esquema",
    "ST203": "acepta la petición sin una cabecera obligatoria", "ST204": "método no declarado sin 405 + Allow",
    "ST205": "cabecera Allow incorrecta", "ST301": "recurso borrado sigue disponible",
    "ST302": "recurso creado no encontrado", "ST401": "autenticación no exigida",
    "ST402": "acceso a objetos de otro usuario (BOLA)",
}
# ST101, ST401 y ST402 son defectos de la API; el resto suele ser desajuste entre contrato e implementación
# (se corrige en el código o en el OpenAPI, según cuál tenga razón).
GRAVES = {"ST101", "ST102", "ST401", "ST402", "ST301"}

EXCLUIDAS = ["registerDeveloper", "verifyDeveloper", "getToken", "rotateSecret", "revokeLink", "deleteWebhook",
             "requestPromotion", "revokePatientLink", "createPairingCode"]


def toml_cadena(valor: str) -> str:
    return json.dumps(valor)


def main() -> int:
    cfg = cargar_config()
    informe = Informe("08_contrato", "Pruebas de contrato contra el OpenAPI (Schemathesis)")
    exigir_no_produccion(cfg, "Schemathesis (genera miles de peticiones con datos inválidos)")
    if not cfg.openapi.exists():
        informe.registrar("C-00", "Existe el contrato OpenAPI", False, f"{cfg.openapi} no existe (WELLQ_OPENAPI)")
        return informe.cerrar()
    st = herramienta("schemathesis") or herramienta("st")
    if not st:
        informe.registrar("C-00", "Schemathesis instalado", False, "pip install -r pruebas/requirements.txt")
        return informe.cerrar()
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    estado = informe.verificar("C-01", "Preparar credenciales y vínculo de pruebas", lambda: sandbox.preparar(cfg, api))
    if not estado:
        return informe.cerrar()

    carpeta = informe.carpeta
    rapido = "--rapido" in sys.argv
    extra = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    lineas = [
        f"base-url = {toml_cadena(cfg.api)}",
        "",
        "[auth.openapi.partnerOAuth]", f"bearer = {toml_cadena(estado['access_token'])}",
    ]
    if estado.get("portal_token"):
        lineas += ["[auth.openapi.portalToken]", f"bearer = {toml_cadena(estado['portal_token'])}"]
    if cfg["WELLQ_PATIENT_JWT"]:
        lineas += ["[auth.openapi.patientJWT]", f"bearer = {toml_cadena(cfg['WELLQ_PATIENT_JWT'])}"]
    if cfg["WELLQ_CLINICIAN_JWT"]:
        lineas += ["[auth.openapi.clinicianJWT]", f"bearer = {toml_cadena(cfg['WELLQ_CLINICIAN_JWT'])}"]
    lineas += ["", "[parameters]", f"\"path.link_id\" = {toml_cadena(estado['link_id'])}",
               f"\"path.app_id\" = {toml_cadena(estado['app_id'])}"]
    if cfg["WELLQ_PATIENT_ID"]:
        lineas.append(f"\"path.patient_id\" = {toml_cadena(cfg['WELLQ_PATIENT_ID'])}")
    # La API responde 413 (batch-too-large, documentado) a lotes por encima de maxItems: es un rechazo válido.
    lineas += ["", "[checks.negative_data_rejection]",
               'expected-statuses = ["400", "401", "403", "404", "405", "406", "409", "413", "415", "422", "428", '
               '"429", "5XX"]']
    config = carpeta / "schemathesis.toml"
    config.write_text("\n".join(lineas) + "\n", encoding="utf-8")

    junit = carpeta / "junit.xml"
    cmd = [st, "--config-file", str(config), "run", str(cfg.openapi),
           "--checks", "all", "--max-examples", "10" if rapido else "50",
           "--phases", "examples,coverage,fuzzing" if rapido else "examples,coverage,fuzzing,stateful",
           "--report", "junit,har,html", "--report-dir", str(carpeta),
           "--report-junit-path", str(junit), "--report-html-path", str(carpeta / "informe_html"),
           "--request-timeout", "30", "--max-response-time", "10", "--workers", "1",
           "--output-sanitize", "true", "--suppress-health-check", "all", "--seed", "20261026",
           "--warnings", "off"]
    for op in EXCLUIDAS:
        cmd += ["--exclude-operation-id", op]
    if not cfg["WELLQ_PATIENT_JWT"]:
        cmd += ["--exclude-tag", "Patient App (internal)"]
    cmd += extra
    try:
        codigo = ejecutar(cmd, carpeta, "salida_schemathesis.txt", timeout=3600)
    finally:
        config.unlink(missing_ok=True)  # lleva los tokens: no se deja en las evidencias

    if junit.exists():
        for tc in ET.parse(junit).getroot().iter("testcase"):
            fallo = tc.find("failure") if tc.find("failure") is not None else tc.find("error")
            if tc.find("skipped") is not None:
                informe.omitir("C", tc.get("name", ""), (tc.find("skipped").get("message") or "")[:200])
            else:
                texto = "" if fallo is None else (fallo.get("message") or fallo.text or "")
                codigos = sorted(set(re.findall(r"ST\d{3}", texto)))
                detalle = "; ".join(f"{c} {CODIGOS.get(c, '')}" + (" [GRAVE]" if c in GRAVES else "") for c in codigos)
                informe.registrar("C", tc.get("name", ""), fallo is None, detalle or texto[:600])
    if junit.exists():
        print("    Detalle y reproducción con curl de cada fallo: salida_schemathesis.txt e informe_html/")
    else:
        informe.registrar("C-99", "Schemathesis generó el informe JUnit", False, f"código {codigo}")
    for op in EXCLUIDAS:
        informe.omitir("C-EXC", op, "excluida del fuzzing (destructiva o con límite fijo; ver p04/p05)")
    return informe.cerrar({"codigo_salida_schemathesis": codigo})


if __name__ == "__main__":
    sys.exit(main())
