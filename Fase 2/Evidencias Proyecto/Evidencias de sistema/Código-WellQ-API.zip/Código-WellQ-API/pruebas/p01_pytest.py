"""Pruebas funcionales, de seguridad y de fiabilidad del código (pytest + mongomock, sin Mongo ni Redis reales).

Ejecuta la suite existente de data/tests/partner y guarda: salida completa, informe JUnit XML,
un caso por test en resultado.md y, si pytest-cov está instalado, la cobertura en HTML.

    python pruebas/p01_pytest.py              # toda la suite
    python pruebas/p01_pytest.py -k ssrf      # argumentos extra que se pasan tal cual a pytest
"""
from __future__ import annotations

import sys
import xml.etree.ElementTree as ET

from comun import Informe, cargar_config, ejecutar, modulo_disponible


def main() -> int:
    cfg = cargar_config()
    informe = Informe("01_pytest", "Pruebas unitarias e integración del código (pytest)")
    carpeta = informe.carpeta
    if not (cfg.data_dir / "pytest.ini").exists() and not (cfg.data_dir / "tests").exists():
        informe.registrar("PY-00", "Existe la carpeta del servicio con sus tests", False,
                          f"No se encontró {cfg.data_dir} (ajusta WELLQ_DATA_DIR)")
        return informe.cerrar()
    if not modulo_disponible("pytest"):
        informe.registrar("PY-00", "pytest instalado", False, "pip install -r data/requirements-dev.txt")
        return informe.cerrar()

    junit = carpeta / "junit.xml"
    cmd = [sys.executable, "-m", "pytest", "-v", "-p", "no:warnings", "-p", "no:cacheprovider",
           f"--junitxml={junit}"]
    if modulo_disponible("pytest_cov"):
        cmd += ["--cov=app", "--cov-report=term", f"--cov-report=html:{carpeta / 'cobertura'}",
                f"--cov-report=xml:{carpeta / 'cobertura.xml'}"]
    cmd += sys.argv[1:]
    codigo = ejecutar(cmd, carpeta, "salida_pytest.txt", cwd=cfg.data_dir,
                      env={"APP_ENV": "test", "PYTHONDONTWRITEBYTECODE": "1"})

    if not junit.exists():
        informe.registrar("PY-00", "pytest generó el informe JUnit", False, f"código de salida {codigo}")
        return informe.cerrar()
    for tc in ET.parse(junit).getroot().iter("testcase"):
        nombre = f"{tc.get('classname', '').split('.')[-1]}::{tc.get('name')}"
        problema = tc.find("failure") if tc.find("failure") is not None else tc.find("error")
        if tc.find("skipped") is not None:
            informe.omitir("PY", nombre, tc.find("skipped").get("message", "omitido"))
        elif problema is not None:
            informe.registrar("PY", nombre, False, (problema.get("message") or "")[:500])
        else:
            informe.registrar("PY", nombre, True)
    if codigo not in (0, 1):  # 2+: error de recolección/uso; los fallos individuales ya se registraron
        informe.registrar("PY-99", "pytest terminó sin errores de ejecución", False, f"código de salida {codigo}")
    return informe.cerrar({"codigo_salida_pytest": codigo})


if __name__ == "__main__":
    sys.exit(main())
