"""Prepara (o reutiliza) un fabricante de pruebas en el sandbox: cuenta, app, token, modelo y vínculo.

Uso directo:  python pruebas/sandbox.py          (prepara y muestra el estado, sin secretos)
              python pruebas/sandbox.py --nuevo  (descarta el estado guardado y empieza de cero)

El estado se guarda en pruebas/.estado/estado_sandbox.json (contiene secretos; está en .gitignore).
"""
from __future__ import annotations

import sys
import time
import uuid
from typing import Any

from comun import (ClienteAPI, Config, Informe, cargar_config, cargar_estado, enmascarar, esperar_estado,
                   guardar_estado, run_id)

TODOS_LOS_SCOPES_CONSENTIMIENTO = [
    "ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:body",
    "ingest:msk", "ingest:device", "read:goals", "read:scores",
]
SCOPES_TOKEN = ["links:manage", "webhooks:manage"] + TODOS_LOS_SCOPES_CONSENTIMIENTO
MODELO = "QA-BAND-1"
DISPOSITIVO = "QA-BAND-1-SN0001"

_CLAVES_CODIGO = ("verification_token", "verification_code", "dev_verification_token",
                  "dev_verification_code", "code", "dev_code")


def _buscar_codigo(datos: Any) -> str | None:
    """Con PARTNER_DEV_TOOLS_ENABLED el registro devuelve el código de verificación en la respuesta."""
    if isinstance(datos, dict):
        for clave in _CLAVES_CODIGO:
            if isinstance(datos.get(clave), str) and datos[clave]:
                return datos[clave]
        for valor in datos.values():
            encontrado = _buscar_codigo(valor)
            if encontrado:
                return encontrado
    return None


def registrar_desarrollador(cfg: Config, api: ClienteAPI, sufijo: str) -> dict[str, str]:
    """Registro + verificación. Devuelve developer_id, portal_token y el correo usado."""
    correo = f"qa+{sufijo}@example.com"
    r = api.post("/partner/developers/register", json={
        "company_name": f"QA Pruebas {sufijo}", "contact_email": correo, "contact_name": "QA WellQ",
        "country": "GB", "website": "https://example.com", "accept_terms": True,
    })
    datos = esperar_estado(r, 200, 201, 202)
    codigo = _buscar_codigo(datos) or cfg["WELLQ_VERIFY_CODE"]
    if not codigo:
        raise AssertionError(
            "El registro no devolvió el código de verificación (solo lo hace con APP_ENV de desarrollo y "
            "PARTNER_DEV_TOOLS_ENABLED=true). Pon el código del correo en WELLQ_VERIFY_CODE o un portal_token "
            "en WELLQ_PORTAL_TOKEN y vuelve a ejecutar.")
    r = api.post("/partner/developers/verify",
                 json={"developer_id": datos["developer_id"], "verification_token": codigo})
    v = esperar_estado(r, 200)
    return {"developer_id": datos["developer_id"], "portal_token": v["portal_token"], "correo": correo}


def crear_app(api: ClienteAPI, portal_token: str, nombre: str) -> dict[str, Any]:
    r = api.post("/partner/apps", portal_token, json={
        "name": nombre, "description": "App creada por los scripts de pruebas",
        "privacy_policy_url": "https://example.com/privacidad", "logo_url": "https://example.com/logo.png",
        "requested_scopes": TODOS_LOS_SCOPES_CONSENTIMIENTO,
    })
    return esperar_estado(r, 200, 201)


def obtener_token(api: ClienteAPI, client_id: str, client_secret: str, scopes: list[str] | None = None) -> str:
    form = {"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret}
    if scopes is not None:
        form["scope"] = " ".join(scopes)
    r = api.post("/partner/oauth/token", data=form)
    return esperar_estado(r, 200)["access_token"]


def declarar_modelo(api: ClienteAPI, token: str, app_id: str) -> list[str]:
    """Declara un modelo con todas las métricas del catálogo para que ninguna ingesta se rechace por no declarada."""
    r = api.get("/partner/capabilities/metrics", token)
    catalogo = esperar_estado(r, 200) or []
    if isinstance(catalogo, dict):
        catalogo = catalogo.get("items", [])
    metricas = sorted({m["metric"] for m in catalogo if isinstance(m, dict) and m.get("metric")})
    r = api.post(f"/partner/apps/{app_id}/device-models", token, json={
        "model_code": MODELO, "display_name": "QA Band 1", "form_factor": "band", "body_placement": "wrist_left",
        "capabilities": [{"metric": m, "typical_interval_seconds": 60, "sampling_mode": "continuous"} for m in metricas],
        "regulatory": {"ukca_or_ce_medical_device": False}, "firmware_min_version": "1.0.0",
    })
    if r.status_code not in (200, 201, 409):  # 409: ya declarado en una ejecución anterior
        esperar_estado(r, 201)
    return metricas


def nuevo_vinculo(api: ClienteAPI, token: str, scopes: list[str] | None = None,
                  perfil: str = "knee_rehab", external_user_id: str | None = None) -> dict[str, Any]:
    """Crea un paciente sintético y canjea su código. Devuelve el vínculo y el código usado."""
    r = api.post("/partner/sandbox/patients", token,
                 json={"scopes": scopes or TODOS_LOS_SCOPES_CONSENTIMIENTO, "profile": perfil})
    paciente = esperar_estado(r, 200, 201)
    r = api.post("/partner/links", token, json={
        "pairing_code": paciente["pairing_code"],
        "external_user_id": external_user_id or f"qa-{uuid.uuid4().hex[:12]}",
        "device_id": DISPOSITIVO, "model_code": MODELO, "timezone": "Europe/London",
    })
    vinculo = esperar_estado(r, 200, 201)
    vinculo["_pairing_code"] = paciente["pairing_code"]
    vinculo["_sandbox_patient_id"] = paciente.get("sandbox_patient_id")
    return vinculo


def preparar(cfg: Config, api: ClienteAPI, nuevo: bool = False) -> dict[str, Any]:
    """Devuelve un estado listo para usar: access_token (fresco), app_id, link_id..."""
    try:
        return _preparar(cfg, api, nuevo)
    except AssertionError as exc:
        # Estado guardado de una base que ya no existe (p. ej. se reinició la API local): se empieza de cero.
        if nuevo or "HTTP 401" not in str(exc) or cfg["WELLQ_CLIENT_ID"]:
            raise
        print("    (credenciales guardadas no válidas: se crea un fabricante nuevo)")
        return _preparar(cfg, api, True)


def _preparar(cfg: Config, api: ClienteAPI, nuevo: bool) -> dict[str, Any]:
    estado = {} if nuevo else cargar_estado()
    if estado.get("base_url") != cfg["WELLQ_BASE_URL"]:
        estado = {}
    estado["base_url"] = cfg["WELLQ_BASE_URL"]

    if cfg["WELLQ_CLIENT_ID"] and cfg["WELLQ_CLIENT_SECRET"]:
        estado.update(client_id=cfg["WELLQ_CLIENT_ID"], client_secret=cfg["WELLQ_CLIENT_SECRET"],
                      app_id=cfg["WELLQ_APP_ID"] or estado.get("app_id", ""))
    if not estado.get("client_secret"):
        sufijo = f"{run_id()}-{uuid.uuid4().hex[:6]}".lower()
        portal = cfg["WELLQ_PORTAL_TOKEN"]
        if not portal:
            dev = registrar_desarrollador(cfg, api, sufijo)
            portal = dev["portal_token"]
            estado.update(developer_id=dev["developer_id"], correo=dev["correo"])
        app = crear_app(api, portal, f"QA Partner {sufijo}")
        estado.update(portal_token=portal, portal_token_en=time.time(), app_id=app["app_id"],
                      client_id=app["client_id"], client_secret=app["client_secret"],
                      granted_scopes=app.get("granted_scopes"))
        estado.pop("link_id", None)

    # Otras suites (p05, p07 y el fuzzing de p08) cambian los scopes de esta app compartida. Si ya no tiene todos
    # los de consentimiento, se restauran y se pide un token nuevo; si no, k6 y las demás reciben 403/400.
    if estado.get("portal_token") and estado.get("app_id"):
        r = api.get(f"/partner/apps/{estado['app_id']}", estado["portal_token"])
        if r.status_code == 200 and not set(TODOS_LOS_SCOPES_CONSENTIMIENTO) <= set(r.json().get("granted_scopes") or []):
            r = api.patch(f"/partner/apps/{estado['app_id']}", estado["portal_token"],
                          json={"requested_scopes": TODOS_LOS_SCOPES_CONSENTIMIENTO})
            if r.status_code == 200:
                print("    (scopes de la app de pruebas restaurados)")
                estado.pop("access_token", None)

    # Los access_token duran 1 h: se pide uno nuevo si el guardado tiene más de 45 min.
    if not estado.get("access_token") or time.time() - estado.get("access_token_en", 0) > 45 * 60:
        estado["access_token"] = obtener_token(api, estado["client_id"], estado["client_secret"], SCOPES_TOKEN)
        estado["access_token_en"] = time.time()

    if not estado.get("modelo_declarado") and estado.get("app_id"):
        estado["metricas"] = declarar_modelo(api, estado["access_token"], estado["app_id"])
        estado["modelo_declarado"] = True

    if estado.get("link_id"):
        r = api.get(f"/partner/links/{estado['link_id']}", estado["access_token"])
        if r.status_code == 401:
            esperar_estado(r, 200)  # provoca el reinicio del estado
        if r.status_code != 200 or r.json().get("status") != "active":
            estado.pop("link_id")
    if not estado.get("link_id"):
        vinculo = nuevo_vinculo(api, estado["access_token"])
        estado.update(link_id=vinculo["link_id"], external_user_id=vinculo.get("external_user_id"),
                      device_id=DISPOSITIVO, model_code=MODELO)
    guardar_estado(estado)
    return estado


def main() -> int:
    cfg = cargar_config()
    informe = Informe("00_sandbox", "Preparación del fabricante de pruebas (sandbox)")
    api = ClienteAPI(cfg, informe.carpeta)
    estado = informe.verificar("SBX-01", "Registrar/reutilizar fabricante, app, token, modelo y vínculo",
                               lambda: preparar(cfg, api, nuevo="--nuevo" in sys.argv))
    if estado:
        print(enmascarar({k: v for k, v in estado.items() if k != "metricas"}))
    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
