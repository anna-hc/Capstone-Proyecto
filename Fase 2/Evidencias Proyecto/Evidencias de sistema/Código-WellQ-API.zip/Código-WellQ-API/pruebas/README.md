# Pruebas automatizadas de la WellQ Partner API

Scripts para ejecutar con un solo comando las pruebas automatizables del plan (puntos 2 a 8 y contrato OpenAPI) y guardar las evidencias en `evidencia/pruebas/<fecha-hora>/`. Las pruebas manuales o guiadas (Postman, OWASP ZAP con interfaz, app móvil, revisión de privacidad) están en [GUIA_PRUEBAS_MANUALES.md](GUIA_PRUEBAS_MANUALES.md).

## 1. Qué hay

| Script | Punto del plan | Qué prueba | Necesita | Herramienta |
|---|---|---|---|---|
| `p01_pytest.py` | 2, 3, 4, 8 | Los 47 tests de `data/tests/partner` (mongomock, sin Mongo ni Redis) | — | pytest (+ cobertura si hay pytest-cov) |
| `p02_pip_audit.py` | 4 | Dependencias con vulnerabilidades conocidas | Internet | pip-audit |
| `p03_bandit_secretos.py` | 4 | Análisis estático del código y secretos en el repositorio | — | bandit + búsqueda propia |
| `p04_funcional_e2e.py` | 2, 6 | Flujo completo del fabricante, los cinco tipos de ingesta, lecturas, webhooks, revocación; app del paciente y panel clínico si hay JWT | API | requests |
| `p05_autenticacion.py` | 3 | Tokens ausentes/manipulados/alg=none, OAuth, scopes del token y del consentimiento, BOLA entre fabricantes, separación de actores, rotación, fuerza bruta de códigos, cron | API | requests |
| `p06_seguridad_http.py` | 4 | Cabeceras, docs/demo cerradas, CORS, métodos, errores sin trazas, SSRF, inyección NoSQL, límites de tamaño y gzip bomb, rate limit | API | requests |
| `p07_privacidad.py` | 5 | Consentimiento registrado, minimización en goals/scores, seudonimato, ecos en errores y revisión de todas las respuestas de la ejecución | API | requests |
| `p08_contrato_schemathesis.py` | Contrato | Que la API cumple el OpenAPI (fuzzing basado en propiedades) | API | Schemathesis |
| `p09_carga_k6.py` + `k6/carga.js` | 7 | Rendimiento y carga: perfiles humo, carga, estrés, pico y resistencia con umbrales p95/p99 | API | k6 |
| `p10_fiabilidad.py` | 8 | Idempotencia, concurrencia, reanudación con sync-state, jobs asíncronos, cron, recuperación tras 429, disponibilidad | API | requests |
| `p11_zap_baseline.py` | 4 | Escaneo OWASP ZAP de la API a partir del OpenAPI | API + Docker | ZAP |
| `p12_postman_newman.py` | 2, 6 | La colección de Postman de `postman/` ejecutada con Newman | API + Node.js | Newman |
| `run_all.py` | — | Lanza varias suites y genera `RESUMEN.md` | — | — |
| `sandbox.py` | — | Crea (o reutiliza) el fabricante, la app, el token y el vínculo de pruebas que usan las demás | API | — |
| `herramientas/verificar_firma_webhook.py` | 4, 6 | Comprueba la firma `X-WellQ-Signature` de un webhook recibido (caso PM-01 de la guía) | — | — |
| `postman/` | 2, 6 | Colección y entornos de Postman: `v3/` en formato v3 YAML para la app (modo local) y los JSON v2.1 para Newman; `generar_coleccion.py` regenera ambos | — | Postman / Newman |

## 2. Requisitos e instalación

- **Python 3.11 o superior** (el proyecto usa 3.12).
- **k6** solo para `p09`: Windows `winget install k6 --source winget`, macOS `brew install k6`, Linux: <https://grafana.com/docs/k6/latest/set-up/install-k6/>.
- **Node.js LTS** solo para `p12` (Newman se descarga solo con `npx` la primera vez).
- **Docker Desktop** solo para `p11`.

Desde la raíz del repositorio `WellQ-API` (Windows PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r data\requirements-dev.txt -r pruebas\requirements.txt
Copy-Item pruebas\config.env.example pruebas\config.env
```

En macOS/Linux, lo mismo con `source .venv/bin/activate` y `cp`.

## 3. Configuración

Todo se lee de `pruebas/config.env` (copia de `config.env.example`, que explica cada variable). Las variables de entorno del sistema tienen prioridad, así que también vale `set WELLQ_BASE_URL=...` o `WELLQ_BASE_URL=... python ...`.

Lo mínimo para las pruebas contra la API:

| Variable | Ejemplo | Para qué |
|---|---|---|
| `WELLQ_BASE_URL` | `http://127.0.0.1:8000` o `https://wellq-demo.vercel.app` | Raíz del servicio, sin `/api/v1` |
| `WELLQ_ENTORNO` | `local` / `sandbox` / `produccion` | Con `produccion` se niegan a correr los scripts que crean datos o generan carga |
| `WELLQ_CRON_SECRET` | el `CRON_SECRET` del entorno | Probar y forzar los trabajos de cron (p05, p10) |
| `WELLQ_WEBHOOK_URL` | una URL de <https://webhook.site> | Probar webhooks (p04, p12). Sin ella, esos casos salen OMITIDOS |

Para que los scripts se den de alta solos como fabricante, el entorno debe tener `APP_ENV=dev` y `PARTNER_DEV_TOOLS_ENABLED=true` (el código de verificación llega en la respuesta del registro). En un entorno sin herramientas de desarrollo, pon el código del correo en `WELLQ_VERIFY_CODE`, un `WELLQ_PORTAL_TOKEN`, o las credenciales de una app ya creada (`WELLQ_CLIENT_ID`, `WELLQ_CLIENT_SECRET`, `WELLQ_APP_ID`).

Opcionales para la integración con WellQ: `WELLQ_PATIENT_JWT` (paciente de prueba; con la app de sandbox de estas pruebas, un paciente del tenant `partner-sandbox`, porque el paciente solo ve apps de su entorno), `WELLQ_CLINICIAN_JWT` + `WELLQ_PATIENT_ID` (clínico asignado a ese paciente), `WELLQ_TENANT`.

## 4. Arrancar la API en local para probarla

Las suites `p04`–`p12` necesitan la API en marcha. En local, con un MongoDB desechable:

```powershell
docker run -d --name wellq-mongo-pruebas -p 27017:27017 mongo:7
cd data
# En data\.env (copia de .env.example): APP_ENV=dev, PARTNER_DEV_TOOLS_ENABLED=true, MONGODB_URI=mongodb://127.0.0.1:27017,
# MONGODB_DB=wellq-pruebas, PARTNER_TOKEN_SECRET (32+ caracteres), PARTNER_ENCRYPTION_KEY (Fernet), JWT_SECRET y CRON_SECRET.
python -m app.scripts.create_partner_indexes
python -m uvicorn app.main:app --port 8000
```

Comprueba `http://127.0.0.1:8000/api/v1/health`: debe decir `"partner_api": true`. Para generar claves:
`python -c "import secrets; print(secrets.token_urlsafe(48))"` y
`python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`.

> Usa siempre una base de datos de pruebas: los scripts crean fabricantes, apps, pacientes sintéticos y datos.

## 5. Cómo ejecutar

Desde la raíz del repositorio, con el entorno virtual activo:

```powershell
python pruebas\run_all.py                         # estático: pytest, pip-audit, bandit (no necesita la API)
python pruebas\run_all.py --perfil api            # + todas las pruebas contra la API y k6 de humo (~5 min)
python pruebas\run_all.py --perfil completo       # + k6 con K6_PERFIL y escaneo ZAP (Docker)
python pruebas\run_all.py --solo p04,p05,p07      # solo esas suites
python pruebas\run_all.py --perfil api --excluir p08,p12
```

Cada script también se puede lanzar suelto:

```powershell
python pruebas\p01_pytest.py -k ssrf              # argumentos extra van a pytest
python pruebas\p06_seguridad_http.py --sin-rate-limit
python pruebas\p08_contrato_schemathesis.py --rapido
python pruebas\p09_carga_k6.py carga              # humo | carga | estres | pico | resistencia
python pruebas\p11_zap_baseline.py --pasivo
python pruebas\sandbox.py --nuevo                 # descarta el fabricante guardado y crea otro
```

Orden recomendado si se lanzan a mano: p04 → p12 → p05 → p06 → p07 (revisa las respuestas de las anteriores) → p08 → p10 → p09 → p11. Newman (p12) va antes que p05 porque la fuerza bruta de códigos de p05 bloquea el canje de códigos de emparejamiento durante unos minutos y la colección fallaría en cadena con 429. Schemathesis, la fuerza bruta de códigos (p05 A-11) y los límites de tasa (p06 S-11, p10 R-07) pueden dejar la IP o la app limitada durante uno o diez minutos: por eso van al final de cada script y `run_all` respeta este orden.

## 6. Evidencias y cómo interpretarlas

Cada ejecución crea `evidencia/pruebas/<AAAAMMDD-HHMMSS>/`:

```
evidencia/pruebas/20261026-170512/
├── RESUMEN.md              ← empezar por aquí: una fila por suite
├── resumen.json
├── 01_pytest/              junit.xml, salida_pytest.txt, cobertura/ (HTML)
├── 02_pip_audit/           pip_audit_requirements.json
├── 03_bandit_secretos/     bandit.json, bandit.txt
├── 04_funcional/           http_log.jsonl (cada petición y respuesta, secretos enmascarados)
├── 08_contrato/            junit.xml, informe_html/, har-*.json, salida_schemathesis.txt
├── 09_carga_k6/            resumen_k6.md (latencias y umbrales), resumen_k6.json
├── 11_zap/                 zap_informe.html / .json / .md
├── 12_newman/              newman_junit.xml, newman_resultado.json
└── …/resultado.md          tabla de casos: id, descripción, estado y detalle
```

- **OK**: el caso se cumplió. **FALLO**: no se cumplió; el detalle dice qué se esperaba y qué llegó, y `http_log.jsonl` tiene la petición exacta (busca por la hora o por el `X-Trace-Id` de la respuesta, que también está en los registros de Vercel). **OMITIDO**: no se pudo ejecutar por falta de un dato opcional (el detalle dice cuál) o es informativo.
- Código de salida: `0` todo OK, `1` hay fallos, `3` abortado por protección de producción. `run_all` devuelve `1` si alguna suite falla.
- Un FALLO en `PRE-01` significa que la API no responde o que `/health` dice `partner_api: false` (faltan `PARTNER_TOKEN_SECRET` o `PARTNER_ENCRYPTION_KEY`).

Notas por herramienta:

- **pip-audit**: cada vulnerabilidad sale como FALLO con la versión que la corrige. Si se acepta una a propósito, anótala en `pip_audit_ignorar.txt` con su ID, la justificación y la fecha; aparecerá como OMITIDA.
- **bandit**: fallan los hallazgos de severidad y confianza ≥ `BANDIT_NIVEL` (MEDIUM). Los de nivel bajo aparecen como informativos. Revisa a mano cada `# nosec` que cuente el informe.
- **Schemathesis**: cada operación del OpenAPI es un caso. Los códigos `ST101` (5xx), `ST401` (autenticación no exigida) y `ST402` (BOLA) se marcan `[GRAVE]`: son defectos de la API. El resto (`ST103` código no documentado, `ST108` respuesta fuera de esquema, `ST201/ST202` validación distinta del contrato, `ST204` método no declarado sin `405 + Allow`) son desajustes entre contrato e implementación que se corrigen en el código o en el OpenAPI. `salida_schemathesis.txt` trae el `curl` para reproducir cada uno; `schemathesis explain ST103` explica un código.
- **k6**: `resumen_k6.md` trae p50/p95/p99 de ingesta y lectura y si se cumple cada umbral (ingesta p95 < 800 ms, lectura p95 < 400 ms, errores < 1 %, 429 < 5 %). Si no se cumple alguno, k6 sale con 99 y la suite falla. Ajusta los umbrales en `k6/carga.js` al SLO acordado. Cada app tiene 600 peticiones/min: para cargas altas, `K6_APPS` reparte los usuarios virtuales entre varias apps. Sin `REDIS_URL`, cada instancia de Vercel cuenta sus límites por separado.
- **ZAP**: fallan las alertas de riesgo Alto o Medio. Las reglas que no aplican a una API JSON se aceptan en `zap_reglas.tsv`, con su motivo.

## 7. Integración continua

`.github/workflows/pruebas-partner-api.yml` ejecuta el perfil estático en cada push y PR que toque `data/` o `pruebas/`, y en los PR levanta además la API en el propio runner con un MongoDB de servicio para ejecutar todas las pruebas contra ella. Bajo demanda (*Actions → Pruebas Partner API → Run workflow*) se puede elegir `remota` para probar el sandbox o la demo desplegados, con los secretos `WELLQ_SANDBOX_URL` y `WELLQ_SANDBOX_CRON_SECRET` del entorno `sandbox` de GitHub. Las evidencias se descargan como artefacto del run.

## 8. Precauciones

- No apuntes estos scripts a producción: crean datos, fuerzan límites y envían cargas maliciosas. Con `WELLQ_ENTORNO=produccion` se niegan, salvo `WELLQ_PERMITIR_PRODUCCION=si` con autorización escrita.
- `pruebas/config.env` y `pruebas/.estado/` contienen secretos y están en `.gitignore`. Los registros HTTP enmascaran tokens, secretos y códigos.
- Usa JWT de pacientes y clínicos **de prueba**, nunca de personas reales.

## 9. Mantenimiento

- Si cambia el contrato, Schemathesis lo recoge solo. Si cambia el flujo, actualiza `p04` y regenera la colección de Postman con `python pruebas/postman/generar_coleccion.py`.
- Los casos se escribieron a partir del OpenAPI, la guía técnica y la lista de los 47 tests. Si el código usa otro nombre de campo o de ruta (por ejemplo, la clave con la que el registro devuelve el código de verificación en desarrollo, que se busca en `sandbox.py`), basta con ajustarlo en el script correspondiente.
