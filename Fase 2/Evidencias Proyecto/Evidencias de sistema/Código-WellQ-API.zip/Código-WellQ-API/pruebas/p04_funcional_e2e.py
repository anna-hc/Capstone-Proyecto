"""Pruebas funcionales de extremo a extremo contra una API en marcha (local, demo de Vercel o sandbox).

Recorre el flujo completo del fabricante: alta, app, token, modelo, vínculo, los cinco tipos de ingesta,
idempotencia, estado de sincronización, lecturas, webhooks (si hay WELLQ_WEBHOOK_URL) y revocación.
Con WELLQ_PATIENT_JWT añade las rutas de la app del paciente; con WELLQ_CLINICIAN_JWT, las del panel clínico.

    python pruebas/p04_funcional_e2e.py
"""
from __future__ import annotations

import datetime as dt
import gzip
import json
import sys
import time
import uuid

import sandbox
from comun import ClienteAPI, Informe, cargar_config, esperar_estado, exigir_api, exigir_no_produccion, problem_type

HOY = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)


def iso(t: dt.datetime) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def resumen_diario(rid: str, dias_atras: int, **extra) -> dict:
    return {"record_id": rid, "local_date": (HOY - dt.timedelta(days=dias_atras)).date().isoformat(),
            "tz_offset_minutes": 0, "device_id": sandbox.DISPOSITIVO, "completeness": "final",
            "wear_time_minutes": 1300, "steps": 7412, "distance_m": 5210.5, "active_minutes": 48,
            "resting_heart_rate_bpm": 58, "hrv_rmssd_ms": 46.2, "sleep_total_minutes": 431, **extra}


def estados_de(resultado: dict) -> list[str]:
    return [r.get("status") for r in resultado.get("results", [])]


def main() -> int:
    cfg = cargar_config()
    informe = Informe("04_funcional", "Pruebas funcionales de extremo a extremo")
    exigir_no_produccion(cfg, "La prueba funcional (crea cuentas y datos)")
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    v = informe.verificar

    def salud():
        r = api.get("/health")
        assert r.json().get("partner_api") is True, f"partner_api={r.json().get('partner_api')}"
        assert r.headers.get("X-Trace-Id"), "falta la cabecera X-Trace-Id"
    v("F-01", "/health indica partner_api=true y devuelve X-Trace-Id", salud)

    estado = v("F-02", "Alta del fabricante → app → token → modelo → paciente sintético → vínculo",
               lambda: sandbox.preparar(cfg, api, nuevo=True))
    if not estado:
        return informe.cerrar()
    tok, link, app_id = estado["access_token"], estado["link_id"], estado["app_id"]
    sufijo = uuid.uuid4().hex[:8]

    def catalogo():
        datos = esperar_estado(api.get("/partner/capabilities/metrics", tok), 200)
        items = datos if isinstance(datos, list) else datos.get("items", [])
        assert items, "el catálogo de métricas está vacío"
        assert all("metric" in m and "canonical_unit" in m for m in items), "faltan metric/canonical_unit"
    v("F-03", "GET /capabilities/metrics devuelve el catálogo con unidades", catalogo)

    def apps_portal():
        datos = esperar_estado(api.get("/partner/apps", estado["portal_token"]), 200)
        items = datos if isinstance(datos, list) else datos.get("items", [])
        assert any(a.get("app_id") == app_id for a in items), "la app creada no aparece en el listado"
        assert all("client_secret" not in a for a in items), "el listado expone client_secret"
    if estado.get("portal_token"):
        v("F-04", "GET /apps (portal) lista la app sin exponer el secreto", apps_portal)

    def vinculo():
        datos = esperar_estado(api.get(f"/partner/links/{link}", tok), 200)
        assert datos.get("status") == "active", f"status={datos.get('status')}"
        prohibidos = {"patient_id", "user_id", "email", "name", "first_name", "last_name", "phone", "dob"} & set(datos)
        assert not prohibidos, f"el vínculo expone {prohibidos}"
        lista = esperar_estado(api.get("/partner/links", tok, params={"status": "active"}), 200)
        assert any(x.get("link_id") == link for x in lista.get("items", [])), "el vínculo no aparece en /links"
    v("F-05", "El vínculo está activo, aparece en /links y no expone datos del paciente", vinculo)

    def resumenes():
        cuerpo = {"summaries": [resumen_diario(f"qa-ds-{sufijo}-1", 1), resumen_diario(f"qa-ds-{sufijo}-2", 2)]}
        r1 = esperar_estado(api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo,
                                     headers={"Idempotency-Key": str(uuid.uuid4())}), 200)
        assert r1.get("accepted") == 2 and estados_de(r1) == ["created", "created"], r1
        cuerpo["summaries"][0]["steps"] = 8000
        r2 = esperar_estado(api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo), 200)
        assert set(estados_de(r2)) <= {"updated", "duplicate"}, f"el reenvío no se trató como upsert: {r2}"
    v("F-06", "daily-summaries: alta de 2 días y reenvío como actualización (upsert)", resumenes)

    def sesiones():
        ini = HOY - dt.timedelta(hours=10)
        cuerpo = {"sessions": [
            {"session_type": "sleep", "record_id": f"qa-sl-{sufijo}", "device_id": sandbox.DISPOSITIVO,
             "start": iso(ini), "end": iso(ini + dt.timedelta(hours=7)), "tz_offset_minutes": 0,
             "stages": [{"stage": "light", "start": iso(ini), "end": iso(ini + dt.timedelta(hours=3))},
                        {"stage": "deep", "start": iso(ini + dt.timedelta(hours=3)), "end": iso(ini + dt.timedelta(hours=7))}],
             "summary": {"total_sleep_minutes": 400, "time_in_bed_minutes": 420, "efficiency_pct": 95}},
            {"session_type": "exercise", "record_id": f"qa-ex-{sufijo}", "device_id": sandbox.DISPOSITIVO,
             "start": iso(HOY - dt.timedelta(hours=2)), "end": iso(HOY - dt.timedelta(hours=1)),
             "activity_type": "strength_training", "sets": [{"set_index": 1, "repetitions": 12, "load_kg": 10}],
             "summary": {"duration_seconds": 3600, "avg_heart_rate_bpm": 110}},
        ]}
        r = esperar_estado(api.post(f"/partner/links/{link}/sessions", tok, json=cuerpo), 200)
        assert r.get("accepted") == 2, r
    v("F-07", "sessions: sesión de sueño con fases y sesión de ejercicio con series", sesiones)

    def msk():
        cuerpo = {"measurements": [{"record_id": f"qa-msk-{sufijo}", "device_id": sandbox.DISPOSITIVO,
                                    "timestamp": iso(HOY - dt.timedelta(hours=1)),
                                    "measurement_type": "range_of_motion_flexion", "body_region": "knee",
                                    "side": "right", "value": 118.5, "unit": "deg", "context": "free_activity",
                                    "confidence": 0.9}]}
        r = esperar_estado(api.post(f"/partner/links/{link}/msk-measurements", tok, json=cuerpo), 200)
        assert r.get("accepted") == 1, r
    v("F-08", "msk-measurements: flexión de rodilla", msk)

    def eventos():
        cuerpo = {"events": [{"record_id": f"qa-ev-{sufijo}-{i}", "device_id": sandbox.DISPOSITIVO,
                              "timestamp": iso(HOY - dt.timedelta(minutes=30 - i)), "event_type": t,
                              "details": {"battery_pct": 12}} for i, t in enumerate(["worn", "battery_low", "sync_completed"])]}
        r = esperar_estado(api.post(f"/partner/links/{link}/device-events", tok, json=cuerpo), 200)
        assert r.get("accepted") == 3, r
    v("F-09", "device-events: puesto, batería baja y sincronización", eventos)

    serie = {"metric": "heart_rate", "unit": "bpm", "device_id": sandbox.DISPOSITIVO,
             "start": iso(HOY - dt.timedelta(hours=3)), "offsets_ms": [i * 60000 for i in range(60)],
             "durations_ms": [60000] * 60, "values": [60 + (i % 7) for i in range(60)]}

    def esperar_job(job_id: str) -> dict:
        limite = time.time() + 60
        while True:
            job = esperar_estado(api.get(f"/partner/ingest/jobs/{job_id}", tok), 200)
            if job.get("status") in ("completed", "failed", "partially_completed") or time.time() > limite:
                return job
            if cfg["WELLQ_CRON_SECRET"]:
                api.get("/internal/cron/sweep-ingest", cfg["WELLQ_CRON_SECRET"])
            time.sleep(2)

    def muestras_json():
        r = esperar_estado(api.post(f"/partner/links/{link}/samples", tok, json={"series": [serie]}), 202)
        job = esperar_job(r["job_id"])
        assert job.get("status") == "completed", f"job {r['job_id']} en estado {job.get('status')}: {job.get('errors')}"
        assert job.get("summary", {}).get("points_accepted") == 60, job.get("summary")
    v("F-10", "samples (JSON): 202 con job_id y el job termina con 60 puntos aceptados", muestras_json)

    def muestras_gzip():
        s = dict(serie, start=iso(HOY - dt.timedelta(hours=5)))
        cuerpo = gzip.compress(json.dumps({"series": [s]}).encode())
        r = esperar_estado(api.post(f"/partner/links/{link}/samples", tok, data=cuerpo,
                                    headers={"Content-Type": "application/json", "Content-Encoding": "gzip"}), 202)
        assert esperar_job(r["job_id"]).get("status") == "completed"
    v("F-11", "samples (gzip): se acepta Content-Encoding: gzip", muestras_gzip)

    def muestras_ndjson():
        s = dict(serie, start=iso(HOY - dt.timedelta(hours=7)))
        r = api.post(f"/partner/links/{link}/samples", tok, data=(json.dumps(s) + "\n").encode(),
                     headers={"Content-Type": "application/x-ndjson"})
        esperar_estado(r, 202)
    v("F-12", "samples (NDJSON): una serie por línea", muestras_ndjson)

    def sync_state():
        datos = esperar_estado(api.get(f"/partner/links/{link}/sync-state", tok), 200)
        assert datos.get("last_received"), f"last_received vacío: {datos}"
        assert "gaps" in datos, "falta gaps"
    v("F-13", "sync-state informa de lo último recibido y de los huecos", sync_state)

    def lecturas():
        esperar_estado(api.get(f"/partner/links/{link}/goals", tok), 200)
        desde, hasta = (HOY - dt.timedelta(days=7)).date().isoformat(), HOY.date().isoformat()
        datos = esperar_estado(api.get(f"/partner/links/{link}/scores", tok,
                                       params={"from_date": desde, "to_date": hasta}), 200)
        for dia in datos.get("days", []):
            for k in ("activity", "sleep", "adherence", "stability"):
                assert dia.get(k) is None or 0 <= dia[k] <= 100, f"score fuera de rango: {dia}"
        r = api.get(f"/partner/links/{link}/scores", tok, params={"from_date": "2026-01-01", "to_date": hasta})
        assert r.status_code in (400, 422), f"un rango de más de 90 días respondió {r.status_code}"
    v("F-14", "goals y scores responden; scores 0-100 y rango máximo de 90 días", lecturas)

    def validacion():
        cuerpo = {"summaries": [resumen_diario(f"qa-ds-{sufijo}-bad", 3, resting_heart_rate_bpm=300)]}
        r = api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo)
        if r.status_code == 422:
            assert "application/problem+json" in r.headers.get("Content-Type", ""), "422 sin problem+json"
            return
        datos = esperar_estado(r, 200)
        assert estados_de(datos) == ["rejected"], f"un pulso de 300 lpm no se rechazó: {datos}"
        assert datos["results"][0].get("errors"), "el rechazo no indica el campo"
    v("F-15", "Valores fuera de rango (pulso en reposo 300) se rechazan indicando el campo", validacion)

    def desconocidos():
        cuerpo = {"summaries": [resumen_diario(f"qa-ds-{sufijo}-x", 4, campo_inventado=1)]}
        r = api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo)
        if r.status_code == 200:
            assert estados_de(r.json()) == ["rejected"], f"campo desconocido aceptado: {r.json()}"
        else:
            assert r.status_code == 422, r.status_code
    v("F-16", "Campos desconocidos se rechazan (modelos estrictos)", desconocidos)

    if cfg["WELLQ_WEBHOOK_URL"]:
        def webhooks():
            wh = esperar_estado(api.post(f"/partner/apps/{app_id}/webhooks", tok, json={
                "url": cfg["WELLQ_WEBHOOK_URL"], "events": ["ping", "link.created", "link.revoked",
                                                             "ingest.job.completed"], "description": "QA"}), 201)
            assert wh.get("secret"), "el alta no devuelve el secret"
            prueba = esperar_estado(api.post(f"/partner/apps/{app_id}/webhooks/{wh['webhook_id']}/test", tok), 200)
            assert prueba.get("delivered") is True, f"ping no entregado: {prueba}"
            entregas = esperar_estado(api.get(f"/partner/apps/{app_id}/webhooks/{wh['webhook_id']}/deliveries", tok), 200)
            assert entregas.get("items"), "el historial de entregas está vacío"
            lista = esperar_estado(api.get(f"/partner/apps/{app_id}/webhooks", tok), 200)
            assert all("secret" not in w for w in lista), "el listado de webhooks expone el secret"
            esperar_estado(api.delete(f"/partner/apps/{app_id}/webhooks/{wh['webhook_id']}", tok), 204)
        v("F-17", "Webhooks: alta, ping entregado, historial y baja", webhooks)
    else:
        informe.omitir("F-17", "Webhooks: alta, ping entregado, historial y baja",
                       "define WELLQ_WEBHOOK_URL (p. ej. una URL de webhook.site) para probarlos")

    def revocacion():
        otro = sandbox.nuevo_vinculo(api, tok)
        lid = otro["link_id"]
        esperar_estado(api.delete(f"/partner/links/{lid}", tok), 204)
        datos = esperar_estado(api.get(f"/partner/links/{lid}", tok), 200)
        assert datos.get("status") == "revoked" and datos.get("revoked_by") == "partner", datos
        r = api.post(f"/partner/links/{lid}/daily-summaries", tok,
                     json={"summaries": [resumen_diario(f"qa-ds-{sufijo}-rev", 1)]})
        assert r.status_code == 403 and "link-revoked" in problem_type(r), f"{r.status_code} {problem_type(r)}"
        r = api.post("/partner/links", tok, json={"pairing_code": otro["_pairing_code"], "external_user_id": "qa-reuse"})
        assert r.status_code == 404, f"un código ya usado respondió {r.status_code}"
    v("F-18", "Revocación por el fabricante: 204, estado revoked, ingesta 403 link-revoked y código no reutilizable",
      revocacion)

    integracion_paciente(cfg, api, informe, estado)
    return informe.cerrar()


def integracion_paciente(cfg, api: ClienteAPI, informe: Informe, estado: dict) -> None:
    """Rutas internas de la app del paciente y del panel clínico (requieren JWT reales de WellQ)."""
    v = informe.verificar
    pjwt, cjwt = cfg["WELLQ_PATIENT_JWT"], cfg["WELLQ_CLINICIAN_JWT"]
    if not pjwt:
        informe.omitir("INT-01", "App del paciente: consent-info, código, vínculos y revocación",
                       "define WELLQ_PATIENT_JWT (JWT de un paciente de prueba) para probarlas")
    else:
        def paciente():
            info = api.get("/wearables/consent-info", pjwt, params={"app_id": estado["app_id"]})
            assert info.status_code in (200, 404), f"consent-info respondió {info.status_code}"
            r = api.post("/wearables/pairing-codes", pjwt, json={
                "app_id": estado["app_id"], "scopes": ["ingest:activity", "ingest:sleep"],
                "consent_doc_version": cfg.get("WELLQ_CONSENT_DOC_VERSION", "wearable-sharing-v1")})
            codigo = esperar_estado(r, 201)
            assert codigo["pairing_code"].startswith("WQ-") and codigo.get("expires_at"), codigo
            vinc = esperar_estado(api.post("/partner/links", estado["access_token"], json={
                "pairing_code": codigo["pairing_code"], "external_user_id": f"qa-pac-{uuid.uuid4().hex[:8]}",
                "device_id": sandbox.DISPOSITIVO, "model_code": sandbox.MODELO}), 201)
            lista = esperar_estado(api.get("/wearables/links", pjwt), 200)
            assert any(x.get("link_id") == vinc["link_id"] for x in lista), "el paciente no ve el vínculo"
            esperar_estado(api.delete(f"/wearables/links/{vinc['link_id']}", pjwt, params={"delete_data": "true"}), 204)
            r = api.get(f"/partner/links/{vinc['link_id']}", estado["access_token"])
            assert r.json().get("revoked_by") == "patient", r.text[:200]
        v("INT-01", "App del paciente: genera código, el fabricante lo canjea, el paciente lo ve y lo revoca",
          paciente)
    if not cjwt or not cfg["WELLQ_PATIENT_ID"]:
        informe.omitir("INT-02", "Panel clínico: dispositivos del paciente",
                       "define WELLQ_CLINICIAN_JWT y WELLQ_PATIENT_ID para probarlo")
    else:
        v("INT-02", "Panel clínico: GET /maindash/patient/{id}/wearables",
          lambda: esperar_estado(api.get(f"/maindash/patient/{cfg['WELLQ_PATIENT_ID']}/wearables", cjwt), 200))


if __name__ == "__main__":
    sys.exit(main())
