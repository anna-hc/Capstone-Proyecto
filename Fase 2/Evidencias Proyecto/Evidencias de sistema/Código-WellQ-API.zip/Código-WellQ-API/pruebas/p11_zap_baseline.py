"""Escaneo automático de OWASP ZAP contra la API usando el contrato OpenAPI (requiere Docker).

Lanza el contenedor oficial de ZAP con zap-api-scan.py: importa el OpenAPI, recorre todas las rutas con el
access_token del fabricante de pruebas y ejecuta las reglas pasivas y activas para APIs.
Es la parte automatizable; la exploración manual con la interfaz de ZAP está en GUIA_PRUEBAS_MANUALES.md.

    python pruebas/p11_zap_baseline.py            # escaneo activo (ataques) contra sandbox/local
    python pruebas/p11_zap_baseline.py --pasivo   # solo reglas pasivas (seguro en entornos compartidos)

Con la API en local (127.0.0.1), el script usa host.docker.internal para que el contenedor la alcance.
Resultados: zap_informe.html, zap_informe.json y zap_informe.md. FALLO si hay alertas de riesgo Alto o Medio
no aceptadas en pruebas/zap_reglas.tsv.
"""
from __future__ import annotations

import json
import os
import shutil
import sys

import sandbox
from comun import DIR_PRUEBAS, ClienteAPI, Informe, cargar_config, ejecutar, exigir_api, exigir_no_produccion


def main() -> int:
    cfg = cargar_config()
    informe = Informe("11_zap", "Escaneo de seguridad automatizado (OWASP ZAP API scan)")
    pasivo = "--pasivo" in sys.argv
    if not pasivo:
        exigir_no_produccion(cfg, "El escaneo activo de ZAP")
    docker = shutil.which("docker")
    if not docker:
        informe.registrar("ZAP-00", "Docker instalado", False, "instala Docker Desktop o usa la guía manual de ZAP")
        return informe.cerrar()
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    estado = informe.verificar("ZAP-01", "Preparar credenciales de pruebas", lambda: sandbox.preparar(cfg, api))
    if not estado or not cfg.openapi.exists():
        if estado:
            informe.registrar("ZAP-00", "Existe el contrato OpenAPI", False, str(cfg.openapi))
        return informe.cerrar()

    carpeta = informe.carpeta
    shutil.copy(cfg.openapi, carpeta / "openapi.yaml")
    if (DIR_PRUEBAS / "zap_reglas.tsv").exists():
        shutil.copy(DIR_PRUEBAS / "zap_reglas.tsv", carpeta / "zap_reglas.tsv")
    objetivo = cfg.api.replace("127.0.0.1", "host.docker.internal").replace("localhost", "host.docker.internal")
    # El OpenAPI declara los servidores de WellQ; -O lo redirige al entorno bajo prueba.
    cmd = [docker, "run", "--rm", "-v", f"{carpeta}:/zap/wrk:rw", "--add-host", "host.docker.internal:host-gateway",
           "-e", f"ZAP_AUTH_HEADER_VALUE=Bearer {estado['access_token']}", "-e", "ZAP_AUTH_HEADER=Authorization",
           cfg["ZAP_IMAGEN"], "zap-api-scan.py", "-t", "openapi.yaml", "-f", "openapi", "-O", objetivo,
           "-r", "zap_informe.html", "-J", "zap_informe.json", "-w", "zap_informe.md", "-I", "-d"]
    if (carpeta / "zap_reglas.tsv").exists():
        cmd += ["-c", "zap_reglas.tsv"]
    if pasivo:
        cmd += ["-S"]
    if os.name != "nt" and hasattr(os, "getuid"):
        cmd[2:2] = ["--user", f"{os.getuid()}:{os.getgid()}"]
    visible = [c if not c.startswith("ZAP_AUTH_HEADER_VALUE") else "ZAP_AUTH_HEADER_VALUE=Bearer …" for c in cmd]
    print("$ " + " ".join(visible))
    codigo = ejecutar(cmd, carpeta, "salida_zap.txt", timeout=3 * 3600)

    informe_json = carpeta / "zap_informe.json"
    if not informe_json.exists():
        informe.registrar("ZAP-99", "ZAP generó su informe", False, f"código {codigo}; revisa salida_zap.txt")
        return informe.cerrar()
    datos = json.loads(informe_json.read_text(encoding="utf-8"))
    graves = 0
    for sitio in datos.get("site", []):
        for alerta in sitio.get("alerts", []):
            riesgo = int(alerta.get("riskcode", 0))
            nombre = f"[{alerta.get('riskdesc', '')}] {alerta.get('name')} ({alerta.get('count', '?')} URLs)"
            if riesgo >= 2:
                graves += 1
                informe.registrar("ZAP", nombre, False, (alerta.get("solution") or "")[:300])
            else:
                informe.omitir("ZAP-INFO", nombre, "riesgo bajo o informativo: revisar")
    informe.registrar("ZAP-02", "Sin alertas de riesgo Alto o Medio", graves == 0, f"{graves} alertas")
    return informe.cerrar({"modo": "pasivo" if pasivo else "activo"})


if __name__ == "__main__":
    sys.exit(main())
