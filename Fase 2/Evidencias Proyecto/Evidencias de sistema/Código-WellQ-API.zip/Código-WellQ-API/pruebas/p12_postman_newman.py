"""Ejecuta la colección de Postman con Newman (la misma que se usa a mano en Postman).

    python pruebas/p12_postman_newman.py
    python pruebas/p12_postman_newman.py --carpeta "05 Ingesta"   # solo una carpeta (requiere variables previas)

Necesita Node.js (usa `npx newman`, que se descarga solo la primera vez). Toma base_url y los JWT opcionales
de pruebas/config.env, de modo que no hay que editar el entorno de Postman para lanzarla desde aquí.
Resultados: newman_junit.xml y newman_resultado.json; un caso por test de Postman en resultado.md.
"""
from __future__ import annotations

import json
import shutil
import sys

from comun import DIR_PRUEBAS, Informe, cargar_config, ejecutar, exigir_api, exigir_no_produccion


def main() -> int:
    cfg = cargar_config()
    informe = Informe("12_newman", "Colección de Postman ejecutada con Newman")
    exigir_no_produccion(cfg, "La colección de Postman (crea cuentas y datos)")
    npx = shutil.which("npx") or shutil.which("npx.cmd")
    newman = shutil.which("newman") or shutil.which("newman.cmd")
    if not newman and not npx:
        informe.registrar("NM-00", "Node.js/Newman instalado", False, "instala Node.js LTS (https://nodejs.org)")
        return informe.cerrar()
    exigir_api(cfg, informe)
    carpeta = informe.carpeta
    coleccion = DIR_PRUEBAS / "postman" / "WellQ_Partner_API.postman_collection.json"
    entorno = DIR_PRUEBAS / "postman" / "WellQ_local.postman_environment.json"
    base = [newman] if newman else [npx, "--yes", "newman@6"]
    cmd = base + ["run", str(coleccion), "-e", str(entorno),
                  "--env-var", f"base_url={cfg['WELLQ_BASE_URL'].rstrip('/')}",
                  "--reporters", "cli,junit,json",
                  "--reporter-junit-export", str(carpeta / "newman_junit.xml"),
                  "--reporter-json-export", str(carpeta / "newman_resultado.json"),
                  "--timeout-request", "30000", "--color", "off"]
    for var, clave in (("webhook_url", "WELLQ_WEBHOOK_URL"), ("patient_jwt", "WELLQ_PATIENT_JWT"),
                       ("clinician_jwt", "WELLQ_CLINICIAN_JWT"), ("patient_id", "WELLQ_PATIENT_ID"),
                       ("cron_secret", "WELLQ_CRON_SECRET")):
        if cfg[clave]:
            cmd += ["--env-var", f"{var}={cfg[clave]}"]
    if cfg["WELLQ_VERIFY_CODE"]:
        cmd += ["--env-var", f"verification_code={cfg['WELLQ_VERIFY_CODE']}"]
    omitidas = []
    if "--carpeta" in sys.argv:
        cmd += ["--folder", sys.argv[sys.argv.index("--carpeta") + 1]]
    else:
        # Las carpetas que dependen de datos opcionales solo se lanzan si están configurados.
        carpetas = ["00 Salud", "01 Alta del fabricante", "02 OAuth", "03 Capacidades", "04 Vinculación",
                    "05 Ingesta", "06 Lectura", "08 Seguridad (casos negativos)", "11 Cierre"]
        if cfg["WELLQ_WEBHOOK_URL"]:
            carpetas.insert(7, "07 Webhooks")
        else:
            omitidas.append(("07 Webhooks", "define WELLQ_WEBHOOK_URL"))
        if cfg["WELLQ_PATIENT_JWT"]:
            carpetas.insert(-1, "09 App del paciente")
        else:
            omitidas.append(("09 App del paciente", "define WELLQ_PATIENT_JWT"))
        if cfg["WELLQ_CLINICIAN_JWT"] and cfg["WELLQ_PATIENT_ID"]:
            carpetas.insert(-1, "10 Panel clínico")
        else:
            omitidas.append(("10 Panel clínico", "define WELLQ_CLINICIAN_JWT y WELLQ_PATIENT_ID"))
        for c in carpetas:
            cmd += ["--folder", c]
    codigo = ejecutar(cmd, carpeta, "salida_newman.txt", timeout=1800)

    resultado = carpeta / "newman_resultado.json"
    if resultado.exists():
        datos = json.loads(resultado.read_text(encoding="utf-8"))
        for ej in datos.get("run", {}).get("executions", []):
            nombre = ej.get("item", {}).get("name", "?")
            codigo_http = ej.get("response", {}).get("code", "—")
            for a in ej.get("assertions", []):
                err = a.get("error")
                informe.registrar("NM", f"{nombre} · {a.get('assertion')}", err is None,
                                  "" if err is None else f"HTTP {codigo_http}: {err.get('message', '')}")
    else:
        informe.registrar("NM-99", "Newman generó su informe", False, f"código {codigo}")
    for c, motivo in omitidas:
        informe.omitir("NM-OMIT", c, motivo)
    return informe.cerrar({"codigo_salida_newman": codigo})


if __name__ == "__main__":
    sys.exit(main())
