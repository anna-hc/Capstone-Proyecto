"""Pruebas de autenticación y autorización contra una API en marcha.

Tokens ausentes, manipulados o con alg=none; OAuth con credenciales y scopes inválidos; scopes del token y
del consentimiento del paciente; aislamiento entre fabricantes (BOLA); separación de credenciales por actor;
rotación de secretos; códigos de emparejamiento; rutas de cron.

Crea un segundo fabricante de pruebas para los casos de aislamiento y de rotación.

    python pruebas/p05_autenticacion.py
"""
from __future__ import annotations

import base64
import json
import sys
import uuid

import sandbox
from comun import ClienteAPI, Informe, cargar_config, esperar_estado, exigir_api, exigir_no_produccion, problem_type

RUTAS_PROTEGIDAS = [
    ("GET", "/partner/links"),
    ("POST", "/partner/links"),
    ("GET", "/partner/links/{link}"),
    ("GET", "/partner/links/{link}/sync-state"),
    ("POST", "/partner/links/{link}/daily-summaries"),
    ("POST", "/partner/links/{link}/samples"),
    ("POST", "/partner/links/{link}/sessions"),
    ("POST", "/partner/links/{link}/msk-measurements"),
    ("POST", "/partner/links/{link}/device-events"),
    ("GET", "/partner/links/{link}/goals"),
    ("GET", "/partner/links/{link}/scores?from_date=2026-01-01&to_date=2026-01-02"),
    ("GET", "/partner/apps"),
    ("POST", "/partner/apps"),
    ("GET", "/partner/apps/{app}"),
    ("GET", "/partner/apps/{app}/webhooks"),
    ("GET", "/partner/apps/{app}/device-models"),
    ("POST", "/partner/sandbox/patients"),
    ("GET", "/partner/ingest/jobs/job_inexistente"),
    ("GET", "/wearables/links"),
    ("POST", "/wearables/pairing-codes"),
]


def b64(datos: bytes) -> str:
    return base64.urlsafe_b64encode(datos).rstrip(b"=").decode()


def decodificar(parte: str) -> dict:
    return json.loads(base64.urlsafe_b64decode(parte + "=" * (-len(parte) % 4)))


def tokens_manipulados(token: str) -> dict[str, str]:
    cab, carga, firma = token.split(".")
    datos = decodificar(carga)
    datos_mod = dict(datos, scope="links:manage webhooks:manage ingest:activity admin", sub="otro-cliente")
    return {
        "firma alterada": f"{cab}.{carga}.{firma[:-2]}{'AA' if not firma.endswith('AA') else 'BB'}",
        "carga modificada con la firma original": f"{cab}.{b64(json.dumps(datos_mod).encode())}.{firma}",
        "alg=none sin firma": f"{b64(json.dumps({'alg': 'none', 'typ': 'JWT'}).encode())}.{carga}.",
        "caducado (exp en 2020)": f"{cab}.{b64(json.dumps(dict(datos, exp=1577836800)).encode())}.{firma}",
        "basura": "esto.no.esunjwt",
    }


def main() -> int:
    cfg = cargar_config()
    informe = Informe("05_autenticacion", "Pruebas de autenticación y autorización")
    exigir_no_produccion(cfg, "La prueba de autenticación (crea cuentas y fuerza límites)")
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    v = informe.verificar

    estado = v("A-00", "Preparar fabricante A en sandbox", lambda: sandbox.preparar(cfg, api))
    if not estado:
        return informe.cerrar()
    tok, link, app = estado["access_token"], estado["link_id"], estado["app_id"]

    def rutas(token_prueba, descripcion_token):
        # Falla si alguna ruta responde 2xx (acceso concedido) o 5xx (error al validar la credencial).
        # Otros 4xx (p. ej. 422 por validar el cuerpo antes que el token) se anotan para revisarlos.
        fallos, otros = [], []
        for metodo, ruta in RUTAS_PROTEGIDAS:
            r = api.peticion(metodo, ruta.format(link=link, app=app), token_prueba, json={} if metodo == "POST" else None)
            if r.status_code < 400 or r.status_code >= 500:
                fallos.append(f"{metodo} {ruta} → {r.status_code}")
            elif r.status_code not in (401, 403):
                otros.append(f"{metodo} {ruta} → {r.status_code}")
        assert not fallos, f"aceptaron {descripcion_token}: " + "; ".join(fallos)
        if otros:
            print(f"    (revisar, {descripcion_token}: no devuelven 401/403 → {'; '.join(otros)})")

    v("A-01", f"Sin token: {len(RUTAS_PROTEGIDAS)} rutas protegidas responden 401/403", lambda: rutas(None, "sin token"))
    for nombre, falso in tokens_manipulados(tok).items():
        v("A-02", f"Token {nombre}: rechazado en todas las rutas", lambda f=falso, n=nombre: rutas(f, n))

    def problem_401():
        r = api.get("/partner/links", "invalido")
        assert r.status_code == 401, r.status_code
        assert "application/problem+json" in r.headers.get("Content-Type", ""), "el 401 no es problem+json"
        assert "trace_id" in r.json(), "el error no lleva trace_id"
        assert "Traceback" not in r.text and "File \"" not in r.text, "el error filtra detalles internos"
    v("A-03", "Los 401 usan problem+json con trace_id y sin detalles internos", problem_401)

    def oauth_invalido():
        casos = {
            "secreto incorrecto": {"grant_type": "client_credentials", "client_id": estado["client_id"],
                                   "client_secret": "incorrecto"},
            "cliente inexistente": {"grant_type": "client_credentials", "client_id": "cli_no_existe",
                                    "client_secret": "x"},
            "grant_type password": {"grant_type": "password", "client_id": estado["client_id"],
                                    "client_secret": estado["client_secret"]},
            "scope no concedido": {"grant_type": "client_credentials", "client_id": estado["client_id"],
                                   "client_secret": estado["client_secret"], "scope": "admin:all"},
        }
        fallos = [f"{n} → {r.status_code}" for n, form in casos.items()
                  if (r := api.post("/partner/oauth/token", data=form)).status_code not in (400, 401, 403)]
        assert not fallos, "; ".join(fallos)
    v("A-04", "OAuth rechaza secreto incorrecto, cliente inexistente, otro grant_type y scopes no concedidos",
      oauth_invalido)

    def scope_token():
        reducido = sandbox.obtener_token(api, estado["client_id"], estado["client_secret"], ["links:manage"])
        r = api.post(f"/partner/links/{link}/daily-summaries", reducido, json={"summaries": [{
            "record_id": f"qa-a-{uuid.uuid4().hex[:6]}", "local_date": "2026-10-01", "tz_offset_minutes": 0,
            "device_id": sandbox.DISPOSITIVO, "steps": 100}]})
        assert r.status_code == 403 and "insufficient-scope" in problem_type(r), f"ingesta: {r.status_code} {problem_type(r)}"
        r = api.get(f"/partner/apps/{app}/webhooks", reducido)
        assert r.status_code == 403, f"webhooks sin webhooks:manage → {r.status_code}"
        r = api.get(f"/partner/links/{link}/goals", reducido)
        assert r.status_code == 403, f"goals sin read:goals → {r.status_code}"
    v("A-05", "Un token solo con links:manage no puede ingerir, leer objetivos ni gestionar webhooks", scope_token)

    def scope_vinculo():
        limitado = sandbox.nuevo_vinculo(api, tok, scopes=["ingest:activity"])
        lid = limitado["link_id"]
        r = api.get(f"/partner/links/{lid}/goals", tok)
        assert r.status_code == 403 and "insufficient-scope" in problem_type(r), f"goals: {r.status_code}"
        r = api.post(f"/partner/links/{lid}/sessions", tok, json={"sessions": [{
            "session_type": "sleep", "record_id": f"qa-a-sl-{uuid.uuid4().hex[:6]}", "device_id": sandbox.DISPOSITIVO,
            "start": "2026-10-01T22:00:00Z", "end": "2026-10-02T06:00:00Z"}]})
        rechazado = r.status_code == 403 or (r.status_code == 200 and r.json().get("rejected") == 1)
        assert rechazado, f"sueño sin consentimiento ingest:sleep → {r.status_code} {r.text[:200]}"
        r = api.post(f"/partner/links/{lid}/daily-summaries", tok, json={"summaries": [{
            "record_id": f"qa-a-ds-{uuid.uuid4().hex[:6]}", "local_date": "2026-10-01", "tz_offset_minutes": 0,
            "device_id": sandbox.DISPOSITIVO, "steps": 500, "resting_heart_rate_bpm": 60}]})
        datos = esperar_estado(r, 200, 403)
        if r.status_code == 200:
            errores = json.dumps(datos.get("results", []))
            assert "resting_heart_rate" in errores or datos.get("rejected"), \
                f"se guardó el pulso sin consentimiento ingest:vitals: {datos}"
        api.delete(f"/partner/links/{lid}", tok)
    v("A-06", "El consentimiento del vínculo limita lo que se lee y se guarda (campo a campo)", scope_vinculo)

    # Fabricante B: aislamiento y rotación sin tocar las credenciales de A.
    def fabricante_b():
        suf = uuid.uuid4().hex[:8]
        portal = cfg["WELLQ_PORTAL_TOKEN"] or sandbox.registrar_desarrollador(cfg, api, f"b-{suf}")["portal_token"]
        app_b = sandbox.crear_app(api, portal, f"QA Partner B {suf}")
        tok_b = sandbox.obtener_token(api, app_b["client_id"], app_b["client_secret"], sandbox.SCOPES_TOKEN)
        return {"portal": portal, "app": app_b, "tok": tok_b}
    b = v("A-07", "Preparar fabricante B", fabricante_b)
    if b:
        def bola():
            fallos = []
            for metodo, ruta in [("GET", f"/partner/links/{link}"), ("GET", f"/partner/links/{link}/sync-state"),
                                 ("GET", f"/partner/links/{link}/goals"), ("DELETE", f"/partner/links/{link}"),
                                 ("POST", f"/partner/links/{link}/device-events"), ("GET", f"/partner/apps/{app}"),
                                 ("GET", f"/partner/apps/{app}/webhooks"), ("GET", f"/partner/apps/{app}/device-models")]:
                cuerpo = {"events": [{"record_id": "x", "device_id": "x", "timestamp": "2026-10-01T00:00:00Z",
                                      "event_type": "worn"}]} if metodo == "POST" else None
                r = api.peticion(metodo, ruta, b["tok"], json=cuerpo)
                if r.status_code not in (403, 404):
                    fallos.append(f"{metodo} {ruta} → {r.status_code}")
            r = api.get(f"/partner/apps/{app}", b["portal"])
            if r.status_code not in (403, 404):
                fallos.append(f"portal B GET app A → {r.status_code}")
            listado = api.get("/partner/links", b["tok"]).json().get("items", [])
            if any(x.get("link_id") == link for x in listado):
                fallos.append("el listado de B incluye el vínculo de A")
            assert not fallos, "; ".join(fallos)
            assert api.get(f"/partner/links/{link}", tok).json().get("status") == "active", "B consiguió revocar el vínculo de A"
        v("A-08", "BOLA: el fabricante B no ve, modifica ni revoca recursos de A (404 sin revelar existencia)", bola)

        def separacion_actores():
            r = api.post("/partner/apps", b["tok"], json={"name": "no debería"})
            assert r.status_code in (401, 403), f"access_token en ruta de portal → {r.status_code}"
            r = api.get("/partner/links", b["portal"])
            assert r.status_code in (401, 403), f"portal_token en ruta de fabricante → {r.status_code}"
            r = api.get("/wearables/links", b["tok"])
            assert r.status_code in (401, 403), f"token de fabricante en ruta de paciente → {r.status_code}"
            if cfg["WELLQ_PATIENT_JWT"]:
                r = api.get("/partner/links", cfg["WELLQ_PATIENT_JWT"])
                assert r.status_code in (401, 403), f"JWT de paciente en ruta de fabricante → {r.status_code}"
        v("A-09", "Cada credencial solo sirve en las rutas de su actor (portal, fabricante, paciente)", separacion_actores)

        def rotacion():
            app_id_b = b["app"]["app_id"]
            r = api.post(f"/partner/apps/{app_id_b}/secrets/rotate", b["tok"], json={"grace_period_seconds": 0})
            assert r.status_code in (401, 403), f"rotar con access_token → {r.status_code} (solo desde el portal)"
            nuevo = esperar_estado(api.post(f"/partner/apps/{app_id_b}/secrets/rotate", b["portal"],
                                            json={"grace_period_seconds": 0}), 200)
            r = api.get("/partner/links", b["tok"])
            assert r.status_code == 401, f"el token anterior sigue valiendo tras rotar sin gracia → {r.status_code}"
            r = api.post("/partner/oauth/token", data={"grant_type": "client_credentials",
                                                       "client_id": b["app"]["client_id"],
                                                       "client_secret": b["app"]["client_secret"]})
            assert r.status_code == 401, f"el secreto anterior sigue valiendo → {r.status_code}"
            b["tok"] = sandbox.obtener_token(api, nuevo["client_id"], nuevo["client_secret"], sandbox.SCOPES_TOKEN)
            esperar_estado(api.get("/partner/links", b["tok"]), 200)
        v("A-10", "Rotación sin gracia (solo desde el portal) revoca el secreto y los tokens anteriores", rotacion)

        def codigos():
            r = api.post("/partner/links", b["tok"], json={"pairing_code": "WQ-0000-0000", "external_user_id": "qa"})
            assert r.status_code == 404, f"código inexistente → {r.status_code}"
            estados = []
            for i in range(40):
                r = api.post("/partner/links", b["tok"],
                             json={"pairing_code": f"WQ-ZZZZ-{i:04d}", "external_user_id": f"qa-bf-{i}"})
                estados.append(r.status_code)
                if r.status_code == 429:
                    assert r.headers.get("Retry-After"), "el 429 no trae Retry-After"
                    return
            raise AssertionError(f"40 códigos erróneos seguidos sin 429: {sorted(set(estados))}")
        v("A-11", "Códigos de emparejamiento: inexistente → 404 y fuerza bruta bloqueada con 429 + Retry-After", codigos)

    def cron():
        for trabajo in ("deliver-webhooks", "sweep-ingest", "run-deletions"):
            for token in (None, "secreto-incorrecto"):
                r = api.get(f"/internal/cron/{trabajo}", token)
                assert r.status_code in (401, 403, 404), f"{trabajo} con {token or 'sin token'} → {r.status_code}"
        if cfg["WELLQ_CRON_SECRET"]:
            r = api.get("/internal/cron/sweep-ingest", cfg["WELLQ_CRON_SECRET"])
            assert r.status_code == 200, f"con CRON_SECRET correcto → {r.status_code}"
    v("A-12", "Las rutas de cron solo responden con el CRON_SECRET correcto", cron)

    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
