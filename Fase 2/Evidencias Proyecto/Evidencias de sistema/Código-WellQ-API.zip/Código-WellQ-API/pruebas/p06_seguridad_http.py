"""Pruebas de seguridad de la superficie HTTP contra una API en marcha (caja negra).

Cabeceras de seguridad, documentación y demo ocultas en producción, CORS, métodos no permitidos, errores sin
detalles internos, SSRF en webhooks, inyección de operadores de Mongo, límites de tamaño (cuerpo, lote,
gzip bomb) y límites de tasa. Complementa al escaneo de OWASP ZAP (p11 y guía manual).

    python pruebas/p06_seguridad_http.py
    python pruebas/p06_seguridad_http.py --sin-rate-limit   # no satura los límites (útil en entornos compartidos)
"""
from __future__ import annotations

import gzip
import json
import sys
import uuid

import sandbox
from comun import ClienteAPI, Informe, cargar_config, exigir_api, exigir_no_produccion

URLS_SSRF = [
    "https://169.254.169.254/latest/meta-data", "https://127.0.0.1/hook", "https://localhost/hook",
    "https://10.0.0.5/x", "https://192.168.1.1/x", "https://[::1]/x", "https://[::ffff:127.0.0.1]/x",
    "http://example.com/x", "https://user:pass@example.com/x", "https://metadata.google.internal/x",
    "ftp://example.com/x", "file:///etc/passwd", "https://0x7f000001/x", "https://2130706433/x",
]


def main() -> int:
    cfg = cargar_config()
    informe = Informe("06_seguridad_http", "Pruebas de seguridad HTTP (caja negra)")
    exigir_no_produccion(cfg, "La prueba de seguridad HTTP (envía cargas maliciosas y satura límites)")
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    v = informe.verificar
    estado = v("S-00", "Preparar fabricante de pruebas", lambda: sandbox.preparar(cfg, api))
    if not estado:
        return informe.cerrar()
    tok, link, app = estado["access_token"], estado["link_id"], estado["app_id"]
    https = cfg["WELLQ_BASE_URL"].startswith("https://")

    def cabeceras():
        faltan = []
        for ruta, token in (("/health", None), ("/partner/links", tok), ("/partner/links", None)):
            h = {k.lower(): val for k, val in api.get(ruta, token).headers.items()}
            if h.get("x-content-type-options", "").lower() != "nosniff":
                faltan.append(f"{ruta}: X-Content-Type-Options")
            if "x-frame-options" not in h and "frame-ancestors" not in h.get("content-security-policy", ""):
                faltan.append(f"{ruta}: X-Frame-Options/CSP frame-ancestors")
            if "referrer-policy" not in h:
                faltan.append(f"{ruta}: Referrer-Policy")
            if https and "strict-transport-security" not in h:
                faltan.append(f"{ruta}: Strict-Transport-Security")
            if token and "no-store" not in h.get("cache-control", ""):
                faltan.append(f"{ruta}: Cache-Control no-store en respuesta autenticada")
        assert not faltan, "; ".join(faltan)
    v("S-01", "Cabeceras de seguridad en respuestas públicas, autenticadas y de error", cabeceras)

    def servidor():
        h = api.get("/health").headers
        for clave in ("Server", "X-Powered-By"):
            valor = h.get(clave, "")
            assert not any(c.isdigit() for c in valor), f"{clave}: {valor} revela versión"
    v("S-02", "Las cabeceras no revelan versiones de servidor o framework", servidor)

    def docs_y_demo():
        rutas = ["/docs", "/redoc", "/openapi.json", "/api/v1/partner-demo/", "/api/v1/partner/dev/patients"]
        abiertas = [f"{r} → {c}" for r in rutas if (c := api.get(r).status_code) not in (401, 403, 404, 405)]
        if cfg.es_produccion or cfg.get("WELLQ_ESPERA_DOCS_OCULTAS", "").lower() in ("si", "sí", "true"):
            assert not abiertas, "en producción deben responder 404: " + "; ".join(abiertas)
        elif abiertas:
            print(f"    (informativo, entorno {cfg['WELLQ_ENTORNO']}: accesibles {abiertas})")
    v("S-03", "Documentación interactiva, demo y herramientas de desarrollo cerradas en producción", docs_y_demo)

    def cors():
        r = api.peticion("OPTIONS", "/partner/links", headers={
            "Origin": "https://atacante.example", "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "authorization"})
        origen = r.headers.get("Access-Control-Allow-Origin", "")
        assert origen not in ("*", "https://atacante.example"), f"CORS permite {origen}"
        r = api.get("/partner/links", tok, headers={"Origin": "https://atacante.example"})
        assert r.headers.get("Access-Control-Allow-Origin", "") not in ("*", "https://atacante.example")
    v("S-04", "CORS no autoriza orígenes arbitrarios", cors)

    def metodos():
        for metodo in ("TRACE", "PUT"):
            r = api.peticion(metodo, "/partner/links", tok)
            assert r.status_code in (404, 405), f"{metodo} → {r.status_code}"
    v("S-05", "Métodos no definidos (TRACE, PUT) → 405/404", metodos)

    def errores():
        r = api.post(f"/partner/links/{link}/daily-summaries", tok, data=b"{no es json",
                     headers={"Content-Type": "application/json"})
        assert r.status_code in (400, 422), f"JSON roto → {r.status_code}"
        for marca in ("Traceback", "File \"/", "pymongo", "motor", "site-packages", "ValueError("):
            assert marca not in r.text, f"el error filtra '{marca}'"
        assert "problem+json" in r.headers.get("Content-Type", ""), r.headers.get("Content-Type")
    v("S-06", "JSON malformado → 400/422 problem+json sin trazas internas", errores)

    def ssrf():
        aceptadas = []
        for url in URLS_SSRF:
            r = api.post(f"/partner/apps/{app}/webhooks", tok, json={"url": url, "events": ["ping"]})
            if r.status_code in (200, 201):
                aceptadas.append(url)
                api.delete(f"/partner/apps/{app}/webhooks/{r.json().get('webhook_id')}", tok)
        assert not aceptadas, "webhooks aceptados hacia: " + ", ".join(aceptadas)
    v("S-07", f"SSRF: {len(URLS_SSRF)} URLs internas, no HTTPS o con credenciales se rechazan", ssrf)

    def inyeccion():
        fallos = []
        r = api.get("/partner/links/%7B%22%24ne%22%3Anull%7D", tok)
        if r.status_code not in (404, 422):
            fallos.append(f"link_id con operador → {r.status_code}")
        r = api.get("/partner/links", tok, params={"status": '{"$ne": null}'})
        if r.status_code not in (400, 422):
            fallos.append(f"status con operador → {r.status_code}")
        for cuerpo in ({"summaries": [{"record_id": {"$gt": ""}, "local_date": "2026-10-01", "tz_offset_minutes": 0,
                                       "device_id": sandbox.DISPOSITIVO}]},
                       {"summaries": [{"record_id": "x", "local_date": "2026-10-01", "tz_offset_minutes": 0,
                                       "device_id": {"$ne": None}}]},
                       {"summaries": [], "$where": "sleep(1000)"}):
            r = api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo)
            ok = r.status_code in (400, 422) or (r.status_code == 200 and r.json().get("accepted", 0) == 0)
            if not ok:
                fallos.append(f"{json.dumps(cuerpo)[:80]} → {r.status_code} {r.text[:100]}")
        r = api.post("/partner/links", tok, json={"pairing_code": {"$ne": None}, "external_user_id": "qa"})
        if r.status_code not in (400, 404, 422):
            fallos.append(f"pairing_code con operador → {r.status_code}")
        assert not fallos, "; ".join(fallos)
    v("S-08", "Inyección de operadores de Mongo en ruta, query y cuerpo se rechaza", inyeccion)

    def tamanos():
        fallos = []
        grande = b'{"summaries":[],"relleno":"' + b"a" * (1_100_000) + b'"}'
        r = api.post(f"/partner/links/{link}/daily-summaries", tok, data=grande,
                     headers={"Content-Type": "application/json"})
        if r.status_code != 413:
            fallos.append(f"cuerpo de 1,1 MB → {r.status_code}")
        lote = {"summaries": [{"record_id": f"qa-lote-{i}", "local_date": "2026-10-01", "tz_offset_minutes": 0,
                               "device_id": sandbox.DISPOSITIVO} for i in range(101)]}
        r = api.post(f"/partner/links/{link}/daily-summaries", tok, json=lote)
        if r.status_code not in (413, 422):
            fallos.append(f"lote de 101 resúmenes → {r.status_code}")
        bomba = gzip.compress(b'{"series":[' + b" " * 30_000_000 + b"]}", compresslevel=9)
        r = api.post(f"/partner/links/{link}/samples", tok, data=bomba,
                     headers={"Content-Type": "application/json", "Content-Encoding": "gzip"})
        if r.status_code not in (400, 413, 422):
            fallos.append(f"gzip bomb ({len(bomba) // 1024} KB → 30 MB) → {r.status_code}")
        assert not fallos, "; ".join(fallos)
    v("S-09", "Límites de tamaño: cuerpo > 1 MB, lote > 100 y gzip bomb → 413", tamanos)

    def datos_salida():
        r = api.get(f"/partner/links/{link}", tok)
        texto = r.text
        for marca in ("patient_id", "\"_id\"", "mongo_uri", "client_secret", "password"):
            assert marca not in texto, f"la respuesta incluye {marca}"
    v("S-10", "Las respuestas no exponen identificadores internos ni secretos", datos_salida)

    if "--sin-rate-limit" in sys.argv:
        informe.omitir("S-11", "Límite de tasa público en /oauth/token", "--sin-rate-limit")
    else:
        def rate_limit():
            for i in range(80):
                r = api.post("/partner/oauth/token", data={"grant_type": "client_credentials",
                                                           "client_id": f"cli_rl_{uuid.uuid4().hex[:6]}",
                                                           "client_secret": "x"})
                if r.status_code == 429:
                    assert r.headers.get("Retry-After"), "429 sin Retry-After"
                    assert "problem+json" in r.headers.get("Content-Type", ""), "429 sin problem+json"
                    print(f"    429 tras {i + 1} peticiones; Retry-After={r.headers.get('Retry-After')}")
                    return
            raise AssertionError("80 peticiones seguidas a /oauth/token sin recibir 429 (límite fijo: 60/min por IP)")
        v("S-11", "Límite de tasa público en /oauth/token → 429 con Retry-After", rate_limit)

    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
