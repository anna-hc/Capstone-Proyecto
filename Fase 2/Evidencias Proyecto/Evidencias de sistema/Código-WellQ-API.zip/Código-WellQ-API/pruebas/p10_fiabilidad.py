"""Pruebas de fiabilidad contra una API en marcha.

Idempotencia (Idempotency-Key y record_id), concurrencia sobre la misma clave, reanudación con sync-state,
procesamiento asíncrono de samples con y sin cron, trabajos de cron (protección y ejecución), revocación con
borrado reintentable, respuesta a 429 con Retry-After y disponibilidad sostenida de /health.

    python pruebas/p10_fiabilidad.py
    FIAB_MINUTOS_DISPONIBILIDAD=10 python pruebas/p10_fiabilidad.py
"""
from __future__ import annotations

import datetime as dt
import statistics
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

import sandbox
from comun import ClienteAPI, Informe, cargar_config, esperar_estado, exigir_api, exigir_no_produccion

TRABAJOS_CRON = ["deliver-webhooks", "sweep-ingest", "run-deletions", "detect-goals", "detect-gaps", "ensure-indexes"]


def main() -> int:
    cfg = cargar_config()
    informe = Informe("10_fiabilidad", "Pruebas de fiabilidad")
    exigir_no_produccion(cfg, "La prueba de fiabilidad")
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    v = informe.verificar
    estado = v("R-00", "Preparar fabricante de pruebas", lambda: sandbox.preparar(cfg, api))
    if not estado:
        return informe.cerrar()
    tok, link = estado["access_token"], estado["link_id"]
    sufijo = uuid.uuid4().hex[:8]
    fecha = (dt.date.today() - dt.timedelta(days=2)).isoformat()

    # La API identifica un resumen diario por dispositivo + día (record_key ds:<device>:<fecha>), no por record_id.
    # R-03 necesita un día que no exista todavía en el vínculo (que se reutiliza entre ejecuciones): uno propio.
    fecha_r03 = (dt.date.today() - dt.timedelta(days=30 + int(sufijo, 16) % 3650)).isoformat()

    def lote(rid: str, pasos: int = 1000, dia: str = "") -> dict:
        return {"summaries": [{"record_id": rid, "local_date": dia or fecha, "tz_offset_minutes": 0,
                               "device_id": sandbox.DISPOSITIVO, "steps": pasos}]}

    def idempotency_key():
        clave = str(uuid.uuid4())
        r1 = api.post(f"/partner/links/{link}/daily-summaries", tok, json=lote(f"qa-r-{sufijo}-1"),
                      headers={"Idempotency-Key": clave})
        r2 = api.post(f"/partner/links/{link}/daily-summaries", tok, json=lote(f"qa-r-{sufijo}-1"),
                      headers={"Idempotency-Key": clave})
        assert r1.status_code == r2.status_code == 200, f"{r1.status_code}/{r2.status_code}"
        assert r1.json() == r2.json(), f"la repetición no devolvió la respuesta original: {r1.json()} vs {r2.json()}"
        r3 = api.post(f"/partner/links/{link}/daily-summaries", tok, json=lote(f"qa-r-{sufijo}-otro"),
                      headers={"Idempotency-Key": clave})
        assert r3.status_code in (409, 422), f"misma clave con otro cuerpo → {r3.status_code} (se esperaba 409/422)"
    v("R-01", "Idempotency-Key: repetir devuelve la respuesta original; reutilizarla con otro cuerpo → 409/422",
      idempotency_key)

    def concurrencia():
        clave = str(uuid.uuid4())
        cuerpo = lote(f"qa-r-{sufijo}-conc", 4242)
        with ThreadPoolExecutor(max_workers=20) as pool:
            respuestas = list(pool.map(lambda _: api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo,
                                                          headers={"Idempotency-Key": clave}), range(20)))
        codigos = [r.status_code for r in respuestas]
        assert all(c in (200, 409) for c in codigos), f"códigos inesperados: {sorted(set(codigos))}"
        # Las repeticiones devuelven la respuesta original (o 409 si la primera aún está en curso): todas iguales.
        cuerpos = {r.text for r in respuestas if r.status_code == 200}
        assert len(cuerpos) == 1, f"{len(cuerpos)} respuestas 200 distintas para la misma clave"
        # Y el registro existe una sola vez: reenviarlo sin clave ya no lo crea.
        r = esperar_estado(api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo), 200)
        assert r["results"][0]["status"] in ("updated", "duplicate"), f"el registro se creó de nuevo: {r}"
    v("R-02", "20 envíos simultáneos con la misma clave producen un solo efecto", concurrencia)

    def concurrencia_record():
        cuerpo = lote(f"qa-r-{sufijo}-rec", 1111, fecha_r03)
        with ThreadPoolExecutor(max_workers=20) as pool:
            respuestas = list(pool.map(lambda _: api.post(f"/partner/links/{link}/daily-summaries", tok, json=cuerpo),
                                       range(20)))
        estados = [r.json()["results"][0]["status"] for r in respuestas if r.status_code == 200]
        assert estados.count("created") == 1, f"'created' {estados.count('created')} veces: {estados}"
        assert all(r.status_code in (200, 409) for r in respuestas), [r.status_code for r in respuestas]
    v("R-03", "20 envíos simultáneos del mismo record_id sin clave: un solo 'created'", concurrencia_record)

    def reanudacion():
        antes = esperar_estado(api.get(f"/partner/links/{link}/sync-state", tok), 200)
        esperar_estado(api.post(f"/partner/links/{link}/device-events", tok, json={"events": [{
            "record_id": f"qa-r-{sufijo}-ev", "device_id": sandbox.DISPOSITIVO,
            "timestamp": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "event_type": "sync_completed"}]}), 200)
        despues = esperar_estado(api.get(f"/partner/links/{link}/sync-state", tok), 200)
        assert despues.get("last_received") and despues != antes, "sync-state no cambió tras recibir datos"
    v("R-04", "sync-state se actualiza tras cada envío (permite reanudar sin duplicar)", reanudacion)

    def job_asincrono():
        # El modelo de pruebas declara typical_interval_seconds=60: muestras cada 60 s (400 puntos ≈ 6,7 h).
        serie = {"metric": "heart_rate", "unit": "bpm", "device_id": sandbox.DISPOSITIVO,
                 "start": (dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=8)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                 "offsets_ms": [i * 60000 for i in range(400)], "values": [60.0] * 400}
        r = esperar_estado(api.post(f"/partner/links/{link}/samples", tok, json={"series": [serie]}), 202)
        limite, job = time.time() + 90, {}
        while time.time() < limite:
            job = esperar_estado(api.get(f"/partner/ingest/jobs/{r['job_id']}", tok), 200)
            if job.get("status") in ("completed", "failed", "partially_completed"):
                break
            if cfg["WELLQ_CRON_SECRET"]:
                api.get("/internal/cron/sweep-ingest", cfg["WELLQ_CRON_SECRET"])
            time.sleep(3)
        assert job.get("status") == "completed", f"el job no terminó en 90 s: {job.get('status')}"
    v("R-05", "Un envío de samples se procesa (en la misma petición o por cron) en menos de 90 s", job_asincrono)

    if cfg["WELLQ_CRON_SECRET"]:
        def cron():
            fallos = []
            for trabajo in TRABAJOS_CRON:
                r1 = api.get(f"/internal/cron/{trabajo}", cfg["WELLQ_CRON_SECRET"])
                r2 = api.get(f"/internal/cron/{trabajo}", cfg["WELLQ_CRON_SECRET"])  # dos seguidas: sin efectos dobles
                if r1.status_code != 200 or r2.status_code != 200:
                    fallos.append(f"{trabajo} → {r1.status_code}/{r2.status_code}")
            assert not fallos, "; ".join(fallos)
        v("R-06", f"Los {len(TRABAJOS_CRON)} trabajos de cron responden 200 y toleran ejecuciones repetidas", cron)
    else:
        informe.omitir("R-06", "Trabajos de cron", "define WELLQ_CRON_SECRET para ejecutarlos")

    def retry_after():
        espera = None
        for _ in range(80):
            r = api.post("/partner/oauth/token", data={"grant_type": "client_credentials",
                                                       "client_id": "cli_fiab", "client_secret": "x"})
            if r.status_code == 429:
                espera = int(r.headers.get("Retry-After", "0"))
                break
        assert espera is not None, "no se alcanzó el 429"
        assert 0 < espera <= 120, f"Retry-After={espera}"
        time.sleep(espera + 1)
        r = api.post("/partner/oauth/token", data={"grant_type": "client_credentials",
                                                   "client_id": "cli_fiab", "client_secret": "x"})
        assert r.status_code != 429, "tras esperar Retry-After sigue en 429"
    if "--sin-rate-limit" in sys.argv:
        informe.omitir("R-07", "Recuperación tras 429", "--sin-rate-limit")
    else:
        v("R-07", "Tras un 429, esperar Retry-After basta para volver a ser atendido", retry_after)

    def disponibilidad():
        minutos = float(cfg["FIAB_MINUTOS_DISPONIBILIDAD"] or 2)
        fin, tiempos, errores = time.time() + minutos * 60, [], 0
        while time.time() < fin:
            t0 = time.time()
            try:
                r = api.get("/health")
                errores += r.status_code != 200
            except Exception:  # noqa: BLE001 - un corte de red cuenta como no disponible
                errores += 1
            tiempos.append((time.time() - t0) * 1000)
            time.sleep(2)
        disp = 100 * (1 - errores / max(len(tiempos), 1))
        print(f"    {len(tiempos)} sondeos en {minutos} min · disponibilidad {disp:.2f} % · "
              f"mediana {statistics.median(tiempos):.0f} ms · máx {max(tiempos):.0f} ms")
        assert disp >= 99.5, f"disponibilidad {disp:.2f} % < 99,5 %"
    v("R-08", "Disponibilidad sostenida de /health (sondeo cada 2 s)", disponibilidad)

    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
