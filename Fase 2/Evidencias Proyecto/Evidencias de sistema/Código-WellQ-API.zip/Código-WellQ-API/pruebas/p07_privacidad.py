"""Pruebas de privacidad (minimización de datos y seudonimización, UK GDPR) contra una API en marcha.

1. Comprueba en vivo que las rutas del fabricante solo devuelven los campos previstos y que el consentimiento
   queda registrado en el vínculo.
2. Revisa TODAS las respuestas registradas en esta ejecución (http_log.jsonl de las demás suites) buscando
   identificadores internos, correos, teléfonos o campos clínicos en rutas /partner.

Conviene ejecutarlo después de p04-p06 con el mismo WELLQ_RUN_ID (run_all.py ya lo hace).

    python pruebas/p07_privacidad.py
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
import uuid
from pathlib import Path

import sandbox
from comun import ClienteAPI, Informe, RAIZ_REPO, cargar_config, esperar_estado, exigir_api, run_id

CLAVES_PROHIBIDAS = {
    "patient_id", "patientid", "wellq_patient_id", "user_id", "email", "correo", "first_name", "last_name",
    "full_name", "nombre", "apellidos", "phone", "telefono", "dob", "date_of_birth", "fecha_nacimiento",
    "nhs_number", "address", "direccion", "diagnosis", "diagnostico", "diagnoses", "checkins", "pain",
    "dolor", "clinical_notes", "notes", "notas", "tenant_db", "mongo_uri", "_id",
}
PATRONES = {
    "correo": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    "ObjectId de Mongo": re.compile(r"(?<![\w-])[0-9a-f]{24}(?![\w-])"),
    # Los números de teléfono y NHS deben ir separados de letras: así no se confunden con trazas o ids hex.
    "teléfono": re.compile(r"(?<![\w-])\+?\d[\d\s-]{9,}\d(?![\w-])"),
    "NHS number": re.compile(r"(?<![\w-])\d{3}\s?\d{3}\s?\d{4}(?![\w-])"),
}
# D-03: metric_goals y data_status están documentados en el contrato OpenAPI (GET /goals y GET /scores) y no
# contienen diagnóstico, notas ni datos identificativos, así que forman parte de la lista permitida
CAMPOS_GOALS = {"link_id", "health_goals", "metric_goals", "prescribed_exercises", "updated_at"}
CAMPOS_METRIC_GOAL = {"metric_type", "target_exercises_per_week"}
CAMPOS_EJERCICIO = {"wellq_exercise_code", "name", "target_sessions_per_week", "target_sets", "target_reps",
                    "body_region"}
CAMPOS_SCORES_DIA = {"local_date", "activity", "sleep", "adherence", "stability", "data_status"}
RUTAS_CON_CORREO_PERMITIDO = ("/partner/developers/",)


def claves(obj, prefijo=""):
    if isinstance(obj, dict):
        for k, val in obj.items():
            yield f"{prefijo}{k}", k.lower()
            yield from claves(val, f"{prefijo}{k}.")
    elif isinstance(obj, list):
        for val in obj:
            yield from claves(val, prefijo + "[].")


def revisar_respuesta(url: str, cuerpo) -> list[str]:
    problemas = []
    if "/partner/" not in url or any(r in url for r in RUTAS_CON_CORREO_PERMITIDO):
        return problemas
    for ruta, clave in claves(cuerpo):
        if clave in CLAVES_PROHIBIDAS:
            problemas.append(f"campo '{ruta}'")
    for texto in cadenas(cuerpo):
        if ISO_FECHA.match(texto):
            continue  # fechas y marcas de tiempo
        for nombre, patron in PATRONES.items():
            for m in patron.finditer(texto):
                valor = m.group(0)
                if nombre == "correo" and valor.endswith(("@example.com", "@wellq.co.uk")):
                    continue
                problemas.append(f"{nombre}: {valor[:40]}")
    return problemas


ISO_FECHA = re.compile(r"^\d{4}-\d{2}-\d{2}([T ][\d:.]+(Z|[+-]\d{2}:?\d{2})?)?$")


def cadenas(obj):
    """Solo se buscan patrones dentro de valores de texto (los números de las series no cuentan)."""
    if isinstance(obj, dict):
        for val in obj.values():
            yield from cadenas(val)
    elif isinstance(obj, list):
        for val in obj:
            yield from cadenas(val)
    elif isinstance(obj, str):
        yield obj


def logs_de_la_ejecucion() -> list[Path]:
    carpeta = RAIZ_REPO / "evidencia" / "pruebas" / run_id()
    return sorted(carpeta.glob("*/http_log.jsonl"))


def main() -> int:
    cfg = cargar_config()
    informe = Informe("07_privacidad", "Pruebas de privacidad y minimización de datos")
    exigir_api(cfg, informe)
    api = ClienteAPI(cfg, informe.carpeta)
    v = informe.verificar
    estado = v("P-00", "Preparar fabricante de pruebas", lambda: sandbox.preparar(cfg, api))
    if not estado:
        return informe.cerrar()
    tok, link = estado["access_token"], estado["link_id"]

    def consentimiento():
        datos = esperar_estado(api.get(f"/partner/links/{link}", tok), 200)
        consent = datos.get("consent") or {}
        assert consent.get("doc_version") and consent.get("granted_at"), f"consentimiento no registrado: {consent}"
        assert datos.get("granted_scopes"), "el vínculo no indica los scopes concedidos"
    v("P-01", "El vínculo registra versión del documento de consentimiento, fecha y scopes", consentimiento)

    def goals():
        datos = esperar_estado(api.get(f"/partner/links/{link}/goals", tok), 200)
        extra = set(datos) - CAMPOS_GOALS
        assert not extra, f"goals devuelve campos no previstos: {extra}"
        for ej in datos.get("prescribed_exercises", []):
            assert not set(ej) - CAMPOS_EJERCICIO, f"ejercicio con campos no previstos: {set(ej) - CAMPOS_EJERCICIO}"
        for meta in datos.get("metric_goals", []):
            assert not set(meta) - CAMPOS_METRIC_GOAL, f"objetivo con campos no previstos: {set(meta) - CAMPOS_METRIC_GOAL}"
    v("P-02", "goals solo devuelve objetivos y ejercicios (sin diagnóstico ni notas)", goals)

    def scores():
        hoy = dt.date.today()
        datos = esperar_estado(api.get(f"/partner/links/{link}/scores", tok, params={
            "from_date": (hoy - dt.timedelta(days=30)).isoformat(), "to_date": hoy.isoformat()}), 200)
        assert not set(datos) - {"link_id", "days"}, f"campos no previstos: {set(datos) - {'link_id', 'days'}}"
        for dia in datos.get("days", []):
            assert not set(dia) - CAMPOS_SCORES_DIA, f"día con campos no previstos: {set(dia) - CAMPOS_SCORES_DIA}"
    v("P-03", "scores solo devuelve las cuatro puntuaciones por día", scores)

    def seudonimo():
        r = api.post("/partner/sandbox/patients", tok, json={"scopes": ["ingest:activity"]})
        codigo = esperar_estado(r, 201)["pairing_code"]
        r = api.post("/partner/links", tok, json={"pairing_code": codigo, "external_user_id": "juan.perez@gmail.com",
                                                  "device_id": sandbox.DISPOSITIVO, "model_code": sandbox.MODELO})
        if r.status_code in (200, 201):
            api.delete(f"/partner/links/{r.json()['link_id']}", tok)
        assert r.status_code in (400, 422), (f"se aceptó un correo como external_user_id ({r.status_code}); "
                                             "el contrato exige que sea seudónimo")
    v("P-04", "external_user_id con forma de correo se rechaza (debe ser seudónimo)", seudonimo)

    def sandbox_sin_pii():
        r = api.post("/partner/sandbox/patients", tok, json={"profile": "generic"})
        datos = esperar_estado(r, 201)
        problemas = revisar_respuesta("/partner/sandbox/patients", datos)
        assert not problemas, "; ".join(problemas)
    v("P-05", "El paciente sintético del sandbox no devuelve datos identificativos", sandbox_sin_pii)

    def eco_errores():
        sensible = f"Maria Lopez {uuid.uuid4().hex[:4]}"
        r = api.post(f"/partner/links/{link}/daily-summaries", tok, json={"summaries": [{
            "record_id": "x", "local_date": sensible, "tz_offset_minutes": 0, "device_id": sandbox.DISPOSITIVO}]})
        assert sensible not in r.text or r.status_code == 200 and "rejected" in r.text, \
            "el mensaje de error repite el valor enviado (evita ecos de datos personales en errores y logs)"
    v("P-06", "Los errores de validación no repiten el valor recibido", eco_errores)

    def revisar_logs():
        archivos = logs_de_la_ejecucion()
        total, problemas = 0, []
        for archivo in archivos:
            for linea in archivo.read_text(encoding="utf-8").splitlines():
                entrada = json.loads(linea)
                total += 1
                for p in revisar_respuesta(entrada["url"], entrada.get("respuesta")):
                    problemas.append(f"{archivo.parent.name} {entrada['metodo']} {entrada['url'].split('/api/v1')[-1]}: {p}")
        print(f"    {total} respuestas revisadas en {len(archivos)} suites")
        assert total, "no hay respuestas registradas en esta ejecución"
        únicos = sorted(set(problemas))
        assert not únicos, f"{len(únicos)} posibles fugas: " + " | ".join(únicos[:15])
    v("P-07", "Ninguna respuesta /partner de esta ejecución contiene datos identificativos o clínicos", revisar_logs)

    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
