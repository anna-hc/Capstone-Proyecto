"""Análisis estático de seguridad del código (bandit) y búsqueda de secretos en el repositorio.

- bandit sobre data/app (sin los tests). Falla con hallazgos de severidad y confianza >= BANDIT_NIVEL (MEDIUM).
- Secretos: .env no versionado y ningún archivo versionado con URIs de Mongo/Redis con contraseña,
  claves privadas o tokens con pinta de reales.

    python pruebas/p03_bandit_secretos.py
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys

from comun import DIR_PRUEBAS, RAIZ_REPO, Informe, cargar_config, ejecutar, herramienta, modulo_disponible

NIVELES = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}

PATRONES_SECRETO = {
    # Las plantillas con variables ({_esc_pass}, ${PASS}, %s) no cuentan: solo valores escritos tal cual.
    "URI de Mongo con contraseña": re.compile(r"mongodb(\+srv)?://[^\s:/@{}$%]+:[^\s@/{}$%]{3,}@", re.I),
    "URI de Redis con contraseña": re.compile(r"rediss?://[^\s:/@{}$%]*:[^\s@/{}$%]{6,}@", re.I),
    "Clave privada": re.compile(r"-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----"),
    "Clave Fernet o secreto asignado": re.compile(
        r"(PARTNER_TOKEN_SECRET|PARTNER_ENCRYPTION_KEY|JWT_SECRET|CRON_SECRET|SMTP_PASSWORD)[ \t]*[=:][ \t]*['\"]?"
        r"(?!<|\$|change|cambia|xxx|your|tu_|example|dummy|test)[A-Za-z0-9_\-+/=]{16,}", re.I),
    "Token de GitHub/AWS/Slack": re.compile(r"(ghp_[A-Za-z0-9]{30,}|AKIA[0-9A-Z]{16}|xox[bpa]-[A-Za-z0-9-]{10,})"),
}
EXTENSIONES_BINARIAS = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf", ".docx", ".xlsx", ".zip", ".woff", ".woff2"}


def bandit(cfg, informe) -> None:
    carpeta = informe.carpeta
    if modulo_disponible("bandit"):
        base = [sys.executable, "-m", "bandit"]
    elif herramienta("bandit"):
        base = [herramienta("bandit")]
    else:
        informe.registrar("SAST-00", "bandit instalado", False, "pip install -r pruebas/requirements.txt")
        return
    objetivo = cfg.data_dir / "app"
    if not objetivo.exists():
        informe.registrar("SAST-00", f"Existe {objetivo}", False, "ajusta WELLQ_DATA_DIR")
        return
    salida = carpeta / "bandit.json"
    excluir = ",".join(str(p) for p in (cfg.data_dir / "tests", cfg.data_dir / ".venv") if p.exists())
    cmd = base + ["-r", str(objetivo), "-f", "json", "-o", str(salida), "-q"] + (["-x", excluir] if excluir else [])
    ejecutar(cmd, carpeta, "salida_bandit.txt")
    ejecutar(base + ["-r", str(objetivo), "-f", "txt", "-o", str(carpeta / "bandit.txt"), "-q"]
             + (["-x", excluir] if excluir else []), carpeta, "salida_bandit_txt.txt")
    if not salida.exists():
        informe.registrar("SAST-00", "bandit generó su informe", False, "revisa salida_bandit.txt")
        return
    datos = json.loads(salida.read_text(encoding="utf-8"))
    umbral = NIVELES.get(cfg.get("BANDIT_NIVEL", "MEDIUM").upper(), 2)
    graves = 0
    for r in datos.get("results", []):
        sev, conf = NIVELES[r["issue_severity"]], NIVELES[r["issue_confidence"]]
        ruta = os.path.relpath(r["filename"], RAIZ_REPO)
        desc = f"{r['test_id']} {r['issue_text']} ({ruta}:{r['line_number']})"
        if sev >= umbral and conf >= umbral:
            graves += 1
            informe.registrar("SAST", desc, False, f"severidad {r['issue_severity']}, confianza {r['issue_confidence']}")
        else:
            informe.omitir("SAST-INFO", desc, f"informativo: severidad {r['issue_severity']}, "
                                              f"confianza {r['issue_confidence']}")
    totales = datos.get("metrics", {}).get("_totals", {})
    informe.registrar("SAST-01", f"bandit: {int(totales.get('loc', 0))} líneas analizadas, "
                                 f"{graves} hallazgos >= {cfg.get('BANDIT_NIVEL', 'MEDIUM').upper()}",
                      graves == 0, f"{int(totales.get('nosec', 0))} líneas con # nosec (revísalas a mano)")


def archivos_versionados() -> list[str]:
    try:
        salida = subprocess.run(["git", "ls-files"], cwd=RAIZ_REPO, capture_output=True, text=True, check=True)
        return [linea for linea in salida.stdout.splitlines() if linea]
    except (OSError, subprocess.CalledProcessError):
        archivos = []
        for raiz, dirs, nombres in os.walk(RAIZ_REPO):
            dirs[:] = [d for d in dirs if d not in {".git", ".venv", "venv", "node_modules", "evidencia", "__pycache__"}]
            archivos += [os.path.relpath(os.path.join(raiz, n), RAIZ_REPO) for n in nombres]
        return archivos


def secretos_aceptados() -> dict[str, str]:
    """Coincidencias revisadas y aceptadas (valores de ejemplo, no secretos reales): pruebas/secretos_aceptados.txt."""
    ruta = DIR_PRUEBAS / "secretos_aceptados.txt"
    res: dict[str, str] = {}
    if ruta.exists():
        for linea in ruta.read_text(encoding="utf-8").splitlines():
            linea = linea.strip()
            if linea and not linea.startswith("#"):
                clave, _, motivo = linea.partition(" ")
                res[clave] = motivo.strip() or "aceptado sin justificación"
    return res


def secretos(informe) -> None:
    archivos = archivos_versionados()
    envs = [a for a in archivos if os.path.basename(a) == ".env" or os.path.basename(a).startswith(".env.")
            and not a.endswith((".example", ".sample", ".template"))]
    informe.registrar("SEC-01", "Ningún archivo .env real está en el repositorio", not envs, ", ".join(envs))
    hallazgos = []
    aceptados = secretos_aceptados()
    for rel in archivos:
        ruta = RAIZ_REPO / rel
        if ruta.suffix.lower() in EXTENSIONES_BINARIAS or not ruta.is_file() or ruta.stat().st_size > 2_000_000:
            continue
        if rel.startswith(("evidencia/", "evidencia\\")) or "estado_sandbox" in rel:
            continue
        try:
            texto = ruta.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for nombre, patron in PATRONES_SECRETO.items():
            for m in patron.finditer(texto):
                if "localhost" in m.group(0) or "127.0.0.1" in m.group(0):
                    continue
                linea = texto.count("\n", 0, m.start()) + 1
                clave = f"{rel.replace(os.sep, '/')}:{linea}"
                if clave in aceptados:
                    informe.omitir("SEC-ACEP", f"{clave} {nombre}", aceptados[clave])
                    continue
                hallazgos.append(f"{rel}:{linea} {nombre}")
    for h in hallazgos[:50]:
        informe.registrar("SEC", f"Posible secreto: {h}", False, "revisa y, si es real, rótalo y bórralo del historial")
    informe.registrar("SEC-02", f"Búsqueda de secretos en {len(archivos)} archivos", not hallazgos,
                      f"{len(hallazgos)} coincidencias" if hallazgos else "")


def main() -> int:
    cfg = cargar_config()
    informe = Informe("03_bandit_secretos", "Análisis estático de seguridad (bandit) y secretos")
    bandit(cfg, informe)
    secretos(informe)
    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
