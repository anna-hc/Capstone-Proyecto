"""Utilidades compartidas por los scripts de pruebas de la WellQ Partner API.

- Lee la configuración de pruebas/config.env (las variables de entorno la sobrescriben).
- Crea la carpeta de evidencias de la ejecución: evidencia/pruebas/<RUN_ID>/<suite>/.
- Registra cada caso (OK / FALLO / OMITIDO) y escribe resultado.json y resultado.md.
- Cliente HTTP que guarda cada petición y respuesta en http_log.jsonl con los secretos enmascarados.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DIR_PRUEBAS = Path(__file__).resolve().parent
RAIZ_REPO = DIR_PRUEBAS.parent
PREFIJO_API = "/api/v1"

OK, FALLO, OMITIDO = "OK", "FALLO", "OMITIDO"

# ───────────────────────────── configuración ─────────────────────────────

VALORES_POR_DEFECTO = {
    "WELLQ_BASE_URL": "http://127.0.0.1:8000",
    "WELLQ_ENTORNO": "local",  # local | sandbox | produccion
    "WELLQ_DATA_DIR": "data",
    "WELLQ_OPENAPI": "",
    "WELLQ_CRON_SECRET": "",
    "WELLQ_VERIFY_CODE": "",
    "WELLQ_PORTAL_TOKEN": "",
    "WELLQ_CLIENT_ID": "",
    "WELLQ_CLIENT_SECRET": "",
    "WELLQ_APP_ID": "",
    "WELLQ_PATIENT_JWT": "",
    "WELLQ_PATIENT_JWT_OTRO": "",
    "WELLQ_CLINICIAN_JWT": "",
    "WELLQ_TENANT": "",
    "WELLQ_PATIENT_ID": "",
    "WELLQ_WEBHOOK_URL": "",
    "WELLQ_PERMITIR_PRODUCCION": "no",
    "WELLQ_TIMEOUT": "30",
    "K6_PERFIL": "humo",
    "K6_VUS": "",
    "K6_DURACION": "",
    "ZAP_IMAGEN": "ghcr.io/zaproxy/zaproxy:stable",
    "FIAB_MINUTOS_DISPONIBILIDAD": "2",
}


def _leer_env(ruta: Path) -> dict[str, str]:
    valores: dict[str, str] = {}
    if not ruta.exists():
        return valores
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if not linea or linea.startswith("#") or "=" not in linea:
            continue
        clave, valor = linea.split("=", 1)
        valor = valor.strip()
        if len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in "\"'":
            valor = valor[1:-1]
        valores[clave.strip()] = valor
    return valores


class Config(dict):
    def __getattr__(self, nombre: str) -> str:
        try:
            return self[nombre]
        except KeyError as exc:
            raise AttributeError(nombre) from exc

    @property
    def api(self) -> str:
        return self["WELLQ_BASE_URL"].rstrip("/") + PREFIJO_API

    @property
    def data_dir(self) -> Path:
        ruta = Path(self["WELLQ_DATA_DIR"])
        return ruta if ruta.is_absolute() else RAIZ_REPO / ruta

    @property
    def openapi(self) -> Path:
        if self["WELLQ_OPENAPI"]:
            ruta = Path(self["WELLQ_OPENAPI"])
            return ruta if ruta.is_absolute() else RAIZ_REPO / ruta
        for candidato in (
            RAIZ_REPO / "documentacion" / "wellq-partner-api-openapi.yaml",
            RAIZ_REPO / "wellq-partner-api-openapi.yaml",
            DIR_PRUEBAS / "wellq-partner-api-openapi.yaml",
        ):
            if candidato.exists():
                return candidato
        return RAIZ_REPO / "documentacion" / "wellq-partner-api-openapi.yaml"

    @property
    def es_produccion(self) -> bool:
        return self["WELLQ_ENTORNO"].lower() in ("produccion", "producción", "production", "prod")

    @property
    def timeout(self) -> float:
        return float(self["WELLQ_TIMEOUT"] or 30)


def cargar_config() -> Config:
    cfg = Config(VALORES_POR_DEFECTO)
    cfg.update(_leer_env(DIR_PRUEBAS / "config.env"))
    for clave in list(cfg) + [k for k in os.environ if k.startswith(("WELLQ_", "K6_", "ZAP_", "FIAB_"))]:
        if clave in os.environ:
            cfg[clave] = os.environ[clave]
    return cfg


def exigir_no_produccion(cfg: Config, que: str) -> None:
    """Las pruebas que generan carga o datos no se lanzan contra producción sin permiso explícito."""
    if cfg.es_produccion and cfg["WELLQ_PERMITIR_PRODUCCION"].lower() not in ("si", "sí", "yes", "true", "1"):
        print(f"[ABORTADO] {que} no se ejecuta contra producción. "
              "Usa el sandbox o pon WELLQ_PERMITIR_PRODUCCION=si si tienes autorización por escrito.")
        sys.exit(3)


# ───────────────────────────── evidencias ─────────────────────────────

def run_id() -> str:
    if not os.environ.get("WELLQ_RUN_ID"):
        os.environ["WELLQ_RUN_ID"] = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    return os.environ["WELLQ_RUN_ID"]


def carpeta_evidencia(suite: str) -> Path:
    ruta = RAIZ_REPO / "evidencia" / "pruebas" / run_id() / suite
    ruta.mkdir(parents=True, exist_ok=True)
    return ruta


RUTA_ESTADO = DIR_PRUEBAS / ".estado" / "estado_sandbox.json"  # contiene secretos: en .gitignore


def cargar_estado() -> dict[str, Any]:
    if RUTA_ESTADO.exists():
        return json.loads(RUTA_ESTADO.read_text(encoding="utf-8"))
    return {}


def guardar_estado(estado: dict[str, Any]) -> None:
    RUTA_ESTADO.parent.mkdir(parents=True, exist_ok=True)
    RUTA_ESTADO.write_text(json.dumps(estado, indent=2, ensure_ascii=False), encoding="utf-8")


_CLAVES_SECRETAS = re.compile(
    r"(secret|token|password|passwd|authorization|pairing_code|verification|api[_-]?key|cookie)", re.I)


def enmascarar(valor: Any, clave: str = "") -> Any:
    if isinstance(valor, dict):
        return {k: enmascarar(v, k) for k, v in valor.items()}
    if isinstance(valor, list):
        return [enmascarar(v, clave) for v in valor]
    if isinstance(valor, str) and clave and _CLAVES_SECRETAS.search(clave):
        return valor[:4] + "…(oculto)" if len(valor) > 8 else "…(oculto)"
    return valor


@dataclass
class Caso:
    id: str
    descripcion: str
    estado: str
    detalle: str = ""
    duracion_ms: int = 0


@dataclass
class Informe:
    suite: str
    titulo: str
    casos: list[Caso] = field(default_factory=list)
    inicio: float = field(default_factory=time.time)

    @property
    def carpeta(self) -> Path:
        return carpeta_evidencia(self.suite)

    def registrar(self, id_: str, descripcion: str, ok: bool | None, detalle: str = "", t0: float | None = None) -> bool:
        estado = OMITIDO if ok is None else (OK if ok else FALLO)
        dur = int((time.time() - t0) * 1000) if t0 else 0
        self.casos.append(Caso(id_, descripcion, estado, str(detalle)[:2000], dur))
        icono = {OK: "✔", FALLO: "✘", OMITIDO: "–"}[estado]
        print(f"  {icono} [{estado:7}] {id_} {descripcion}" + (f" → {detalle}" if detalle and estado != OK else ""))
        return bool(ok)

    def omitir(self, id_: str, descripcion: str, motivo: str) -> None:
        self.registrar(id_, descripcion, None, motivo)

    def verificar(self, id_: str, descripcion: str, func) -> Any:
        """Ejecuta func(); si lanza AssertionError o excepción, el caso falla con el mensaje."""
        t0 = time.time()
        try:
            res = func()
        except AssertionError as exc:
            self.registrar(id_, descripcion, False, str(exc) or "aserción fallida", t0)
            return None
        except Exception as exc:  # noqa: BLE001 - se registra cualquier error como fallo del caso
            self.registrar(id_, descripcion, False, f"{type(exc).__name__}: {exc}", t0)
            return None
        self.registrar(id_, descripcion, True, "", t0)
        return res

    @property
    def fallos(self) -> int:
        return sum(c.estado == FALLO for c in self.casos)

    def cerrar(self, extra: dict[str, Any] | None = None) -> int:
        cuenta = {e: sum(c.estado == e for c in self.casos) for e in (OK, FALLO, OMITIDO)}
        datos = {
            "suite": self.suite,
            "titulo": self.titulo,
            "run_id": run_id(),
            "fecha": _dt.datetime.now().isoformat(timespec="seconds"),
            "duracion_s": round(time.time() - self.inicio, 1),
            "resumen": cuenta,
            "resultado": FALLO if cuenta[FALLO] else OK,
            "casos": [c.__dict__ for c in self.casos],
            **(extra or {}),
        }
        (self.carpeta / "resultado.json").write_text(json.dumps(datos, indent=2, ensure_ascii=False), encoding="utf-8")
        lineas = [f"# {self.titulo}", "", f"Ejecución `{run_id()}` · {datos['fecha']} · {datos['duracion_s']} s", "",
                  f"**Resultado: {datos['resultado']}** · {cuenta[OK]} OK · {cuenta[FALLO]} fallos · {cuenta[OMITIDO]} omitidos", "",
                  "| Caso | Descripción | Estado | Detalle |", "|---|---|---|---|"]
        for c in self.casos:
            detalle = c.detalle.replace("|", "\\|").replace("\n", " ")[:300]
            lineas.append(f"| {c.id} | {c.descripcion} | {c.estado} | {detalle} |")
        (self.carpeta / "resultado.md").write_text("\n".join(lineas) + "\n", encoding="utf-8")
        print(f"\n{self.titulo}: {datos['resultado']} ({cuenta[OK]} OK, {cuenta[FALLO]} fallos, {cuenta[OMITIDO]} omitidos)")
        print(f"Evidencias en {self.carpeta}")
        return 1 if cuenta[FALLO] else 0


# ───────────────────────────── cliente HTTP ─────────────────────────────

class ClienteAPI:
    """Cliente sobre requests que registra cada intercambio en http_log.jsonl."""

    def __init__(self, cfg: Config, carpeta: Path):
        import requests  # importación diferida: los scripts offline no lo necesitan

        self.cfg = cfg
        self.sesion = requests.Session()
        self.log = (carpeta / "http_log.jsonl").open("a", encoding="utf-8")
        self.respuestas: list[dict[str, Any]] = []

    def url(self, ruta: str) -> str:
        if ruta.startswith("http"):
            return ruta
        # "/api/..." o "/docs" van contra la raíz; el resto ("/partner/...", "/health") cuelga de /api/v1.
        if ruta.startswith("/api/") or ruta in ("/", "/docs", "/redoc", "/openapi.json"):
            return self.cfg["WELLQ_BASE_URL"].rstrip("/") + ruta
        return self.cfg.api + ruta

    def peticion(self, metodo: str, ruta: str, token: str | None = None, **kw):
        cabeceras = dict(kw.pop("headers", {}) or {})
        if token:
            cabeceras["Authorization"] = f"Bearer {token}"
        if self.cfg["WELLQ_TENANT"] and "x-tenant" not in {k.lower() for k in cabeceras}:
            cabeceras["x-tenant"] = self.cfg["WELLQ_TENANT"]
        kw.setdefault("timeout", self.cfg.timeout)
        kw.setdefault("allow_redirects", False)
        t0 = time.time()
        resp = self.sesion.request(metodo, self.url(ruta), headers=cabeceras, **kw)
        ms = int((time.time() - t0) * 1000)
        try:
            cuerpo = resp.json()
        except ValueError:
            cuerpo = resp.text[:2000]
        cuerpo_peticion = kw.get("json") if kw.get("json") is not None else kw.get("data")
        if isinstance(cuerpo_peticion, (bytes, bytearray)):
            cuerpo_peticion = f"<{len(cuerpo_peticion)} bytes>"
        entrada = {
            "t": _dt.datetime.now().isoformat(timespec="milliseconds"),
            "metodo": metodo, "url": resp.request.url, "estado": resp.status_code, "ms": ms,
            "cabeceras_peticion": enmascarar(cabeceras, ""),
            "peticion": enmascarar(cuerpo_peticion),
            "cabeceras_respuesta": dict(resp.headers),
            "respuesta": enmascarar(cuerpo),
        }
        for k in list(entrada["cabeceras_peticion"]):
            if _CLAVES_SECRETAS.search(k):
                entrada["cabeceras_peticion"][k] = "…(oculto)"
        self.log.write(json.dumps(entrada, ensure_ascii=False, default=str) + "\n")
        self.log.flush()
        self.respuestas.append({"url": entrada["url"], "estado": resp.status_code,
                                "cabeceras": dict(resp.headers), "cuerpo": cuerpo})
        return resp

    def get(self, ruta: str, token: str | None = None, **kw):
        return self.peticion("GET", ruta, token, **kw)

    def post(self, ruta: str, token: str | None = None, **kw):
        return self.peticion("POST", ruta, token, **kw)

    def delete(self, ruta: str, token: str | None = None, **kw):
        return self.peticion("DELETE", ruta, token, **kw)

    def patch(self, ruta: str, token: str | None = None, **kw):
        return self.peticion("PATCH", ruta, token, **kw)


def esperar_estado(resp, *esperados: int) -> Any:
    if resp.status_code not in esperados:
        raise AssertionError(f"HTTP {resp.status_code} (se esperaba {'/'.join(map(str, esperados))}) en "
                             f"{resp.request.method} {resp.request.path_url}: {resp.text[:300]}")
    try:
        return resp.json()
    except ValueError:
        return None


def problem_type(resp) -> str:
    try:
        return str(resp.json().get("type", ""))
    except (ValueError, AttributeError):
        return ""


def api_disponible(cfg: Config) -> tuple[bool, str]:
    import requests

    url = cfg.api + "/health"
    try:
        resp = requests.get(url, timeout=10)
    except requests.RequestException as exc:
        return False, f"No se pudo conectar a {url}: {exc}"
    if resp.status_code != 200:
        return False, f"{url} respondió {resp.status_code}"
    try:
        datos = resp.json()
    except ValueError:
        return False, f"{url} no devolvió JSON"
    if datos.get("partner_api") is False:
        return False, f"{url} dice partner_api=false (revisa PARTNER_TOKEN_SECRET y PARTNER_ENCRYPTION_KEY)"
    return True, url


def exigir_api(cfg: Config, informe: Informe) -> None:
    ok, detalle = api_disponible(cfg)
    if not ok:
        informe.registrar("PRE-01", "La API responde en /api/v1/health", False, detalle)
        sys.exit(informe.cerrar())
    informe.registrar("PRE-01", "La API responde en /api/v1/health", True)


# ───────────────────────────── procesos externos ─────────────────────────────

def ejecutar(cmd: list[str], carpeta: Path, nombre_log: str, cwd: Path | None = None,
             env: dict[str, str] | None = None, timeout: int | None = None) -> int:
    """Ejecuta un comando, muestra su salida y la guarda en <carpeta>/<nombre_log>."""
    print("$ " + " ".join(cmd))
    entorno = {**os.environ, **(env or {}), "PYTHONIOENCODING": "utf-8"}
    with (carpeta / nombre_log).open("w", encoding="utf-8") as log:
        log.write("$ " + " ".join(cmd) + "\n\n")
        proc = subprocess.Popen(cmd, cwd=cwd, env=entorno, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace")
        assert proc.stdout is not None

        def volcar():
            for linea in proc.stdout:
                sys.stdout.write(linea)
                log.write(linea)

        lector = threading.Thread(target=volcar, daemon=True)
        lector.start()
        try:
            codigo = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
            codigo = 124
        lector.join(timeout=10)
        if codigo == 124:
            log.write(f"\n[TIEMPO AGOTADO tras {timeout} s]\n")
            print(f"[TIEMPO AGOTADO tras {timeout} s]")
        return codigo


def herramienta(nombre: str) -> str | None:
    """Ruta de un ejecutable; busca también junto al intérprete (venv/Scripts o venv/bin)."""
    junto = Path(sys.executable).parent / (nombre + (".exe" if os.name == "nt" else ""))
    if junto.exists():
        return str(junto)
    return shutil.which(nombre)


def modulo_disponible(modulo: str) -> bool:
    import importlib.util

    return importlib.util.find_spec(modulo) is not None
