"""Genera la colección de Postman de la WellQ Partner API y sus entornos (local y sandbox).

La colección sigue el flujo real del fabricante en orden: cada petición guarda en variables lo que la
siguiente necesita (portal_token, client_id, access_token, link_id…) y lleva tests que se ven en Postman
y en Newman. Si cambias el flujo, edita este archivo y vuelve a ejecutarlo:

    python pruebas/postman/generar_coleccion.py

Genera dos formatos: los JSON v2.1 (los usa Newman, p12) y el workspace local v3 YAML en v3/ (lo que abre
Postman en modo local).
"""
from __future__ import annotations

import json
import shutil
import subprocess
import uuid
from pathlib import Path

AQUI = Path(__file__).resolve().parent
SCOPES = "links:manage webhooks:manage ingest:activity ingest:sleep ingest:vitals ingest:body ingest:msk ingest:device read:goals read:scores"
CONSENT = ["ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:body", "ingest:msk", "ingest:device",
           "read:goals", "read:scores"]

PRE_COLECCION = r"""
// Variables dinámicas comunes a todas las peticiones.
const hoy = new Date();
const dia = (n) => new Date(hoy.getTime() - n * 86400000).toISOString().slice(0, 10);
pm.variables.set('ayer', dia(1));
pm.variables.set('anteayer', dia(2));
pm.variables.set('hace_30_dias', dia(30));
pm.variables.set('hoy', dia(0));
pm.variables.set('ahora', hoy.toISOString().replace(/\.\d+Z$/, 'Z'));
pm.variables.set('hace_1h', new Date(hoy.getTime() - 3600000).toISOString().replace(/\.\d+Z$/, 'Z'));
pm.variables.set('hace_9h', new Date(hoy.getTime() - 9 * 3600000).toISOString().replace(/\.\d+Z$/, 'Z'));
pm.variables.set('hace_2h', new Date(hoy.getTime() - 2 * 3600000).toISOString().replace(/\.\d+Z$/, 'Z'));
if (!pm.collectionVariables.get('sufijo')) pm.collectionVariables.set('sufijo', Date.now().toString(36));
""".strip()

TEST_COLECCION = r"""
// Comprobaciones comunes: trace_id en cada respuesta y errores en formato problem+json.
pm.test('Respuesta con cabecera X-Trace-Id', () => pm.expect(pm.response.headers.has('X-Trace-Id')).to.be.true);
if (pm.response.code >= 400) {
  pm.test('Error en formato application/problem+json', () =>
    pm.expect(pm.response.headers.get('Content-Type') || '').to.include('problem+json'));
}
pm.test('Tiempo de respuesta < 2 s', () => pm.expect(pm.response.responseTime).to.be.below(2000));
""".strip()


def js(texto: str) -> list[str]:
    return texto.strip().splitlines()


def peticion(nombre, metodo, ruta, *, cuerpo=None, form=None, auth="oauth", tests="", pre="", cabeceras=None,
             descripcion="", query=None, crudo=None):
    partes = [p for p in ruta.strip("/").split("/")]
    url = {"raw": "{{base_url}}/api/v1/" + ruta.strip("/") + ("?" + "&".join(f"{k}={v}" for k, v in query.items()) if query else ""),
           "host": ["{{base_url}}"], "path": ["api", "v1"] + partes}
    if query:
        url["query"] = [{"key": k, "value": v} for k, v in query.items()]
    req = {"method": metodo, "header": [], "url": url, "description": descripcion}
    for k, val in (cabeceras or {}).items():
        req["header"].append({"key": k, "value": val})
    if cuerpo is not None:
        req["header"].append({"key": "Content-Type", "value": "application/json"})
        req["body"] = {"mode": "raw", "raw": json.dumps(cuerpo, indent=2, ensure_ascii=False),
                       "options": {"raw": {"language": "json"}}}
    if crudo is not None:
        req["body"] = {"mode": "raw", "raw": crudo}
    if form is not None:
        req["body"] = {"mode": "urlencoded", "urlencoded": [{"key": k, "value": val} for k, val in form.items()]}
    if auth == "ninguna":
        req["auth"] = {"type": "noauth"}
    elif auth == "portal":
        req["auth"] = {"type": "bearer", "bearer": [{"key": "token", "value": "{{portal_token}}", "type": "string"}]}
    elif auth == "paciente":
        req["auth"] = {"type": "bearer", "bearer": [{"key": "token", "value": "{{patient_jwt}}", "type": "string"}]}
    elif auth == "clinico":
        req["auth"] = {"type": "bearer", "bearer": [{"key": "token", "value": "{{clinician_jwt}}", "type": "string"}]}
    elif auth == "cron":
        req["auth"] = {"type": "bearer", "bearer": [{"key": "token", "value": "{{cron_secret}}", "type": "string"}]}
    elif auth != "oauth":
        req["auth"] = {"type": "bearer", "bearer": [{"key": "token", "value": auth, "type": "string"}]}
    item = {"name": nombre, "request": req, "event": []}
    if pre:
        item["event"].append({"listen": "prerequest", "script": {"type": "text/javascript", "exec": js(pre)}})
    if tests:
        item["event"].append({"listen": "test", "script": {"type": "text/javascript", "exec": js(tests)}})
    return item


def carpeta(nombre, descripcion, items):
    return {"name": nombre, "description": descripcion, "item": items}


def estado(*codigos):
    lista = ", ".join(map(str, codigos))
    return f"pm.test('HTTP {' o '.join(map(str, codigos))}', () => pm.expect(pm.response.code).to.be.oneOf([{lista}]));"


def resumen(rid, dia="{{ayer}}", **extra):
    return {"record_id": rid, "local_date": dia, "tz_offset_minutes": 0, "device_id": "{{device_id}}",
            "completeness": "final", "steps": 7412, "distance_m": 5210.5, "active_minutes": 48,
            "resting_heart_rate_bpm": 58, "sleep_total_minutes": 431, **extra}


def coleccion() -> dict:
    items = [
        carpeta("00 Salud", "Comprueba que la API está montada.", [
            peticion("Health", "GET", "health", auth="ninguna", tests=estado(200) + """
pm.test('partner_api = true', () => pm.expect(pm.response.json().partner_api).to.eql(true));"""),
        ]),
        carpeta("01 Alta del fabricante", "Registro, verificación de correo (portal_token) y alta de la app.", [
            peticion("Registrar desarrollador", "POST", "partner/developers/register", auth="ninguna", cuerpo={
                "company_name": "QA Postman {{sufijo}}", "contact_email": "qa+postman{{sufijo}}@example.com",
                "contact_name": "QA", "country": "GB", "website": "https://example.com", "accept_terms": True},
                tests=estado(202, 200, 201) + r"""
const d = pm.response.json();
pm.collectionVariables.set('developer_id', d.developer_id);
// Con las herramientas de desarrollo activas el código llega en la respuesta; si no, ponlo a mano en verification_code.
const codigo = d.verification_token || d.verification_code || d.dev_verification_token || d.dev_verification_code || d.code;
if (codigo) pm.collectionVariables.set('verification_code', codigo);
pm.test('Devuelve developer_id', () => pm.expect(d.developer_id).to.be.a('string'));""",
                descripcion="Si el entorno no devuelve el código, copia el del correo en la variable verification_code."),
            peticion("Registrar el mismo correo (no revela si existe)", "POST", "partner/developers/register",
                     auth="ninguna", cuerpo={"company_name": "QA Postman {{sufijo}}",
                                             "contact_email": "qa+postman{{sufijo}}@example.com", "country": "GB",
                                             "accept_terms": True},
                     tests=estado(202, 200, 201) + "\npm.test('Misma forma de respuesta', () => pm.expect(pm.response.json()).to.have.property('status'));"),
            peticion("Verificar correo", "POST", "partner/developers/verify", auth="ninguna",
                     cuerpo={"developer_id": "{{developer_id}}", "verification_token": "{{verification_code}}"},
                     tests=estado(200) + "\npm.collectionVariables.set('portal_token', pm.response.json().portal_token);"),
            peticion("Crear app (sandbox)", "POST", "partner/apps", auth="portal", cuerpo={
                "name": "QA Postman {{sufijo}}", "description": "Pruebas Postman",
                "privacy_policy_url": "https://example.com/privacidad", "logo_url": "https://example.com/logo.png",
                "requested_scopes": CONSENT}, tests=estado(201) + r"""
const a = pm.response.json();
pm.collectionVariables.set('app_id', a.app_id);
pm.collectionVariables.set('client_id', a.client_id);
pm.collectionVariables.set('client_secret', a.client_secret);
pm.test('Entorno sandbox', () => pm.expect(a.environment).to.eql('sandbox'));
pm.test('Devuelve client_secret una sola vez', () => pm.expect(a.client_secret).to.be.a('string'));"""),
            peticion("Listar apps", "GET", "partner/apps", auth="portal", tests=estado(200) + r"""
pm.test('No expone client_secret', () => pm.expect(pm.response.text()).to.not.include('client_secret'));"""),
            peticion("Obtener app", "GET", "partner/apps/{{app_id}}", auth="portal", tests=estado(200)),
            peticion("Actualizar app", "PATCH", "partner/apps/{{app_id}}", auth="portal",
                     cuerpo={"name": "QA Postman {{sufijo}} (editada)"}, tests=estado(200)),
        ]),
        carpeta("02 OAuth", "client_credentials → access_token (1 h).", [
            peticion("Obtener access_token", "POST", "partner/oauth/token", auth="ninguna",
                     form={"grant_type": "client_credentials", "client_id": "{{client_id}}",
                           "client_secret": "{{client_secret}}", "scope": SCOPES},
                     tests=estado(200) + r"""
const t = pm.response.json();
pm.collectionVariables.set('access_token', t.access_token);
pm.test('token_type Bearer', () => pm.expect(t.token_type).to.eql('Bearer'));"""),
            peticion("Token con secreto incorrecto → 401", "POST", "partner/oauth/token", auth="ninguna",
                     form={"grant_type": "client_credentials", "client_id": "{{client_id}}", "client_secret": "incorrecto"},
                     tests=estado(401)),
            peticion("Token solo links:manage (para pruebas de scope)", "POST", "partner/oauth/token", auth="ninguna",
                     form={"grant_type": "client_credentials", "client_id": "{{client_id}}",
                           "client_secret": "{{client_secret}}", "scope": "links:manage"},
                     tests=estado(200) + "\npm.collectionVariables.set('token_reducido', pm.response.json().access_token);"),
        ]),
        carpeta("03 Capacidades", "Catálogo de métricas y modelo de dispositivo.", [
            peticion("Catálogo de métricas", "GET", "partner/capabilities/metrics", tests=estado(200) + r"""
const m = pm.response.json();
const lista = Array.isArray(m) ? m : (m.items || []);
pm.test('Catálogo no vacío', () => pm.expect(lista.length).to.be.above(0));
pm.collectionVariables.set('metricas', JSON.stringify(lista.map(x => x.metric)));"""),
            peticion("Declarar modelo", "POST", "partner/apps/{{app_id}}/device-models", pre=r"""
const metricas = JSON.parse(pm.collectionVariables.get('metricas') || '["steps","heart_rate"]');
pm.variables.set('capacidades', JSON.stringify(metricas.map(m => ({metric: m, typical_interval_seconds: 60, sampling_mode: 'continuous'}))));""",
                     crudo='{\n  "model_code": "{{model_code}}",\n  "display_name": "QA Band 1",\n  "form_factor": "band",\n  "body_placement": "wrist_left",\n  "capabilities": {{capacidades}}\n}',
                     cabeceras={"Content-Type": "application/json"}, tests=estado(201, 409)),
            peticion("Listar modelos", "GET", "partner/apps/{{app_id}}/device-models", tests=estado(200)),
        ]),
        carpeta("04 Vinculación", "Paciente sintético → código → link_id.", [
            peticion("Crear paciente sintético", "POST", "partner/sandbox/patients",
                     cuerpo={"scopes": CONSENT, "profile": "knee_rehab"}, tests=estado(201) + r"""
const p = pm.response.json();
pm.collectionVariables.set('pairing_code', p.pairing_code);
pm.test('Código con formato WQ-', () => pm.expect(p.pairing_code).to.match(/^WQ-/));"""),
            peticion("Canjear código (crear vínculo)", "POST", "partner/links", cuerpo={
                "pairing_code": "{{pairing_code}}", "external_user_id": "qa-postman-{{sufijo}}",
                "device_id": "{{device_id}}", "model_code": "{{model_code}}", "timezone": "Europe/London"},
                tests=estado(201) + r"""
const l = pm.response.json();
pm.collectionVariables.set('link_id', l.link_id);
pm.test('Vínculo activo', () => pm.expect(l.status).to.eql('active'));
pm.test('No expone patient_id', () => pm.expect(l).to.not.have.property('patient_id'));"""),
            peticion("Reutilizar el mismo código → 404", "POST", "partner/links", cuerpo={
                "pairing_code": "{{pairing_code}}", "external_user_id": "qa-postman-otro-{{sufijo}}"}, tests=estado(404)),
            peticion("Listar vínculos", "GET", "partner/links", query={"status": "active"}, tests=estado(200)),
            peticion("Estado del vínculo", "GET", "partner/links/{{link_id}}", tests=estado(200)),
        ]),
        carpeta("05 Ingesta", "Los cinco tipos de datos, idempotencia y estado de sincronización.", [
            peticion("daily-summaries", "POST", "partner/links/{{link_id}}/daily-summaries",
                     pre="pm.collectionVariables.set('idem_key', pm.variables.replaceIn('{{$guid}}'));",
                     cabeceras={"Idempotency-Key": "{{idem_key}}"},
                     cuerpo={"summaries": [resumen("pm-{{sufijo}}-1"), resumen("pm-{{sufijo}}-2", "{{anteayer}}")]},
                     tests=estado(200) + r"""
const r = pm.response.json();
pm.collectionVariables.set('respuesta_original', pm.response.text());
pm.test('2 aceptados', () => pm.expect(r.accepted).to.eql(2));"""),
            peticion("daily-summaries repetido (misma Idempotency-Key)", "POST",
                     "partner/links/{{link_id}}/daily-summaries", cabeceras={"Idempotency-Key": "{{idem_key}}"},
                     cuerpo={"summaries": [resumen("pm-{{sufijo}}-1"), resumen("pm-{{sufijo}}-2", "{{anteayer}}")]},
                     tests=estado(200) + r"""
pm.test('Devuelve la respuesta original', () => pm.expect(pm.response.json()).to.eql(JSON.parse(pm.collectionVariables.get('respuesta_original'))));"""),
            peticion("daily-summaries con pulso fuera de rango", "POST", "partner/links/{{link_id}}/daily-summaries",
                     cuerpo={"summaries": [resumen("pm-{{sufijo}}-bad", resting_heart_rate_bpm=300)]},
                     tests=estado(200, 422) + r"""
if (pm.response.code === 200) pm.test('Registro rechazado', () => pm.expect(pm.response.json().results[0].status).to.eql('rejected'));"""),
            peticion("samples (serie de pulso)", "POST", "partner/links/{{link_id}}/samples", cuerpo={"series": [{
                "metric": "heart_rate", "unit": "bpm", "device_id": "{{device_id}}", "start": "{{hace_2h}}",
                "offsets_ms": [0, 60000, 120000, 180000], "durations_ms": [60000] * 4, "values": [61, 63, 60, 62]}]},
                tests=estado(202) + "\npm.collectionVariables.set('job_id', pm.response.json().job_id);"),
            peticion("Estado del job", "GET", "partner/ingest/jobs/{{job_id}}", tests=estado(200) + r"""
pm.test('Estado válido', () => pm.expect(pm.response.json().status).to.be.oneOf(['queued','processing','completed','failed','partially_completed']));"""),
            peticion("sessions (sueño y ejercicio)", "POST", "partner/links/{{link_id}}/sessions", cuerpo={"sessions": [
                {"session_type": "sleep", "record_id": "pm-sl-{{sufijo}}", "device_id": "{{device_id}}",
                 "start": "{{hace_9h}}", "end": "{{hace_2h}}", "summary": {"total_sleep_minutes": 400}},
                {"session_type": "exercise", "record_id": "pm-ex-{{sufijo}}", "device_id": "{{device_id}}",
                 "start": "{{hace_2h}}", "end": "{{hace_1h}}", "activity_type": "strength_training",
                 "sets": [{"set_index": 1, "repetitions": 12, "load_kg": 10}]}]},
                tests=estado(200) + "\npm.test('2 aceptadas', () => pm.expect(pm.response.json().accepted).to.eql(2));"),
            peticion("msk-measurements", "POST", "partner/links/{{link_id}}/msk-measurements", cuerpo={"measurements": [{
                "record_id": "pm-msk-{{sufijo}}", "device_id": "{{device_id}}", "timestamp": "{{hace_1h}}",
                "measurement_type": "range_of_motion_flexion", "body_region": "knee", "side": "right",
                "value": 118.5, "unit": "deg"}]}, tests=estado(200)),
            peticion("device-events", "POST", "partner/links/{{link_id}}/device-events", cuerpo={"events": [{
                "record_id": "pm-ev-{{sufijo}}", "device_id": "{{device_id}}", "timestamp": "{{ahora}}",
                "event_type": "battery_low", "details": {"battery_pct": 12}}]}, tests=estado(200)),
            peticion("sync-state", "GET", "partner/links/{{link_id}}/sync-state", tests=estado(200) + r"""
pm.test('Incluye last_received', () => pm.expect(pm.response.json()).to.have.property('last_received'));"""),
        ]),
        carpeta("06 Lectura", "Objetivos y puntuaciones (según consentimiento).", [
            peticion("goals", "GET", "partner/links/{{link_id}}/goals", tests=estado(200)),
            peticion("scores (30 días)", "GET", "partner/links/{{link_id}}/scores",
                     query={"from_date": "{{hace_30_dias}}", "to_date": "{{hoy}}"}, tests=estado(200)),
        ]),
        carpeta("07 Webhooks", "Necesita la variable webhook_url (p. ej. una URL de https://webhook.site).", [
            peticion("Registrar webhook", "POST", "partner/apps/{{app_id}}/webhooks", cuerpo={
                "url": "{{webhook_url}}", "events": ["ping", "link.created", "link.revoked", "ingest.job.completed",
                                                      "patient.data_deletion_requested"], "description": "QA Postman"},
                tests=estado(201) + r"""
const w = pm.response.json();
pm.collectionVariables.set('webhook_id', w.webhook_id);
pm.collectionVariables.set('webhook_secret', w.secret);
pm.test('Devuelve el secret', () => pm.expect(w.secret).to.be.a('string'));"""),
            peticion("Enviar ping", "POST", "partner/apps/{{app_id}}/webhooks/{{webhook_id}}/test",
                     tests=estado(200) + "\npm.test('Entregado', () => pm.expect(pm.response.json().delivered).to.eql(true));"),
            peticion("Historial de entregas", "GET", "partner/apps/{{app_id}}/webhooks/{{webhook_id}}/deliveries",
                     tests=estado(200)),
            peticion("Listar webhooks", "GET", "partner/apps/{{app_id}}/webhooks", tests=estado(200) + r"""
pm.test('No expone el secret', () => pm.expect(pm.response.text()).to.not.include('"secret"'));"""),
            peticion("Webhook a IP interna → rechazado (SSRF)", "POST", "partner/apps/{{app_id}}/webhooks",
                     cuerpo={"url": "https://169.254.169.254/latest/meta-data", "events": ["ping"]},
                     tests=estado(400, 422)),
            peticion("Eliminar webhook", "DELETE", "partner/apps/{{app_id}}/webhooks/{{webhook_id}}", tests=estado(204)),
        ]),
        carpeta("08 Seguridad (casos negativos)", "Deben fallar de la forma esperada.", [
            peticion("Sin token → 401", "GET", "partner/links", auth="ninguna", tests=estado(401)),
            peticion("Token manipulado → 401", "GET", "partner/links", auth="{{access_token}}x", tests=estado(401)),
            peticion("portal_token en ruta de fabricante → 401/403", "GET", "partner/links", auth="portal",
                     tests=estado(401, 403)),
            peticion("access_token en ruta de portal → 401/403", "POST", "partner/apps", cuerpo={"name": "x"},
                     tests=estado(401, 403)),
            peticion("Scope insuficiente → 403", "POST", "partner/links/{{link_id}}/daily-summaries",
                     auth="{{token_reducido}}", cuerpo={"summaries": [resumen("pm-{{sufijo}}-scope")]},
                     tests=estado(403) + r"""
pm.test('type insufficient-scope', () => pm.expect(pm.response.json().type).to.include('insufficient-scope'));"""),
            peticion("Vínculo ajeno o inexistente → 404", "GET", "partner/links/lnk_00000000000000", tests=estado(404)),
            peticion("Campo desconocido → rechazado", "POST", "partner/links/{{link_id}}/daily-summaries",
                     cuerpo={"summaries": [resumen("pm-{{sufijo}}-x", campo_inventado=1)]}, tests=estado(200, 422) + r"""
if (pm.response.code === 200) pm.test('Registro rechazado', () => pm.expect(pm.response.json().results[0].status).to.eql('rejected'));"""),
            peticion("Operador de Mongo en el cuerpo → rechazado", "POST", "partner/links",
                     cuerpo={"pairing_code": {"$ne": None}, "external_user_id": "qa"}, tests=estado(400, 404, 422)),
            peticion("Cron sin secreto → 404", "GET", "internal/cron/sweep-ingest", auth="ninguna",
                     tests=estado(401, 403, 404)),
        ]),
        carpeta("09 App del paciente", "Necesita patient_jwt (JWT de un paciente de prueba de WellQ).", [
            peticion("Información de consentimiento", "GET", "wearables/consent-info", auth="paciente",
                     query={"app_id": "{{app_id}}"}, tests=estado(200)),
            peticion("Generar código de emparejamiento", "POST", "wearables/pairing-codes", auth="paciente",
                     cuerpo={"app_id": "{{app_id}}", "scopes": ["ingest:activity", "ingest:sleep"],
                             "consent_doc_version": "{{consent_doc_version}}"},
                     tests=estado(201) + "\npm.collectionVariables.set('pairing_code_paciente', pm.response.json().pairing_code);"),
            peticion("Fabricante canjea el código del paciente", "POST", "partner/links", cuerpo={
                "pairing_code": "{{pairing_code_paciente}}", "external_user_id": "qa-pac-{{sufijo}}",
                "device_id": "{{device_id}}", "model_code": "{{model_code}}"},
                tests=estado(201) + "\npm.collectionVariables.set('link_id_paciente', pm.response.json().link_id);"),
            peticion("Vínculos del paciente", "GET", "wearables/links", auth="paciente", tests=estado(200)),
            peticion("Paciente revoca con borrado de datos", "DELETE", "wearables/links/{{link_id_paciente}}",
                     auth="paciente", query={"delete_data": "true"}, tests=estado(204)),
        ]),
        carpeta("10 Panel clínico", "Necesita clinician_jwt y patient_id.", [
            peticion("Dispositivos del paciente", "GET", "maindash/patient/{{patient_id}}/wearables", auth="clinico",
                     tests=estado(200)),
        ]),
        carpeta("11 Cierre", "Revocación por el fabricante y comprobación de que corta la ingesta.", [
            peticion("Revocar vínculo", "DELETE", "partner/links/{{link_id}}", tests=estado(204)),
            peticion("Ingesta tras revocar → 403 link-revoked", "POST", "partner/links/{{link_id}}/device-events",
                     cuerpo={"events": [{"record_id": "pm-ev2-{{sufijo}}", "device_id": "{{device_id}}",
                                         "timestamp": "{{ahora}}", "event_type": "worn"}]},
                     tests=estado(403) + r"""
pm.test('type link-revoked', () => pm.expect(pm.response.json().type).to.include('link-revoked'));"""),
        ]),
    ]
    variables = ["developer_id", "verification_code", "portal_token", "app_id", "client_id", "client_secret",
                 "access_token", "token_reducido", "metricas", "pairing_code", "link_id", "idem_key",
                 "respuesta_original", "job_id", "webhook_id", "webhook_secret", "pairing_code_paciente",
                 "link_id_paciente", "sufijo"]
    return {
        "info": {"_postman_id": str(uuid.uuid5(uuid.NAMESPACE_URL, "wellq-partner-api-qa")),
                 "name": "WellQ Partner API · Pruebas",
                 "description": "Flujo completo del fabricante con tests. Ejecutar en orden (Runner o Newman). "
                                "Ver pruebas/GUIA_PRUEBAS_MANUALES.md.",
                 "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},
        "auth": {"type": "bearer", "bearer": [{"key": "token", "value": "{{access_token}}", "type": "string"}]},
        "event": [{"listen": "prerequest", "script": {"type": "text/javascript", "exec": js(PRE_COLECCION)}},
                  {"listen": "test", "script": {"type": "text/javascript", "exec": js(TEST_COLECCION)}}],
        "variable": [{"key": k, "value": ""} for k in variables],
        "item": items,
    }


def entorno(nombre: str, base_url: str) -> dict:
    valores = [("base_url", base_url, "default"), ("device_id", "QA-BAND-1-SN0001", "default"),
               ("model_code", "QA-BAND-1", "default"), ("webhook_url", "", "default"),
               ("consent_doc_version", "wearable-sharing-v1", "default"), ("patient_jwt", "", "secret"),
               ("clinician_jwt", "", "secret"), ("patient_id", "", "default"), ("cron_secret", "", "secret")]
    return {"id": str(uuid.uuid5(uuid.NAMESPACE_URL, nombre)), "name": nombre,
            "values": [{"key": k, "value": val, "type": t, "enabled": True} for k, val, t in valores],
            "_postman_variable_scope": "environment"}


def entorno_yaml(nombre: str, base_url: str) -> str:
    """Entorno en el formato v3 YAML de Postman (modo local): postman/environments/<nombre>.environment.yaml."""
    lineas = [f"name: {json.dumps(nombre, ensure_ascii=False)}", "values:"]
    for v in entorno(nombre, base_url)["values"]:
        lineas += [f"  - key: {v['key']}", f"    value: {json.dumps(v['value'], ensure_ascii=False)}", "    enabled: true"]
    return "\n".join(lineas) + "\n"


def generar_v3(entornos) -> None:
    """Workspace local de Postman (formato v3 YAML) en postman/v3/. Lo abre Postman en modo local.

    La colección se convierte con la herramienta oficial de Postman (postman-cli, vía npx). Newman sigue usando
    los JSON v2.1 de esta carpeta, porque Newman no ejecuta colecciones v3.
    """
    destino = AQUI / "v3" / "postman"
    (destino / "environments").mkdir(parents=True, exist_ok=True)
    for _, nombre, url in entornos:
        (destino / "environments" / f"{nombre}.environment.yaml").write_text(entorno_yaml(nombre, url), encoding="utf-8")
    npx = shutil.which("npx") or shutil.which("npx.cmd")
    if not npx:
        print("Sin Node.js: no se regeneró la colección v3 (postman/v3/postman/collections).")
        return
    coleccion_v3 = destino / "collections" / "WellQ Partner API"
    if coleccion_v3.exists():
        shutil.rmtree(coleccion_v3)
    subprocess.run([npx, "--yes", "postman-cli@1.82.0", "collection", "migrate",
                    str(AQUI / "WellQ_Partner_API.postman_collection.json"), "-o", str(coleccion_v3)], check=True)


def main() -> None:
    (AQUI / "WellQ_Partner_API.postman_collection.json").write_text(
        json.dumps(coleccion(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    entornos = (("local", "WellQ local", "http://127.0.0.1:8000"),
                ("sandbox", "WellQ sandbox", "https://TU-PROYECTO-DEMO.vercel.app"))
    for archivo, nombre, url in entornos:
        (AQUI / f"WellQ_{archivo}.postman_environment.json").write_text(
            json.dumps(entorno(nombre, url), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    generar_v3(entornos)
    print("Colección y entornos generados en", AQUI, "(JSON v2.1 para Newman y v3 YAML en v3/)")


if __name__ == "__main__":
    main()
