"""Ejecuta las suites de pruebas y genera un resumen único en evidencia/pruebas/<RUN_ID>/RESUMEN.md.

    python pruebas/run_all.py                      # perfil "estatico": pytest, pip-audit, bandit (sin API)
    python pruebas/run_all.py --perfil api         # + funcional, auth, seguridad, privacidad, contrato, fiabilidad,
                                                   #   Newman y k6 de humo contra WELLQ_BASE_URL
    python pruebas/run_all.py --perfil completo    # + k6 con K6_PERFIL y escaneo ZAP (Docker)
    python pruebas/run_all.py --solo p04,p05       # solo esas suites
    python pruebas/run_all.py --perfil api --excluir p08,p12

Código de salida: 0 si todas las suites pasan, 1 si alguna falla.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

from comun import DIR_PRUEBAS, RAIZ_REPO, api_disponible, cargar_config, run_id

SUITES = {
    "p01": ("p01_pytest.py", [], "01_pytest", "Funcionales/seguridad del código (pytest)"),
    "p02": ("p02_pip_audit.py", [], "02_pip_audit", "Dependencias vulnerables (pip-audit)"),
    "p03": ("p03_bandit_secretos.py", [], "03_bandit_secretos", "Análisis estático y secretos (bandit)"),
    "p04": ("p04_funcional_e2e.py", [], "04_funcional", "Funcionales de extremo a extremo"),
    # Newman va antes de p05: la fuerza bruta de códigos de p05 (A-11) deja bloqueado el canje de códigos y la
    # colección fallaba en cadena con 429 (defecto D-05)
    "p12": ("p12_postman_newman.py", [], "12_newman", "Colección Postman (Newman)"),
    "p05": ("p05_autenticacion.py", [], "05_autenticacion", "Autenticación y autorización"),
    "p06": ("p06_seguridad_http.py", [], "06_seguridad_http", "Seguridad HTTP"),
    "p07": ("p07_privacidad.py", [], "07_privacidad", "Privacidad y minimización"),
    "p08": ("p08_contrato_schemathesis.py", ["--rapido"], "08_contrato", "Contrato OpenAPI (Schemathesis)"),
    "p10": ("p10_fiabilidad.py", [], "10_fiabilidad", "Fiabilidad"),
    "p09": ("p09_carga_k6.py", [], "09_carga_k6", "Rendimiento y carga (k6)"),
    "p11": ("p11_zap_baseline.py", [], "11_zap", "Escaneo OWASP ZAP"),
}
PERFILES = {
    "estatico": ["p01", "p02", "p03"],
    "api": ["p01", "p02", "p03", "p04", "p12", "p05", "p06", "p07", "p08", "p10", "p09"],
    "completo": ["p01", "p02", "p03", "p04", "p12", "p05", "p06", "p07", "p08", "p10", "p09", "p11"],
}
NECESITAN_API = {"p04", "p05", "p06", "p07", "p08", "p09", "p10", "p11", "p12"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Ejecuta las pruebas de la WellQ Partner API")
    parser.add_argument("--perfil", choices=PERFILES, default="estatico")
    parser.add_argument("--solo", help="lista de suites separadas por coma (p01,p04…)")
    parser.add_argument("--excluir", default="", help="suites a saltar, separadas por coma")
    parser.add_argument("--parar-en-fallo", action="store_true", help="detenerse en la primera suite que falle")
    args = parser.parse_args()

    cfg = cargar_config()
    rid = run_id()
    seleccion = args.solo.split(",") if args.solo else PERFILES[args.perfil]
    seleccion = [s.strip() for s in seleccion if s.strip() and s.strip() not in args.excluir.split(",")]
    # con --solo también se respeta el orden seguro (p12 antes que p05), sea cual sea el orden escrito
    orden = list(SUITES)
    seleccion = sorted(dict.fromkeys(seleccion), key=lambda s: orden.index(s) if s in orden else len(orden))
    desconocidas = [s for s in seleccion if s not in SUITES]
    if desconocidas:
        parser.error(f"suites desconocidas: {desconocidas}. Válidas: {', '.join(SUITES)}")
    # El perfil "api" lanza k6 en modo humo salvo que se pida otro perfil expresamente.
    if args.perfil == "api" and not args.solo and "K6_PERFIL" not in os.environ:
        os.environ["K6_PERFIL"] = "humo"

    print(f"Ejecución {rid} · suites: {', '.join(seleccion)} · API: {cfg['WELLQ_BASE_URL']} ({cfg['WELLQ_ENTORNO']})")
    if NECESITAN_API & set(seleccion):
        ok, detalle = api_disponible(cfg)
        if not ok:
            print(f"\n[AVISO] {detalle}\nLas suites que necesitan la API fallarán. Arranca la API (ver README) "
                  "o ajusta WELLQ_BASE_URL en pruebas/config.env.\n")

    filas = []
    for clave in seleccion:
        script, extra, carpeta, titulo = SUITES[clave]
        print(f"\n{'═' * 78}\n▶ {clave} · {titulo}\n{'═' * 78}")
        t0 = time.time()
        codigo = subprocess.call([sys.executable, str(DIR_PRUEBAS / script), *extra], cwd=RAIZ_REPO,
                                 env={**os.environ, "WELLQ_RUN_ID": rid, "PYTHONIOENCODING": "utf-8"})
        res_json = RAIZ_REPO / "evidencia" / "pruebas" / rid / carpeta / "resultado.json"
        datos = json.loads(res_json.read_text(encoding="utf-8")) if res_json.exists() else {}
        resumen = datos.get("resumen", {})
        estado = {0: "OK", 3: "ABORTADA"}.get(codigo, "FALLO")
        filas.append({"suite": clave, "titulo": titulo, "estado": estado, "codigo": codigo,
                      "ok": resumen.get("OK", 0), "fallos": resumen.get("FALLO", 0),
                      "omitidos": resumen.get("OMITIDO", 0), "segundos": round(time.time() - t0),
                      "detalle": f"{carpeta}/resultado.md"})
        if codigo and args.parar_en_fallo:
            break

    carpeta_run = RAIZ_REPO / "evidencia" / "pruebas" / rid
    carpeta_run.mkdir(parents=True, exist_ok=True)
    lineas = [f"# Resumen de pruebas · {rid}", "",
              f"- API: `{cfg['WELLQ_BASE_URL']}` (entorno {cfg['WELLQ_ENTORNO']})",
              f"- Perfil: {args.solo and 'personalizado' or args.perfil}", "",
              "| Suite | Tipo de prueba | Resultado | OK | Fallos | Omitidos | Duración | Detalle |",
              "|---|---|---|---|---|---|---|---|"]
    for f in filas:
        lineas.append(f"| {f['suite']} | {f['titulo']} | **{f['estado']}** | {f['ok']} | {f['fallos']} | "
                      f"{f['omitidos']} | {f['segundos']} s | [{f['detalle']}]({f['detalle']}) |")
    lineas += ["", "Cada carpeta contiene `resultado.md`, `resultado.json`, la salida completa de la herramienta y, "
               "en las pruebas contra la API, `http_log.jsonl` con cada petición y respuesta (secretos enmascarados)."]
    (carpeta_run / "RESUMEN.md").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    (carpeta_run / "resumen.json").write_text(json.dumps(filas, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"\n{'═' * 78}\nRESUMEN {rid}")
    for f in filas:
        print(f"  {f['estado']:8} {f['suite']} {f['titulo']:42} {f['ok']:4} OK {f['fallos']:3} fallos {f['omitidos']:3} omitidos")
    print(f"\nResumen: {carpeta_run / 'RESUMEN.md'}")
    return 1 if any(f["estado"] != "OK" for f in filas) else 0


if __name__ == "__main__":
    sys.exit(main())
