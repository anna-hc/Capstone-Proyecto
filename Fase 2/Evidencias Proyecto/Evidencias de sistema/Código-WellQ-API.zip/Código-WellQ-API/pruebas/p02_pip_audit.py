"""Vulnerabilidades conocidas en las dependencias (pip-audit contra la base de datos de PyPI/OSV).

Audita data/requirements.txt (lo que se despliega en Vercel) y, si existe, data/requirements-dev.txt.
Cada vulnerabilidad es un FALLO salvo que su ID esté en pruebas/pip_audit_ignorar.txt con justificación.

    python pruebas/p02_pip_audit.py
"""
from __future__ import annotations

import json
import sys

from comun import DIR_PRUEBAS, Informe, cargar_config, ejecutar, herramienta, modulo_disponible


def ignorados() -> dict[str, str]:
    ruta = DIR_PRUEBAS / "pip_audit_ignorar.txt"
    res: dict[str, str] = {}
    if ruta.exists():
        for linea in ruta.read_text(encoding="utf-8").splitlines():
            linea = linea.strip()
            if linea and not linea.startswith("#"):
                vid, _, motivo = linea.partition(" ")
                res[vid] = motivo.strip() or "sin justificación"
    return res


def main() -> int:
    cfg = cargar_config()
    informe = Informe("02_pip_audit", "Dependencias con vulnerabilidades conocidas (pip-audit)")
    carpeta = informe.carpeta
    if modulo_disponible("pip_audit"):
        base = [sys.executable, "-m", "pip_audit"]
    elif herramienta("pip-audit"):
        base = [herramienta("pip-audit")]
    else:
        informe.registrar("DEP-00", "pip-audit instalado", False, "pip install -r pruebas/requirements.txt")
        return informe.cerrar()

    lista_ignorar = ignorados()
    for nombre in ("requirements.txt", "requirements-dev.txt"):
        req = cfg.data_dir / nombre
        if not req.exists():
            if nombre == "requirements.txt":
                informe.registrar("DEP-00", f"Existe {req}", False, "ajusta WELLQ_DATA_DIR")
            continue
        salida = carpeta / f"pip_audit_{req.stem}.json"
        cmd = base + ["-r", str(req), "--format", "json", "--output", str(salida), "--progress-spinner", "off",
                      "--desc", "on"]
        for vid in lista_ignorar:
            cmd += ["--ignore-vuln", vid]
        codigo = ejecutar(cmd, carpeta, f"salida_{req.stem}.txt", timeout=1200)
        if not salida.exists():
            informe.registrar("DEP-00", f"pip-audit analizó {nombre}", False,
                              f"código {codigo}; revisa salida_{req.stem}.txt (¿sin red o versión no instalable?)")
            continue
        datos = json.loads(salida.read_text(encoding="utf-8"))
        deps = datos.get("dependencies", datos if isinstance(datos, list) else [])
        hallazgos, vistos = 0, set()
        for dep in deps:
            for v in dep.get("vulns", []):
                if (dep["name"], v["id"]) in vistos:  # la misma vulnerabilidad puede venir de varias fuentes
                    continue
                vistos.add((dep["name"], v["id"]))
                hallazgos += 1
                arreglo = ", ".join(v.get("fix_versions", [])) or "sin versión corregida"
                informe.registrar("DEP", f"{nombre}: {dep['name']} {dep.get('version', '')} · {v['id']}", False,
                                  f"corregido en {arreglo}. {(v.get('description') or '')[:200]}")
        sin_analizar = [d["name"] for d in deps if d.get("skip_reason")]
        informe.registrar("DEP-01", f"{nombre}: {len(deps)} paquetes analizados, {hallazgos} vulnerabilidades",
                          hallazgos == 0, f"sin analizar: {', '.join(sin_analizar)}" if sin_analizar else "")
    for vid, motivo in lista_ignorar.items():
        informe.omitir("DEP-IGN", f"{vid} ignorada a propósito", motivo)
    return informe.cerrar()


if __name__ == "__main__":
    sys.exit(main())
