"""Verifica la firma de un webhook de WellQ tal como debe hacerlo el fabricante.

WellQ firma cada entrega con  X-WellQ-Signature: t=<unix>,v1=<hex(HMAC-SHA256(secret, "<t>.<cuerpo>"))>
y el receptor debe rechazar firmas de más de 5 minutos.

    python pruebas/herramientas/verificar_firma_webhook.py --secreto whsec_... --firma "t=...,v1=..." --cuerpo cuerpo.json
    python pruebas/herramientas/verificar_firma_webhook.py ... --sin-caducidad   # para entregas antiguas de webhook.site

El cuerpo debe ser el texto EXACTO recibido (en webhook.site: "Raw content"), sin reformatear.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import sys
import time
from pathlib import Path


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--secreto", required=True, help="secret devuelto al crear el webhook")
    p.add_argument("--firma", required=True, help="valor de la cabecera X-WellQ-Signature")
    p.add_argument("--cuerpo", required=True, help="archivo con el cuerpo exacto recibido")
    p.add_argument("--tolerancia", type=int, default=300, help="antigüedad máxima en segundos (300)")
    p.add_argument("--sin-caducidad", action="store_true", help="no comprobar la antigüedad")
    args = p.parse_args()

    partes = dict(x.split("=", 1) for x in args.firma.split(",") if "=" in x)
    if "t" not in partes or "v1" not in partes:
        print("FALLO: la cabecera no tiene el formato t=<unix>,v1=<hex>")
        return 1
    cuerpo = Path(args.cuerpo).read_bytes()
    esperada = hmac.new(args.secreto.encode(), f"{partes['t']}.".encode() + cuerpo, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(esperada, partes["v1"]):
        print("FALLO: la firma no coincide (¿secreto equivocado o cuerpo modificado/reformateado?)")
        return 1
    edad = int(time.time()) - int(partes["t"])
    if not args.sin_caducidad and abs(edad) > args.tolerancia:
        print(f"FALLO: firma válida pero con {edad} s de antigüedad (> {args.tolerancia} s): el receptor debe rechazarla")
        return 1
    print(f"OK: firma válida ({edad} s de antigüedad)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
