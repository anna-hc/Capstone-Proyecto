# WellQ Partner API

API para que los fabricantes de wearables envíen datos a WellQ (reemplazo de Spike). El contrato está en `documentacion/wellq-partner-api-openapi.yaml`.

## Carpetas

- `data/`: **versión autónoma**, ejecutable sin la app WellQ y preparada para Vercel. Se conecta a la base Mongo de WellQ y acepta sus JWT de paciente y de clínico. Instrucciones en [`data/README.md`](data/README.md).
- `integracion/`: los mismos módulos preparados para integrarse dentro de `wellq-app-main` (misma estructura que la app) y `wellq-app-main.patch` con los cambios a archivos existentes. Guía en `documentacion/revision/GUIA_INTEGRACION.md`.
- `documentacion/revision/`: informe de la revisión, catálogo de requisitos, registro de brechas, equivalencias Spike → WellQ y guía del piloto con Hytro.
- `evidencia/`: sonda sobre la alfa original, cobertura del contrato, carga ligera y recorridos de la interfaz de prueba con Playwright (`evidencia/ui/` integrada, `evidencia/autonoma/` versión de `data/`).

La alfa original del Equipo 1, que vivía en `data/` y tenía los fallos documentados en `BRECHAS.md`, sigue disponible en el historial de git (commit `7aaeff8` y anteriores).
