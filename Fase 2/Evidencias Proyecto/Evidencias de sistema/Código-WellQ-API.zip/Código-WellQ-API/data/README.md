# WellQ Partner API (versión autónoma)

Partner API de fabricantes de wearables lista para ejecutarse sola, sin la app WellQ, y desplegarse en Vercel. Es el mismo código que `../integracion/` (routers, servicios, modelos, jobs, demo), más una capa mínima propia en lugar de la de la app: configuración, conexión a Mongo, validación de los JWT de WellQ, resolución de tenants, correo y entrada ASGI.

Se conecta a la **misma base Mongo de WellQ** (escribe los datos de salud en el tenant del paciente) y acepta los **mismos JWT** de paciente y de clínico, así que la app y la web siguen leyendo los datos sin cambios. Para la arquitectura, la seguridad y los supuestos, ver `../documentacion/revision/`.

## Estructura

```
app/main.py                  app FastAPI autónoma y entrada de Vercel (salud, cabeceras de seguridad, cron protegido)
vercel.json                  duración máxima y cron de los jobs
app/config.py, db.py, ...    capa propia equivalente a la de la app WellQ
app/api/v1/routers/partner_* rutas de la Partner API, de la app del paciente y del panel clínico
app/services/partner/        tokens, cifrado, SSRF, ingesta, scores, webhooks, borrado, auditoría
app/partner_demo/            interfaz de prueba (solo desarrollo)
tests/                       47 tests (mongomock) + recorrido Playwright y carga ligera
```

## Ejecutar en local

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements-dev.txt
copy .env.example .env    # rellenar: Mongo, JWT_SECRET de WellQ, PARTNER_TOKEN_SECRET, PARTNER_ENCRYPTION_KEY
.venv\Scripts\python -m uvicorn app.main:app --port 8000
```

Para la demo, en `.env`: `APP_ENV=dev`, `PARTNER_DEMO_ENABLED=true`, `PARTNER_DEV_TOOLS_ENABLED=true` y, si el webhook de prueba apunta a `localhost`, `PARTNER_WEBHOOK_ALLOW_PRIVATE=true`. Luego abrir `http://localhost:8000/` (redirige a `/api/v1/partner-demo/`). Con `PARTNER_LOCAL_SCHEDULER=true` los jobs (webhooks, series, supresiones, huecos) corren en el propio proceso.

Modo presentación (para proyectar): `/api/v1/partner-demo/presentacion/`, enlazado desde la demo ("Modo presentación"). Es un recorrido guiado en 5 pasos (alta, vinculación, envío, lectura y revocación) con las mismas llamadas que la demo, el diagrama de actores, lo enviado y lo recibido de cada petición y qué comprobó la API. Mismas barreras que la demo (flag, `APP_ENV` de desarrollo, login y CSP sin recursos externos). La vista del clínico y el webhook necesitan además `PARTNER_DEV_TOOLS_ENABLED=true`; si faltan, esas peticiones se omiten y el recorrido sigue.

La demo, `/docs` y las herramientas de desarrollo piden usuario y contraseña (`/login`). Configura `DASHBOARD_USER`, `DASHBOARD_PASSWORD_HASH` (`.venv\Scripts\python -m app.scripts.hash_password`) y `DASHBOARD_SESSION_SECRET`; sin ellas esas páginas quedan cerradas. En local se puede desactivar con `DASHBOARD_LOGIN_DISABLED=true`. Detalle en `../VARIABLES_ENTORNO.md`.

Índices (idempotente): `.venv\Scripts\python -m app.scripts.create_partner_indexes`.

## Tests

```powershell
.venv\Scripts\python -m pytest            # 47 tests, sin Mongo ni Redis reales
.venv\Scripts\python tests\partner_ui\demo_playwright.py http://127.0.0.1:8000 salida msedge
.venv\Scripts\python tests\partner_ui\carga_ligera.py http://127.0.0.1:8000 carga.json
```

## Desplegar en Vercel

1. Crear un proyecto con **Root Directory = `data`** (runtime Python; Vercel instala `requirements.txt`).
2. Definir las variables de `.env.example` en el proyecto. Imprescindibles: `MONGODB_URI`, `MONGODB_DB`, `MONGO_CENTRAL_URI`, `MONGODB_CENTRAL_DB`, `TENANT_DB_ENCRYPTION_KEY`, `JWT_SECRET`, `PARTNER_TOKEN_SECRET`, `PARTNER_ENCRYPTION_KEY`, `PARTNER_ADMIN_TENANT_SLUGS`, `CRON_SECRET`; recomendadas: `REDIS_URL` (límites compartidos entre instancias) y `SMTP_*`.
3. Permitir el acceso de Vercel al clúster de Atlas (lista de IP o integración de Vercel con Atlas).
4. Ejecutar una vez `python -m app.scripts.create_partner_indexes` contra la base (el cron diario `ensure-indexes` lo repite).
5. Los jobs los dispara Vercel Cron (`vercel.json`) llamando a `/api/v1/internal/cron/*` con `Authorization: Bearer $CRON_SECRET`. `vercel.json` los programa **una vez al día** porque el plan Hobby rechaza el despliegue si un cron corre más a menudo. Las entregas de webhooks y los jobs de series se procesan al momento dentro de la misma petición; el cron solo recoge reintentos y pendientes. En plan Pro, subir la frecuencia: `deliver-webhooks` y `sweep-ingest` cada minuto (`* * * * *`), `run-deletions` cada 5 min, `detect-goals` cada 15 min y `detect-gaps` cada hora. En Hobby se puede lograr lo mismo con un programador externo (p. ej. GitHub Actions) que llame a esas rutas con el mismo `CRON_SECRET`.
6. Producción: `APP_ENV=production` y **sin** `PARTNER_DEMO_ENABLED`, `PARTNER_DEV_TOOLS_ENABLED` ni `PARTNER_WEBHOOK_ALLOW_PRIVATE`. Para probar la demo en Vercel, usar un proyecto aparte de no producción con `APP_ENV=dev` y una base de pruebas.

Límites de Vercel a tener en cuenta: cuerpo máximo 4,5 MB (por eso `/samples` admite 4 MB comprimidos) y duración máxima de la función (60 s en `vercel.json`).
