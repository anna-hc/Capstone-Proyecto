import os
import sys
from pathlib import Path

from cryptography.fernet import Fernet

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
# la app lee la configuración al importarse: los valores de prueba tienen que existir antes
for key, value in {
    "APP_ENV": "test", "JWT_SECRET": "test-only-jwt-secret-0123456789abcdef", "JWT_ALG": "HS256",
    "MONGODB_URI": "mongodb://127.0.0.1:1/?serverSelectionTimeoutMS=200", "MONGODB_DB": "tenant-test",
    "PARTNER_API_ENABLED": "true", "PARTNER_TOKEN_SECRET": "test-only-partner-secret-0123456789abcdefghij",
    "PARTNER_ENCRYPTION_KEY": Fernet.generate_key().decode(), "PARTNER_WEBHOOK_ALLOW_PRIVATE": "true",
    "PARTNER_DEV_TOOLS_ENABLED": "true", "PARTNER_DEMO_ENABLED": "true", "PARTNER_ADMIN_TENANT_SLUGS": "clinica-test",
    "CRON_SECRET": "test-only-cron-secret",
    # el login del dashboard se prueba en test_dashboard_login.py activándolo con monkeypatch
    "DASHBOARD_LOGIN_DISABLED": "true",
}.items():
    os.environ.setdefault(key, value)
