"""Pruebas de las correcciones del documento «Cosas por mejorar en la API» (noviembre de 2026)."""
import gzip
import json
from datetime import datetime, timedelta, timezone

import pytest
from conftest import MOCK, TENANT_DB, Partner, make_admin, make_clinician, make_patient, promote, summary

import app.config as conf
from app.repositories import partner as repo
from app.services.partner import alerts, ingest, links as link_service
from app.tasks import partner_jobs

SANDBOX = conf.PARTNER_SANDBOX_DB
API = "/api/v1"


def _real_link(client, mailbox, scopes=None, external_user_id="u-real", model=True, timezone_name=None):
    """App en producción, paciente real con clínico y vínculo activo."""
    p = Partner(client, mailbox)
    code_model = p.device_model() if model else None
    promote(client, p)
    clinician = make_clinician()
    patient = make_patient(care_clinician=clinician["oid"])
    r = client.post(f"{API}/wearables/pairing-codes", headers=patient["headers"], json={
        "app_id": p.app_id, "scopes": scopes or ["ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:msk",
                                                 "ingest:device", "read:goals", "read:scores"],
        "consent_doc_version": "wearable-sharing-v1"})
    assert r.status_code == 201, r.text
    body = {"pairing_code": r.json()["pairing_code"], "external_user_id": external_user_id}
    if code_model:
        body["model_code"] = code_model
    if timezone_name:
        body["timezone"] = timezone_name
    r = client.post(f"{API}/partner/links", headers=p.auth, json=body)
    assert r.status_code == 201, r.text
    return p, patient, clinician, r.json()["link_id"]


# --- Estado de la sincronización por métrica y huecos -------------------------------------------------------

def test_sync_state_por_metrica_y_huecos_con_motivo(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    today = datetime.now(timezone.utc).date()
    d = [(today - timedelta(days=n)).isoformat() for n in range(6, 0, -1)]  # 6 días hasta ayer
    r = client.post(f"{API}/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("s1", d[0], tz_offset_minutes=0, steps=5000, resting_heart_rate_bpm=60),
        summary("s2", d[1], tz_offset_minutes=0, steps=5100),               # falta la FC en reposo
        # d[2]: no llega nada y el dispositivo avisó de que estaba quitado -> not_worn
        # d[3]: no llega nada sin explicación -> no_data
        summary("s5", d[4], tz_offset_minutes=0, steps=4000, resting_heart_rate_bpm=61),
    ]})
    assert r.status_code == 200 and r.json()["accepted"] == 3, r.text
    client.post(f"{API}/partner/links/{link_id}/device-events", headers=p.auth, json={"events": [
        {"record_id": "ev-off", "device_id": "ACME-SN1", "timestamp": f"{d[2]}T08:00:00Z", "event_type": "removed"}]})

    r = client.get(f"{API}/partner/links/{link_id}/sync-state", headers=p.auth)
    assert r.status_code == 200, r.text
    state = r.json()
    # hasta dónde llegó cada métrica, no solo cada tipo de envío
    assert state["metrics"]["daily:steps"]["latest_timestamp"].startswith(d[4])
    assert state["metrics"]["daily:resting_heart_rate_bpm"]["latest_timestamp"].startswith(d[4])
    assert "device_event" in state["metrics"]
    gaps = {(g["metric"], g.get("local_date")): g["reason"] for g in state["gaps"]}
    assert gaps[("daily:resting_heart_rate_bpm", d[1])] == "metric_missing"
    assert gaps[("daily_summary", d[2])] == "not_worn"
    assert gaps[("daily_summary", d[3])] == "no_data"
    # el dispositivo dejó de enviar al final del período: ayer también figura como hueco
    assert gaps[("daily_summary", d[5])] == "no_data"


def test_serie_que_deja_de_llegar_es_un_hueco_abierto(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    start = (datetime.now(timezone.utc) - timedelta(hours=20)).replace(microsecond=0)
    series = {"series": [{"metric": "heart_rate", "unit": "bpm", "device_id": "ACME-SN1",
                          "start": start.isoformat().replace("+00:00", "Z"), "offsets_ms": [0, 60000],
                          "values": [60, 61]}]}
    r = client.post(f"{API}/partner/links/{link_id}/samples", headers=p.auth, json=series)
    partner_jobs.process_ingest_job(r.json()["job_id"])
    gaps = client.get(f"{API}/partner/links/{link_id}/sync-state", headers=p.auth).json()["gaps"]
    assert any(g["metric"] == "samples:heart_rate" and g.get("open") for g in gaps)


# --- Datos que llegan tarde: el final no lo pisa un partial ---------------------------------------------------

def test_partial_tardio_no_pisa_el_final_pero_un_final_si_corrige(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    url = f"{API}/partner/links/{link_id}/daily-summaries"
    assert client.post(url, headers=p.auth, json={"summaries": [
        summary("d-final", "2026-09-01", completeness="final", steps=9000)]}).json()["accepted"] == 1
    r = client.post(url, headers=p.auth, json={"summaries": [
        summary("d-tarde", "2026-09-01", completeness="partial", steps=3000)]})
    body = r.json()
    assert body["accepted"] == 0 and body["rejected"] == 1
    assert body["results"][0]["status"] == "rejected" and "stale" in body["results"][0]["errors"][0]["message"]
    doc = MOCK[SANDBOX]["metrics"].find_one({"link_id": link_id, "partner_kind": "daily_summary"})
    assert doc["partner_summary"]["steps"] == 9000
    # una corrección válida (final sobre final) sí se aplica
    r = client.post(url, headers=p.auth, json={"summaries": [
        summary("d-corr", "2026-09-01", completeness="final", steps=9100)]})
    assert r.json()["results"][0]["status"] == "updated"
    assert MOCK[SANDBOX]["metrics"].find_one({"link_id": link_id})["partner_summary"]["steps"] == 9100


def test_regla_final_gana_tambien_con_escritura_simultanea():
    # carrera: la lectura previa no ve el final que otra petición acaba de guardar
    col = MOCK["race-final"]["metrics"]
    col.drop()
    col.create_index([("link_id", 1), ("record_key", 1)], unique=True)
    now = datetime.now(timezone.utc)
    col.insert_one({"link_id": "l", "record_key": "ds:D:2026-09-01", "payload_hash": "final", "completeness": "final",
                    "created_at": now})

    class Ciega:
        def __init__(self, real):
            self.real = real

        def find(self, *a, **k):
            return []

        def __getattr__(self, name):
            return getattr(self.real, name)

    results = [None]
    doc = {"link_id": "l", "record_key": "ds:D:2026-09-01", "payload_hash": "partial", "completeness": "partial",
           "received_at": now}
    ingest._upsert(Ciega(col), "l", [(0, "r", doc)], results, stale=ingest._final_wins, guard=ingest._final_guard)
    assert results[0]["status"] == "rejected"
    assert col.find_one({"link_id": "l"})["payload_hash"] == "final"


# --- Puntuaciones por día local ----------------------------------------------------------------------------

def test_sesion_cerca_de_medianoche_cuenta_en_el_dia_local(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    # 22:30 UTC del 1 de septiembre son las 00:30 del 2 en UTC+2
    r = client.post(f"{API}/partner/links/{link_id}/sessions", headers=p.auth, json={"sessions": [
        {"session_type": "exercise", "record_id": "e-noche", "device_id": "ACME-SN1", "tz_offset_minutes": 120,
         "start": "2026-09-01T22:30:00Z", "end": "2026-09-01T23:10:00Z", "activity_type": "walking"}]})
    assert r.json()["accepted"] == 1, r.text
    workout = MOCK[SANDBOX]["patient_wearable_workouts"].find_one({"link_id": link_id})
    assert workout["local_date"] == "2026-09-02"
    client.post(f"{API}/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("d1", "2026-09-01", tz_offset_minutes=120, wear_time_minutes=1380),
        summary("d2", "2026-09-02", tz_offset_minutes=120, wear_time_minutes=1380)]})
    days = client.get(f"{API}/partner/links/{link_id}/scores", headers=p.auth,
                      params={"from_date": "2026-09-01", "to_date": "2026-09-02", "types": "adherence"}).json()["days"]
    by_day = {d["local_date"]: d["adherence"] for d in days}
    assert by_day["2026-09-02"] > by_day["2026-09-01"]


def test_zona_horaria_del_vinculo_si_el_registro_no_trae_offset(client, mailbox):
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
    try:
        ZoneInfo("America/Santiago")
    except ZoneInfoNotFoundError:
        pytest.fail("Falta la base de datos de zonas horarias. En Windows: pip install -r requirements-dev.txt "
                    "(instala tzdata)")
    p = Partner(client, mailbox)
    r = client.post(f"{API}/partner/sandbox/patients", json={}, headers=p.auth)
    link = client.post(f"{API}/partner/links", headers=p.auth, json={
        "pairing_code": r.json()["pairing_code"], "external_user_id": "tz", "timezone": "America/Santiago"}).json()
    client.post(f"{API}/partner/links/{link['link_id']}/device-events", headers=p.auth, json={"events": [
        {"record_id": "ev", "device_id": "D", "timestamp": "2026-09-02T02:00:00Z", "event_type": "worn"}]})
    # 02:00 UTC del 2 de septiembre son las 22:00 del 1 en Santiago
    assert MOCK[SANDBOX]["device_events"].find_one({"link_id": link["link_id"]})["local_date"] == "2026-09-01"


# --- Frecuencia semanal de los ejercicios -------------------------------------------------------------------

def test_objetivos_entregan_la_frecuencia_semanal(client, mailbox):
    p, patient, _, link_id = _real_link(client, mailbox)
    tdb = MOCK[TENANT_DB]
    tdb["program_templates"].insert_one({"template_id": "tpl-1", "exercises": [
        {"exercise_id": "EJ-1", "sets": 3, "reps": 10, "sessions_per_week": 4},
        {"exercise_id": "EJ-2", "sets": 2, "reps": 12},
        {"exercise_id": "EJ-3", "sets": 2, "reps": 8}]})
    tdb["patient_programs"].insert_one({"patient_id": patient["patient_id"], "template_ids": ["tpl-1"],
                                        "active_until": None})
    tdb["patient_goals"].insert_one({"patient_id": patient["patient_id"],
                                     "health_goals": {"exercise_target_count_week": 3},
                                     "metric_goals": [{"metric_type": "EJ-2", "target_exercises_per_week": 5}]})
    r = client.get(f"{API}/partner/links/{link_id}/goals", headers=p.auth)
    assert r.status_code == 200, r.text
    freq = {e["wellq_exercise_code"]: (e["target_sessions_per_week"], e["frequency_source"])
            for e in r.json()["prescribed_exercises"]}
    assert freq == {"EJ-1": (4, "exercise"), "EJ-2": (5, "metric_goal"), "EJ-3": (3, "health_goal")}


# --- Aprobación de fabricantes ------------------------------------------------------------------------------

def test_aprobacion_bloqueada_si_falta_el_checklist(client, mailbox):
    p = Partner(client, mailbox)
    r = client.post(f"{API}/partner/apps/{p.app_id}/promotion-requests", headers=p.portal,
                    json={"dpa_accepted": True, "security_contact_email": "s@acme-wearables.com"})
    assert r.status_code == 202
    assert r.json()["checklist_complete"] is False
    assert set(r.json()["missing"]) == {"device_models_declared", "webhook_tested", "privacy_policy_url"}
    req_id = r.json()["request_id"]
    r = client.post(f"{API}/partner/admin/promotion-requests/{req_id}/approve", headers=make_admin())
    assert r.status_code == 409 and r.json()["type"].endswith("/checklist-incomplete")
    assert repo.apps().find_one({"app_id": p.app_id})["environment"] == "sandbox"
    from conftest import complete_checklist
    complete_checklist(p)
    r = client.post(f"{API}/partner/admin/promotion-requests/{req_id}/approve", headers=make_admin())
    assert r.status_code == 200, r.text


# --- Lo que ve el clínico: MSK, prioridad de fuentes y respuestas cortadas ----------------------------------

def test_clinico_ve_mediciones_msk_y_sesiones(client, mailbox):
    p, patient, clinician, link_id = _real_link(client, mailbox)
    client.post(f"{API}/partner/links/{link_id}/msk-measurements", headers=p.auth, json={"measurements": [
        {"record_id": "m-1", "device_id": "ACME-SN1", "timestamp": "2026-09-02T09:14:00Z",
         "measurement_type": "range_of_motion_flexion", "body_region": "knee", "side": "right", "value": 2.07,
         "unit": "rad", "context": "prescribed_exercise"}]})
    base = f"{API}/maindash/patient/{patient['patient_id']}/wearables/data"
    r = client.get(f"{base}/msk-measurements", headers=clinician["headers"], params={
        "from_timestamp": "2026-09-01T00:00:00Z", "to_timestamp": "2026-09-03T00:00:00Z", "body_regions": "knee"})
    assert r.status_code == 200, r.text
    item = r.json()["items"][0]
    assert item["unit"] == "deg" and round(item["value"], 1) == 118.6 and item["side"] == "right"
    assert r.json()["truncated"] is False
    # el propio paciente también las ve
    assert client.get(f"{API}/wearables/data/msk-measurements", headers=patient["headers"], params={
        "from_timestamp": "2026-09-01T00:00:00Z", "to_timestamp": "2026-09-03T00:00:00Z"}).json()["items"]


def test_prioridad_de_fuentes_configurable_y_aviso_de_corte(client, mailbox, monkeypatch):
    clinician = make_clinician()
    patient = make_patient(care_clinician=clinician["oid"])
    partners, links_ = [], []
    for name in ("A", "B"):
        p = Partner(client, mailbox, name)
        promote(client, p)
        code = client.post(f"{API}/wearables/pairing-codes", headers=patient["headers"], json={
            "app_id": p.app_id, "scopes": ["ingest:activity"], "consent_doc_version": "wearable-sharing-v1"}).json()
        link_id = client.post(f"{API}/partner/links", headers=p.auth, json={
            "pairing_code": code["pairing_code"], "external_user_id": f"u-{name}"}).json()["link_id"]
        partners.append(p)
        links_.append(link_id)
    client.post(f"{API}/partner/links/{links_[0]}/daily-summaries", headers=partners[0].auth,
                json={"summaries": [summary("a", "2026-09-01", steps=1000)]})
    client.post(f"{API}/partner/links/{links_[1]}/daily-summaries", headers=partners[1].auth,
                json={"summaries": [summary("b", "2026-09-01", steps=2000)]})
    base = f"{API}/maindash/patient/{patient['patient_id']}/wearables"
    params = {"from_date": "2026-09-01", "to_date": "2026-09-01", "types": "steps"}
    r = client.put(f"{base}/{links_[1]}/source-priority", headers=clinician["headers"], json={"source_priority": 90})
    assert r.status_code == 200, r.text
    assert client.get(f"{base}/data/statistics/daily", headers=clinician["headers"], params=params
                      ).json()["items"][0]["steps"] == 2000
    client.put(f"{base}/{links_[0]}/source-priority", headers=clinician["headers"], json={"source_priority": 100})
    r = client.get(f"{base}/data/statistics/daily", headers=clinician["headers"], params=params)
    assert r.json()["items"][0]["steps"] == 1000 and r.json()["truncated"] is False
    # si un límite corta la respuesta, se avisa
    import app.api.v1.routers.partner_data as data_router
    monkeypatch.setattr(data_router, "RECORDS_LIMIT", 1)
    r = client.get(f"{base}/data/records", headers=clinician["headers"], params={
        "from_timestamp": "2026-08-30T00:00:00Z", "to_timestamp": "2026-09-03T00:00:00Z"})
    assert r.json()["truncated"] is True and len(r.json()["items"]) == 1


# --- Consentimiento y emparejamiento ------------------------------------------------------------------------

def test_consentimiento_exige_la_version_vigente(client, mailbox):
    p = Partner(client, mailbox)
    promote(client, p)
    patient = make_patient()
    MOCK[TENANT_DB]["legal_docs"].update_one({"version": "wearable-sharing-v1"},
                                             {"$set": {"created_at": datetime(2026, 1, 1, tzinfo=timezone.utc)}})
    MOCK[TENANT_DB]["legal_docs"].insert_one({"type": "wearable_sharing", "version": "wearable-sharing-v2",
                                             "path": "legal/v2.pdf", "created_at": datetime(2026, 10, 1, tzinfo=timezone.utc)})
    info = client.get(f"{API}/wearables/consent-info", params={"app_id": p.app_id}, headers=patient["headers"]).json()
    assert info["consent_doc"]["version"] == "wearable-sharing-v2"
    body = {"app_id": p.app_id, "scopes": ["ingest:activity"]}
    r = client.post(f"{API}/wearables/pairing-codes", headers=patient["headers"],
                    json={**body, "consent_doc_version": "wearable-sharing-v1"})
    assert r.status_code == 409 and r.json()["current_version"] == "wearable-sharing-v2"
    r = client.post(f"{API}/wearables/pairing-codes", headers=patient["headers"],
                    json={**body, "consent_doc_version": "wearable-sharing-v2"})
    assert r.status_code == 201
    link = client.post(f"{API}/partner/links", headers=p.auth, json={
        "pairing_code": r.json()["pairing_code"], "external_user_id": "u"}).json()
    assert link["consent"]["doc_version"] == "wearable-sharing-v2" and link["consent"]["revoked_at"] is None
    client.delete(f"{API}/wearables/links/{link['link_id']}", headers=patient["headers"])
    stored = repo.links().find_one({"link_id": link["link_id"]})
    assert stored["consent"]["revoked_at"] is not None and stored["consent"]["linked_at"] is not None


def test_emparejamiento_reanudable_sin_gastar_el_codigo_dos_veces(client, mailbox):
    p = Partner(client, mailbox)
    code = client.post(f"{API}/partner/sandbox/patients", json={}, headers=p.auth).json()["pairing_code"]
    # falla a mitad (después de canjear el código): el código vuelve a quedar disponible
    import app.api.v1.routers.partner_links as links_router
    real = repo.col("partner_links", majority=True)
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(links_router.repo, "links", lambda: _SinInsert(real))
        r = client.post(f"{API}/partner/links", headers=p.auth, json={"pairing_code": code, "external_user_id": "u-1"})
    assert r.status_code == 500
    assert repo.pairing_codes().find_one({"used_at": None}) is not None
    r = client.post(f"{API}/partner/links", headers=p.auth, json={"pairing_code": code, "external_user_id": "u-1"})
    assert r.status_code == 201, r.text
    link_id = r.json()["link_id"]
    # la respuesta se perdió y el fabricante reintenta con el mismo código: recibe el mismo vínculo
    r = client.post(f"{API}/partner/links", headers=p.auth, json={"pairing_code": code, "external_user_id": "u-1"})
    assert r.status_code == 200 and r.json()["link_id"] == link_id
    # con otro external_user_id el código ya no vale
    r = client.post(f"{API}/partner/links", headers=p.auth, json={"pairing_code": code, "external_user_id": "u-2"})
    assert r.status_code == 404


class _SinInsert:
    """Colección de vínculos cuyo insert falla: simula una caída a mitad del emparejamiento."""

    def __init__(self, real):
        self.real = real

    def insert_one(self, *a, **k):
        raise RuntimeError("caída")

    def __getattr__(self, name):
        return getattr(self.real, name)


# --- Eliminación de datos con cargas en curso ---------------------------------------------------------------

def test_borrado_cancela_cargas_en_cola_y_no_reaparecen_datos(client, mailbox):
    p, patient, clinician, link_id = _real_link(client, mailbox)
    series = {"series": [{"metric": "heart_rate", "unit": "bpm", "device_id": "ACME-SN1",
                          "start": "2026-09-02T05:00:00Z", "offsets_ms": [0, 60000], "values": [61, 63]}]}
    job_id = client.post(f"{API}/partner/links/{link_id}/samples", headers=p.auth, json=series).json()["job_id"]
    link = repo.links().find_one({"link_id": link_id}, {"_id": 0})

    r = client.delete(f"{API}/wearables/links/{link_id}?delete_data=true", headers=patient["headers"])
    assert r.status_code == 204
    assert repo.ingest_jobs().find_one({"job_id": job_id})["status"] == "cancelled"
    assert partner_jobs.process_ingest_job(job_id) is None
    # una carga síncrona que validó el vínculo antes del borrado no deja nada escrito
    from app.models.partner import DailySummary
    with pytest.raises(ingest.LinkClosed):
        ingest.ingest_daily_summaries({"_scopes": {"ingest:activity"}}, link,
                                      [DailySummary.model_validate(summary("tarde", "2026-09-03"))])
    assert MOCK[TENANT_DB]["metrics"].count_documents({"link_id": link_id}) == 0

    status = client.get(f"{API}/wearables/links/{link_id}/deletion", headers=patient["headers"])
    assert status.status_code == 200 and status.json()["status"] == "pending"
    assert client.get(f"{API}/wearables/links", headers=patient["headers"]).json()[0]["deletion"]["status"] == "pending"
    req = link_service.run_deletion(status.json()["request_id"])
    assert req["status"] == "done"
    r = client.get(f"{API}/maindash/patient/{patient['patient_id']}/wearables/{link_id}/deletion",
                   headers=clinician["headers"])
    assert r.json()["status"] == "done" and r.json()["completed_at"]


def test_borrado_espera_a_la_carga_que_se_esta_procesando(client, mailbox):
    p, patient, _, link_id = _real_link(client, mailbox)
    now = datetime.now(timezone.utc)
    repo.ingest_jobs().insert_one({"job_id": "job_busy", "link_id": link_id, "app_id": p.app_id, "status": "processing",
                                   "lease_until": now + timedelta(minutes=5), "received_at": now})
    client.delete(f"{API}/wearables/links/{link_id}?delete_data=true", headers=patient["headers"])
    status = client.get(f"{API}/wearables/links/{link_id}/deletion", headers=patient["headers"]).json()
    assert status["status"] == "waiting_ingest"
    repo.ingest_jobs().update_one({"job_id": "job_busy"}, {"$set": {"status": "completed", "lease_until": None}})
    assert link_service.run_deletion(status["request_id"])["status"] == "pending"
    assert link_service.run_deletion(status["request_id"])["status"] == "done"


# --- Avisos y borrados pendientes: plazos y alertas ---------------------------------------------------------

def test_alertas_de_borrados_vencidos_y_avisos_no_entregados(client, mailbox, monkeypatch):
    monkeypatch.setattr(conf, "PARTNER_ALERT_EMAIL", "ops@wellq.test")
    p = Partner(client, mailbox)
    now = datetime.now(timezone.utc)
    repo.deletion_requests().insert_one({"request_id": "del_old", "link_id": "lnk_x", "app_id": p.app_id,
                                         "status": "failed", "attempts": 6, "requested_at": now - timedelta(days=5),
                                         "deadline_at": now - timedelta(days=2), "next_attempt_at": now})
    repo.webhook_deliveries().insert_one({"delivery_id": "dlv_x", "app_id": p.app_id, "event_type": "link.revoked",
                                          "event_id": "evt_x", "status": "failed", "attempt": 8, "created_at": now})
    repo.ingest_jobs().insert_one({"job_id": "job_old", "app_id": p.app_id, "link_id": "lnk_x", "status": "queued",
                                   "received_at": now - timedelta(hours=3), "lease_until": None})
    assert alerts.check_overdue() == {"deletions": 1, "webhooks": 1, "ingest_jobs": 1}
    # cada alerta sale una sola vez
    assert alerts.check_overdue() == {"deletions": 0, "webhooks": 0, "ingest_jobs": 0}
    subjects = [m["subject"] for m in mailbox]
    assert sum("alerta" in s for s in subjects) == 3 and "WellQ: aviso no entregado" in subjects
    r = client.get(f"{API}/partner/admin/alerts", headers=make_admin())
    assert r.status_code == 200
    assert r.json()["deletions"][0]["overdue"] is True
    assert r.json()["undelivered_webhooks"][0]["delivery_id"] == "dlv_x"
    assert r.json()["stuck_ingest_jobs"][0]["job_id"] == "job_old"


def test_cron_check_overdue_registrado():
    from app.main import _jobs
    assert "check-overdue" in _jobs()
    vercel = json.loads((__import__("pathlib").Path(__file__).resolve().parents[2] / "vercel.json").read_text())
    assert any(c["path"].endswith("/check-overdue") for c in vercel["crons"])


# --- Alta del fabricante con correo fallido -----------------------------------------------------------------

def test_alta_con_correo_fallido_se_puede_retomar(client, mailbox, monkeypatch):
    import app.services.mailer as mailer
    sent = []
    monkeypatch.setattr(conf, "PARTNER_DEV_TOOLS_ENABLED", False)
    monkeypatch.setattr(mailer, "send_email_html", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("smtp")))
    body = {"company_name": "X", "contact_email": "fallo@acme-wearables.com", "country": "GB", "accept_terms": True}
    first = client.post(f"{API}/partner/developers/register", json=body)
    assert first.status_code == 202 and "verification_token" not in first.json()
    # vuelve el correo: repetir el alta reenvía un código; la respuesta es igual que la de un alta nueva
    monkeypatch.setattr(mailer, "send_email_html", lambda subject, to, html, text=None: sent.append(text))
    again = client.post(f"{API}/partner/developers/register", json=body)
    assert again.status_code == 202 and set(again.json()) == set(first.json())
    token = [line.split(": ")[1] for line in sent[-1].splitlines() if line.startswith("código")][0]
    r = client.post(f"{API}/partner/developers/verify", json={"developer_id": first.json()["developer_id"],
                                                             "verification_token": token})
    assert r.status_code == 200


# --- Significado de las métricas y límites de tamaño --------------------------------------------------------

def test_catalogo_explica_unidades_rangos_y_cero_frente_a_ausente(client, mailbox):
    p = Partner(client, mailbox)
    catalog = {m["metric"]: m for m in client.get(f"{API}/partner/capabilities/metrics", headers=p.auth).json()}
    for metric in ("sleep", "sleep_efficiency", "skin_temperature", "skin_temperature_deviation", "hrv_rmssd",
                   "hrv_sdnn"):
        entry = catalog[metric]
        assert entry["description"] and entry["zero_meaning"] and entry["missing_value"], metric
        assert entry["canonical_unit"] and "min" in entry["range"], metric
    assert catalog["skin_temperature_deviation"]["range"] == {"min": -10, "max": 10}
    assert catalog["skin_temperature"]["range"] == {"min": 20, "max": 45}


def test_limites_publicados_y_envio_justo_en_el_limite(client, mailbox):
    import asyncio

    from starlette.requests import Request

    from app.services.partner.problems import PartnerProblem, read_bounded_body
    p = Partner(client, mailbox)
    limits = client.get(f"{API}/partner/capabilities/limits", headers=p.auth).json()
    assert limits["body_bytes"]["samples"] == conf.PARTNER_MAX_SAMPLES_BODY_BYTES
    assert limits["body_bytes"]["measured_on"] == "wire"
    raw = json.dumps({"values": list(range(5000))}).encode()
    packed = gzip.compress(raw)
    assert len(raw) > len(packed)

    def leer(body: bytes, limit: int):
        async def receive():
            return {"type": "http.request", "body": body, "more_body": False}
        scope = {"type": "http", "method": "POST", "path": "/", "headers": [
            (b"content-length", str(len(body)).encode()), (b"content-encoding", b"gzip")]}
        return asyncio.run(read_bounded_body(Request(scope, receive), limit, 10 * len(raw)))

    # el tamaño se mide sobre lo que viaja (comprimido): justo en el límite se acepta, un byte menos de límite no
    assert leer(packed, len(packed)) == raw
    with pytest.raises(PartnerProblem) as exc:
        leer(packed, len(packed) - 1)
    assert exc.value.status == 413
