import pytest

import app.config as conf
from conftest import Partner


def test_salud_y_cabeceras_de_seguridad(client):
    r = client.get("/api/v1/health")
    assert r.status_code == 200 and r.json()["partner_api"] is True
    assert r.headers["x-content-type-options"] == "nosniff"
    assert "frame-ancestors 'none'" in r.headers["content-security-policy"]
    assert "strict-transport-security" in r.headers


def test_cron_protegido_por_secreto(client, monkeypatch):
    path = "/api/v1/internal/cron/deliver-webhooks"
    assert client.get(path).status_code == 404
    assert client.get(path, headers={"Authorization": "Bearer otro"}).status_code == 404
    r = client.get(path, headers={"Authorization": f"Bearer {conf.CRON_SECRET}"})
    assert r.status_code == 200 and r.json()["job"] == "deliver-webhooks"
    assert client.get("/api/v1/internal/cron/no-existe",
                      headers={"Authorization": f"Bearer {conf.CRON_SECRET}"}).status_code == 404
    monkeypatch.setattr(conf, "CRON_SECRET", "")
    assert client.get(path, headers={"Authorization": "Bearer "}).status_code == 404


def test_cron_procesa_jobs_pendientes(client, mailbox):
    from app.repositories import partner as repo
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers=p.auth, json={"series": [{
        "metric": "heart_rate", "unit": "bpm", "device_id": "D", "start": "2026-09-01T00:00:00Z",
        "offsets_ms": [0, 60000], "values": [60, 61]}]})
    job_id = r.json()["job_id"]
    from datetime import datetime, timedelta, timezone
    repo.ingest_jobs().update_one({"job_id": job_id}, {"$set": {"received_at": datetime.now(timezone.utc) - timedelta(minutes=5)}})
    r = client.get("/api/v1/internal/cron/sweep-ingest", headers={"Authorization": f"Bearer {conf.CRON_SECRET}"})
    assert r.status_code == 200 and r.json()["result"] == 1
    assert client.get(f"/api/v1/partner/ingest/jobs/{job_id}", headers=p.auth).json()["status"] == "completed"


def test_docs_solo_en_desarrollo(client):
    assert client.get("/docs").status_code == 200
    assert client.get("/api/v1/partner/links/x").headers["content-type"].startswith("application/problem+json")


def test_raiz_redirige_a_la_demo_en_desarrollo(client):
    r = client.get("/", follow_redirects=False)
    assert r.status_code == 307 and r.headers["location"].endswith("/api/v1/partner-demo/")


def test_trace_id_y_problem_json_fuera_de_partner(client):
    # D-04: /health y cron también devuelven X-Trace-Id, y el 404 de cron usa problem+json
    r = client.get("/api/v1/health")
    assert r.status_code == 200 and r.headers.get("X-Trace-Id")
    r = client.get("/api/v1/internal/cron/sweep-ingest")
    assert r.status_code == 404
    assert r.headers.get("X-Trace-Id")
    assert r.headers["content-type"].startswith("application/problem+json")
    assert r.json()["trace_id"] == r.headers["X-Trace-Id"]
    # el X-Request-Id del cliente se reutiliza también en las rutas /partner
    r = client.get("/api/v1/partner/links/x", headers={"X-Request-Id": "abc-123"})
    assert r.headers["X-Trace-Id"] == "abc-123" and r.json()["trace_id"] == "abc-123"


def test_cabecera_cross_origin_resource_policy(client):
    # D-08: ZAP marcaba la falta de Cross-Origin-Resource-Policy
    for path in ("/api/v1/health", "/api/v1/partner/links", "/api/v1/internal/cron/x"):
        assert client.get(path).headers.get("Cross-Origin-Resource-Policy") == "same-origin"


def test_allow_lista_todos_los_metodos_de_la_ruta(client, mailbox):
    # Schemathesis ST205 (D-06): el 405 debe anunciar todos los métodos que admite la URL
    p = Partner(client, mailbox)
    r = client.request("OPTIONS", f"/api/v1/partner/apps/{p.app_id}", headers=p.portal)
    assert r.status_code == 405
    assert set(r.headers["Allow"].split(", ")) == {"GET", "PATCH"}
    assert r.headers["content-type"].startswith("application/problem+json")
    r = client.request("OPTIONS", "/api/v1/partner/links", headers=p.auth)
    assert set(r.headers["Allow"].split(", ")) == {"GET", "POST"}


@pytest.mark.parametrize("types", ["", ",", " , "])
def test_estadisticas_sin_types_devuelven_422_y_no_500(client, types):
    from conftest import make_clinician, make_patient
    clinician = make_clinician()
    patient = make_patient(care_clinician=clinician["oid"])
    base = f"/api/v1/maindash/patient/{patient['patient_id']}"
    rango = {"from_date": "2026-09-01", "to_date": "2026-09-02", "types": types}
    casos = [
        ("/api/v1/wearables/data/statistics/daily", rango, patient["headers"]),
        ("/api/v1/wearables/data/statistics/interval", {"types": types}, patient["headers"]),
        (f"{base}/wearables/data/statistics/daily", rango, clinician["headers"]),
        (f"{base}/wearables/data/statistics/interval", {"types": types}, clinician["headers"]),
    ]
    for url, params, headers in casos:
        r = client.get(url, params=params, headers=headers)
        assert r.status_code == 422, (url, r.status_code, r.text)
        assert r.headers["content-type"].startswith("application/problem+json"), (url, r.text)


def test_patch_app_con_null_no_borra_nombre_ni_scopes(client, mailbox):
    p = Partner(client, mailbox)
    antes = client.get(f"/api/v1/partner/apps/{p.app_id}", headers=p.portal).json()
    assert antes["name"] and antes["requested_scopes"]
    r = client.patch(f"/api/v1/partner/apps/{p.app_id}", headers=p.portal,
                     json={"name": None, "requested_scopes": None, "description": None})
    assert r.status_code == 200, r.text
    despues = r.json()
    assert despues["name"] == antes["name"]
    assert despues["requested_scopes"] == antes["requested_scopes"]
    assert set(antes["requested_scopes"]) <= set(despues["granted_scopes"])
    assert despues["description"] is None
