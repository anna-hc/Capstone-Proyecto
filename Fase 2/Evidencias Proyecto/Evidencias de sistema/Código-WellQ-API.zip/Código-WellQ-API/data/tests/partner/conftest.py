import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import mongomock
import pytest
from bson import ObjectId
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import app.config as conf  # noqa: E402
import app.db as dbmod  # noqa: E402
import app.middleware.tenant_middleware as tm  # noqa: E402
from app.main import app as fastapi_app  # noqa: E402
from app.security import create_access_jwt  # noqa: E402
from app.services.partner import ratelimit, tenancy  # noqa: E402
from app.tasks import partner_jobs  # noqa: E402

MOCK = mongomock.MongoClient(tz_aware=True)

# mongomock no es seguro entre hilos: dos peticiones simultáneas pueden recorrer y modificar el mismo diccionario
# a la vez (RuntimeError, KeyError o un DuplicateKeyError suelto). En MongoDB cada operación es atómica; este cerrojo
# reproduce eso para que las pruebas de concurrencia midan la API y no un fallo del simulador. Pasaba sobre todo en
# Windows, donde los hilos se alternan de otra forma.
_MOCK_LOCK = threading.RLock()
_LOCKED_METHODS = ("insert_one", "insert_many", "update_one", "update_many", "replace_one", "delete_one",
                   "delete_many", "bulk_write", "find_one", "find_one_and_update", "find_one_and_replace",
                   "find_one_and_delete", "count_documents", "estimated_document_count", "distinct", "aggregate",
                   "create_index", "create_indexes", "drop", "drop_index", "drop_indexes")


def _locked(fn):
    def wrapper(*args, **kwargs):
        with _MOCK_LOCK:
            return fn(*args, **kwargs)
    wrapper.__wrapped__ = fn
    return wrapper


_orig_add_replace = mongomock.collection.BulkOperationBuilder.add_replace
_orig_add_update = mongomock.collection.BulkOperationBuilder.add_update


TENANT_SLUG = "clinica-test"
TENANT_DB = "tenant-test"


class Mailbox(list):
    def last_token(self):
        for msg in reversed(self):
            m = re.search(r"código: (\S+)", msg["text"])
            if m:
                return m.group(1)
        return None


@pytest.fixture(autouse=True)
def clean_state(monkeypatch):
    # todo el estado global se parchea por test y se restaura al terminar: no afecta al resto de la suite
    monkeypatch.setattr(mongomock.collection.BulkOperationBuilder, "add_replace",
                        lambda self, selector, doc, upsert, collation=None, **_: _orig_add_replace(self, selector, doc,
                                                                                                    upsert, collation))
    monkeypatch.setattr(mongomock.collection.BulkOperationBuilder, "add_update",
                        lambda self, selector, doc, multi, upsert, collation=None, array_filters=None, **_:
                        _orig_add_update(self, selector, doc, multi, upsert, collation, array_filters))
    for name in _LOCKED_METHODS:
        if hasattr(mongomock.collection.Collection, name):
            monkeypatch.setattr(mongomock.collection.Collection, name,
                                _locked(getattr(mongomock.collection.Collection, name)))
    monkeypatch.setattr(mongomock.collection.Cursor, "_compute_results",
                        _locked(mongomock.collection.Cursor._compute_results))
    monkeypatch.setattr(dbmod, "_client", MOCK)
    monkeypatch.setattr(dbmod, "_central_client", MOCK)
    monkeypatch.setattr(dbmod, "central_db", MOCK["central-test"])
    monkeypatch.setattr(dbmod, "db", MOCK[TENANT_DB])
    monkeypatch.setattr(tm, "_client", MOCK)
    monkeypatch.setattr(conf, "MONGO_DB", TENANT_DB)
    monkeypatch.setattr(conf, "APP_ENV", "test")
    monkeypatch.setattr(conf, "PARTNER_WEBHOOK_ALLOW_PRIVATE", True)
    monkeypatch.setattr(conf, "PARTNER_DEV_TOOLS_ENABLED", True)
    monkeypatch.setattr(conf, "PARTNER_DEMO_ENABLED", True)
    monkeypatch.setattr(ratelimit, "_redis", None)
    monkeypatch.setattr(ratelimit, "_redis_checked_at", time.time() + 10 ** 9)
    tenancy.use_tenant_resolver(lambda slug, name: MOCK[conf.PARTNER_SANDBOX_DB if slug == tenancy.SANDBOX_TENANT else name])
    for name in MOCK.list_database_names():
        MOCK.drop_database(name)
    dbmod.ensure_partner_indexes(dbmod.central_db)
    dbmod.ensure_partner_tenant_indexes(MOCK[TENANT_DB])
    dbmod.ensure_partner_tenant_indexes(MOCK[conf.PARTNER_SANDBOX_DB])
    MOCK[TENANT_DB]["patient_wearable_workouts"].create_index([("patient_id", 1), ("workout_id", 1)], unique=True)
    dbmod.central_db["tenants"].insert_one({"slug": TENANT_SLUG, "mongo_db": TENANT_DB, "status": "active", "name": "Test"})
    MOCK[TENANT_DB]["legal_docs"].insert_one({"type": "wearable_sharing", "version": "wearable-sharing-v1",
                                             "path": "legal/wearables-v1.pdf"})
    tm.clear_tenant_caches()
    ratelimit.reset_memory()
    monkeypatch.setattr(partner_jobs, "enqueue", lambda job_id: True)
    from app.services.partner import webhooks
    monkeypatch.setattr(webhooks, "kick", lambda: None)
    yield
    tenancy.use_tenant_resolver(None)
    tm.clear_tenant_caches()


@pytest.fixture
def mailbox(monkeypatch):
    box = Mailbox()

    def fake_send(subject, recipient, html_body, text_body=None):
        box.append({"subject": subject, "to": recipient, "text": text_body or html_body})

    import app.services.mailer as mailer
    monkeypatch.setattr(mailer, "send_email_html", fake_send)
    return box


@pytest.fixture
def client():
    return TestClient(fastapi_app, raise_server_exceptions=False)


class Receiver:
    def __init__(self, status=200):
        self.status = status
        self.calls = []
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
                outer.calls.append({"headers": dict(self.headers), "body": body})
                self.send_response(outer.status)
                self.end_headers()

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}/hook"

    def bodies(self):
        return [json.loads(c["body"]) for c in self.calls]

    def close(self):
        self.server.shutdown()


@pytest.fixture
def receiver():
    r = Receiver()
    yield r
    r.close()


def make_patient(tenant_db=TENANT_DB, care_clinician=None):
    oid = ObjectId()
    patient_id = "P-" + str(oid)[-12:].upper()
    MOCK[tenant_db]["patients"].insert_one({"_id": oid, "patient_id": patient_id, "first_name": "Ana", "state": "active",
                                            "care_clinician_id": care_clinician})
    token = create_access_jwt(sub=str(oid), extra={"roles": ["patient"], "scope": "mobile", "tenant_slug": TENANT_SLUG,
                                                   "patient_id": patient_id})
    return {"oid": oid, "patient_id": patient_id, "headers": {"Authorization": f"Bearer {token}", "x-tenant": TENANT_SLUG}}


def make_clinician():
    oid = ObjectId()
    token = create_access_jwt(sub=str(oid), extra={"roles": ["clinician"], "tenant_slug": TENANT_SLUG,
                                                   "subject": {"kind": "clinician", "id": str(oid)}})
    return {"oid": oid, "headers": {"Authorization": f"Bearer {token}", "x-tenant": TENANT_SLUG}}


def make_admin():
    token = create_access_jwt(sub=str(ObjectId()), extra={"roles": ["itadmin"], "tenant_slug": TENANT_SLUG})
    return {"Authorization": f"Bearer {token}"}


class Partner:
    """Fabricante de pruebas: desarrollador verificado, app de sandbox y token."""

    def __init__(self, client, mailbox, name="Acme", requested_scopes=None, scope=None):
        self.client = client
        email = f"dev-{ObjectId()}@acme-wearables.com"
        r = client.post("/api/v1/partner/developers/register", json={
            "company_name": name, "contact_email": email, "country": "GB", "accept_terms": True})
        assert r.status_code == 202, r.text
        self.developer_id = r.json()["developer_id"]
        r = client.post("/api/v1/partner/developers/verify", json={
            "developer_id": self.developer_id, "verification_token": mailbox.last_token()})
        assert r.status_code == 200, r.text
        self.portal = {"Authorization": f"Bearer {r.json()['portal_token']}"}
        body = {"name": f"{name} Cloud"}
        if requested_scopes is not None:
            body["requested_scopes"] = requested_scopes
        r = client.post("/api/v1/partner/apps", json=body, headers=self.portal)
        assert r.status_code == 201, r.text
        self.app = r.json()
        self.app_id = self.app["app_id"]
        self.secret = self.app["client_secret"]
        self.auth = self.token(scope)

    def token(self, scope=None, secret=None):
        data = {"grant_type": "client_credentials", "client_id": self.app["client_id"],
                "client_secret": secret or self.secret}
        if scope:
            data["scope"] = scope
        r = self.client.post("/api/v1/partner/oauth/token", data=data)
        assert r.status_code == 200, r.text
        return {"Authorization": f"Bearer {r.json()['access_token']}"}

    def device_model(self, code="ACME-BAND-2", capabilities=None):
        caps = capabilities or [{"metric": m} for m in (
            "steps", "distance", "heart_rate", "resting_heart_rate", "hrv_rmssd", "spo2", "sleep", "exercise",
            "weight", "body_fat", "range_of_motion_flexion", "isometric_force", "device_wear", "calories_active",
            "active_minutes")]
        r = self.client.post(f"/api/v1/partner/apps/{self.app_id}/device-models", json={
            "model_code": code, "display_name": "Acme Band 2", "form_factor": "band", "capabilities": caps},
            headers=self.auth)
        assert r.status_code == 201, r.text
        return code

    def sandbox_link(self, scopes=None, external_user_id=None, model_code=None):
        body = {"scopes": scopes} if scopes is not None else {}
        r = self.client.post("/api/v1/partner/sandbox/patients", json=body, headers=self.auth)
        assert r.status_code == 201, r.text
        link_body = {"pairing_code": r.json()["pairing_code"], "external_user_id": external_user_id or f"u-{ObjectId()}"}
        if model_code:
            link_body["model_code"] = model_code
        r2 = self.client.post("/api/v1/partner/links", json=link_body, headers=self.auth)
        assert r2.status_code == 201, r2.text
        return r2.json()["link_id"], r.json()["sandbox_patient_id"]


def complete_checklist(partner):
    """Deja la app con el checklist de producción completo (device-model, webhook probado y política de privacidad)."""
    import datetime as _dt
    now = _dt.datetime.now(_dt.timezone.utc)
    central = dbmod.central_db
    if not central["partner_device_models"].find_one({"app_id": partner.app_id}):
        central["partner_device_models"].insert_one({"app_id": partner.app_id, "model_code": "CHECKLIST-MODEL",
                                                     "display_name": "Checklist", "form_factor": "band",
                                                     "capabilities": [{"metric": "steps"}], "created_at": now})
    central["webhook_deliveries"].insert_one({"delivery_id": f"dlv_{ObjectId()}", "app_id": partner.app_id,
                                              "event_type": "ping", "status": "delivered", "created_at": now})
    central["partner_apps"].update_one({"app_id": partner.app_id, "privacy_policy_url": None},
                                       {"$set": {"privacy_policy_url": "https://acme-wearables.com/privacy"}})


def promote(client, partner):
    """Aprueba la app en producción y recupera credenciales nuevas."""
    complete_checklist(partner)
    req = client.post(f"/api/v1/partner/apps/{partner.app_id}/promotion-requests", headers=partner.portal,
                      json={"dpa_accepted": True, "security_contact_email": "s@acme-wearables.com"}).json()["request_id"]
    assert client.post(f"/api/v1/partner/admin/promotion-requests/{req}/approve", headers=make_admin()).status_code == 200
    partner.secret = client.post(f"/api/v1/partner/apps/{partner.app_id}/secrets/rotate", headers=partner.portal,
                                 json={"grace_period_seconds": 0}).json()["client_secret"]
    partner.auth = partner.token()


def summary(record_id="d-1", day="2026-09-01", **fields):
    base = {"record_id": record_id, "local_date": day, "tz_offset_minutes": 60, "device_id": "ACME-SN1",
            "completeness": "final", "steps": 7412}
    base.update(fields)
    return base
