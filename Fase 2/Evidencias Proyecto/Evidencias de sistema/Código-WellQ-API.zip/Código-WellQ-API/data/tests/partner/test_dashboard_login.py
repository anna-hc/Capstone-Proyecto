import re

import pytest

import app.config as conf
from app import dashboard_auth
from app.services.partner import ratelimit

USUARIO, CLAVE = "admin-panel", "clave-de-prueba-muy-larga"
SECCIONES = ["/", "/docs", "/openapi.json", "/api/v1/partner-demo/", "/api/v1/partner-demo/demo.js",
             "/api/v1/partner-dev/webhook-sink"]


@pytest.fixture
def login_activo(monkeypatch):
    monkeypatch.setattr(conf, "DASHBOARD_LOGIN_DISABLED", False)
    monkeypatch.setattr(conf, "DASHBOARD_USER", USUARIO)
    monkeypatch.setattr(conf, "DASHBOARD_PASSWORD_HASH", dashboard_auth.hash_password(CLAVE, iterations=1000))
    monkeypatch.setattr(conf, "DASHBOARD_SESSION_SECRET", "s" * 40)
    ratelimit.reset_memory()
    yield
    ratelimit.reset_memory()


def _csrf(client):
    r = client.get("/login")
    assert r.status_code == 200
    return re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)


def _entrar(client, usuario=USUARIO, clave=CLAVE, siguiente="/api/v1/partner-demo/"):
    return client.post("/login", data={"csrf": _csrf(client), "username": usuario, "password": clave, "next": siguiente},
                       follow_redirects=False)


def test_sin_sesion_cada_seccion_redirige_o_responde_401(client, login_activo):
    for ruta in SECCIONES:
        r = client.get(ruta, headers={"accept": "text/html"}, follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"].startswith("/login?next="), ruta
        r = client.get(ruta, headers={"accept": "application/json"}, follow_redirects=False)
        assert r.status_code == 401, ruta
    assert client.post("/api/v1/partner-dev/admin-session").status_code == 401


def test_la_api_de_fabricantes_health_y_cron_no_piden_login(client, login_activo):
    assert client.get("/api/v1/health").status_code == 200
    assert client.get("/api/v1/partner/links").status_code == 401  # su propio token, no el login del panel
    assert "problem+json" in client.get("/api/v1/partner/links").headers["content-type"]
    r = client.get("/api/v1/internal/cron/sweep-ingest", headers={"Authorization": "Bearer test-only-cron-secret"})
    assert r.status_code == 200
    # el receptor de webhooks de prueba lo llama el servidor sin sesión
    assert client.post("/api/v1/partner-dev/webhook-sink", json={"ping": 1}).status_code != 401


def test_login_correcto_da_acceso_a_todas_las_secciones(client, login_activo):
    r = _entrar(client)
    assert r.status_code == 303 and r.headers["location"] == "/api/v1/partner-demo/"
    cookie = r.cookies.get(dashboard_auth.SESSION_COOKIE)
    assert cookie
    assert "httponly" in r.headers["set-cookie"].lower() and "samesite=lax" in r.headers["set-cookie"].lower()
    for ruta in ["/docs", "/openapi.json", "/api/v1/partner-demo/", "/api/v1/partner-demo/demo.css"]:
        assert client.get(ruta).status_code == 200, ruta
    assert client.get("/", follow_redirects=False).status_code == 307
    assert client.post("/api/v1/partner-dev/admin-session").status_code == 200


def test_contrasena_o_usuario_incorrectos(client, login_activo):
    for usuario, clave in ((USUARIO, "otra-clave"), ("otro", CLAVE), ("", "")):
        r = _entrar(client, usuario, clave)
        assert r.status_code == 401
        assert "Usuario o contraseña incorrectos." in r.text
        assert dashboard_auth.SESSION_COOKIE not in r.cookies
    assert client.get("/docs", follow_redirects=False).status_code == 401


def test_formulario_sin_csrf_valido_se_rechaza(client, login_activo):
    _csrf(client)
    r = client.post("/login", data={"csrf": "falso", "username": USUARIO, "password": CLAVE}, follow_redirects=False)
    assert r.status_code == 403 and dashboard_auth.SESSION_COOKIE not in r.cookies


def test_logout_cierra_la_sesion(client, login_activo):
    _entrar(client)
    pagina = client.get("/logout")
    token = re.search(r'name="csrf" value="([^"]+)"', pagina.text).group(1)
    assert client.post("/logout", data={"csrf": "otro"}, follow_redirects=False).status_code == 403
    r = client.post("/logout", data={"csrf": token}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/login"
    client.cookies.clear()
    assert client.get("/docs", follow_redirects=False).status_code == 401


def test_cookie_manipulada_o_caducada_se_rechaza(client, login_activo):
    valida = dashboard_auth.make_session(USUARIO)
    payload, firma = valida.split(".")
    otra = dashboard_auth._b64(f"intruso|9999999999|x".encode())
    for cookie in (payload + "." + firma[:-2] + "AA", otra + "." + firma, "basura", dashboard_auth.make_session(USUARIO, now=0)):
        client.cookies.set(dashboard_auth.SESSION_COOKIE, cookie)
        assert client.get("/docs", follow_redirects=False).status_code == 401
    # cambiar la contraseña invalida las sesiones abiertas
    client.cookies.set(dashboard_auth.SESSION_COOKIE, valida)
    assert client.get("/docs").status_code == 200
    conf.DASHBOARD_PASSWORD_HASH = dashboard_auth.hash_password("nueva-clave-larga", iterations=1000)
    assert client.get("/docs", follow_redirects=False).status_code == 401


def test_limite_de_intentos(client, login_activo):
    for _ in range(conf.DASHBOARD_LOGIN_RPM_PER_IP):
        assert _entrar(client, clave="mal").status_code == 401
    r = _entrar(client)
    assert r.status_code == 429 and int(r.headers["retry-after"]) >= 1


def test_redireccion_solo_a_rutas_locales(client, login_activo):
    for destino in ("https://evil.example", "//evil.example", "/\\evil.example"):
        ratelimit.reset_memory()
        client.cookies.clear()
        r = _entrar(client, siguiente=destino)
        assert r.status_code == 303 and r.headers["location"] == "/"


def test_sin_configuracion_queda_cerrado(client, monkeypatch):
    monkeypatch.setattr(conf, "DASHBOARD_LOGIN_DISABLED", False)
    monkeypatch.setattr(conf, "DASHBOARD_USER", "")
    assert client.get("/docs").status_code == 503
    assert client.get("/login").status_code == 503
    # la excepción para desarrollo local no vale en Vercel
    monkeypatch.setattr(conf, "DASHBOARD_LOGIN_DISABLED", True)
    monkeypatch.setenv("VERCEL", "1")
    assert client.get("/docs").status_code == 503


def test_tolera_espacios_saltos_y_comillas_al_copiar(client, login_activo, monkeypatch):
    monkeypatch.setattr(conf, "DASHBOARD_USER", f'  "{USUARIO}"\r\n')
    monkeypatch.setattr(conf, "DASHBOARD_PASSWORD_HASH", f"'{conf.DASHBOARD_PASSWORD_HASH}'\n")
    monkeypatch.setattr(conf, "DASHBOARD_SESSION_SECRET", ' "' + "s" * 40 + '" ')
    assert dashboard_auth.config_problems() == []
    assert _entrar(client).status_code == 303
    assert client.get("/docs").status_code == 200


def test_pagina_503_nombra_lo_que_falta_sin_mostrar_valores(client, login_activo, monkeypatch):
    monkeypatch.setattr(conf, "DASHBOARD_PASSWORD_HASH", "texto-pegado-sin-formato")
    monkeypatch.setattr(conf, "DASHBOARD_SESSION_SECRET", "corto-secreto")
    r = client.get("/docs")
    assert r.status_code == 503
    assert "DASHBOARD_PASSWORD_HASH con formato inválido" in r.text
    assert "DASHBOARD_SESSION_SECRET tiene 13 caracteres" in r.text
    assert "texto-pegado-sin-formato" not in r.text and "corto-secreto" not in r.text
    # fuera de desarrollo la página no da detalles (quedan solo en el log)
    monkeypatch.setattr(conf, "APP_ENV", "production")
    assert "DASHBOARD_" not in dashboard_auth._no_configurado().body.decode()


def test_hash_de_contrasena():
    h = dashboard_auth.hash_password("una-clave", iterations=1000)
    assert h.startswith("pbkdf2_sha256$1000$") and "una-clave" not in h
    assert dashboard_auth.verify_password("una-clave", h)
    assert not dashboard_auth.verify_password("otra", h)
    assert not dashboard_auth.verify_password("una-clave", "md5$x$y$z")
