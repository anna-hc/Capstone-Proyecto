import re

import pytest

import app.config as conf

BASE = "/api/v1/partner-demo/presentacion/"
FILES = {"": "text/html", "index.html": "text/html", "presentacion.js": "text/javascript",
         "presentacion.css": "text/css"}


@pytest.mark.parametrize("name,ctype", FILES.items())
def test_presentacion_responde_con_la_demo_habilitada(client, name, ctype):
    r = client.get(BASE + name)
    assert r.status_code == 200
    assert r.headers["content-type"].startswith(ctype)
    assert r.headers["cache-control"] == "no-store"
    assert r.headers["x-frame-options"] == "DENY"


def test_presentacion_sin_barra_redirige(client):
    r = client.get("/api/v1/partner-demo/presentacion", follow_redirects=False)
    assert r.status_code == 307 and r.headers["location"].endswith("presentacion/")


def test_presentacion_csp_sin_cdn_ni_scripts_en_linea(client):
    r = client.get(BASE)
    csp = r.headers["content-security-policy"]
    for directive in ("default-src 'none'", "script-src 'self'", "style-src 'self'", "connect-src 'self'",
                      "frame-ancestors 'none'", "base-uri 'none'", "form-action 'none'"):
        assert directive in csp
    assert "unsafe-inline" not in csp and "http" not in csp
    html = r.text
    # sin scripts en línea, sin estilos en línea y sin recursos de otros orígenes
    assert not re.search(r"<script(?![^>]*\bsrc=)", html)
    assert "style=" not in html and "<style" not in html
    assert not re.search(r"(src|href)=\"(https?:)?//", html)
    assert 'src="presentacion.js"' in html and 'href="presentacion.css"' in html


def test_presentacion_no_existe_si_la_demo_esta_deshabilitada(client, monkeypatch):
    monkeypatch.setattr(conf, "PARTNER_DEMO_ENABLED", False)
    for name in FILES:
        assert client.get(BASE + name).status_code == 404
    assert client.get("/api/v1/partner-demo/presentacion", follow_redirects=False).status_code == 404


def test_presentacion_no_existe_en_produccion(client, monkeypatch):
    monkeypatch.setattr(conf, "APP_ENV", "production")
    for name in FILES:
        assert client.get(BASE + name).status_code == 404


def test_presentacion_solo_sirve_sus_archivos(client):
    for name in ("demo.js", "..%2Findex.html", "secreto.txt", "presentacion.py"):
        assert client.get(BASE + name).status_code == 404


def test_presentacion_pide_login_si_esta_activo(client, monkeypatch):
    from app import dashboard_auth
    monkeypatch.setattr(conf, "DASHBOARD_LOGIN_DISABLED", False)
    monkeypatch.setattr(conf, "DASHBOARD_USER", "admin-panel")
    monkeypatch.setattr(conf, "DASHBOARD_PASSWORD_HASH", dashboard_auth.hash_password("clave-de-prueba-larga", iterations=1000))
    monkeypatch.setattr(conf, "DASHBOARD_SESSION_SECRET", "s" * 40)
    for name in ("", "presentacion.js"):
        r = client.get(BASE + name, headers={"accept": "text/html"}, follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"].startswith("/login?next="), name
        r = client.get(BASE + name, headers={"accept": "application/json"}, follow_redirects=False)
        assert r.status_code == 401, name
    r = client.post("/login", data={"csrf": _csrf(client), "username": "admin-panel", "password": "clave-de-prueba-larga",
                                    "next": BASE}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == BASE
    assert client.get(BASE).status_code == 200


def _csrf(client):
    r = client.get("/login")
    return re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)


def test_la_demo_enlaza_la_presentacion(client):
    r = client.get("/api/v1/partner-demo/")
    assert r.status_code == 200 and 'href="presentacion/"' in r.text


def test_el_js_no_usa_innerhtml_ni_otros_origenes():
    from pathlib import Path
    js = (Path(__file__).resolve().parents[2] / "app" / "partner_demo" / "presentacion" / "presentacion.js").read_text("utf-8")
    assert "innerHTML" not in js and "eval(" not in js and "document.write" not in js
    assert not re.search(r"['\"`]https?://(?!acme-wearables\.example)", js)
