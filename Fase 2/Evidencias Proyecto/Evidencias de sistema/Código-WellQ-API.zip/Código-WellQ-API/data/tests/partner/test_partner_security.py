import gzip
import json
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import jwt
import pytest
from conftest import MOCK, TENANT_DB, Partner, make_admin, make_patient, summary

import app.config as conf
from app.repositories import partner as repo
from app.services.partner import ssrf, webhooks
from app.services.partner.security import verify_webhook_signature

SANDBOX = conf.PARTNER_SANDBOX_DB


def test_rutas_de_apps_exigen_autenticacion_y_propiedad(client, mailbox):
    a = Partner(client, mailbox, "A")
    b = Partner(client, mailbox, "B")
    for method, path in (("get", f"/api/v1/partner/apps/{a.app_id}"), ("patch", f"/api/v1/partner/apps/{a.app_id}"),
                         ("post", f"/api/v1/partner/apps/{a.app_id}/secrets/rotate"),
                         ("post", f"/api/v1/partner/apps/{a.app_id}/promotion-requests")):
        r = client.request(method.upper(), path, json={})
        assert r.status_code == 401, (method, path, r.status_code)
        assert r.headers["content-type"].startswith("application/problem+json") and r.json()["trace_id"]
    assert client.get(f"/api/v1/partner/apps/{a.app_id}", headers=b.portal).status_code == 404
    assert client.get(f"/api/v1/partner/apps/{a.app_id}", headers=b.auth).status_code == 404
    assert client.patch(f"/api/v1/partner/apps/{a.app_id}", json={"name": "x"}, headers=b.portal).status_code == 404
    assert client.post(f"/api/v1/partner/apps/{a.app_id}/secrets/rotate", headers=b.portal).status_code == 404
    r = client.post(f"/api/v1/partner/apps/{a.app_id}/promotion-requests", headers=b.portal,
                    json={"dpa_accepted": True, "security_contact_email": "x@b.com"})
    assert r.status_code == 404
    assert client.get("/api/v1/partner/links", headers=a.auth).status_code == 200


def test_bola_entre_fabricantes(client, mailbox, receiver):
    a = Partner(client, mailbox, "A")
    b = Partner(client, mailbox, "B")
    link_a, _ = a.sandbox_link()
    job = client.post(f"/api/v1/partner/links/{link_a}/samples", headers=a.auth, json={"series": [{
        "metric": "heart_rate", "unit": "bpm", "device_id": "D", "start": "2026-09-01T00:00:00Z",
        "offsets_ms": [0], "values": [60]}]}).json()
    hook = client.post(f"/api/v1/partner/apps/{a.app_id}/webhooks", headers=a.auth,
                       json={"url": receiver.url, "events": ["ping"]}).json()
    checks = [
        client.get(f"/api/v1/partner/links/{link_a}", headers=b.auth),
        client.delete(f"/api/v1/partner/links/{link_a}", headers=b.auth),
        client.get(f"/api/v1/partner/links/{link_a}/sync-state", headers=b.auth),
        client.post(f"/api/v1/partner/links/{link_a}/daily-summaries", headers=b.auth, json={"summaries": [summary()]}),
        client.get(f"/api/v1/partner/links/{link_a}/goals", headers=b.auth),
        client.get(f"/api/v1/partner/ingest/jobs/{job['job_id']}", headers=b.auth),
        client.get(f"/api/v1/partner/apps/{a.app_id}/webhooks", headers=b.auth),
        client.post(f"/api/v1/partner/apps/{a.app_id}/webhooks/{hook['webhook_id']}/test", headers=b.auth),
        client.get(f"/api/v1/partner/apps/{a.app_id}/device-models", headers=b.auth),
    ]
    assert [r.status_code for r in checks] == [404] * len(checks)
    assert client.get(f"/api/v1/partner/ingest/jobs/{job['job_id']}").status_code == 401
    assert repo.links().find_one({"link_id": link_a})["status"] == "active"


def test_tokens_manipulados_expirados_o_de_otro_tipo(client, mailbox):
    p = Partner(client, mailbox)
    token = p.auth["Authorization"].split()[1]
    payload = jwt.decode(token, options={"verify_signature": False})
    cases = {
        "firma_otra_clave": jwt.encode(payload, "otra-clave-cualquiera-0123456789abcdef", algorithm="HS256"),
        "alg_none": jwt.encode({**payload, "scope": "links:manage"}, None, algorithm="none"),
        "expirado": jwt.encode({**payload, "exp": int(time.time()) - 10}, conf.PARTNER_TOKEN_SECRET, algorithm="HS256"),
        "otra_audiencia": jwt.encode({**payload, "aud": "wellq-partner-portal"}, conf.PARTNER_TOKEN_SECRET, algorithm="HS256"),
        "scope_inflado": jwt.encode({**payload, "scope": "x"}, "x" * 40, algorithm="HS256"),
    }
    for name, bad in cases.items():
        r = client.get("/api/v1/partner/links", headers={"Authorization": f"Bearer {bad}"})
        assert r.status_code == 401, name
    assert client.get("/api/v1/partner/links", headers=p.portal).status_code == 401
    patient = make_patient()
    assert client.get("/api/v1/partner/links", headers=patient["headers"]).status_code == 401
    assert client.get("/api/v1/partner/apps", headers=p.auth).status_code == 401


def test_rotacion_con_gracia_y_revocacion(client, mailbox):
    p = Partner(client, mailbox)
    old = p.secret
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/secrets/rotate", headers=p.portal,
                    json={"grace_period_seconds": 3600})
    new = r.json()["client_secret"]
    assert r.json()["previous_secret_valid_until"]
    assert p.token(secret=old) and p.token(secret=new)
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/secrets/rotate", headers=p.portal, json={"grace_period_seconds": 0})
    newest = r.json()["client_secret"]
    for secret in (old, new):
        r = client.post("/api/v1/partner/oauth/token", data={"grant_type": "client_credentials",
                                                              "client_id": p.app["client_id"], "client_secret": secret})
        assert r.status_code == 401
    assert client.get("/api/v1/partner/links", headers=p.auth).status_code == 401
    assert p.token(secret=newest)
    stored = repo.apps().find_one({"app_id": p.app_id})
    assert newest not in json.dumps(stored, default=str) and old not in json.dumps(stored, default=str)


def test_scope_del_token_y_del_vinculo(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link(scopes=["ingest:activity"])
    narrow = p.token(scope="links:manage")
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=narrow, json={"summaries": [summary()]})
    assert r.status_code == 403 and r.json()["type"].endswith("/insufficient-scope")
    r = client.post("/api/v1/partner/oauth/token", data={"grant_type": "client_credentials", "client_id": p.app["client_id"],
                                                          "client_secret": p.secret, "scope": "links:manage admin:all"})
    assert r.status_code == 400 and r.json()["type"].endswith("/invalid-scope")
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("ok", "2026-09-01"), summary("vit", "2026-09-02", resting_heart_rate_bpm=60, weight_kg=70)]})
    body = r.json()
    assert r.status_code == 200 and body["accepted"] == 1 and body["rejected"] == 1
    rejected = [x for x in body["results"] if x["status"] == "rejected"][0]
    paths = {e["path"] for e in rejected["errors"]}
    assert paths == {"summaries[1].resting_heart_rate_bpm", "summaries[1].weight_kg"}
    assert MOCK[SANDBOX]["metrics"].count_documents({"link_id": link_id}) == 1
    r = client.post(f"/api/v1/partner/links/{link_id}/sessions", headers=p.auth, json={"sessions": [
        {"session_type": "sleep", "record_id": "s", "device_id": "D", "start": "2026-09-01T00:00:00Z",
         "end": "2026-09-01T07:00:00Z"}]})
    assert r.status_code == 200 and r.json()["rejected"] == 1
    assert "ingest:sleep" in r.json()["results"][0]["errors"][0]["message"]
    link_msk, _ = p.sandbox_link(scopes=["ingest:activity"])
    r = client.post(f"/api/v1/partner/links/{link_msk}/msk-measurements", headers=p.auth, json={"measurements": [
        {"record_id": "m", "device_id": "D", "timestamp": "2026-09-01T00:00:00Z", "measurement_type": "gait_cadence",
         "body_region": "knee", "value": 100, "unit": "steps/min"}]})
    assert r.status_code == 403
    r = client.get(f"/api/v1/partner/links/{link_id}/scores?from_date=2026-09-01&to_date=2026-09-01", headers=p.auth)
    assert r.status_code == 403


def test_validacion_contra_device_model_y_frecuencia(client, mailbox):
    p = Partner(client, mailbox)
    model = p.device_model("ACME-STEPS", [{"metric": "steps"}, {"metric": "heart_rate", "typical_interval_seconds": 60}])
    link_id, _ = p.sandbox_link(model_code=model)
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("x", "2026-09-01", weight_kg=70)]})
    assert r.json()["rejected"] == 1 and "no declarada" in r.json()["results"][0]["errors"][0]["message"]
    fast = {"series": [{"metric": "heart_rate", "unit": "bpm", "device_id": "D", "start": "2026-09-01T00:00:00Z",
                        "offsets_ms": [0, 1000, 2000, 3000], "values": [60, 61, 62, 63]}]}
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers=p.auth, json=fast)
    assert r.status_code == 422 and "frecuencia" in json.dumps(r.json())
    r = client.post("/api/v1/partner/links", headers=p.auth, json={"pairing_code": "WQ-AAAA-BBBB",
                                                                   "external_user_id": "x", "model_code": "NOPE"})
    assert r.status_code == 422


def test_idempotency_replay_y_reutilizacion(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    key = str(uuid.uuid4())
    body = {"summaries": [summary("d-1")]}
    first = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers={**p.auth, "Idempotency-Key": key},
                        json=body)
    second = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers={**p.auth, "Idempotency-Key": key},
                         json=body)
    assert first.json() == second.json() and second.headers.get("Idempotency-Replayed") == "true"
    assert first.json()["results"][0]["status"] == "created"
    other = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers={**p.auth, "Idempotency-Key": key},
                        json={"summaries": [summary("d-2")]})
    assert other.status_code == 422 and other.json()["type"].endswith("/idempotency-key-reused")
    bad = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers={**p.auth, "Idempotency-Key": "abc"},
                      json=body)
    assert bad.status_code == 400
    again = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json=body)
    assert again.json()["results"][0]["status"] == "duplicate"
    changed = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth,
                          json={"summaries": [summary("d-1", steps=8000)]})
    assert changed.json()["results"][0]["status"] == "updated"
    assert MOCK[SANDBOX]["metrics"].count_documents({"link_id": link_id}) == 1


def test_concurrencia_misma_clave_y_mismo_record(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    key = str(uuid.uuid4())
    body = {"summaries": [summary("c-1", "2026-09-05", steps=5000)]}

    def send(with_key):
        headers = {**p.auth, **({"Idempotency-Key": key} if with_key else {})}
        return client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=headers, json=body)

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(send, [True] * 8))
    assert all(r.status_code in (200, 409) for r in results)
    assert sum(1 for r in results if r.status_code == 200 and r.headers.get("Idempotency-Replayed") != "true") == 1
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(send, [False] * 8))
    assert all(r.status_code == 200 for r in results)
    assert MOCK[SANDBOX]["metrics"].count_documents({"link_id": link_id, "metric_date": "2026-09-05"}) == 1


def test_concurrencia_mismo_record_un_solo_created(client, mailbox):
    # D-01: 20 envíos simultáneos del mismo record_id sin Idempotency-Key -> un solo "created"
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    body = {"summaries": [summary("c-20", "2026-09-06", steps=4321)]}

    def send(_):
        return client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json=body)

    with ThreadPoolExecutor(max_workers=20) as pool:
        results = list(pool.map(send, range(20)))
    assert all(r.status_code == 200 for r in results)
    estados = [r.json()["results"][0]["status"] for r in results]
    assert estados.count("created") == 1, estados
    assert set(estados) <= {"created", "duplicate"}, estados
    assert MOCK[SANDBOX]["metrics"].count_documents({"link_id": link_id, "metric_date": "2026-09-06"}) == 1
    # un cambio real del mismo registro se informa como "updated" y no duplica el documento
    body["summaries"][0]["steps"] = 9999
    r = send(0)
    assert r.json()["results"][0]["status"] == "updated"
    assert MOCK[SANDBOX]["metrics"].count_documents({"link_id": link_id, "metric_date": "2026-09-06"}) == 1


def test_registros_aislados_por_vinculo(client, mailbox):
    p = Partner(client, mailbox)
    l1, _ = p.sandbox_link()
    l2, _ = p.sandbox_link()
    for link, steps in ((l1, 1111), (l2, 2222), (l2, 3333)):
        client.post(f"/api/v1/partner/links/{link}/daily-summaries", headers=p.auth,
                    json={"summaries": [summary("r-1", "2026-09-01", steps=steps)]})
        client.post(f"/api/v1/partner/links/{link}/device-events", headers=p.auth, json={"events": [
            {"record_id": "e-1", "device_id": "D", "timestamp": "2026-09-01T10:00:00Z", "event_type": "worn"}]})
    assert MOCK[SANDBOX]["metrics"].find_one({"link_id": l1})["sensors"]["steps"]["value"] == 1111
    assert MOCK[SANDBOX]["metrics"].find_one({"link_id": l2})["sensors"]["steps"]["value"] == 3333
    assert MOCK[SANDBOX]["device_events"].count_documents({"link_id": l2}) == 1


@pytest.mark.parametrize("url", [
    "https://169.254.169.254/latest/meta-data", "https://127.0.0.1/hook", "https://localhost/hook",
    "https://10.0.0.5/x", "https://[::1]/x", "https://[::ffff:127.0.0.1]/x", "http://example.com/x",
    "https://user:pass@example.com/x", "https://metadata.google.internal/x", "ftp://example.com/x",
])
def test_ssrf_urls_rechazadas(client, mailbox, monkeypatch, url):
    monkeypatch.setattr(conf, "PARTNER_WEBHOOK_ALLOW_PRIVATE", False)
    p = Partner(client, mailbox)
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth, json={"url": url, "events": ["ping"]})
    assert r.status_code == 422, (url, r.text)


def test_ssrf_dns_rebinding_y_ip_fijada(monkeypatch):
    monkeypatch.setattr(conf, "PARTNER_WEBHOOK_ALLOW_PRIVATE", False)
    monkeypatch.setattr(ssrf.socket, "getaddrinfo", lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443)),
                                                                   (2, 1, 6, "", ("10.0.0.1", 443))])
    with pytest.raises(ssrf.UnsafeUrl):
        ssrf.resolve_public_ip("rebind.example", 443)
    connected = []
    monkeypatch.setattr(ssrf.socket, "getaddrinfo", lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr(ssrf.socket, "create_connection",
                        lambda addr, timeout=None: connected.append(addr) or (_ for _ in ()).throw(OSError("blocked")))
    status, error, _ = ssrf.post_json("https://hook.example/x", b"{}", {})
    assert status is None and connected == [("93.184.216.34", 443)]


def test_inyeccion_de_operadores_y_campos_desconocidos(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    attacks = [
        {"summaries": [{**summary(), "record_id": {"$ne": None}}]},
        {"summaries": [summary()], "$where": "sleep(1000)"},
        {"summaries": [{**summary(), "extra": 1}]},
        {"summaries": [{**summary(), "vendor_specific": {"$set": {"x": 1}}}]},
        {"summaries": [{**summary(), "local_date": "no-es-fecha"}]},
    ]
    for body in attacks:
        r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json=body)
        assert r.status_code == 422, body
        assert r.json()["errors"]
    r = client.get("/api/v1/partner/links", headers=p.auth, params={"external_user_id": "{\"$ne\": null}"})
    assert r.status_code == 200 and r.json()["items"] == []
    r = client.post("/api/v1/partner/links", headers=p.auth, json={"pairing_code": {"$ne": ""}, "external_user_id": "x"})
    assert r.status_code == 422


def test_limites_de_tamano_lote_y_gzip_bomb(client, mailbox, monkeypatch):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth,
                    json={"summaries": [summary(f"b-{i}") for i in range(101)]})
    assert r.status_code == 413
    huge = b'{"summaries": [' + b" " * (conf.PARTNER_MAX_BODY_BYTES + 10) + b"]}"
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers={**p.auth, "Content-Type": "application/json"},
                    content=huge)
    assert r.status_code == 413
    monkeypatch.setattr(conf, "PARTNER_MAX_DECOMPRESSED_BYTES", 2_000_000)
    bomb = gzip.compress(b'{"series": [' + b" " * 50_000_000 + b"]}")
    assert len(bomb) < conf.PARTNER_MAX_SAMPLES_BODY_BYTES
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers={**p.auth, "Content-Encoding": "gzip"}, content=bomb)
    assert r.status_code == 413 and r.json()["type"].endswith("/decompressed-too-large")
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers={**p.auth, "Content-Encoding": "br"}, content=b"x")
    assert r.status_code == 415
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers={**p.auth, "Content-Encoding": "gzip"},
                    content=b"no-es-gzip")
    assert r.status_code == 400
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers={**p.auth, "Content-Type": "application/json"},
                    content=b'{"series": [{"metric": "heart_rate", "unit": "bpm", "device_id": "D", "start": "2026-')
    assert r.status_code == 422


def test_ndjson_y_cuota_diaria(client, mailbox):
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    line = json.dumps({"metric": "steps", "unit": "count", "device_id": "D", "start": "2026-09-01T00:00:00Z",
                       "offsets_ms": [0, 60000], "values": [10, 20]})
    r = client.post(f"/api/v1/partner/links/{link_id}/samples",
                    headers={**p.auth, "Content-Type": "application/x-ndjson"}, content=(line + "\n" + line).encode())
    assert r.status_code == 202, r.text
    repo.apps().update_one({"app_id": p.app_id}, {"$set": {"rate_limit.samples_per_day": 5}})
    r = client.post(f"/api/v1/partner/links/{link_id}/samples",
                    headers={**p.auth, "Content-Type": "application/x-ndjson"}, content=(line + "\n" + line).encode())
    assert r.status_code == 429 and r.json()["type"].endswith("/quota-exceeded")


def test_rate_limit_publico_y_por_app(client, mailbox):
    p = Partner(client, mailbox)
    codes = [client.post("/api/v1/partner/developers/verify", json={"developer_id": "dev_x", "verification_token": "00000000"}
                         ).status_code for _ in range(15)]
    assert 429 in codes
    repo.apps().update_one({"app_id": p.app_id}, {"$set": {"rate_limit.requests_per_minute": 3}})
    codes = [client.get("/api/v1/partner/links", headers=p.auth) for _ in range(5)]
    assert [r.status_code for r in codes][-1] == 429
    assert codes[0].headers["RateLimit-Limit"] == "3" and codes[-1].headers["Retry-After"]


def test_pairing_un_solo_uso_y_limite_de_intentos(client, mailbox):
    a = Partner(client, mailbox, "A")
    b = Partner(client, mailbox, "B")
    r = client.post("/api/v1/partner/sandbox/patients", json={}, headers=a.auth)
    code = r.json()["pairing_code"]
    assert client.post("/api/v1/partner/links", headers=b.auth, json={"pairing_code": code, "external_user_id": "x"}
                       ).status_code == 404
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(lambda i: client.post("/api/v1/partner/links", headers=a.auth, json={
            "pairing_code": code, "external_user_id": f"u-{i}"}).status_code, range(6)))
    assert results.count(201) == 1 and results.count(404) == 5
    stored = repo.pairing_codes().find_one({})
    assert "pairing_code" not in stored and code.replace("-", "") not in json.dumps(stored, default=str)
    statuses = [client.post("/api/v1/partner/links", headers=b.auth,
                            json={"pairing_code": f"WQ-AAAA-{i:04d}".replace("0", "A").replace("1", "B"),
                                  "external_user_id": "x"}).status_code for i in range(25)]
    assert statuses[-1] == 429
    from app.services.partner import ratelimit
    ratelimit.reset_memory()
    repo.pairing_codes().update_many({}, {"$set": {"used_at": None,
                                                   "expires_at": datetime.now(timezone.utc) - timedelta(seconds=1)}})
    assert client.post("/api/v1/partner/links", headers=a.auth, json={"pairing_code": code, "external_user_id": "z"}
                       ).status_code == 404


def test_codigo_real_no_canjeable_en_sandbox(client, mailbox):
    from conftest import promote
    sandbox_app = Partner(client, mailbox, "S")
    real_app = Partner(client, mailbox, "R")
    promote(client, real_app)
    patient = make_patient()
    body = {"scopes": ["ingest:activity"], "consent_doc_version": "wearable-sharing-v1"}
    assert client.post("/api/v1/wearables/pairing-codes", headers=patient["headers"], json=body).status_code == 422
    assert client.post("/api/v1/wearables/pairing-codes", headers=patient["headers"],
                       json={**body, "app_id": sandbox_app.app_id}).status_code == 404
    assert client.post("/api/v1/wearables/pairing-codes", headers=patient["headers"],
                       json={**body, "app_id": real_app.app_id, "consent_doc_version": "v9"}).status_code == 422
    r = client.post("/api/v1/wearables/pairing-codes", headers=patient["headers"], json={**body, "app_id": real_app.app_id})
    assert r.status_code == 201
    code = r.json()["pairing_code"]
    assert client.post("/api/v1/partner/links", headers=sandbox_app.auth,
                       json={"pairing_code": code, "external_user_id": "x"}).status_code == 404
    assert client.post("/api/v1/partner/links", headers=real_app.auth,
                       json={"pairing_code": code, "external_user_id": "x"}).status_code == 201
    MOCK[TENANT_DB]["legal_docs"].delete_many({})
    r = client.post("/api/v1/wearables/pairing-codes", headers=patient["headers"], json={**body, "app_id": real_app.app_id})
    assert r.status_code == 409 and r.json()["type"].endswith("/consent-document-missing")


def test_webhook_reintento_cierra_entrega_y_reenvia_payload(client, mailbox, receiver):
    p = Partner(client, mailbox)
    receiver.status = 500
    hook = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                       json={"url": receiver.url, "events": ["link.created"]}).json()
    link_id, _ = p.sandbox_link()
    webhooks.deliver_due()
    delivery = repo.webhook_deliveries().find_one({"webhook_id": hook["webhook_id"]})
    assert delivery["status"] == "pending" and delivery["attempt"] == 1
    repo.webhook_deliveries().update_one({"delivery_id": delivery["delivery_id"]},
                                         {"$set": {"next_retry_at": datetime.now(timezone.utc)}})
    receiver.status = 200
    webhooks.deliver_due()
    delivery = repo.webhook_deliveries().find_one({"webhook_id": hook["webhook_id"]})
    assert delivery["status"] == "delivered" and delivery["attempt"] == 2 and delivery["next_retry_at"] is None
    bodies = receiver.bodies()
    assert bodies[0] == bodies[1] and bodies[1]["data"]["link_id"] == link_id
    assert repo.webhook_deliveries().count_documents({"webhook_id": hook["webhook_id"]}) == 1
    webhooks.deliver_due()
    assert len(receiver.calls) == 2
    secret = hook["secret"]
    header = receiver.calls[1]["headers"]["X-WellQ-Signature"]
    assert verify_webhook_signature(secret, receiver.calls[1]["body"], header, int(time.time()))
    assert not verify_webhook_signature(secret, receiver.calls[1]["body"], header, int(time.time()) + 600)
    assert not verify_webhook_signature(secret, receiver.calls[1]["body"] + b" ", header, int(time.time()))
    stored = repo.webhook_subscriptions().find_one({"webhook_id": hook["webhook_id"]})
    assert secret not in json.dumps(stored, default=str)


def test_webhook_desactivado_tras_50_fallos_y_aviso(client, mailbox, receiver):
    p = Partner(client, mailbox)
    receiver.status = 500
    hook = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                       json={"url": receiver.url, "events": ["link.created"]}).json()
    repo.webhook_subscriptions().update_one({"webhook_id": hook["webhook_id"]}, {"$set": {"failure_count": 49}})
    p.sandbox_link()
    webhooks.deliver_due()
    stored = repo.webhook_subscriptions().find_one({"webhook_id": hook["webhook_id"]})
    assert stored["status"] == "disabled_failures"
    assert any("desactivó" in m["text"] for m in mailbox)


def test_webhook_agota_reintentos(client, mailbox, receiver):
    p = Partner(client, mailbox)
    receiver.status = 503
    hook = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                       json={"url": receiver.url, "events": ["link.created"]}).json()
    p.sandbox_link()
    for _ in range(webhooks.MAX_ATTEMPTS + 2):
        repo.webhook_deliveries().update_many({"status": "pending"}, {"$set": {"next_retry_at": datetime.now(timezone.utc)}})
        webhooks.deliver_due()
    delivery = repo.webhook_deliveries().find_one({"webhook_id": hook["webhook_id"]})
    assert delivery["status"] == "failed" and delivery["attempt"] == webhooks.MAX_ATTEMPTS
    assert len(receiver.calls) == webhooks.MAX_ATTEMPTS
    assert sum(webhooks.RETRY_SCHEDULE_SECONDS) <= 86400


def test_auditoria_sin_secretos_y_solo_insercion(client, mailbox):
    p = Partner(client, mailbox)
    p.sandbox_link()
    entries = list(repo.col("partner_audit_log").find({}, {"_id": 0}))
    assert entries and all(e.get("trace_id") for e in entries if e.get("path"))
    dumped = json.dumps(entries, default=str)
    assert p.secret not in dumped and p.auth["Authorization"].split()[1] not in dumped
    import app.repositories.partner as repo_module
    assert not any(name for name in dir(repo_module) if "audit" in name and name != "append_audit")


def test_registro_no_revela_correos_existentes(client, mailbox):
    body = {"company_name": "X", "contact_email": "same@acme-wearables.com", "country": "GB", "accept_terms": True}
    first = client.post("/api/v1/partner/developers/register", json=body)
    second = client.post("/api/v1/partner/developers/register", json=body)
    assert first.status_code == second.status_code == 202
    assert set(first.json()) == set(second.json()) == {"developer_id", "status"}
    assert client.post("/api/v1/partner/developers/verify", json={
        "developer_id": first.json()["developer_id"], "verification_token": "x" * 20}).status_code == 400
    token = mailbox.last_token()
    assert client.post("/api/v1/partner/developers/verify", json={
        "developer_id": first.json()["developer_id"], "verification_token": token}).status_code == 200
    assert client.post("/api/v1/partner/developers/verify", json={
        "developer_id": first.json()["developer_id"], "verification_token": token}).status_code == 400


def test_promocion_ajena_no_bloquea_y_suspension_revoca(client, mailbox):
    from conftest import make_admin
    a = Partner(client, mailbox, "A")
    r = client.post(f"/api/v1/partner/apps/{a.app_id}/promotion-requests", headers=a.portal,
                    json={"dpa_accepted": False, "security_contact_email": "s@a.com"})
    assert r.status_code == 422
    r = client.post(f"/api/v1/partner/apps/{a.app_id}/promotion-requests", headers=a.portal,
                    json={"dpa_accepted": True, "security_contact_email": "s@a.com"})
    assert r.status_code == 202
    assert client.get("/api/v1/partner/links", headers=a.auth).status_code == 200
    assert client.get("/api/v1/partner/admin/promotion-requests", headers=a.auth).status_code == 401
    patient = make_patient()
    assert client.get("/api/v1/partner/admin/promotion-requests", headers=patient["headers"]).status_code == 403
    r = client.post(f"/api/v1/partner/admin/apps/{a.app_id}/suspend", headers=make_admin())
    assert r.status_code == 200
    assert client.get("/api/v1/partner/links", headers=a.auth).status_code == 401
    r = client.post("/api/v1/partner/oauth/token", data={"grant_type": "client_credentials",
                                                          "client_id": a.app["client_id"], "client_secret": a.secret})
    assert r.status_code == 403


def test_paciente_no_accede_a_vinculos_ajenos_ni_de_otro_tenant(client, mailbox):
    p = Partner(client, mailbox)
    owner = make_patient()
    other = make_patient()
    p.device_model()
    from conftest import promote
    promote(client, p)
    code = client.post("/api/v1/wearables/pairing-codes", headers=owner["headers"], json={
        "app_id": p.app_id, "scopes": ["ingest:activity"], "consent_doc_version": "wearable-sharing-v1"}
    ).json()["pairing_code"]
    link_id = client.post("/api/v1/partner/links", headers=p.auth, json={"pairing_code": code, "external_user_id": "o"}
                          ).json()["link_id"]
    assert client.delete(f"/api/v1/wearables/links/{link_id}", headers=other["headers"]).status_code == 404
    assert client.patch(f"/api/v1/wearables/links/{link_id}", headers=other["headers"], json={"scopes": ["ingest:activity"]}
                        ).status_code == 404
    assert client.get("/api/v1/wearables/links", headers=other["headers"]).json() == []
    spoof = {**owner["headers"], "x-tenant": "otra-clinica"}
    MOCK["central-test"]["tenants"].insert_one({"slug": "otra-clinica", "mongo_db": "tenant-otra", "status": "active"})
    assert client.get("/api/v1/wearables/links", headers=spoof).status_code == 403
    from conftest import make_clinician
    stranger = make_clinician()
    assert client.get(f"/api/v1/maindash/patient/{owner['patient_id']}/wearables", headers=stranger["headers"]
                      ).status_code == 404
    assert client.get(f"/api/v1/maindash/patient/{owner['patient_id']}/wearables", headers=owner["headers"]
                      ).status_code == 403


def test_herramientas_de_desarrollo_fallan_cerrado(client, monkeypatch):
    assert client.post("/api/v1/partner-dev/patient-session", json={}).status_code == 200
    monkeypatch.setattr(conf, "APP_ENV", "production")
    assert client.post("/api/v1/partner-dev/patient-session", json={}).status_code == 404
    assert client.get("/api/v1/partner-demo/").status_code == 404
    monkeypatch.setattr(conf, "APP_ENV", "test")
    monkeypatch.setattr(conf, "PARTNER_DEMO_ENABLED", False)
    assert client.get("/api/v1/partner-demo/").status_code == 404
    monkeypatch.setattr(conf, "PARTNER_DEMO_ENABLED", True)
    r = client.get("/api/v1/partner-demo/")
    assert r.status_code == 200 and "frame-ancestors 'none'" in r.headers["content-security-policy"]
    assert "script-src 'self'" in r.headers["content-security-policy"]


def test_login_del_portal_por_codigo(client, mailbox):
    p = Partner(client, mailbox)
    email = mailbox[0]["to"]
    r = client.post("/api/v1/partner/developers/login-code", json={"contact_email": email})
    assert r.status_code == 202 and set(r.json()) == {"status"}
    r2 = client.post("/api/v1/partner/developers/login-code", json={"contact_email": "nadie@acme-wearables.com"})
    assert r2.status_code == 202 and r2.json() == r.json()
    r = client.post("/api/v1/partner/developers/verify", json={"developer_id": p.developer_id,
                                                               "verification_token": mailbox.last_token()})
    assert r.status_code == 200 and r.json()["portal_token"]


def test_rotacion_solo_desde_el_portal(client, mailbox):
    p = Partner(client, mailbox)
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/secrets/rotate", headers=p.auth, json={"grace_period_seconds": 0})
    assert r.status_code == 401
    assert client.get("/api/v1/partner/links", headers=p.auth).status_code == 200


def test_admin_de_otro_tenant_no_promociona(client, mailbox, monkeypatch):
    p = Partner(client, mailbox)
    req = client.post(f"/api/v1/partner/apps/{p.app_id}/promotion-requests", headers=p.portal,
                      json={"dpa_accepted": True, "security_contact_email": "s@a.com"}).json()["request_id"]
    monkeypatch.setattr(conf, "PARTNER_ADMIN_TENANT_SLUGS", ["wellq-platform"])
    r = client.post(f"/api/v1/partner/admin/promotion-requests/{req}/approve", headers=make_admin())
    assert r.status_code == 403
    monkeypatch.setattr(conf, "PARTNER_ADMIN_TENANT_SLUGS", [])
    assert client.post(f"/api/v1/partner/admin/promotion-requests/{req}/approve", headers=make_admin()).status_code == 403


def test_un_solo_vinculo_activo_por_usuario_externo(client, mailbox):
    p = Partner(client, mailbox)
    codes = [client.post("/api/v1/partner/sandbox/patients", json={}, headers=p.auth).json()["pairing_code"]
             for _ in range(6)]
    with ThreadPoolExecutor(max_workers=6) as pool:
        statuses = list(pool.map(lambda c: client.post("/api/v1/partner/links", headers=p.auth, json={
            "pairing_code": c, "external_user_id": "mismo"}).status_code, codes))
    assert statuses.count(201) >= 1
    assert repo.links().count_documents({"app_id": p.app_id, "external_user_id": "mismo", "status": "active"}) == 1


def test_paciente_desactivado_corta_la_ingesta(client, mailbox):
    p = Partner(client, mailbox)
    link_id, patient_id = p.sandbox_link()
    MOCK[conf.PARTNER_SANDBOX_DB]["patients"].update_one({"patient_id": patient_id}, {"$set": {"state": "inactive"}})
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [summary()]})
    assert r.status_code == 403


def test_error_interno_al_entregar_cuenta_como_fallo(client, mailbox, receiver, monkeypatch):
    p = Partner(client, mailbox)
    hook = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                       json={"url": receiver.url, "events": ["link.created"]}).json()
    p.sandbox_link()

    def boom(*a, **k):
        raise RuntimeError("clave cambiada")
    monkeypatch.setattr(webhooks, "send", boom)
    webhooks.deliver_due()
    d = repo.webhook_deliveries().find_one({"webhook_id": hook["webhook_id"]})
    assert d["attempt"] == 1 and d["status"] == "pending" and d["lease_until"] is None


@pytest.mark.parametrize("body", [b"\x14\xef\xbf\xbd\xff\x17", b'{"notes": "\xff"}', b"\xff\xfe"])
def test_cuerpo_utf8_invalido_no_produce_500(client, mailbox, body):
    # D-02: un JSON con bytes UTF-8 inválidos debe responder 400 problem+json, no 500
    p = Partner(client, mailbox)
    rutas = ["/api/v1/partner/admin/promotion-requests/req-x/approve",
             "/api/v1/partner/admin/promotion-requests/req-x/reject",
             f"/api/v1/partner/apps/{p.app_id}/device-models"]
    for ruta in rutas:
        headers = {**(make_admin() if "/admin/" in ruta else p.auth), "Content-Type": "application/json"}
        r = client.post(ruta, content=body, headers=headers)
        assert r.status_code in (400, 422), (ruta, r.status_code, r.text)
        assert r.headers["content-type"].startswith("application/problem+json")
        assert r.json()["trace_id"] and r.headers.get("X-Trace-Id")


def test_upsert_decide_el_estado_por_lo_que_escribe_la_base_de_datos():
    # D-01 (determinista): otra petición guarda el mismo registro entre la lectura previa y la escritura.
    # Antes el reemplazo encontraba ese documento y respondía "created" otra vez.
    from app.services.partner import ingest

    col = MOCK["race-test"]["metrics"]
    col.drop()
    col.create_index([("link_id", 1), ("record_key", 1)], unique=True)

    class LecturaPrevia:
        """Simula la carrera: la lectura previa no ve el documento que otra petición acaba de insertar."""

        def __init__(self, real):
            self.real = real

        def find(self, *args, **kwargs):
            return []

        def __getattr__(self, name):
            return getattr(self.real, name)

    def doc(h):
        return {"link_id": "lnk_r", "record_key": "ds:D:2026-09-01", "payload_hash": h,
                "received_at": datetime.now(timezone.utc), "steps": 1}

    resultados: list = [None]
    assert ingest._upsert(col, "lnk_r", [(0, "r-1", doc("h1"))], resultados)["created"] == 1
    # mismo contenido, lectura desactualizada: es un duplicado, no otro "created"
    resultados = [None]
    counts = ingest._upsert(LecturaPrevia(col), "lnk_r", [(0, "r-1", doc("h1"))], resultados)
    assert resultados[0]["status"] == "duplicate", resultados
    assert counts == {"created": 0, "updated": 0, "duplicate": 1}
    # contenido distinto, lectura desactualizada: es una actualización
    resultados = [None]
    ingest._upsert(LecturaPrevia(col), "lnk_r", [(0, "r-1", doc("h2"))], resultados)
    assert resultados[0]["status"] == "updated", resultados
    assert col.count_documents({"link_id": "lnk_r"}) == 1
    assert col.find_one({"link_id": "lnk_r"})["payload_hash"] == "h2"


def test_lote_parcial_con_valor_fuera_de_rango(client, mailbox):
    # PM-13: un valor fuera de rango rechaza solo su registro; el resto del lote se guarda
    p = Partner(client, mailbox)
    link_id, _ = p.sandbox_link()
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("pm13-ok", "2026-09-01"),
        summary("pm13-hr", "2026-09-02", resting_heart_rate_bpm=300),
        summary("pm13-neg", "2026-09-03", steps=-5),
        summary("pm13-spo2", "2026-09-04", spo2_avg_pct=120)]})
    body = r.json()
    assert r.status_code == 200, body
    assert body["accepted"] == 1 and body["rejected"] == 3
    estados = {x["record_id"]: x for x in body["results"]}
    assert estados["pm13-ok"]["status"] == "created"
    for rid, campo in (("pm13-hr", "summaries[1].resting_heart_rate_bpm"), ("pm13-neg", "summaries[2].steps"),
                       ("pm13-spo2", "summaries[3].spo2_avg_pct")):
        assert estados[rid]["status"] == "rejected"
        assert [e["path"] for e in estados[rid]["errors"]] == [campo]
    assert MOCK[SANDBOX]["metrics"].count_documents({"link_id": link_id}) == 1
    # un cuerpo mal formado sigue rechazando el lote entero
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("pm13-ok2", "2026-09-05"), summary("pm13-tipo", "2026-09-06", steps="muchos")]})
    assert r.status_code == 422


def test_hilo_congelado_no_reenvia_una_entrega_ya_reclamada(client, mailbox, receiver):
    # FIA-06 en Vercel: el envío en segundo plano se congeló, el cron reclamó la entrega al caducar el lease y,
    # al reanudarse, el hilo congelado la envió otra vez (dos POST con el mismo X-WellQ-Delivery)
    p = Partner(client, mailbox)
    hook = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                       json={"url": receiver.url, "events": ["link.created"]}).json()
    p.sandbox_link()
    congelado = webhooks._claim({"webhook_id": hook["webhook_id"]})
    assert congelado and congelado["lease_token"]
    repo.webhook_deliveries().update_one({"delivery_id": congelado["delivery_id"]},
                                         {"$set": {"lease_until": datetime.now(timezone.utc) - timedelta(seconds=1)}})
    assert webhooks.deliver_due() == 1  # el cron la reclama y la entrega
    resultado = webhooks.attempt(congelado)  # el hilo congelado se reanuda
    assert resultado["status"] == "lease_lost"
    assert len([c for c in receiver.calls if c["headers"].get("X-WellQ-Event") == "link.created"]) == 1
    d = repo.webhook_deliveries().find_one({"delivery_id": congelado["delivery_id"]})
    assert d["status"] == "delivered" and d["attempt"] == 1 and d["lease_token"] is None


def test_en_serverless_la_entrega_es_inmediata_y_unica(client, mailbox, receiver, monkeypatch):
    monkeypatch.setenv("VERCEL", "1")
    p = Partner(client, mailbox)
    hook = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                       json={"url": receiver.url, "events": ["link.created"]}).json()
    p.sandbox_link()
    d = repo.webhook_deliveries().find_one({"webhook_id": hook["webhook_id"]})
    assert d["status"] == "delivered" and d["attempt"] == 1  # sin esperar al cron
    assert webhooks.deliver_due() == 0
    assert len([c for c in receiver.calls if c["headers"].get("X-WellQ-Event") == "link.created"]) == 1
