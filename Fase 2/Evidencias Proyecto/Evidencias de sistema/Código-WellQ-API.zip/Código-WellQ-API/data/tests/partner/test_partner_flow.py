import gzip
import hashlib
import hmac
import json

from conftest import MOCK, TENANT_DB, Partner, make_clinician, make_patient, summary

import app.config as conf
from app.repositories import partner as repo
from app.services.partner import webhooks
from app.tasks import partner_jobs

SANDBOX = conf.PARTNER_SANDBOX_DB


def test_flujo_completo_sandbox(client, mailbox, receiver):
    p = Partner(client, mailbox)
    r = client.get("/api/v1/partner/capabilities/metrics", headers=p.auth)
    assert r.status_code == 200 and any(m["metric"] == "steps" for m in r.json())
    model = p.device_model()

    r = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth, json={
        "url": receiver.url, "events": ["link.created", "link.revoked", "ingest.job.completed",
                                        "patient.data_deletion_requested", "ping"]})
    assert r.status_code == 201, r.text
    wh = r.json()
    assert wh["secret"].startswith("whsec_")
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks/{wh['webhook_id']}/test", headers=p.auth)
    assert r.json()["delivered"] is True
    ping = receiver.calls[-1]
    ts, sig = [kv.split("=", 1)[1] for kv in ping["headers"]["X-WellQ-Signature"].split(",")]
    expected = hmac.new(wh["secret"].encode(), f"{ts}.".encode() + ping["body"], hashlib.sha256).hexdigest()
    assert hmac.compare_digest(sig, expected)

    link_id, _ = p.sandbox_link(model_code=model, external_user_id="u-8812")
    webhooks.deliver_due()
    assert any(b["event_type"] == "link.created" for b in receiver.bodies())

    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth, json={"summaries": [
        summary("d-1", "2026-09-01", resting_heart_rate_bpm=58, hrv_rmssd_ms=46.2, sleep_total_minutes=431,
                active_minutes=48, wear_time_minutes=1380),
        summary("d-2", "2026-09-02", steps=9000, resting_heart_rate_bpm=60, hrv_rmssd_ms=44.0, sleep_total_minutes=400)]})
    assert r.status_code == 200, r.text
    assert r.json()["accepted"] == 2

    r = client.post(f"/api/v1/partner/links/{link_id}/sessions", headers=p.auth, json={"sessions": [
        {"session_type": "sleep", "record_id": "s-1", "device_id": "ACME-SN1", "start": "2026-09-01T22:30:00Z",
         "end": "2026-09-02T06:30:00Z", "stages": [{"stage": "deep", "start": "2026-09-01T23:00:00Z",
                                                     "end": "2026-09-02T00:00:00Z"}]},
        {"session_type": "exercise", "record_id": "e-1", "device_id": "ACME-SN1", "start": "2026-09-02T10:00:00Z",
         "end": "2026-09-02T10:40:00Z", "activity_type": "strength_training",
         "sets": [{"set_index": 1, "repetitions": 10, "load_kg": 20, "rpe": 7}]}]})
    assert r.status_code == 200 and r.json()["accepted"] == 2, r.text

    r = client.post(f"/api/v1/partner/links/{link_id}/msk-measurements", headers=p.auth, json={"measurements": [
        {"record_id": "m-1", "device_id": "ACME-SN1", "timestamp": "2026-09-02T09:14:00Z",
         "measurement_type": "range_of_motion_flexion", "body_region": "knee", "side": "right", "value": 2.07,
         "unit": "rad", "context": "prescribed_exercise"}]})
    assert r.status_code == 200 and r.json()["accepted"] == 1, r.text
    msk = MOCK[SANDBOX]["msk_measurements"].find_one({"link_id": link_id})
    assert msk["unit"] == "deg" and round(msk["value"], 1) == 118.6

    r = client.post(f"/api/v1/partner/links/{link_id}/device-events", headers=p.auth, json={"events": [
        {"record_id": "ev-1", "device_id": "ACME-SN1", "timestamp": "2026-09-02T07:00:00Z", "event_type": "worn"}]})
    assert r.status_code == 200 and r.json()["accepted"] == 1

    series = {"series": [{"metric": "heart_rate", "unit": "bpm", "device_id": "ACME-SN1", "start": "2026-09-02T05:00:00Z",
                          "offsets_ms": [0, 60000, 120000, 180000], "values": [61, 63, 60, 62]}]}
    r = client.post(f"/api/v1/partner/links/{link_id}/samples", headers={**p.auth, "Content-Encoding": "gzip"},
                    content=gzip.compress(json.dumps(series).encode()))
    assert r.status_code == 202, r.text
    job_id = r.json()["job_id"]
    assert r.json()["status"] == "queued"
    partner_jobs.process_ingest_job(job_id)
    r = client.get(f"/api/v1/partner/ingest/jobs/{job_id}", headers=p.auth)
    assert r.json()["status"] == "completed" and r.json()["summary"]["points_accepted"] == 4

    r = client.get(f"/api/v1/partner/links/{link_id}/sync-state", headers=p.auth)
    assert {"daily_summary", "samples", "session"} <= set(r.json()["last_received"])

    r = client.get(f"/api/v1/partner/links/{link_id}/goals", headers=p.auth)
    assert r.status_code == 200 and r.json()["health_goals"]["steps_target_day"] == conf.PARTNER_DEFAULT_STEPS_TARGET
    r = client.get(f"/api/v1/partner/links/{link_id}/scores?from_date=2026-09-01&to_date=2026-09-02", headers=p.auth)
    assert r.status_code == 200
    day1 = r.json()["days"][0]
    assert day1["activity"] is not None and day1["sleep"] is not None and day1["data_status"] == "ok"
    assert r.json()["days"][1]["stability"] is not None

    metrics_doc = MOCK[SANDBOX]["metrics"].find_one({"link_id": link_id, "partner_kind": "daily_summary",
                                                     "metric_date": "2026-09-01"})
    assert metrics_doc["sensors"]["steps"] == {"metric": "steps", "value": 7412, "unit": "count"}
    assert metrics_doc["patient_id"] == metrics_doc["meta"]["paciente_id"]
    assert "patient_id" not in json.dumps(client.get(f"/api/v1/partner/links/{link_id}", headers=p.auth).json())

    r = client.delete(f"/api/v1/partner/links/{link_id}", headers=p.auth)
    assert r.status_code == 204
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth,
                    json={"summaries": [summary("d-9", "2026-09-03")]})
    assert r.status_code == 403 and r.json()["type"].endswith("/link-revoked")
    r = client.get(f"/api/v1/partner/links/{link_id}/goals", headers=p.auth)
    assert r.status_code == 403


def test_vinculo_real_paciente_y_borrado(client, mailbox, receiver):
    p = Partner(client, mailbox)
    model = p.device_model()
    admin = __import__("conftest").make_admin()
    clinician = make_clinician()
    patient = make_patient(care_clinician=clinician["oid"])

    r = client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks", headers=p.auth,
                    json={"url": receiver.url, "events": ["ping", "link.revoked", "patient.data_deletion_requested",
                                                          "app.promoted", "link.scopes_changed", "link.config_changed"]})
    hook = r.json()
    client.post(f"/api/v1/partner/apps/{p.app_id}/webhooks/{hook['webhook_id']}/test", headers=p.auth)
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/promotion-requests", headers=p.portal,
                    json={"dpa_accepted": True, "security_contact_email": "sec@acme-wearables.com"})
    assert r.status_code == 202 and r.json()["checklist"]["webhook_tested"] is True
    req_id = r.json()["request_id"]
    # sin política de privacidad el checklist está incompleto y la aprobación se bloquea
    assert r.json()["missing"] == ["privacy_policy_url"]
    r = client.post(f"/api/v1/partner/admin/promotion-requests/{req_id}/approve", headers=admin)
    assert r.status_code == 409 and r.json()["missing"] == ["privacy_policy_url"], r.text
    client.patch(f"/api/v1/partner/apps/{p.app_id}", headers=p.portal,
                 json={"privacy_policy_url": "https://acme-wearables.com/privacy"})
    r = client.post(f"/api/v1/partner/admin/promotion-requests/{req_id}/approve", headers=admin)
    assert r.status_code == 200, r.text
    webhooks.deliver_due()
    assert any(b["event_type"] == "app.promoted" for b in receiver.bodies())
    r = client.get("/api/v1/partner/links", headers=p.auth)
    assert r.status_code == 401
    r = client.post(f"/api/v1/partner/apps/{p.app_id}/secrets/rotate", headers=p.portal, json={"grace_period_seconds": 0})
    p.secret = r.json()["client_secret"]
    p.auth = p.token()

    r = client.get("/api/v1/wearables/consent-info", params={"app_id": p.app_id}, headers=patient["headers"])
    assert r.status_code == 200 and r.json()["partner"]["name"] == "Acme Cloud"
    r = client.post("/api/v1/wearables/pairing-codes", headers=patient["headers"], json={
        "app_id": p.app_id, "scopes": ["ingest:activity", "ingest:sleep", "read:scores"],
        "consent_doc_version": "wearable-sharing-v1"})
    assert r.status_code == 201, r.text
    code = r.json()["pairing_code"]
    assert len(code.replace("WQ-", "").replace("-", "")) == 8
    r = client.post("/api/v1/partner/links", headers=p.auth, json={
        "pairing_code": code, "external_user_id": "u-real", "model_code": model})
    assert r.status_code == 201, r.text
    link_id = r.json()["link_id"]
    assert r.json()["granted_scopes"] == ["ingest:activity", "ingest:sleep", "read:scores"]
    assert MOCK[TENANT_DB]["patients"].find_one({"_id": patient["oid"]})["wearable_links"] == [link_id]

    client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth,
                json={"summaries": [summary("d-1", "2026-09-01", sleep_total_minutes=420)]})
    client.post(f"/api/v1/partner/links/{link_id}/sessions", headers=p.auth, json={"sessions": [
        {"session_type": "exercise", "record_id": "e-1", "device_id": "ACME-SN1", "start": "2026-09-01T10:00:00Z",
         "end": "2026-09-01T10:40:00Z", "activity_type": "walking"}]})
    assert MOCK[TENANT_DB]["metrics"].count_documents({"link_id": link_id}) == 1
    workout = MOCK[TENANT_DB]["patient_wearable_workouts"].find_one({"link_id": link_id})
    assert workout["patient_id"] == patient["patient_id"] and workout["workout_type"] == "walking"

    r = client.get("/api/v1/wearables/links", headers=patient["headers"])
    assert r.status_code == 200 and r.json()[0]["partner_name"] == "Acme Cloud"
    r = client.get(f"/api/v1/maindash/patient/{patient['patient_id']}/wearables", headers=clinician["headers"])
    assert r.status_code == 200 and r.json()[0]["link_id"] == link_id
    r = client.get(f"/api/v1/maindash/patient/{patient['patient_id']}/wearables/data/statistics/daily",
                   params={"from_date": "2026-09-01", "to_date": "2026-09-01", "types": "steps,sleep_duration"},
                   headers=clinician["headers"])
    assert r.status_code == 200 and r.json()["items"][0]["steps"] == 7412, r.text
    r = client.get("/api/v1/wearables/data/workouts", params={
        "from_timestamp": "2026-09-01T00:00:00Z", "to_timestamp": "2026-09-02T00:00:00Z"}, headers=patient["headers"])
    assert r.status_code == 200 and r.json()["items"][0]["activity_type"] == "walking"

    r = client.put(f"/api/v1/maindash/patient/{patient['patient_id']}/wearables/{link_id}/ingest-config",
                   headers=clinician["headers"], json={"intervals": {"heart_rate": 300}})
    assert r.status_code == 200 and {"metric": "heart_rate", "interval_seconds": 300, "source": "wellq"} in \
        r.json()["ingest_config"]["intervals"]
    r = client.get(f"/api/v1/partner/links/{link_id}/config", headers=p.auth)
    assert r.json()["ingest_config"]["intervals"][0]["interval_seconds"] == 300

    r = client.patch(f"/api/v1/wearables/links/{link_id}", headers=patient["headers"],
                     json={"scopes": ["ingest:activity", "ingest:sleep"]})
    assert r.status_code == 200 and "read:scores" not in r.json()["granted_scopes"]
    r = client.get(f"/api/v1/partner/links/{link_id}/scores?from_date=2026-09-01&to_date=2026-09-01", headers=p.auth)
    assert r.status_code == 403 and r.json()["type"].endswith("/insufficient-scope")

    r = client.delete(f"/api/v1/wearables/links/{link_id}?delete_data=true", headers=patient["headers"])
    assert r.status_code == 204
    for name in ("metrics", "patient_wearable_workouts", "msk_measurements", "device_events"):
        assert MOCK[TENANT_DB][name].count_documents({"link_id": link_id}) == 0
    req = repo.deletion_requests().find_one({"link_id": link_id})
    assert req["deleted"]["metrics"] == 1 and req["status"] == "pending" and req["sweeps"] == 1
    # una escritura en vuelo que llega tras el borrado se elimina en la segunda pasada
    MOCK[TENANT_DB]["metrics"].insert_one({"link_id": link_id, "record_key": "tarde", "patient_id": patient["patient_id"]})
    from app.services.partner import links as link_service
    req = link_service.run_deletion(req["request_id"])
    assert req["status"] == "done" and MOCK[TENANT_DB]["metrics"].count_documents({"link_id": link_id}) == 0
    audit = list(repo.col("partner_audit_log").find({"link_id": link_id, "event": "partner.data_deleted"}))
    assert len(audit) == 2
    webhooks.deliver_due()
    events = [b["event_type"] for b in receiver.bodies()]
    assert {"link.scopes_changed", "link.config_changed", "link.revoked", "patient.data_deletion_requested"} <= set(events)
    r = client.post(f"/api/v1/partner/links/{link_id}/daily-summaries", headers=p.auth,
                    json={"summaries": [summary("d-2", "2026-09-02")]})
    assert r.status_code == 403
    assert MOCK[TENANT_DB]["patients"].find_one({"_id": patient["oid"]})["wearable_links"] == []
