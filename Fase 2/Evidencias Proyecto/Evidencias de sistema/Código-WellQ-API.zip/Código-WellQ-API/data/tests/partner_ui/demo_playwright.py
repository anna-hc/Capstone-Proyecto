"""Recorre la interfaz de prueba en un navegador real y deja capturas y un resumen JSON.

Uso: python tests/partner_ui/demo_playwright.py http://127.0.0.1:8765 <carpeta_salida> [msedge|chromium]
"""
import json
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

BASE = sys.argv[1].rstrip("/")
OUT = Path(sys.argv[2])
CHANNEL = sys.argv[3] if len(sys.argv) > 3 else "msedge"
OUT.mkdir(parents=True, exist_ok=True)


def wait_log(page, done, timeout=240):
    # sin wait_for_function: la CSP de la página (sin unsafe-eval) bloquea la evaluación de cadenas
    deadline = time.time() + timeout
    while time.time() < deadline:
        if done(page.locator("#log").inner_text()):
            return
        page.wait_for_timeout(500)
    raise TimeoutError("la interfaz no terminó a tiempo: " + page.locator("#log").inner_text()[:3000])


def main():
    report = {"console_errors": [], "expected_http_errors": [], "page_errors": [], "failed_requests": [], "checks": {}}

    def on_console(msg):
        if msg.type != "error":
            return
        # Chromium registra en consola toda respuesta 4xx de fetch; los casos negativos las provocan a propósito
        if msg.text.startswith("Failed to load resource: the server responded with a status of 4"):
            report["expected_http_errors"].append(msg.text)
        else:
            report["console_errors"].append(msg.text)
    with sync_playwright() as p:
        browser = p.chromium.launch(channel=CHANNEL if CHANNEL != "chromium" else None, headless=True)
        page = browser.new_page(viewport={"width": 1366, "height": 900})
        page.on("console", on_console)
        page.on("pageerror", lambda e: report["page_errors"].append(str(e)))
        page.on("requestfailed", lambda r: report["failed_requests"].append(f"{r.method} {r.url} {r.failure}"))
        resp = page.goto(f"{BASE}/api/v1/partner-demo/")
        headers = resp.headers
        report["checks"]["csp"] = headers.get("content-security-policy", "")
        report["checks"]["nosniff"] = headers.get("x-content-type-options") == "nosniff"
        page.click("#run-flow")
        wait_log(page, lambda t: "Flujo completo superado" in t or any("se esperaba" in x or "Falta" in x for x in
                                                                          page.locator("#log li.err").all_inner_texts()))
        log_items = page.locator("#log li").all_inner_texts()
        report["checks"]["flow_ok"] = any("Flujo completo superado" in t for t in log_items)
        report["checks"]["flow_errors"] = [t for t in log_items if "se esperaba" in t or "Falta" in t]
        page.screenshot(path=str(OUT / "demo_flujo.png"), full_page=False)
        page.click("#run-errors")
        wait_log(page, lambda t: "Casos de error completados" in t or "se esperaba" in t or "No se alcanzó" in t)
        log_items = page.locator("#log li").all_inner_texts()
        report["checks"]["errors_ok"] = any("Casos de error completados" in t for t in log_items)
        report["checks"]["errors_failures"] = [t for t in log_items if "se esperaba" in t or "No se alcanzó" in t]
        report["checks"]["forged_signature_rejected"] = any("INVÁLIDA" in t for t in log_items)
        report["checks"]["valid_signature_seen"] = any("firma válida" in t for t in log_items)
        report["checks"]["storage_empty"] = page.evaluate("localStorage.length === 0 && sessionStorage.length === 0")
        report["checks"]["no_secret_in_dom"] = page.evaluate(
            "!document.body.innerText.match(/wqs_[A-Za-z0-9_-]{20,}|whsec_[A-Za-z0-9_-]{20,}|eyJ[A-Za-z0-9_-]{20,}\\.[A-Za-z0-9_-]{20,}\\./)")
        page.screenshot(path=str(OUT / "demo_errores.png"), full_page=False)
        page.keyboard.press("Tab")
        report["checks"]["keyboard_focus"] = page.evaluate("document.activeElement && document.activeElement.id")
        page.set_viewport_size({"width": 375, "height": 812})
        page.wait_for_timeout(500)
        report["checks"]["no_horizontal_scroll_mobile"] = page.evaluate(
            "document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1")
        report["checks"]["overflowing"] = page.evaluate(
            "[document.documentElement.scrollWidth, document.documentElement.clientWidth].concat([...document.querySelectorAll('body *')]"
            ".filter(e => e.getBoundingClientRect().right > document.documentElement.clientWidth + 0.5)"
            ".slice(0, 8).map(e => e.tagName + '.' + e.className + ' ' + Math.round(e.getBoundingClientRect().right)))")
        page.screenshot(path=str(OUT / "demo_movil.png"), full_page=False)
        unlabeled = page.evaluate("[...document.querySelectorAll('input,textarea')].filter(e => !e.closest('label') && "
                                  "!e.getAttribute('aria-label')).length")
        report["checks"]["unlabeled_inputs"] = unlabeled
        browser.close()
    report["ok"] = (report["checks"]["flow_ok"] and report["checks"]["errors_ok"] and not report["console_errors"]
                    and not report["page_errors"] and report["checks"]["storage_empty"]
                    and report["checks"]["no_secret_in_dom"] and report["checks"]["no_horizontal_scroll_mobile"])
    (OUT / "demo_playwright.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(0 if report["ok"] else 1)


if __name__ == "__main__":
    main()
