from typing import Any, Optional

from pymongo import ReturnDocument, WriteConcern

import app.db as dbmod
from app.db import (TBL_DEVICE_EVENTS, TBL_INGEST_JOBS, TBL_MSK_MEASUREMENTS, TBL_PAIRING_CODES,
                    TBL_PARTNER_APPS, TBL_PARTNER_AUDIT_LOG, TBL_PARTNER_DELETION_REQUESTS,
                    TBL_PARTNER_DEVELOPERS, TBL_PARTNER_DEVICE_MODELS, TBL_PARTNER_EMAIL_VERIFICATIONS,
                    TBL_PARTNER_IDEMPOTENCY, TBL_PARTNER_INGEST_PAYLOADS, TBL_PARTNER_LINKS,
                    TBL_PARTNER_PROMOTION_REQUESTS, TBL_PARTNER_SANDBOX_PATIENTS, TBL_WEBHOOK_DELIVERIES,
                    TBL_WEBHOOK_SUBSCRIPTIONS)

MAJORITY = WriteConcern(w="majority")
_central_override = None


def use_central(database) -> None:
    global _central_override
    _central_override = database


def central():
    return _central_override if _central_override is not None else dbmod.central_db


def col(name: str, majority: bool = False):
    c = central()[name]
    return c.with_options(write_concern=MAJORITY) if majority else c


def developers():
    return col(TBL_PARTNER_DEVELOPERS)


def email_verifications():
    return col(TBL_PARTNER_EMAIL_VERIFICATIONS)


def apps():
    return col(TBL_PARTNER_APPS)


def promotion_requests():
    return col(TBL_PARTNER_PROMOTION_REQUESTS)


def device_models():
    return col(TBL_PARTNER_DEVICE_MODELS)


def pairing_codes():
    return col(TBL_PAIRING_CODES, majority=True)


def links():
    return col(TBL_PARTNER_LINKS, majority=True)


def ingest_jobs():
    return col(TBL_INGEST_JOBS, majority=True)


def ingest_payloads():
    return col(TBL_PARTNER_INGEST_PAYLOADS, majority=True)


def webhook_subscriptions():
    return col(TBL_WEBHOOK_SUBSCRIPTIONS)


def webhook_deliveries():
    return col(TBL_WEBHOOK_DELIVERIES)


def idempotency():
    return col(TBL_PARTNER_IDEMPOTENCY, majority=True)


def deletion_requests():
    return col(TBL_PARTNER_DELETION_REQUESTS, majority=True)


def sandbox_patients():
    return col(TBL_PARTNER_SANDBOX_PATIENTS)


def append_audit(entry: dict) -> None:
    # el log de auditoría solo admite inserciones: este módulo no expone update ni delete sobre él
    col(TBL_PARTNER_AUDIT_LOG).insert_one(dict(entry))


def tenant_collection(tenant_db, name: str, majority: bool = False):
    if name not in (dbmod.TBL_METRICS, dbmod.TBL_PATIENT_WEARABLE_WORKOUTS, TBL_MSK_MEASUREMENTS,
                    TBL_DEVICE_EVENTS, dbmod.TBL_PATIENTS, dbmod.TBL_PATIENT_GOALS, dbmod.TBL_PATIENT_PROGRAMS,
                    dbmod.TBL_PROGRAM_TEMPLATES, dbmod.TBL_EXERCISES_CATALOG, dbmod.TBL_LEGAL_DOCS):
        raise ValueError(f"colección de tenant no permitida: {name}")
    c = tenant_db[name]
    return c.with_options(write_concern=MAJORITY) if majority else c


def find_one_and_update(collection, flt: dict, update: dict, **kwargs) -> Optional[dict]:
    return collection.find_one_and_update(flt, update, return_document=ReturnDocument.AFTER, **kwargs)


def strip(doc: Optional[dict], *fields: str) -> Optional[dict]:
    if doc is None:
        return None
    out = {k: v for k, v in doc.items() if k != "_id" and k not in fields}
    return out


def public_projection(*hidden: str) -> dict[str, Any]:
    proj = {"_id": 0}
    for h in hidden:
        proj[h] = 0
    return proj
