from app.db import tenants_registry_collection


class _TenantRepo:
    def get_by_slug(self, slug: str, active_only: bool = False):
        query = {"slug": slug, **({"status": "active"} if active_only else {})}
        return tenants_registry_collection().find_one(query)

    def get_by_mongo_db(self, mongo_db: str, active_only: bool = False):
        query = {"mongo_db": mongo_db, **({"status": "active"} if active_only else {})}
        return tenants_registry_collection().find_one(query)


tenant_repo = _TenantRepo()
