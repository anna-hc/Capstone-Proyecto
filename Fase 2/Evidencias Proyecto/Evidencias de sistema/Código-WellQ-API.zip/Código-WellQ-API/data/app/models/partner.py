import json
from datetime import date
from typing import Annotated, Any, Literal, Optional, Union

from pydantic import (AfterValidator, AwareDatetime, BaseModel, ConfigDict, EmailStr, Field, HttpUrl,
                      StringConstraints, field_validator, model_validator)

ConsentScope = Literal["ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:body",
                       "ingest:msk", "ingest:device", "read:goals", "read:scores"]
WebhookEventType = Literal["ping", "app.promoted", "app.suspended", "link.created", "link.revoked",
                           "link.scopes_changed", "link.config_changed", "ingest.job.completed",
                           "ingest.job.failed", "goals.updated", "patient.data_deletion_requested",
                           "sync.gap_detected"]
SafeId = Annotated[str, StringConstraints(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9._:\-]+$")]
ShortText = Annotated[str, StringConstraints(min_length=1, max_length=200, strip_whitespace=True)]
LongText = Annotated[str, StringConstraints(max_length=2000)]
Metric = Annotated[str, StringConstraints(min_length=1, max_length=64, pattern=r"^[a-z0-9_]+$")]


def _check_vendor_specific(value: Optional[dict]) -> Optional[dict]:
    if value is None:
        return value
    if len(json.dumps(value, default=str)) > 4096:
        raise ValueError("vendor_specific supera 4 KB")

    def walk(node: Any, depth: int) -> None:
        if depth > 4:
            raise ValueError("vendor_specific con más de 4 niveles")
        if isinstance(node, dict):
            for key, child in node.items():
                if not isinstance(key, str) or key.startswith("$") or "." in key or len(key) > 64:
                    raise ValueError("vendor_specific con claves no permitidas")
                walk(child, depth + 1)
        elif isinstance(node, list):
            for child in node:
                walk(child, depth + 1)
    walk(value, 0)
    return value


VendorSpecific = Annotated[Optional[dict], AfterValidator(_check_vendor_specific)]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_max_length=2000)


class DeveloperRegistration(Strict):
    company_name: ShortText
    contact_email: EmailStr
    contact_name: Optional[ShortText] = None
    country: Annotated[str, StringConstraints(pattern=r"^[A-Z]{2}$")]
    website: Optional[HttpUrl] = None
    accept_terms: bool


class DeveloperLogin(Strict):
    contact_email: EmailStr


class DeveloperVerify(Strict):
    developer_id: SafeId
    verification_token: Annotated[str, StringConstraints(min_length=8, max_length=128)]


class AppCreate(Strict):
    name: ShortText
    description: Optional[LongText] = None
    logo_url: Optional[HttpUrl] = None
    privacy_policy_url: Optional[HttpUrl] = None
    requested_scopes: list[ConsentScope] = Field(default_factory=list, max_length=8)


class AppUpdate(Strict):
    name: Optional[ShortText] = None
    description: Optional[LongText] = None
    logo_url: Optional[HttpUrl] = None
    privacy_policy_url: Optional[HttpUrl] = None
    requested_scopes: Optional[list[ConsentScope]] = Field(default=None, max_length=8)


class RotateSecret(Strict):
    grace_period_seconds: int = Field(default=86400, ge=0, le=604800)


class PromotionRequestIn(Strict):
    dpa_accepted: bool
    security_contact_email: EmailStr
    expected_monthly_volume: Optional[int] = Field(default=None, ge=0, le=10_000_000_000)
    notes: Optional[LongText] = None


class PromotionDecision(Strict):
    notes: Optional[LongText] = None


class DeviceCapability(Strict):
    metric: Metric
    typical_interval_seconds: Optional[int] = Field(default=None, ge=1, le=86400)
    sampling_mode: Optional[Literal["continuous", "on_demand", "daily_aggregate", "per_session"]] = None


class Regulatory(Strict):
    ukca_or_ce_medical_device: Optional[bool] = None
    class_: Optional[Annotated[str, StringConstraints(max_length=16)]] = Field(default=None, alias="class")
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class DeviceModel(Strict):
    model_code: SafeId
    display_name: ShortText
    form_factor: Literal["watch", "band", "ring", "chest_strap", "patch", "sleeve", "insole", "scale", "other"]
    body_placement: Optional[Annotated[str, StringConstraints(max_length=64)]] = None
    capabilities: list[DeviceCapability] = Field(min_length=1, max_length=64)
    regulatory: Optional[Regulatory] = None
    firmware_min_version: Optional[Annotated[str, StringConstraints(max_length=32)]] = None


class LinkCreate(Strict):
    pairing_code: Annotated[str, StringConstraints(min_length=6, max_length=20)]
    external_user_id: SafeId
    device_id: Optional[SafeId] = None
    model_code: Optional[SafeId] = None
    timezone: Optional[Annotated[str, StringConstraints(max_length=64, pattern=r"^[A-Za-z_]+(/[A-Za-z0-9_+\-]+){0,2}$")]] = None


class DailySummary(Strict):
    # los rangos de las métricas (catalog.PLAUSIBLE_RANGES) se comprueban registro a registro en
    # ingest.ingest_daily_summaries: un valor fuera de rango rechaza solo ese registro, no el lote entero
    record_id: SafeId
    local_date: date
    tz_offset_minutes: int = Field(ge=-840, le=840)
    device_id: SafeId
    completeness: Literal["partial", "final"] = "partial"
    wear_time_minutes: Optional[int] = None
    steps: Optional[int] = None
    distance_m: Optional[float] = None
    active_minutes: Optional[int] = None
    calories_active_kcal: Optional[float] = None
    calories_total_kcal: Optional[float] = None
    floors_climbed: Optional[int] = None
    resting_heart_rate_bpm: Optional[int] = None
    avg_heart_rate_bpm: Optional[int] = None
    max_heart_rate_bpm: Optional[int] = None
    hrv_rmssd_ms: Optional[float] = None
    hrv_sdnn_ms: Optional[float] = None
    spo2_avg_pct: Optional[float] = None
    respiratory_rate_avg_bpm: Optional[float] = None
    skin_temperature_deviation_c: Optional[float] = None
    sleep_total_minutes: Optional[int] = None
    sleep_efficiency_pct: Optional[float] = None
    recovery_score: Optional[int] = Field(default=None, ge=0, le=100)
    strain_score: Optional[float] = None
    weight_kg: Optional[float] = None
    body_fat_pct: Optional[float] = None
    vendor_specific: VendorSpecific = None


class DailySummaryBatch(Strict):
    summaries: list[DailySummary] = Field(min_length=1)


class SampleSeries(Strict):
    record_id: Optional[SafeId] = None
    metric: Metric
    unit: Annotated[str, StringConstraints(min_length=1, max_length=16)]
    device_id: SafeId
    start: AwareDatetime
    offsets_ms: list[Annotated[int, Field(ge=0, le=31 * 86400 * 1000)]] = Field(min_length=1, max_length=50000)
    durations_ms: Optional[list[Annotated[int, Field(ge=0, le=86400 * 1000)]]] = Field(default=None, max_length=50000)
    values: list[float] = Field(min_length=1, max_length=50000)
    quality: Optional[list[Annotated[float, Field(ge=0, le=1)]]] = Field(default=None, max_length=50000)

    @model_validator(mode="after")
    def _lengths(self):
        n = len(self.values)
        if len(self.offsets_ms) != n:
            raise ValueError("offsets_ms debe tener la misma longitud que values")
        if self.durations_ms is not None and len(self.durations_ms) != n:
            raise ValueError("durations_ms debe tener la misma longitud que values")
        if self.quality is not None and len(self.quality) != n:
            raise ValueError("quality debe tener la misma longitud que values")
        if any(b < a for a, b in zip(self.offsets_ms, self.offsets_ms[1:], strict=False)):
            raise ValueError("offsets_ms debe ser creciente")
        return self


class SampleBatch(Strict):
    series: list[SampleSeries] = Field(min_length=1, max_length=100)


class SleepStage(Strict):
    stage: Literal["awake", "light", "deep", "rem", "unknown"]
    start: AwareDatetime
    end: AwareDatetime


class SleepSummary(Strict):
    total_sleep_minutes: Optional[int] = Field(default=None, ge=0, le=1440)
    time_in_bed_minutes: Optional[int] = Field(default=None, ge=0, le=1440)
    awakenings: Optional[int] = Field(default=None, ge=0, le=500)
    efficiency_pct: Optional[float] = Field(default=None, ge=0, le=100)
    avg_heart_rate_bpm: Optional[int] = Field(default=None, ge=20, le=300)
    avg_hrv_rmssd_ms: Optional[float] = Field(default=None, ge=1, le=500)
    avg_spo2_pct: Optional[float] = Field(default=None, ge=50, le=100)
    avg_respiratory_rate_bpm: Optional[float] = Field(default=None, ge=4, le=60)


class SleepSession(Strict):
    session_type: Literal["sleep"]
    record_id: SafeId
    device_id: SafeId
    start: AwareDatetime
    end: AwareDatetime
    tz_offset_minutes: Optional[int] = Field(default=None, ge=-840, le=840)
    is_nap: bool = False
    stages: Optional[list[SleepStage]] = Field(default=None, max_length=500)
    summary: Optional[SleepSummary] = None


class ExerciseSet(Strict):
    set_index: Optional[int] = Field(default=None, ge=0, le=1000)
    repetitions: Optional[int] = Field(default=None, ge=0, le=10000)
    load_kg: Optional[float] = Field(default=None, ge=0, le=1000)
    duration_seconds: Optional[int] = Field(default=None, ge=0, le=86400)
    rpe: Optional[float] = Field(default=None, ge=0, le=10)


class ExerciseSummary(Strict):
    duration_seconds: Optional[int] = Field(default=None, ge=0, le=86400)
    calories_kcal: Optional[float] = Field(default=None, ge=0, le=20000)
    distance_m: Optional[float] = Field(default=None, ge=0, le=500000)
    avg_heart_rate_bpm: Optional[int] = Field(default=None, ge=20, le=300)
    max_heart_rate_bpm: Optional[int] = Field(default=None, ge=20, le=300)
    hr_zones_seconds: Optional[list[Annotated[int, Field(ge=0)]]] = Field(default=None, min_length=5, max_length=5)


class ExerciseSession(Strict):
    session_type: Literal["exercise"]
    record_id: SafeId
    device_id: SafeId
    start: AwareDatetime
    end: AwareDatetime
    activity_type: Annotated[str, StringConstraints(min_length=1, max_length=64, pattern=r"^[a-z0-9_]+$")]
    # desfase local del paciente al empezar la sesión: decide en qué día local cuenta para la adherencia
    tz_offset_minutes: Optional[int] = Field(default=None, ge=-840, le=840)
    wellq_exercise_code: Optional[SafeId] = None
    sets: Optional[list[ExerciseSet]] = Field(default=None, max_length=200)
    summary: Optional[ExerciseSummary] = None
    source: Literal["auto_detected", "user_logged"] = "auto_detected"


SessionItem = Annotated[Union[SleepSession, ExerciseSession], Field(discriminator="session_type")]


class SessionBatch(Strict):
    sessions: list[SessionItem] = Field(min_length=1)


class MskMeasurement(Strict):
    record_id: SafeId
    device_id: SafeId
    timestamp: AwareDatetime
    measurement_type: Literal[
        "range_of_motion_flexion", "range_of_motion_extension", "range_of_motion_abduction",
        "range_of_motion_rotation", "isometric_force", "peak_force", "rate_of_force_development",
        "emg_rms", "emg_activation_pct", "muscle_oxygenation_smo2", "joint_load_index",
        "limb_symmetry_index", "gait_cadence", "gait_step_length", "gait_asymmetry_pct",
        "balance_sway_area", "reaction_time", "vendor_specific"]
    body_region: Annotated[str, StringConstraints(min_length=1, max_length=64, pattern=r"^[a-z_]+$")]
    side: Literal["left", "right", "bilateral", "n/a"] = "n/a"
    value: float
    unit: Annotated[str, StringConstraints(min_length=1, max_length=16)]
    context: Literal["rest", "prescribed_exercise", "free_activity", "clinical_test"] = "free_activity"
    wellq_exercise_code: Optional[SafeId] = None
    protocol: Optional[Annotated[str, StringConstraints(max_length=128)]] = None
    confidence: Optional[float] = Field(default=None, ge=0, le=1)
    vendor_specific: VendorSpecific = None


class MskMeasurementBatch(Strict):
    measurements: list[MskMeasurement] = Field(min_length=1)


class DeviceEvent(Strict):
    record_id: SafeId
    device_id: SafeId
    timestamp: AwareDatetime
    event_type: Literal["worn", "removed", "battery_low", "charging", "sync_completed", "firmware_updated", "fault"]
    details: VendorSpecific = None


class DeviceEventBatch(Strict):
    events: list[DeviceEvent] = Field(min_length=1)


class WebhookCreate(Strict):
    url: Annotated[str, StringConstraints(min_length=8, max_length=2048)]
    events: list[WebhookEventType] = Field(min_length=1, max_length=12)
    description: Optional[Annotated[str, StringConstraints(max_length=500)]] = None


class SandboxPatientCreate(Strict):
    scopes: list[ConsentScope] = Field(default_factory=list, max_length=8)
    profile: Literal["knee_rehab", "lower_back", "shoulder", "generic"] = "generic"


class PairingCodeCreate(Strict):
    app_id: Optional[SafeId] = None
    scopes: list[ConsentScope] = Field(min_length=1, max_length=8)
    consent_doc_version: Annotated[str, StringConstraints(min_length=1, max_length=64)]


class LinkScopesUpdate(Strict):
    scopes: list[ConsentScope] = Field(min_length=1, max_length=8)


class IngestConfigUpdate(Strict):
    # segundos por métrica; null quita el ajuste y vuelve al valor del device-model
    intervals: dict[Metric, Optional[Annotated[int, Field(ge=1, le=86400)]]] = Field(max_length=32)

    @field_validator("intervals")
    @classmethod
    def _not_empty(cls, value):
        if not value:
            raise ValueError("intervals no puede estar vacío")
        return value


class SourcePriorityUpdate(Strict):
    # 0-100; a mayor valor, más prioridad cuando dos fuentes envían el mismo día (50 por defecto)
    source_priority: int = Field(ge=0, le=100)


class DevPatientSession(Strict):
    external_ref: Optional[SafeId] = None


class DateRange(Strict):
    from_date: date
    to_date: date
