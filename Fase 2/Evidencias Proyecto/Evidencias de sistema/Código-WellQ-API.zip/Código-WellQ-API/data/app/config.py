import os
from pathlib import Path

from dotenv import load_dotenv

# en local se lee .env; en Vercel las variables vienen del proyecto
load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, "true" if default else "false").strip().lower() == "true"


APP_NAME = os.getenv("APP_NAME", "WellQ Partner API")
APP_ENV = os.getenv("APP_ENV", "production")
DEV_APP_ENVS = ("dev", "development", "local", "test")

# misma base y mismo secreto JWT que la app WellQ: así se aceptan los tokens de paciente y de clínico
MONGO_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGODB_DB", "wellq-dev-1")
MONGO_CENTRAL_URI = os.getenv("MONGO_CENTRAL_URI") or MONGO_URI
MONGODB_CENTRAL_DB = os.getenv("MONGODB_CENTRAL_DB", "wellq_platform")
TENANT_DB_ENCRYPTION_KEY = os.getenv("TENANT_DB_ENCRYPTION_KEY", "")
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALG = os.getenv("JWT_ALG", "HS256")

REDIS_URL = os.getenv("REDIS_URL", "")
REDIS_HOST = os.getenv("REDIS_HOST", "")
REDIS_PORT = os.getenv("REDIS_PORT", "6379")
REDIS_USER = os.getenv("REDIS_USER", "")
REDIS_PASS = os.getenv("REDIS_PASS", "")
REDIS_DB = os.getenv("REDIS_DB", "0")

SMTP_SERVER = os.getenv("SMTP_SERVER", "")
SMTP_PORT = _int("SMTP_PORT", 587)
SMTP_SENDER_EMAIL = os.getenv("SMTP_SENDER_EMAIL", "")
SMTP_SENDER_NAME = os.getenv("SMTP_SENDER_NAME", "WellQ")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_USE_TLS = _bool("SMTP_USE_TLS", True)

CORS_ALLOW_ORIGINS = [o.strip() for o in os.getenv("CORS_ALLOW_ORIGINS", "").split(",") if o.strip()]
# Vercel Cron llama a /api/v1/internal/cron/* con "Authorization: Bearer $CRON_SECRET"
CRON_SECRET = os.getenv("CRON_SECRET", "")
PARTNER_LOCAL_SCHEDULER = _bool("PARTNER_LOCAL_SCHEDULER")

PARTNER_API_ENABLED = _bool("PARTNER_API_ENABLED", True)
PARTNER_TOKEN_SECRET = os.getenv("PARTNER_TOKEN_SECRET", "")
PARTNER_ENCRYPTION_KEY = os.getenv("PARTNER_ENCRYPTION_KEY", "")
PARTNER_TOKEN_ISSUER = os.getenv("PARTNER_TOKEN_ISSUER", "wellq-partner")
PARTNER_SANDBOX_DB = os.getenv("PARTNER_SANDBOX_DB", "wellq_partner_sandbox")
PARTNER_DEFAULT_RPM = _int("PARTNER_DEFAULT_RPM", 600)
PARTNER_DEFAULT_SAMPLES_PER_DAY = _int("PARTNER_DEFAULT_SAMPLES_PER_DAY", 5_000_000)
PARTNER_PUBLIC_RPM_PER_IP = _int("PARTNER_PUBLIC_RPM_PER_IP", 20)
# Vercel corta los cuerpos de más de 4,5 MB, por eso el límite de /samples queda por debajo
PARTNER_MAX_BODY_BYTES = _int("PARTNER_MAX_BODY_BYTES", 1_048_576)
PARTNER_MAX_SAMPLES_BODY_BYTES = _int("PARTNER_MAX_SAMPLES_BODY_BYTES", 4_194_304)
PARTNER_MAX_DECOMPRESSED_BYTES = _int("PARTNER_MAX_DECOMPRESSED_BYTES", 26_214_400)
PARTNER_DEFAULT_STEPS_TARGET = _int("PARTNER_DEFAULT_STEPS_TARGET", 7000)
PARTNER_PORTAL_BASE_URL = os.getenv("PARTNER_PORTAL_BASE_URL", "")
# plazos: un borrado de datos debe quedar terminado en estas horas; si no, salta una alerta
PARTNER_DELETION_DEADLINE_HOURS = _int("PARTNER_DELETION_DEADLINE_HOURS", 72)
# una carga asíncrona en cola o procesándose más de estos minutos se considera atascada
PARTNER_INGEST_JOB_ALERT_MINUTES = _int("PARTNER_INGEST_JOB_ALERT_MINUTES", 60)
# correo de operaciones de WellQ que recibe las alertas (borrados vencidos, avisos no entregados, cargas atascadas)
PARTNER_ALERT_EMAIL = os.getenv("PARTNER_ALERT_EMAIL", "")
PARTNER_DEMO_ENABLED = _bool("PARTNER_DEMO_ENABLED")
PARTNER_DEV_TOOLS_ENABLED = _bool("PARTNER_DEV_TOOLS_ENABLED")
PARTNER_WEBHOOK_ALLOW_PRIVATE = _bool("PARTNER_WEBHOOK_ALLOW_PRIVATE")
PARTNER_ADMIN_TENANT_SLUGS = [s.strip() for s in os.getenv("PARTNER_ADMIN_TENANT_SLUGS", "").split(",") if s.strip()]

# login del dashboard web (demo, /docs y herramientas de desarrollo); sin estas tres variables queda cerrado
DASHBOARD_USER = os.getenv("DASHBOARD_USER", "")
DASHBOARD_PASSWORD_HASH = os.getenv("DASHBOARD_PASSWORD_HASH", "")  # python -m app.scripts.hash_password
DASHBOARD_SESSION_SECRET = os.getenv("DASHBOARD_SESSION_SECRET", "")
DASHBOARD_SESSION_HOURS = _int("DASHBOARD_SESSION_HOURS", 8)
DASHBOARD_LOGIN_RPM_PER_IP = _int("DASHBOARD_LOGIN_RPM_PER_IP", 5)
# solo para desarrollo local y tests: se ignora fuera de APP_ENV de desarrollo y en Vercel
DASHBOARD_LOGIN_DISABLED = _bool("DASHBOARD_LOGIN_DISABLED")
