'use strict';

(() => {
  // misma origen siempre: los tokens nunca salen hacia otro host
  const API = new URL('/api/v1', window.location.origin).toString();
  const SECRET_KEYS = new Set(['portal_token', 'client_secret', 'access_token', 'webhook_secret', 'patient_token',
    'clinician_token', 'admin_token', 'verification_token', 'narrow_token']);
  const S = {};
  const today = new Date();
  const isoDay = (offset) => new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() - offset))
    .toISOString().slice(0, 10);
  const isoTs = (offsetHours) => new Date(Date.now() - offsetHours * 3600 * 1000).toISOString().replace(/\.\d+Z$/, 'Z');
  const uuid = () => crypto.randomUUID();
  const $ = (id) => document.getElementById(id);
  let busy = false;

  const el = (tag, attrs = {}, ...children) => {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v);
    }
    for (const c of children) node.append(c);
    return node;
  };

  const mask = (v) => (typeof v === 'string' && v.length > 10 ? `${v.slice(0, 6)}…${v.slice(-4)}` : '••••');

  function renderState() {
    const dl = $('state');
    dl.replaceChildren();
    for (const [k, v] of Object.entries(S)) {
      if (v === undefined || v === null) continue;
      const secret = SECRET_KEYS.has(k);
      const value = typeof v === 'object' ? JSON.stringify(v) : String(v);
      const copy = el('button', { type: 'button', 'aria-label': `Copiar ${k}`, text: 'Copiar' });
      copy.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(value); log(`Copiado ${k}`, 'ok'); } catch { log('No se pudo copiar', 'warn'); }
      });
      dl.append(el('dt', { text: k }), el('dd', { text: secret ? mask(value) : value }), copy);
    }
  }

  function set(values) {
    Object.assign(S, values);
    renderState();
  }

  function log(text, cls = '') {
    const li = el('li', { class: cls, text: `${new Date().toLocaleTimeString('es-ES', { hour12: false })} · ${text}` });
    $('log').prepend(li);
    while ($('log').children.length > 200) $('log').lastChild.remove();
  }

  function showResponse(res) {
    const line = $('status-line');
    const ok = res.status >= 200 && res.status < 300;
    line.className = `status-line ${ok ? 'ok' : res.status >= 500 || res.status === 0 ? 'err' : 'warn'}`;
    const extra = [res.headers.trace ? `trace ${res.headers.trace}` : '', res.headers.replayed ? 'replay idempotente' : '',
      res.headers.limit ? `rate ${res.headers.remaining}/${res.headers.limit}` : ''].filter(Boolean).join(' · ');
    line.textContent = `${res.method} ${res.path} → ${res.status || 'error de red'} ${extra ? `(${extra})` : ''}`;
    let text = res.text;
    if (res.json !== undefined) {
      text = JSON.stringify(redact(res.json), null, 2);
      if (res.problem) {
        const p = res.json;
        text = `${p.title || 'Error'} (${p.status})\n${p.detail || ''}\n` +
          (Array.isArray(p.errors) ? p.errors.map((e) => `· ${e.path}: ${e.message}`).join('\n') + '\n' : '') +
          `tipo: ${p.type}\ntrace_id: ${p.trace_id || '-'}\n\n${text}`;
      }
    }
    // el texto del servidor se pinta siempre con textContent, nunca como HTML
    $('response').textContent = text.length > 200000 ? `${text.slice(0, 200000)}\n… (recortado)` : text;
  }

  function redact(value) {
    if (Array.isArray(value)) return value.map(redact);
    if (value && typeof value === 'object') {
      const out = {};
      for (const [k, v] of Object.entries(value)) {
        out[k] = ['client_secret', 'access_token', 'portal_token', 'secret', 'verification_token'].includes(k) && typeof v === 'string'
          ? mask(v) : redact(v);
      }
      return out;
    }
    return value;
  }

  const AUTH = {
    none: () => null, portal: () => S.portal_token, partner: () => S.access_token, patient: () => S.patient_token,
    clinician: () => S.clinician_token, admin: () => S.admin_token, narrow: () => S.narrow_token,
  };

  async function call(method, path, { auth = 'none', json, raw, headers = {}, form, quiet = false } = {}) {
    const url = new URL(API + path);
    if (url.origin !== window.location.origin) throw new Error('URL fuera del origen permitido');
    const h = { Accept: 'application/json, application/problem+json', ...headers };
    const token = AUTH[auth] ? AUTH[auth]() : null;
    if (auth !== 'none' && !token) throw new Error(`Falta el token (${auth}); ejecuta antes el paso que lo obtiene`);
    if (token) h.Authorization = `Bearer ${token}`;
    let body;
    if (form) { body = new URLSearchParams(form); h['Content-Type'] = 'application/x-www-form-urlencoded'; }
    else if (raw !== undefined) body = raw;
    else if (json !== undefined) { body = JSON.stringify(json); h['Content-Type'] = 'application/json'; }
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 30000);
    const res = { method, path, status: 0, headers: {}, text: '' };
    try {
      // same-origin: la API no usa cookies, pero la protección de despliegues de Vercel exige su cookie _vercel_jwt
      const r = await fetch(url, { method, headers: h, body, credentials: 'same-origin', cache: 'no-store', signal: ctrl.signal,
        redirect: 'error', referrerPolicy: 'no-referrer' });
      res.status = r.status;
      res.headers = { trace: r.headers.get('X-Trace-Id'), replayed: r.headers.get('Idempotency-Replayed'),
        limit: r.headers.get('RateLimit-Limit'), remaining: r.headers.get('RateLimit-Remaining') };
      res.text = await r.text();
      const ctype = r.headers.get('content-type') || '';
      res.problem = ctype.includes('problem+json');
      if (ctype.includes('json') && res.text) {
        try { res.json = JSON.parse(res.text); } catch { /* respuesta no JSON */ }
      }
    } catch (err) {
      res.text = err.name === 'AbortError' ? 'Tiempo de espera agotado (30 s)' : `Error de red: ${err.message}`;
    } finally {
      clearTimeout(timer);
    }
    if (!quiet) {
      showResponse(res);
      log(`${method} ${path} → ${res.status || 'error'}`, res.status >= 200 && res.status < 300 ? 'ok' : 'err');
    }
    return res;
  }

  async function gzip(text) {
    if (!('CompressionStream' in window)) throw new Error('El navegador no soporta CompressionStream');
    const stream = new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  const sample = {
    summaries: () => ({ summaries: [
      { record_id: `acme-${S.link_id}-${isoDay(1)}`, local_date: isoDay(1), tz_offset_minutes: 60, device_id: 'ACME-BAND-2-SN0091',
        completeness: 'final', wear_time_minutes: 1380, steps: 7412, distance_m: 5210.5, active_minutes: 48,
        calories_active_kcal: 412, resting_heart_rate_bpm: 58, hrv_rmssd_ms: 46.2, sleep_total_minutes: 431, recovery_score: 71 },
      { record_id: `acme-${S.link_id}-${isoDay(0)}`, local_date: isoDay(0), tz_offset_minutes: 60, device_id: 'ACME-BAND-2-SN0091',
        completeness: 'partial', steps: 3120, resting_heart_rate_bpm: 60, hrv_rmssd_ms: 44.1 }] }),
    samples: () => ({ series: [{ metric: 'heart_rate', unit: 'bpm', device_id: 'ACME-BAND-2-SN0091', start: isoTs(3),
      offsets_ms: [0, 60000, 120000, 180000, 240000], values: [61, 63, 60, 62, 64] }] }),
    sessions: () => ({ sessions: [
      { session_type: 'sleep', record_id: `sleep-${isoDay(1)}`, device_id: 'ACME-BAND-2-SN0091', start: `${isoDay(1)}T22:40:00Z`,
        end: `${isoDay(0)}T06:15:00Z`, stages: [{ stage: 'deep', start: `${isoDay(1)}T23:30:00Z`, end: `${isoDay(0)}T00:30:00Z` }],
        summary: { total_sleep_minutes: 431, efficiency_pct: 91 } },
      { session_type: 'exercise', record_id: `ex-${isoDay(0)}`, device_id: 'ACME-BAND-2-SN0091', start: isoTs(5), end: isoTs(4.4),
        activity_type: 'strength_training', sets: [{ set_index: 1, repetitions: 12, load_kg: 10, rpe: 6 }] }] }),
    msk: () => ({ measurements: [{ record_id: `msk-${uuid().slice(0, 8)}`, device_id: 'ACME-SLEEVE-SN014', timestamp: isoTs(2),
      measurement_type: 'range_of_motion_flexion', body_region: 'knee', side: 'right', value: 118.5, unit: 'deg',
      context: 'prescribed_exercise', confidence: 0.92 }] }),
    events: () => ({ events: [{ record_id: `ev-${uuid().slice(0, 8)}`, device_id: 'ACME-BAND-2-SN0091', timestamp: isoTs(6),
      event_type: 'worn' }] }),
  };

  const OPS = [
    { g: 'Alta del fabricante', id: 'register', m: 'POST', p: '/partner/developers/register', t: 'Registrar desarrollador',
      body: () => ({ company_name: 'Acme Wearables Ltd', contact_email: `dev-${uuid().slice(0, 8)}@acme-wearables.com`,
        country: 'GB', accept_terms: true }),
      after: (r) => set({ developer_id: r.json.developer_id, verification_token: r.json.verification_token }) },
    { g: 'Alta del fabricante', id: 'verify', m: 'POST', p: '/partner/developers/verify', t: 'Verificar correo',
      body: () => ({ developer_id: S.developer_id, verification_token: S.verification_token || '' }),
      after: (r) => set({ portal_token: r.json.portal_token }) },
    { g: 'Alta del fabricante', id: 'createApp', m: 'POST', p: '/partner/apps', auth: 'portal', t: 'Crear app (credenciales sandbox)',
      body: () => ({ name: 'Acme Health Cloud', logo_url: 'https://acme-wearables.example/logo.png',
        privacy_policy_url: 'https://acme-wearables.example/privacy', requested_scopes: ['ingest:activity', 'ingest:sleep',
          'ingest:vitals', 'ingest:msk', 'ingest:device', 'read:goals', 'read:scores'] }),
      after: (r) => set({ app_id: r.json.app_id, client_id: r.json.client_id, client_secret: r.json.client_secret }) },
    { g: 'Alta del fabricante', id: 'listApps', m: 'GET', p: '/partner/apps', auth: 'portal', t: 'Listar apps' },
    { g: 'Alta del fabricante', id: 'getApp', m: 'GET', p: '/partner/apps/{app_id}', auth: 'portal', t: 'Ver app' },
    { g: 'Alta del fabricante', id: 'patchApp', m: 'PATCH', p: '/partner/apps/{app_id}', auth: 'portal', t: 'Actualizar app',
      body: () => ({ description: 'Pulsera de rehabilitación de rodilla' }) },
    { g: 'Alta del fabricante', id: 'rotate', m: 'POST', p: '/partner/apps/{app_id}/secrets/rotate', auth: 'portal',
      t: 'Rotar client_secret', body: () => ({ grace_period_seconds: 0 }),
      after: (r) => set({ client_secret: r.json.client_secret, access_token: null }) },
    { g: 'Alta del fabricante', id: 'promotion', m: 'POST', p: '/partner/apps/{app_id}/promotion-requests', auth: 'portal',
      t: 'Pedir paso a producción', body: () => ({ dpa_accepted: true, security_contact_email: 'security@acme-wearables.com',
        expected_monthly_volume: 50000 }), after: (r) => set({ request_id: r.json.request_id }) },
    { g: 'OAuth', id: 'token', m: 'POST', p: '/partner/oauth/token', t: 'Pedir access_token (client credentials)',
      form: () => ({ grant_type: 'client_credentials', client_id: S.client_id, client_secret: S.client_secret }),
      after: (r) => set({ access_token: r.json.access_token, token_scope: r.json.scope }) },
    { g: 'OAuth', id: 'narrowToken', m: 'POST', p: '/partner/oauth/token', t: 'Pedir token solo con links:manage',
      form: () => ({ grant_type: 'client_credentials', client_id: S.client_id, client_secret: S.client_secret, scope: 'links:manage' }),
      after: (r) => set({ narrow_token: r.json.access_token }) },
    { g: 'Capacidades', id: 'metrics', m: 'GET', p: '/partner/capabilities/metrics', auth: 'partner', t: 'Diccionario de métricas',
      query: { category: '' } },
    { g: 'Capacidades', id: 'createModel', m: 'POST', p: '/partner/apps/{app_id}/device-models', auth: 'partner',
      t: 'Declarar device-model', body: () => ({ model_code: 'ACME-BAND-2', display_name: 'Acme Band 2', form_factor: 'band',
        body_placement: 'wrist_left', capabilities: [{ metric: 'steps', sampling_mode: 'daily_aggregate' },
          { metric: 'heart_rate', typical_interval_seconds: 60, sampling_mode: 'continuous' }, { metric: 'resting_heart_rate' },
          { metric: 'hrv_rmssd' }, { metric: 'sleep' }, { metric: 'exercise' }, { metric: 'distance' }, { metric: 'calories_active' },
          { metric: 'active_minutes' }, { metric: 'range_of_motion_flexion' }, { metric: 'device_wear' }],
        regulatory: { ukca_or_ce_medical_device: false } }), after: () => set({ model_code: 'ACME-BAND-2' }) },
    { g: 'Capacidades', id: 'listModels', m: 'GET', p: '/partner/apps/{app_id}/device-models', auth: 'partner', t: 'Listar device-models' },
    { g: 'Webhooks', id: 'createWebhook', m: 'POST', p: '/partner/apps/{app_id}/webhooks', auth: 'partner', t: 'Registrar webhook',
      body: () => ({ url: new URL('/api/v1/partner-dev/webhook-sink', window.location.origin).toString(),
        events: ['ping', 'link.created', 'link.revoked', 'link.scopes_changed', 'link.config_changed', 'ingest.job.completed',
          'ingest.job.failed', 'patient.data_deletion_requested', 'app.promoted', 'app.suspended', 'goals.updated', 'sync.gap_detected'] }),
      after: (r) => set({ webhook_id: r.json.webhook_id, webhook_secret: r.json.secret }) },
    { g: 'Webhooks', id: 'listWebhooks', m: 'GET', p: '/partner/apps/{app_id}/webhooks', auth: 'partner', t: 'Listar webhooks' },
    { g: 'Webhooks', id: 'testWebhook', m: 'POST', p: '/partner/apps/{app_id}/webhooks/{webhook_id}/test', auth: 'partner',
      t: 'Enviar ping' },
    { g: 'Webhooks', id: 'deliveries', m: 'GET', p: '/partner/apps/{app_id}/webhooks/{webhook_id}/deliveries', auth: 'partner',
      t: 'Historial de entregas', query: { limit: '20', cursor: '' } },
    { g: 'Webhooks', id: 'deleteWebhook', m: 'DELETE', p: '/partner/apps/{app_id}/webhooks/{webhook_id}', auth: 'partner',
      t: 'Eliminar webhook' },
    { g: 'Webhooks', id: 'sink', m: 'GET', p: '/partner-dev/webhook-sink', t: 'Ver lo recibido y verificar la firma',
      after: (r) => verifySink(r.json) },
    { g: 'Sandbox', id: 'sandboxPatient', m: 'POST', p: '/partner/sandbox/patients', auth: 'partner', t: 'Paciente sintético + código',
      body: () => ({ profile: 'knee_rehab', scopes: ['ingest:activity', 'ingest:sleep', 'ingest:vitals', 'ingest:msk',
        'ingest:device', 'read:goals', 'read:scores'] }),
      after: (r) => set({ sandbox_patient_id: r.json.sandbox_patient_id, pairing_code: r.json.pairing_code }) },
    { g: 'Vínculos', id: 'redeem', m: 'POST', p: '/partner/links', auth: 'partner', t: 'Canjear código y crear vínculo',
      body: () => ({ pairing_code: S.pairing_code, external_user_id: `u_${uuid().slice(0, 6)}`, device_id: 'ACME-BAND-2-SN0091',
        model_code: S.model_code || undefined, timezone: 'Europe/London' }),
      after: (r) => set({ link_id: r.json.link_id }) },
    { g: 'Vínculos', id: 'listLinks', m: 'GET', p: '/partner/links', auth: 'partner', t: 'Listar vínculos',
      query: { status: '', external_user_id: '', limit: '50', cursor: '' } },
    { g: 'Vínculos', id: 'getLink', m: 'GET', p: '/partner/links/{link_id}', auth: 'partner', t: 'Estado del vínculo' },
    { g: 'Vínculos', id: 'syncState', m: 'GET', p: '/partner/links/{link_id}/sync-state', auth: 'partner', t: 'Estado de sincronización' },
    { g: 'Vínculos', id: 'linkConfig', m: 'GET', p: '/partner/links/{link_id}/config', auth: 'partner', t: 'Frecuencia efectiva' },
    { g: 'Vínculos', id: 'revokeLink', m: 'DELETE', p: '/partner/links/{link_id}', auth: 'partner', t: 'Desvincular (fabricante)' },
    { g: 'Ingesta', id: 'daily', m: 'POST', p: '/partner/links/{link_id}/daily-summaries', auth: 'partner', t: 'Resúmenes diarios',
      body: sample.summaries, idem: true },
    { g: 'Ingesta', id: 'samples', m: 'POST', p: '/partner/links/{link_id}/samples', auth: 'partner', t: 'Series (gzip, 202 + job)',
      body: sample.samples, gzip: true, idem: true, after: (r) => set({ job_id: r.json.job_id }) },
    { g: 'Ingesta', id: 'job', m: 'GET', p: '/partner/ingest/jobs/{job_id}', auth: 'partner', t: 'Estado del job' },
    { g: 'Ingesta', id: 'sessions', m: 'POST', p: '/partner/links/{link_id}/sessions', auth: 'partner', t: 'Sesiones de sueño y ejercicio',
      body: sample.sessions, idem: true },
    { g: 'Ingesta', id: 'msk', m: 'POST', p: '/partner/links/{link_id}/msk-measurements', auth: 'partner', t: 'Mediciones MSK',
      body: sample.msk, idem: true },
    { g: 'Ingesta', id: 'events', m: 'POST', p: '/partner/links/{link_id}/device-events', auth: 'partner', t: 'Eventos del dispositivo',
      body: sample.events, idem: true },
    { g: 'Lectura del fabricante', id: 'goals', m: 'GET', p: '/partner/links/{link_id}/goals', auth: 'partner', t: 'Objetivos' },
    { g: 'Lectura del fabricante', id: 'scores', m: 'GET', p: '/partner/links/{link_id}/scores', auth: 'partner', t: 'Scores diarios',
      query: { from_date: isoDay(6), to_date: isoDay(0), types: '' } },
    { g: 'App del paciente', id: 'patientSession', m: 'POST', p: '/partner-dev/patient-session', t: 'Sesión de paciente sintético (dev)',
      body: () => ({}), after: (r) => set({ patient_token: r.json.access_token, patient_id: r.json.patient_id }) },
    { g: 'App del paciente', id: 'partners', m: 'GET', p: '/wearables/partners', auth: 'patient', t: 'Fabricantes disponibles' },
    { g: 'App del paciente', id: 'consent', m: 'GET', p: '/wearables/consent-info', auth: 'patient', t: 'Pantalla de consentimiento',
      query: { app_id: '{app_id}' } },
    { g: 'App del paciente', id: 'pairingCode', m: 'POST', p: '/wearables/pairing-codes', auth: 'patient', t: 'Generar código',
      body: () => ({ app_id: S.app_id, scopes: ['ingest:activity', 'ingest:sleep', 'ingest:vitals', 'read:scores'],
        consent_doc_version: 'wearable-sharing-v1' }), after: (r) => set({ pairing_code: r.json.pairing_code }) },
    { g: 'App del paciente', id: 'patientLinks', m: 'GET', p: '/wearables/links', auth: 'patient', t: 'Mis dispositivos' },
    { g: 'App del paciente', id: 'patchScopes', m: 'PATCH', p: '/wearables/links/{link_id}', auth: 'patient', t: 'Retirar permisos',
      body: () => ({ scopes: ['ingest:activity', 'ingest:sleep', 'ingest:vitals'] }) },
    { g: 'App del paciente', id: 'patientRevoke', m: 'DELETE', p: '/wearables/links/{link_id}', auth: 'patient',
      t: 'Revocar y borrar datos', query: { delete_data: 'true' } },
    ...['records', 'sleeps', 'workouts', 'statistics/daily', 'statistics/interval', 'timeseries'].map((kind) => (
      { g: 'Datos (paciente)', id: `pdata-${kind}`, m: 'GET', p: `/wearables/data/${kind}`, auth: 'patient', t: `Lectura tipo Spike: ${kind}`,
        query: dataQuery(kind) })),
    { g: 'Panel clínico', id: 'clinicianSession', m: 'POST', p: '/partner-dev/clinician-session', t: 'Sesión de clínico (dev)',
      body: () => ({ patient_id: S.patient_id || S.sandbox_patient_id }), after: (r) => set({ clinician_token: r.json.access_token }) },
    { g: 'Panel clínico', id: 'clinWearables', m: 'GET', p: '/maindash/patient/{patient_id}/wearables', auth: 'clinician',
      t: 'Dispositivos del paciente' },
    { g: 'Panel clínico', id: 'ingestConfig', m: 'PUT', p: '/maindash/patient/{patient_id}/wearables/{link_id}/ingest-config',
      auth: 'clinician', t: 'Ajustar frecuencia por vínculo', body: () => ({ intervals: { heart_rate: 120 } }) },
    ...['records', 'sleeps', 'workouts', 'statistics/daily', 'statistics/interval', 'timeseries'].map((kind) => (
      { g: 'Datos (clínico)', id: `cdata-${kind}`, m: 'GET', p: `/maindash/patient/{patient_id}/wearables/data/${kind}`,
        auth: 'clinician', t: `Lectura tipo Spike: ${kind}`, query: dataQuery(kind) })),
    { g: 'Administración', id: 'adminSession', m: 'POST', p: '/partner-dev/admin-session', t: 'Sesión itadmin (dev)',
      after: (r) => set({ admin_token: r.json.access_token }) },
    { g: 'Administración', id: 'listPromotions', m: 'GET', p: '/partner/admin/promotion-requests', auth: 'admin', t: 'Solicitudes',
      query: { status: 'under_review' } },
    { g: 'Administración', id: 'approve', m: 'POST', p: '/partner/admin/promotion-requests/{request_id}/approve', auth: 'admin',
      t: 'Aprobar (producción)', body: () => ({ notes: 'Checklist revisado' }) },
    { g: 'Administración', id: 'reject', m: 'POST', p: '/partner/admin/promotion-requests/{request_id}/reject', auth: 'admin',
      t: 'Rechazar', body: () => ({ notes: 'Falta probar el webhook' }) },
    { g: 'Administración', id: 'suspend', m: 'POST', p: '/partner/admin/apps/{app_id}/suspend', auth: 'admin', t: 'Suspender app',
      body: () => ({ notes: 'Prueba' }) },
    { g: 'Administración', id: 'reactivate', m: 'POST', p: '/partner/admin/apps/{app_id}/reactivate', auth: 'admin', t: 'Reactivar app' },
  ];

  function dataQuery(kind) {
    if (kind === 'sleeps' || kind === 'statistics/daily') {
      return { from_date: isoDay(6), to_date: isoDay(0), ...(kind === 'statistics/daily' ? { types: 'steps,sleep_duration,heart_rate_resting' } : { include_stages: 'true' }) };
    }
    const base = { from_timestamp: isoTs(24 * 7), to_timestamp: isoTs(0) };
    if (kind === 'statistics/interval') return { ...base, types: 'heart_rate', interval: 'hourly' };
    if (kind === 'timeseries') return { ...base, metric: 'heart_rate', merge_method: 'select_highest_priority_source' };
    if (kind === 'workouts') return { ...base, include_sessions: 'true' };
    return { ...base, include_samples: 'false' };
  }

  function resolvePath(path, values) {
    return path.replace(/\{(\w+)\}/g, (_, key) => {
      const v = values[key] ?? S[key] ?? (key === 'patient_id' ? S.sandbox_patient_id : undefined);
      if (!v) throw new Error(`Falta ${key}`);
      if (!/^[A-Za-z0-9._:\-]+$/.test(v)) throw new Error(`${key} con caracteres no válidos`);
      return encodeURIComponent(v);
    });
  }

  async function runOp(op, overrides = {}) {
    const values = overrides.values || {};
    let path = resolvePath(op.p, values);
    const query = { ...(op.query || {}), ...(overrides.query || {}) };
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
      const val = String(v).replace(/\{(\w+)\}/g, (_, key) => S[key] || '');
      if (val !== '') qs.set(k, val);
    }
    if ([...qs].length) path += `?${qs}`;
    const opts = { auth: overrides.auth || op.auth || 'none', headers: { ...(overrides.headers || {}) } };
    if (op.form) opts.form = op.form();
    const body = overrides.body !== undefined ? overrides.body : (op.body ? op.body() : undefined);
    if (op.idem && !opts.headers['Idempotency-Key']) opts.headers['Idempotency-Key'] = uuid();
    if (body !== undefined && !op.form) {
      if (op.gzip && !overrides.noGzip) {
        opts.raw = await gzip(JSON.stringify(body));
        opts.headers['Content-Encoding'] = 'gzip';
        opts.headers['Content-Type'] = 'application/json';
      } else opts.json = body;
    }
    if (overrides.raw !== undefined) { opts.raw = overrides.raw; delete opts.json; }
    const res = await call(op.m, path, opts);
    if (res.status >= 200 && res.status < 300 && op.after && res.json !== undefined) op.after(res);
    return res;
  }

  async function verifySink(items) {
    if (!Array.isArray(items) || !S.webhook_secret) return;
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(S.webhook_secret), { name: 'HMAC', hash: 'SHA-256' },
      false, ['sign']);
    for (const item of items.slice(-5)) {
      const parts = Object.fromEntries((item.signature || '').split(',').map((kv) => kv.split('=')));
      const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${parts.t}.${item.body}`));
      const hex = [...new Uint8Array(mac)].map((b) => b.toString(16).padStart(2, '0')).join('');
      const fresh = Math.abs(Date.now() / 1000 - Number(parts.t)) <= 300;
      log(`Webhook ${item.event}: firma ${hex === parts.v1 ? 'válida' : 'INVÁLIDA'}${fresh ? '' : ' (más de 5 min)'}`,
        hex === parts.v1 && fresh ? 'ok' : 'err');
    }
  }

  function buildUi() {
    const groups = new Map();
    const tpl = $('op-template');
    for (const op of OPS) {
      if (!groups.has(op.g)) {
        const section = el('section', { class: 'group' }, el('h3', { text: op.g }));
        groups.set(op.g, section);
        $('groups').append(section);
      }
      const node = tpl.content.firstElementChild.cloneNode(true);
      node.dataset.search = `${op.g} ${op.m} ${op.p} ${op.t}`.toLowerCase();
      node.querySelector('.method').textContent = op.m;
      node.querySelector('.method').classList.add(op.m);
      node.querySelector('.path').textContent = op.p;
      node.querySelector('.title').textContent = op.t;
      node.querySelector('.op-desc').textContent = op.auth ? `Autenticación: ${op.auth}` : 'Sin autenticación';
      const params = node.querySelector('.params');
      const textarea = node.querySelector('.body');
      const err = node.querySelector('.error-msg');
      const inputs = {};
      const pathVars = [...op.p.matchAll(/\{(\w+)\}/g)].map((m) => m[1]);
      for (const name of [...pathVars, ...Object.keys(op.query || {})]) {
        const input = el('input', { type: 'text', name, autocomplete: 'off', spellcheck: 'false' });
        inputs[name] = input;
        params.append(el('label', { text: name }, input));
      }
      if (!op.body) node.querySelector('.body-label').hidden = true;
      node.addEventListener('toggle', () => {
        if (!node.open) return;
        for (const name of pathVars) inputs[name].value = S[name] || (name === 'patient_id' ? S.sandbox_patient_id || '' : '');
        for (const [k, v] of Object.entries(op.query || {})) {
          if (!inputs[k].value) inputs[k].value = String(v).replace(/\{(\w+)\}/g, (_, key) => S[key] || '');
        }
        if (op.body) {
          try { textarea.value = JSON.stringify(op.body(), null, 2); } catch { textarea.value = '{}'; }
        }
      });
      const send = node.querySelector('.send');
      send.addEventListener('click', () => guarded(send, async () => {
        err.textContent = '';
        let body;
        if (op.body) {
          try { body = JSON.parse(textarea.value || '{}'); } catch (e) { err.textContent = `JSON inválido: ${e.message}`; return; }
        }
        const values = Object.fromEntries(pathVars.map((n) => [n, inputs[n].value.trim()]));
        const query = Object.fromEntries(Object.keys(op.query || {}).map((n) => [n, inputs[n].value.trim()]));
        try { await runOp(op, { values, query, body }); } catch (e) { err.textContent = e.message; log(e.message, 'err'); }
      }));
      groups.get(op.g).append(node);
    }
    $('filter').addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      for (const node of document.querySelectorAll('.op')) node.hidden = q !== '' && !node.dataset.search.includes(q);
    });
  }

  async function guarded(button, fn) {
    if (busy) return;
    busy = true;
    const buttons = document.querySelectorAll('button');
    buttons.forEach((b) => { if (b !== button) b.disabled = true; });
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    try { await fn(); } finally {
      buttons.forEach((b) => { b.disabled = false; });
      button.removeAttribute('aria-busy');
      busy = false;
    }
  }

  const op = (id) => OPS.find((o) => o.id === id);
  async function step(id, expect, overrides) {
    const res = await runOp(op(id), overrides);
    const ok = Array.isArray(expect) ? expect.includes(res.status) : res.status === expect;
    if (!ok) throw new Error(`${op(id).t}: se esperaba ${expect} y llegó ${res.status}`);
    return res;
  }

  async function waitJob() {
    for (let i = 0; i < 30; i += 1) {
      const res = await step('job', 200);
      if (!['queued', 'processing'].includes(res.json.status)) return res;
      await new Promise((r) => setTimeout(r, 1000));
    }
    throw new Error('El job no terminó en 30 s (¿está el worker o el barrido programado activo?)');
  }

  async function fullFlow() {
    log('Inicio del flujo completo', 'ok');
    await step('register', 202);
    if (!S.verification_token) throw new Error('Sin token de verificación: revisa el correo (SMTP configurado) y pégalo en verify');
    await step('verify', 200);
    await step('createApp', 201);
    await step('token', 200);
    await step('metrics', 200);
    await step('createModel', 201);
    await step('createWebhook', 201);
    await step('testWebhook', 200);
    await step('sandboxPatient', 201);
    await step('redeem', 201);
    await step('daily', 200);
    await step('samples', 202);
    await waitJob();
    await step('sessions', 200);
    await step('msk', 200);
    await step('events', 200);
    await step('syncState', 200);
    await step('goals', 200);
    await step('scores', 200);
    await step('deliveries', 200);
    await step('sink', 200);
    set({ patient_id: S.sandbox_patient_id });
    await step('clinicianSession', 200);
    await step('clinWearables', 200);
    await step('ingestConfig', 200);
    await step('linkConfig', 200);
    for (const kind of ['records', 'sleeps', 'workouts', 'statistics/daily', 'statistics/interval', 'timeseries']) {
      await step(`cdata-${kind}`, 200);
    }
    await step('patientSession', 200);
    await step('partners', 200);
    await step('consent', 200);
    await step('pairingCode', 201);
    await step('redeem', 201);
    await step('patientLinks', 200);
    for (const kind of ['records', 'sleeps', 'workouts', 'statistics/daily', 'statistics/interval', 'timeseries']) {
      await step(`pdata-${kind}`, 200);
    }
    await step('patchScopes', 200);
    await step('patientRevoke', 204);
    await step('goals', 403);
    await step('promotion', 202);
    await step('adminSession', 200);
    await step('listPromotions', 200);
    await step('approve', 200);
    await step('rotate', 200);
    await step('token', 200);
    await step('listLinks', 200);
    log('Flujo completo superado', 'ok');
  }

  async function errorCases() {
    log('Casos de error', 'warn');
    // cuenta nueva en sandbox: no depende de lo que haya dejado el flujo completo (que acaba en producción)
    set({ model_code: null, link_id: null, webhook_id: null, webhook_secret: null });
    await step('register', 202); await step('verify', 200); await step('createApp', 201); await step('token', 200);
    await step('createWebhook', 201); await step('sandboxPatient', 201); await step('redeem', 201);
    const linkPath = { values: { link_id: S.link_id } };
    await step('narrowToken', 200);
    await step('daily', 403, { ...linkPath, auth: 'narrow' });
    const key = uuid();
    const body = sample.summaries();
    await step('daily', [200, 403], { ...linkPath, headers: { 'Idempotency-Key': key }, body });
    const replay = await step('daily', [200, 403], { ...linkPath, headers: { 'Idempotency-Key': key }, body });
    if (replay.status === 200 && replay.headers.replayed !== 'true') throw new Error('El replay no devolvió Idempotency-Replayed');
    await step('daily', [422, 403], { ...linkPath, headers: { 'Idempotency-Key': key }, body: { summaries: [body.summaries[0]] } });
    await step('daily', 413, { ...linkPath, body: { summaries: Array.from({ length: 101 }, (_, i) => ({ ...body.summaries[0], record_id: `b${i}` })) } });
    await step('redeem', 404, { body: { pairing_code: 'WQ-AAAA-AAAA', external_user_id: 'nadie' } });
    await step('createWebhook', 422, { body: { url: 'https://usuario:clave@example.com/hook', events: ['ping'] } });
    const bomb = await gzip(`{"series":[${' '.repeat(30 * 1024 * 1024)}]}`);
    await step('samples', 413, { ...linkPath, raw: bomb, headers: { 'Content-Encoding': 'gzip', 'Content-Type': 'application/json' } });
    let limited = false;
    for (let i = 0; i < 15 && !limited; i += 1) {
      const r = await call('POST', '/partner/developers/verify', { json: { developer_id: 'dev_x', verification_token: 'codigo-invalido' }, quiet: true });
      limited = r.status === 429;
    }
    if (!limited) throw new Error('No se alcanzó el rate limit');
    log('Rate limit alcanzado (429)', 'ok');
    const forged = { event: 'ping', signature: `t=${Math.floor(Date.now() / 1000)},v1=${'0'.repeat(64)}`, body: '{"event_type":"ping"}' };
    await verifySink([forged]);
    log('Casos de error completados', 'ok');
  }

  function init() {
    buildUi();
    renderState();
    $('run-flow').addEventListener('click', (e) => guarded(e.currentTarget, () => fullFlow().catch((err) => log(err.message, 'err'))));
    $('run-errors').addEventListener('click', (e) => guarded(e.currentTarget, () => errorCases().catch((err) => log(err.message, 'err'))));
    $('reset').addEventListener('click', () => { for (const k of Object.keys(S)) delete S[k]; renderState(); log('Sesión vaciada'); });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
