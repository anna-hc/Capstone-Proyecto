'use strict';

// Modo presentación de la Partner API: recorrido guiado en 5 pasos con las mismas llamadas HTTP que la demo.
// Todo el texto que llega del servidor se pinta con textContent; los secretos viven solo en memoria y se enmascaran.
(() => {
  const API = new URL('/api/v1', window.location.origin).toString();
  const $ = (id) => document.getElementById(id);
  const S = {};
  const uuid = () => crypto.randomUUID();
  const today = new Date();
  const isoDay = (offset) => new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() - offset))
    .toISOString().slice(0, 10);
  const isoTs = (offsetHours) => new Date(Date.now() - offsetHours * 3600 * 1000).toISOString().replace(/\.\d+Z$/, 'Z');
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const SECRET_FIELDS = new Set(['client_secret', 'access_token', 'portal_token', 'secret', 'verification_token']);
  const KEY_FIELDS = new Set(['developer_id', 'verification_token', 'portal_token', 'app_id', 'client_id', 'client_secret',
    'access_token', 'scope', 'expires_in', 'model_code', 'webhook_id', 'secret', 'sandbox_patient_id', 'pairing_code',
    'link_id', 'granted_scopes', 'status', 'accepted', 'duplicates', 'rejected', 'job_id', 'points_accepted',
    'steps_target_day', 'sleep_target_hours_night', 'exercise_target_count_week', 'activity', 'sleep', 'adherence',
    'title', 'detail', 'type', 'event_type', 'steps', 'sleep_duration', 'heart_rate_resting', 'hrv_rmssd', 'patient_id']);
  const PHRASES = { 200: 'OK', 201: 'Created', 202: 'Accepted', 204: 'No Content', 400: 'Bad Request', 401: 'Unauthorized',
    403: 'Forbidden', 404: 'Not Found', 409: 'Conflict', 413: 'Payload Too Large', 415: 'Unsupported Media Type',
    422: 'Unprocessable Entity', 429: 'Too Many Requests', 500: 'Internal Server Error', 503: 'Service Unavailable' };
  const DEVICE = 'ACME-BAND-2-SN0091';

  const el = (tag, attrs = {}, ...children) => {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v);
    }
    for (const c of children) if (c !== null && c !== undefined) node.append(c);
    return node;
  };
  const mask = (v) => (typeof v === 'string' && v.length > 10 ? `${v.slice(0, 6)}…${v.slice(-4)}` : '••••');
  const bytes = (n) => (n < 1024 ? `${n} B` : `${(n / 1024).toFixed(1).replace('.', ',')} kB`);
  const byteLen = (v) => (v instanceof Uint8Array ? v.length : new TextEncoder().encode(v || '').length);

  function redact(value) {
    if (Array.isArray(value)) return value.map(redact);
    if (value && typeof value === 'object') {
      const out = {};
      for (const [k, v] of Object.entries(value)) out[k] = SECRET_FIELDS.has(k) && typeof v === 'string' ? { __masked: mask(v) } : redact(v);
      return out;
    }
    return value;
  }

  async function gzip(text) {
    if (!('CompressionStream' in window)) throw new Error('El navegador no soporta CompressionStream (gzip)');
    const stream = new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  // ───────────────────────── datos sintéticos ─────────────────────────
  const batch = {
    summaries: () => ({ summaries: [
      { record_id: `acme-${S.link_id}-${isoDay(1)}`, local_date: isoDay(1), tz_offset_minutes: 60, device_id: DEVICE,
        completeness: 'final', wear_time_minutes: 1380, steps: 7412, distance_m: 5210.5, active_minutes: 48,
        calories_active_kcal: 412, resting_heart_rate_bpm: 58, hrv_rmssd_ms: 46.2, sleep_total_minutes: 431, recovery_score: 71 },
      { record_id: `acme-${S.link_id}-${isoDay(0)}`, local_date: isoDay(0), tz_offset_minutes: 60, device_id: DEVICE,
        completeness: 'partial', steps: 3120, resting_heart_rate_bpm: 60, hrv_rmssd_ms: 44.1 }] }),
    samples: () => ({ series: [{ metric: 'heart_rate', unit: 'bpm', device_id: DEVICE, start: isoTs(3),
      offsets_ms: [0, 60000, 120000, 180000, 240000], values: [61, 63, 60, 62, 64] }] }),
  };

  // ───────────────────────── guion de los 5 pasos ─────────────────────────
  // cada línea es [texto, término técnico, estado opcional: ok | fail | info]
  const PARTNER_KEY = (scopes) => ['Verificó el token de acceso de la app', `JWT${scopes ? ` · ${scopes}` : ''}`];

  const STEPS = [
    {
      title: 'Alta de la marca', short: 'Alta', kicker: 'Paso 1 de 5',
      lead: 'El fabricante se registra, crea su aplicación y obtiene un token de acceso.',
      reqs: [
        { label: 'Registro del fabricante', m: 'POST', p: '/partner/developers/register', expect: [202],
          body: () => ({ company_name: 'Acme Wearables Ltd', contact_email: `dev-${uuid().slice(0, 8)}@acme-wearables.example`,
            country: 'GB', accept_terms: true }),
          after: (r) => {
            Object.assign(S, { developer_id: r.json.developer_id, verification_token: r.json.verification_token });
            if (!S.verification_token) throw new Error('No se recibió el código de verificación (con SMTP configurado se envía por correo). Utilice un despliegue de desarrollo sin SMTP.');
          },
          db: ['escribe', 'partner_developers'],
          explain: [
            ['Creó la cuenta pendiente de verificación', 'pending_verification'],
            ['Generó un código de verificación y almacenó solo su huella', 'HMAC-SHA256'],
            ['Registró la llamada en la auditoría', 'partner_audit_log']] },
        { label: 'Verificación del correo', m: 'POST', p: '/partner/developers/verify', expect: [200],
          body: () => ({ developer_id: S.developer_id, verification_token: S.verification_token }),
          after: (r) => { S.portal_token = r.json.portal_token; },
          db: ['escribe', 'partner_developers'],
          explain: [
            ['Validó el código: vigente y de un solo uso', 'TTL'],
            ['Emitió un token para el portal del desarrollador', 'JWT portal']] },
        { label: 'Creación de la aplicación', m: 'POST', p: '/partner/apps', auth: 'portal', expect: [201],
          body: () => ({ name: 'Acme Health Cloud', logo_url: 'https://acme-wearables.example/logo.png',
            privacy_policy_url: 'https://acme-wearables.example/privacy',
            requested_scopes: ['ingest:activity', 'ingest:sleep', 'ingest:vitals', 'ingest:device', 'read:goals', 'read:scores'] }),
          after: (r) => Object.assign(S, { app_id: r.json.app_id, client_id: r.json.client_id, client_secret: r.json.client_secret }),
          db: ['escribe', 'partner_apps'],
          explain: [
            ['Creó la aplicación en el entorno de pruebas', 'sandbox'],
            ['Emitió las credenciales; el secreto se muestra una sola vez', 'client_id · client_secret']] },
        { label: 'Solicitud del token de acceso', m: 'POST', p: '/partner/oauth/token', expect: [200],
          form: () => ({ grant_type: 'client_credentials', client_id: S.client_id, client_secret: S.client_secret }),
          after: (r) => Object.assign(S, { access_token: r.json.access_token, token_scope: r.json.scope }),
          db: ['lee', 'partner_apps'],
          explain: [
            ['Validó las credenciales de la aplicación', 'OAuth 2.0 client_credentials'],
            ['Emitió un token válido durante una hora con los permisos concedidos', 'JWT · 3600 s']] },
        { label: 'Declaración del dispositivo', m: 'POST', p: '/partner/apps/{app_id}/device-models', auth: 'partner', expect: [201],
          body: () => ({ model_code: 'ACME-BAND-2', display_name: 'Acme Band 2', form_factor: 'band', body_placement: 'wrist_left',
            capabilities: [{ metric: 'steps', sampling_mode: 'daily_aggregate' },
              { metric: 'heart_rate', typical_interval_seconds: 60, sampling_mode: 'continuous' }, { metric: 'resting_heart_rate' },
              { metric: 'hrv_rmssd' }, { metric: 'sleep' }, { metric: 'distance' }, { metric: 'calories_active' }, { metric: 'active_minutes' },
              { metric: 'device_wear' }],
            regulatory: { ukca_or_ce_medical_device: false } }),
          after: () => { S.model_code = 'ACME-BAND-2'; },
          db: ['escribe', 'partner_device_models'],
          explain: [
            PARTNER_KEY(),
            ['Registró las métricas que mide el dispositivo; las no declaradas se rechazarán', 'device-model']] },
        { label: 'Registro del webhook', m: 'POST', p: '/partner/apps/{app_id}/webhooks', auth: 'partner',
          expect: [201], optional: true,
          body: () => ({ url: new URL('/api/v1/partner-dev/webhook-sink', window.location.origin).toString(),
            events: ['link.created', 'link.revoked', 'ingest.job.completed'] }),
          after: (r) => Object.assign(S, { webhook_id: r.json.webhook_id, webhook_secret: r.json.secret }),
          db: ['escribe', 'webhook_subscriptions'],
          explain: [
            ['Validó que la URL no apunta a redes internas', 'protección SSRF'],
            ['Generó un secreto para firmar los avisos', 'HMAC-SHA256']],
          skipNote: 'El receptor de pruebas no está disponible en este despliegue; se continúa sin webhook.' },
      ],
    },
    {
      title: 'Vinculación con el paciente', short: 'Vinculación', kicker: 'Paso 2 de 5',
      lead: 'El paciente autoriza el acceso con un código de un solo uso; el fabricante lo canjea y obtiene un link_id.',
      reqs: [
        { label: 'Paciente de prueba y código', m: 'POST', p: '/partner/sandbox/patients', auth: 'partner', expect: [201],
          db: ['escribe', 'patients · pairing_codes (sandbox)'],
          body: () => ({ profile: 'knee_rehab', scopes: ['ingest:activity', 'ingest:sleep', 'ingest:vitals', 'ingest:device', 'read:goals', 'read:scores'] }),
          after: (r) => Object.assign(S, { sandbox_patient_id: r.json.sandbox_patient_id, pairing_code: r.json.pairing_code }),
          explain: [
            ['Creó un paciente sintético con objetivos de rehabilitación', 'knee_rehab'],
            ['Generó el código que, en producción, obtiene el paciente en la app WellQ', 'pairing code']] },
        { label: 'Canje del código', m: 'POST', p: '/partner/links', auth: 'partner', expect: [201],
          db: ['escribe', 'partner_links'],
          body: () => ({ pairing_code: S.pairing_code, external_user_id: `acme_user_${uuid().slice(0, 6)}`, device_id: DEVICE,
            model_code: S.model_code, timezone: 'Europe/London' }),
          after: (r) => { S.link_id = r.json.link_id; },
          explain: [
            ['Validó el código: vigente y no utilizado', 'un solo uso'],
            ['Concedió solo los permisos autorizados por el paciente', 'granted_scopes'],
            ['Creó el vínculo y notificó al webhook', 'link_id · link.created']] },
      ],
    },
    {
      title: 'Envío de datos', short: 'Envío', kicker: 'Paso 3 de 5',
      lead: 'El fabricante envía resúmenes diarios y una serie de frecuencia cardiaca. Un reenvío no genera duplicados.',
      reqs: [
        { label: 'Envío de resúmenes diarios', m: 'POST', p: '/partner/links/{link_id}/daily-summaries', auth: 'partner', idem: true,
          expect: [200], db: ['escribe', 'metrics'],
          body: () => { S.batch = batch.summaries(); return S.batch; },
          explain: (entry) => [
            PARTNER_KEY('ingest:*'),
            ['Comprobó el consentimiento del paciente para cada dato', 'scope por campo'],
            ['Validó formato, rangos y métricas declaradas', 'esquema · device-model'],
            countsLine(entry, 'Almacenó los registros')] },
        { label: 'Reenvío del mismo lote', m: 'POST', p: '/partner/links/{link_id}/daily-summaries', auth: 'partner', idem: true,
          expect: [200], db: ['lee', 'metrics: sin cambios'],
          body: () => S.batch,
          didactic: 'Mismo lote: la API lo reconoce y no lo almacena de nuevo.',
          explain: (entry) => [
            ['Identificó registros idénticos a los ya almacenados', 'record_key · hash'],
            countsLine(entry, 'No escribió datos nuevos')] },
        { label: 'Corrección del día actual', m: 'POST', p: '/partner/links/{link_id}/daily-summaries', auth: 'partner', idem: true,
          expect: [200], db: ['escribe', 'metrics: 1 registro'],
          body: () => {
            const b = JSON.parse(JSON.stringify(S.batch));
            b.summaries[1].steps = 5480;
            return b;
          },
          didactic: 'El registro de hoy cambia: se actualiza, no se suma.',
          explain: (entry) => [
            ['Sustituyó el registro modificado y mantuvo el resto', 'updated · duplicate'],
            countsLine(entry, 'Resultado')] },
        { label: 'Envío de serie de frecuencia cardiaca', m: 'POST', p: '/partner/links/{link_id}/samples', auth: 'partner', idem: true,
          gzip: true, expect: [202], db: ['escribe', 'ingest_jobs → metrics'],
          body: batch.samples, after: (r) => { S.job_id = r.json.job_id; },
          explain: [
            ['Recibió el lote comprimido y validó unidad, rango y frecuencia', 'gzip · device-model'],
            ['Lo procesa en segundo plano y devuelve un identificador', '202 · job_id']] },
        { label: 'Estado del procesamiento', m: 'GET', p: '/partner/ingest/jobs/{job_id}', auth: 'partner', expect: [200],
          poll: (r) => !['queued', 'processing'].includes(r.json && r.json.status), db: ['lee', 'ingest_jobs'],
          explain: [['Informó del resultado del procesamiento', 'points_accepted']] },
        { label: 'Estado de sincronización', m: 'GET', p: '/partner/links/{link_id}/sync-state', auth: 'partner', expect: [200],
          db: ['lee', 'partner_links'],
          explain: [['Indicó la fecha del último dato recibido de cada tipo', 'last_received']] },
      ],
    },
    {
      title: 'Lectura', short: 'Lectura', kicker: 'Paso 4 de 5',
      lead: 'El fabricante consulta los objetivos y los scores autorizados; el clínico consulta los datos recibidos.',
      reqs: [
        { label: 'Consulta de objetivos', m: 'GET', p: '/partner/links/{link_id}/goals', auth: 'partner', expect: [200],
          db: ['lee', 'patient_goals'],
          explain: [
            ['Comprobó el permiso del paciente para esta lectura', 'read:goals'],
            ['Devolvió los objetivos fijados por la clínica', 'health_goals']] },
        { label: 'Consulta de scores diarios', m: 'GET', p: '/partner/links/{link_id}/scores', auth: 'partner', expect: [200],
          query: () => ({ from_date: isoDay(2), to_date: isoDay(0) }), db: ['lee', 'metrics'],
          explain: [
            ['Comprobó el permiso del paciente para esta lectura', 'read:scores'],
            ['Calculó actividad, sueño, adherencia y estabilidad por día', 'scores 0-100']] },
        { label: 'Sesión del clínico (desarrollo)', m: 'POST', p: '/partner-dev/clinician-session', actor: 'clinic',
          expect: [200], optional: true, db: ['escribe', 'patients'],
          body: () => ({ patient_id: S.sandbox_patient_id }),
          after: (r) => { S.clinician_token = r.json.access_token; },
          explain: [['Creó un clínico de prueba con acceso a este paciente', 'solo en desarrollo']],
          skipNote: 'Las herramientas de desarrollo no están activas en este despliegue; se omite la vista del clínico.' },
        { label: 'Vista del clínico', m: 'GET', p: '/maindash/patient/{sandbox_patient_id}/wearables/data/statistics/daily',
          auth: 'clinician', actor: 'clinic', expect: [200], needs: 'clinician_token',
          query: () => ({ from_date: isoDay(2), to_date: isoDay(0), types: 'steps,sleep_duration,heart_rate_resting,hrv_rmssd' }),
          db: ['lee', 'metrics'],
          explain: [
            ['Comprobó que el paciente está asignado al clínico', 'rol clinician'],
            ['Devolvió los datos enviados por el fabricante', 'statistics/daily']] },
      ],
    },
    {
      title: 'Revocación', short: 'Revocación', kicker: 'Paso 5 de 5',
      lead: 'Se revoca el vínculo. A partir de ese momento, la API rechaza envíos y lecturas.',
      reqs: [
        { label: 'Revocación del vínculo', m: 'DELETE', p: '/partner/links/{link_id}', auth: 'partner', expect: [204],
          db: ['escribe', 'partner_links'],
          explain: [
            ['Marcó el vínculo como revocado y notificó al webhook', 'revoked · link.revoked'],
            ['El paciente también puede revocarlo desde su app', 'DELETE /wearables/links', 'info']] },
        { label: 'Intento de envío', m: 'POST', p: '/partner/links/{link_id}/daily-summaries', auth: 'partner', idem: true,
          expect: [403], expectSlug: 'link-revoked', db: ['sin acceso', 'no se escribe nada'],
          body: () => batch.summaries(),
          didactic: 'El token sigue siendo válido, pero el permiso del paciente ya no existe.',
          explain: () => [
            ['Verificó el token de acceso', 'JWT', 'ok'],
            ['Rechazó la petición: vínculo revocado', '403 link-revoked', 'fail']] },
        { label: 'Intento de lectura', m: 'GET', p: '/partner/links/{link_id}/scores', auth: 'partner', expect: [403],
          expectSlug: 'link-revoked', query: () => ({ from_date: isoDay(2), to_date: isoDay(0) }), db: ['sin acceso', 'no se lee nada'],
          explain: () => [
            ['Verificó el token de acceso', 'JWT', 'ok'],
            ['Rechazó la petición: vínculo revocado', '403 link-revoked', 'fail']] },
        { label: 'Avisos recibidos por el webhook', m: 'GET', p: '/partner-dev/webhook-sink', expect: [200], optional: true,
          needs: 'webhook_secret', actor: 'tool', db: ['lee', 'buzón de pruebas'],
          transform: (json) => (Array.isArray(json) ? json.filter((i) => (i.body || '').includes(S.link_id)) : json),
          poll: (r) => Array.isArray(r.json) && r.json.some((i) => i.event === 'link.revoked' && (i.body || '').includes(S.link_id)),
          maxPolls: 4,
          explain: (entry) => entry.webhookChecks || [],
          skipNote: 'No hay webhook registrado en este despliegue; se omite.' },
      ],
    },
  ];

  // resumen del lote calculado con la respuesta real, no con lo que se esperaba
  function countsLine(entry, prefix) {
    const results = (entry.res && entry.res.json && entry.res.json.results) || [];
    if (!results.length) return [prefix, 'results', 'info'];
    const c = results.reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {});
    const text = ['created', 'updated', 'duplicate', 'rejected'].filter((k) => c[k]).map((k) => `${c[k]} ${k}`).join(' · ');
    return [`${prefix}: ${text}`, 'results[].status', c.rejected ? 'fail' : 'ok'];
  }

  // ───────────────────────── red ─────────────────────────
  const AUTH = { portal: () => S.portal_token, partner: () => S.access_token, clinician: () => S.clinician_token };

  function resolve(path) {
    return path.replace(/\{(\w+)\}/g, (_, key) => {
      const v = S[key];
      if (!v) throw new Error(`Falta ${key}: ejecuta antes el paso que lo obtiene`);
      if (!/^[A-Za-z0-9._:\-]+$/.test(v)) throw new Error(`${key} con caracteres no válidos`);
      return encodeURIComponent(v);
    });
  }

  async function prepare(req) {
    let path = resolve(req.p);
    if (req.query) path += `?${new URLSearchParams(req.query())}`;
    const headers = { Accept: 'application/json, application/problem+json' };
    const shown = [];
    const token = req.auth ? AUTH[req.auth]() : null;
    if (req.auth && !token) throw new Error(`Falta el token (${req.auth})`);
    if (token) { headers.Authorization = `Bearer ${token}`; shown.push(['Authorization', `Bearer ${mask(token)}`, true]); }
    let body; let json; let form; let plainSize = 0; let records = null;
    if (req.form) {
      form = req.form();
      body = new URLSearchParams(form).toString();
      headers['Content-Type'] = 'application/x-www-form-urlencoded';
    } else if (req.body) {
      json = req.body();
      const text = JSON.stringify(json);
      plainSize = byteLen(text);
      headers['Content-Type'] = 'application/json';
      if (req.gzip) { body = await gzip(text); headers['Content-Encoding'] = 'gzip'; } else body = text;
      for (const name of ['summaries', 'series', 'sessions', 'measurements', 'events']) {
        if (Array.isArray(json[name])) {
          records = `${json[name].length} ${json[name].length === 1 ? 'registro' : 'registros'}`;
          if (name === 'series') records += ` · ${json.series.reduce((n, s) => n + s.values.length, 0)} muestras`;
        }
      }
    }
    if (headers['Content-Type']) shown.push(['Content-Type', headers['Content-Type']]);
    if (headers['Content-Encoding']) shown.push(['Content-Encoding', headers['Content-Encoding']]);
    if (req.idem) { headers['Idempotency-Key'] = uuid(); shown.push(['Idempotency-Key', headers['Idempotency-Key']]); }
    shown.push(['Accept', headers.Accept]);
    const size = body === undefined ? 0 : byteLen(body);
    return { method: req.m, path, headers, body, json, form, shown, size, plainSize, records };
  }

  async function send(prep) {
    const url = new URL(API + prep.path);
    if (url.origin !== window.location.origin) throw new Error('URL fuera del origen permitido');
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 30000);
    const res = { status: 0, headers: {}, text: '', ms: 0 };
    const t0 = performance.now();
    try {
      const r = await fetch(url, { method: prep.method, headers: prep.headers, body: prep.body, credentials: 'same-origin',
        cache: 'no-store', signal: ctrl.signal, redirect: 'error', referrerPolicy: 'no-referrer' });
      res.status = r.status;
      res.headers = { trace: r.headers.get('X-Trace-Id'), replayed: r.headers.get('Idempotency-Replayed'),
        limit: r.headers.get('RateLimit-Limit'), remaining: r.headers.get('RateLimit-Remaining'),
        ctype: r.headers.get('content-type') || '' };
      res.text = await r.text();
      res.problem = res.headers.ctype.includes('problem+json');
      if (res.headers.ctype.includes('json') && res.text) {
        try { res.json = JSON.parse(res.text); } catch { /* respuesta no JSON */ }
      }
    } catch (err) {
      res.text = err.name === 'AbortError' ? 'Tiempo de espera agotado (30 s)' : `Error de red: ${err.message}`;
    } finally {
      clearTimeout(timer);
      res.ms = Math.round(performance.now() - t0);
    }
    res.size = byteLen(res.text);
    return res;
  }

  // ───────────────────────── pintado ─────────────────────────
  function jsonView(value, highlight = true) {
    const pre = el('pre', { class: 'json', tabindex: '0' });
    let count = 0;
    const line = (depth, parts, hl) => {
      if (count++ > 400) return;
      const span = el('span', { class: `ln ind${Math.min(depth, 6)}${hl ? ' hl' : ''}` });
      for (const [cls, text] of parts) span.append(cls ? el('span', { class: cls, text }) : document.createTextNode(text));
      pre.append(span);
    };
    const scalar = (v, key) => {
      if (v && typeof v === 'object' && v.__masked) return ['masked', `"${v.__masked}"  (enmascarado)`];
      if (typeof v === 'string') {
        const st = key === 'status' && ['created', 'updated', 'duplicate', 'rejected'].includes(v) ? `s st-${v}` : 's';
        return [st, JSON.stringify(v)];
      }
      if (typeof v === 'number') return ['n', String(v)];
      return ['b', String(v)];
    };
    const isLeaf = (v) => v === null || typeof v !== 'object' || v.__masked;
    const walk = (v, depth, key, last) => {
      const comma = last ? '' : ',';
      const keyParts = key !== undefined ? [['k', JSON.stringify(key)], ['', ': ']] : [];
      const hl = highlight && key !== undefined && KEY_FIELDS.has(key);
      if (isLeaf(v)) { line(depth, [...keyParts, scalar(v, key), ['', comma]], hl); return; }
      const arr = Array.isArray(v);
      const entries = arr ? v.map((x, i) => [undefined, x, i]) : Object.entries(v);
      if (!entries.length) { line(depth, [...keyParts, ['', arr ? `[]${comma}` : `{}${comma}`]], hl); return; }
      // arrays cortos de escalares en una sola línea
      if (arr && v.every((x) => isLeaf(x)) && v.length <= 12) {
        const parts = [...keyParts, ['', '[']];
        v.forEach((x, i) => { parts.push(scalar(x)); if (i < v.length - 1) parts.push(['', ', ']); });
        parts.push(['', `]${comma}`]);
        line(depth, parts, hl);
        return;
      }
      line(depth, [...keyParts, ['', arr ? '[' : '{']], hl);
      entries.forEach(([k, x], i) => walk(x, depth + 1, arr ? undefined : k, i === entries.length - 1));
      line(depth, [['', (arr ? ']' : '}') + comma]], false);
    };
    walk(value, 0, undefined, true);
    if (count > 400) pre.append(el('span', { class: 'ln', text: '… (recortado)' }));
    return pre;
  }

  function kv(rows) {
    const dl = el('dl', { class: 'kv' });
    for (const [k, v, secret] of rows) dl.append(el('dt', { text: k }), el('dd', { class: secret ? 'secret' : '', text: v }));
    return dl;
  }

  function renderSend(entry) {
    const { prep } = entry;
    const box = $('send-body');
    box.replaceChildren();
    box.append(el('div', { class: 'reqline' }, el('span', { class: `method ${prep.method}`, text: prep.method }),
      document.createTextNode(`/api/v1${prep.path}`)));
    box.append(kv(prep.shown));
    const chips = el('div', { class: 'chips' });
    if (prep.body === undefined) chips.append(el('span', { class: 'chip size', text: 'sin cuerpo' }));
    else chips.append(el('span', { class: 'chip size', text: `↑ ${bytes(prep.size)}` }));
    if (prep.records) chips.append(el('span', { class: 'chip', text: prep.records }));
    if (prep.headers['Content-Encoding'] === 'gzip') {
      chips.append(el('span', { class: 'chip info', text: `gzip: ${bytes(prep.plainSize)} → ${bytes(prep.size)}` }));
    }
    box.append(chips);
    if (entry.req.didactic) box.append(el('p', { class: 'note didactic', text: entry.req.didactic }));
    if (prep.form) {
      const shown = Object.fromEntries(Object.entries(prep.form).map(([k, v]) => [k, k === 'client_secret' ? { __masked: mask(v) } : v]));
      box.append(el('p', { class: 'note', text: 'Formulario OAuth 2.0 (x-www-form-urlencoded):' }), jsonView(shown, false));
    } else if (prep.json !== undefined) {
      box.append(jsonView(redact(prep.json), false));
    }
  }

  function statusClass(entry) {
    const s = entry.res ? entry.res.status : 0;
    const cls = `s${Math.floor(s / 100) || 0}`;
    return entry.expectedError ? `${cls} expected` : cls;
  }

  function renderRecv(entry) {
    const box = $('recv-body');
    box.replaceChildren();
    const { res } = entry;
    if (!res) { box.append(el('p', { class: 'placeholder', text: 'Esperando la respuesta…' })); return; }
    box.append(el('div', { class: 'status' },
      el('span', { class: `code ${statusClass(entry)}`, text: res.status || 'ERR' }),
      el('span', { class: 'phrase', text: res.status ? PHRASES[res.status] || '' : 'Sin respuesta' }),
      el('span', { class: 'ms', text: `${res.ms} ms` })));
    const rows = [];
    if (res.headers.trace) rows.push(['X-Trace-Id', res.headers.trace]);
    if (res.headers.replayed) rows.push(['Idempotency-Replayed', res.headers.replayed]);
    if (res.headers.limit) rows.push(['RateLimit', `${res.headers.remaining} de ${res.headers.limit} restantes`]);
    if (res.headers.ctype) rows.push(['Content-Type', res.headers.ctype]);
    if (rows.length) box.append(kv(rows));
    const chips = el('div', { class: 'chips' }, el('span', { class: 'chip size', text: `↓ ${bytes(res.size)}` }));
    for (const chip of keyChips(entry)) chips.append(chip);
    box.append(chips);
    if (entry.expectedError) box.append(el('p', { class: 'note didactic', text: 'Respuesta esperada: el acceso del paciente está revocado.' }));
    if (entry.error) box.append(el('p', { class: 'note err', text: entry.error }));
    const shown = entry.shownJson;
    if (shown !== undefined) box.append(jsonView(redact(shown)));
    else if (res.status === 204) box.append(el('p', { class: 'placeholder', text: '204 No Content: la respuesta no lleva cuerpo.' }));
    else if (res.text) box.append(el('pre', { class: 'json', text: res.text.slice(0, 4000) }));
  }

  function keyChips(entry) {
    const j = entry.shownJson;
    const out = [];
    if (!j || typeof j !== 'object') return out;
    if (entry.res.problem) {
      out.push(el('span', { class: `chip ${entry.expectedError ? 'info' : 'err'}`, text: (j.type || '').split('/').pop() || j.title || 'error' }));
      return out;
    }
    if ('accepted' in j) {
      const st = (j.results || []).reduce((acc, r) => { acc[r.status] = (acc[r.status] || 0) + 1; return acc; }, {});
      for (const [k, cls] of [['created', 'ok'], ['updated', 'info'], ['duplicate', 'warn'], ['rejected', 'err']]) {
        if (st[k]) out.push(el('span', { class: `chip ${cls}`, text: `${k}: ${st[k]}` }));
      }
      if (!Object.keys(st).length) out.push(el('span', { class: 'chip', text: `accepted ${j.accepted} · duplicates ${j.duplicates} · rejected ${j.rejected}` }));
      return out;
    }
    for (const k of ['client_id', 'link_id', 'pairing_code', 'job_id', 'app_id', 'developer_id', 'webhook_id', 'sandbox_patient_id']) {
      if (j[k]) out.push(el('span', { class: 'chip key', text: `${k}: ${j[k]}` }));
    }
    for (const k of ['access_token', 'client_secret', 'portal_token']) {
      if (j[k]) out.push(el('span', { class: 'chip key', text: `${k}: ${mask(j[k])}` }));
    }
    if (j.status && typeof j.status === 'string') out.push(el('span', { class: 'chip ok', text: `status: ${j.status}` }));
    if (j.summary && j.summary.points_accepted !== undefined) {
      out.push(el('span', { class: 'chip ok', text: `${j.summary.points_accepted} muestras aceptadas` }));
    }
    return out.slice(0, 6);
  }

  function renderWhat(entry) {
    const box = $('what-body');
    box.replaceChildren();
    const { req, res } = entry;
    const list = el('ol', { class: 'checks' });
    const okStatus = res && entry.passed;
    let items = typeof req.explain === 'function' ? req.explain(entry) : req.explain;
    if (!items || !items.length) items = [];
    if (res && !okStatus && !entry.expectedError) {
      const p = res.json || {};
      list.append(check(`Rechazó la petición: ${p.detail || p.title || res.text.slice(0, 160) || 'sin respuesta'}`,
        p.type ? p.type.split('/').pop() : `HTTP ${res.status}`, 'fail'));
    }
    for (const [text, tech, state] of items) {
      list.append(check(text, tech, !res ? 'skip' : state || (okStatus ? 'ok' : 'skip')));
    }
    if (!res) box.append(el('p', { class: 'placeholder', text: 'Petición en curso…' }));
    box.append(list);
    if (req.db) {
      box.append(el('p', { class: 'where' }, el('strong', { text: `Base de datos (${req.db[0]}): ` }), document.createTextNode(req.db[1])));
    }
  }

  function check(text, tech, state) {
    const icon = { ok: '✓', fail: '✗', info: 'i', skip: '·' }[state] || '·';
    return el('li', { class: state }, el('span', { class: 'icon', text: icon }),
      el('span', {}, document.createTextNode(text), tech ? el('span', { class: 'tech', text: tech }) : null));
  }

  function renderEntry(entry) {
    showStepIntro(entry.step);
    showReqNow(entry.step, entry.idx);
    setActors(entry.req);
    renderSend(entry);
    renderRecv(entry);
    renderWhat(entry);
    for (const li of $('timeline').children) li.classList.toggle('selected', li.dataset.n === String(entry.n));
  }

  // ───────────────────────── diagrama ─────────────────────────
  function setActors(req) {
    const left = $('actor-left');
    const kind = req ? req.actor || 'maker' : 'maker';
    left.className = `actor ${kind === 'clinic' ? 'clinic' : 'maker'}`;
    $('actor-left-icon').textContent = kind === 'clinic' ? '🩺' : kind === 'tool' ? '🛠' : '⌚';
    $('actor-left-name').textContent = kind === 'clinic' ? 'Panel del clínico' : kind === 'tool' ? 'Herramienta de desarrollo' : 'Servidor del fabricante';
    $('actor-left-sub').textContent = kind === 'clinic' ? 'sesión WellQ' : kind === 'tool' ? 'solo en sandbox' : 'Acme Wearables';
    $('actor-db-sub').textContent = req && req.db ? `${req.db[0]}: ${req.db[1]}` : 'App del paciente y panel clínico';
  }

  function clearWires() {
    for (const id of ['wire-a', 'wire-b']) $(id).className = 'wire';
    for (const id of ['actor-left', 'actor-api', 'actor-db']) $(id).classList.remove('active');
  }

  function animate(packetId, wireId, dir, label, bad) {
    const packet = $(packetId);
    const wire = $(wireId);
    wire.className = `wire active${dir === 'left' ? ' back' : ''}`;
    packet.className = 'packet';
    packet.textContent = label;
    void packet.offsetWidth; // reinicia la animación
    packet.className = `packet go-${dir}${bad ? ' bad' : ''}`;
  }

  async function travelOut(prep, req) {
    clearWires();
    setActors(req);
    $('actor-left').classList.add('active');
    animate('packet-a', 'wire-a', 'right', `↑ ${prep.method} ${bytes(prep.size)}`);
    await sleep(travelMs() * 0.85);
    $('actor-api').classList.add('active');
    if (req.db && req.db[0] !== 'sin acceso') {
      animate('packet-b', 'wire-b', 'right', req.db[0] === 'lee' ? 'consulta' : 'guarda');
      await sleep(travelMs() * 0.85);
      $('actor-db').classList.add('active');
    }
  }

  async function travelBack(entry) {
    const { res, req } = entry;
    const bad = !entry.passed && !entry.expectedError;
    if (req.db && req.db[0] !== 'sin acceso') {
      animate('packet-b', 'wire-b', 'left', 'ok');
      await sleep(travelMs() * 0.7);
    } else $('wire-b').className = 'wire';
    animate('packet-a', 'wire-a', 'left', `↓ ${res.status || 'ERR'} · ${bytes(res.size)}`, bad || entry.expectedError);
    await sleep(travelMs());
  }

  // ───────────────────────── línea de tiempo ─────────────────────────
  const entries = [];
  let totals = { up: 0, down: 0 };

  function addTimeline(entry) {
    const li = el('li', { class: 'pending', tabindex: '0', 'data-n': String(entry.n) });
    li.addEventListener('click', () => { if (!busy) renderEntry(entry); });
    li.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !busy) renderEntry(entry); });
    entry.li = li;
    updateTimeline(entry);
    $('timeline').append(li);
    li.scrollIntoView({ block: 'nearest' });
  }

  function updateTimeline(entry) {
    const { li, prep, res } = entry;
    li.className = res ? statusClass(entry) : 'pending';
    const meta = el('span', { class: 'tl-meta' },
      el('span', { class: 'tl-up', text: `↑ ${bytes(prep.size)}` }),
      el('span', { class: 'tl-down', text: res ? `↓ ${res.status || 'ERR'} · ${bytes(res.size)}` : '↓ …' }),
      res ? el('span', { text: `${res.ms} ms` }) : null);
    li.replaceChildren(el('span', { class: 'tl-title', text: `${entry.step + 1}.${entry.idx + 1} ${entry.req.label}` }),
      el('span', { class: 'tl-meta', text: `${prep.method} ${shortPath(prep.path)}` }), meta);
  }

  // en la línea de tiempo los identificadores largos se acortan para que quepa la ruta
  const shortPath = (path) => path.split('?')[0]
    .replace(/\b(app|lnk|job|whk|dev|cli)_[0-9a-f]{8,}/g, '$1_…').replace(/P-SBX\w+/g, 'P-SBX…');

  function updateTotals() {
    $('tl-total').textContent = `${entries.length} peticiones · ↑ ${bytes(totals.up)} · ↓ ${bytes(totals.down)}`;
  }

  // ───────────────────────── control del recorrido ─────────────────────────
  let busy = false;
  let cursor = { step: -1, idx: 0 }; // siguiente petición a ejecutar
  const stepState = STEPS.map(() => 'todo');

  const speed = () => Number($('speed').value) || 1;
  const travelMs = () => 900 * speed();
  const mode = () => $('mode').value;

  function renderSteps() {
    const ol = $('steps');
    ol.replaceChildren();
    STEPS.forEach((s, i) => {
      const cls = [i === cursor.step ? 'current' : '', stepState[i] === 'done' ? 'done' : '', stepState[i] === 'failed' ? 'failed' : '']
        .filter(Boolean).join(' ');
      ol.append(el('li', { class: cls, 'aria-current': i === cursor.step ? 'step' : null },
        el('span', { class: 'num', text: stepState[i] === 'done' ? '✓' : String(i + 1) }), document.createTextNode(s.short)));
    });
  }

  function showStepIntro(i) {
    const s = STEPS[i];
    $('step-kicker').textContent = s.kicker;
    $('step-title').textContent = `${i + 1}. ${s.title}`;
    $('step-lead').textContent = s.lead;
  }

  function showReqNow(i, j) {
    const node = $('req-now');
    node.hidden = false;
    node.replaceChildren(el('span', { class: 'counter', text: `Petición ${j + 1} de ${STEPS[i].reqs.length}` }),
      document.createTextNode(STEPS[i].reqs[j].label));
  }

  function nextLabel() {
    if (cursor.step === -1) return 'Empezar ▶';
    const s = STEPS[cursor.step];
    if (cursor.idx < s.reqs.length) {
      return mode() === 'peticion' ? `Siguiente petición ▶ (${cursor.idx + 1}/${s.reqs.length})` : `Continuar paso ${cursor.step + 1} ▶`;
    }
    if (cursor.step + 1 < STEPS.length) return `Siguiente: ${cursor.step + 2}. ${STEPS[cursor.step + 1].short} ▶`;
    return 'Recorrido completado ✓';
  }

  function refreshButtons() {
    const finished = cursor.step === STEPS.length - 1 && cursor.idx >= STEPS[cursor.step].reqs.length;
    $('next').textContent = busy ? 'En curso…' : nextLabel();
    $('next').disabled = busy || finished;
    $('repeat').disabled = busy || cursor.step < 0;
    $('reset').disabled = busy;
    renderSteps();
  }

  function banner(text, cls = '') {
    const b = $('banner');
    if (!text) { b.hidden = true; return; }
    b.className = `banner ${cls}`;
    b.textContent = text;
    b.hidden = false;
    if (cls === 'ok') setTimeout(() => { if (b.textContent === text) b.hidden = true; }, 5000);
  }

  async function runRequest(i, j) {
    const req = STEPS[i].reqs[j];
    showReqNow(i, j);
    if (req.needs && !S[req.needs]) {
      const entry = { n: 0, step: i, idx: j, req, skipped: true };
      renderSkip(entry);
      await sleep(1200 * speed());
      return true;
    }
    let attempt = 0;
    for (;;) {
      const prep = await prepare(req);
      const entry = { n: entries.length + 1, step: i, idx: j, req, prep };
      entries.push(entry);
      totals.up += prep.size;
      addTimeline(entry);
      updateTotals();
      renderEntry(entry);
      const [res] = await Promise.all([send(prep), travelOut(prep, req)]);
      entry.res = res;
      totals.down += res.size;
      const slug = res.json && typeof res.json.type === 'string' ? res.json.type.split('/').pop() : '';
      entry.passed = req.expect.includes(res.status) && (!req.expectSlug || slug === req.expectSlug);
      entry.expectedError = entry.passed && res.status >= 400;
      entry.shownJson = res.json !== undefined && req.transform ? req.transform(res.json) : res.json;
      if (entry.passed && req.after && res.json !== undefined) {
        try { req.after(res); } catch (err) { entry.passed = false; entry.error = err.message; }
      }
      if (entry.passed && req.p === '/partner-dev/webhook-sink') entry.webhookChecks = await verifySink(entry.shownJson);
      if (!entry.passed && !entry.error) {
        entry.error = `Se esperaba ${req.expect.join(' o ')}${req.expectSlug ? ` (${req.expectSlug})` : ''} y llegó ${res.status || 'un error de red'}.`;
      }
      updateTimeline(entry);
      updateTotals();
      renderEntry(entry);
      await travelBack(entry);
      if (entry.passed && req.poll && !req.poll(res) && attempt < (req.maxPolls || 10)) {
        attempt += 1;
        await sleep(1500);
        continue;
      }
      if (!entry.passed) {
        if (req.optional) {
          banner(req.skipNote || 'Petición opcional no disponible; el recorrido continúa.');
          return true;
        }
        throw new Error(entry.error);
      }
      return true;
    }
  }

  function renderSkip(entry) {
    $('send-body').replaceChildren(el('p', { class: 'placeholder', text: `Se omite «${entry.req.label}».` }));
    $('recv-body').replaceChildren(el('p', { class: 'placeholder', text: entry.req.skipNote || 'Falta un paso opcional anterior.' }));
    $('what-body').replaceChildren(el('p', { class: 'placeholder', text: 'Sin datos.' }));
  }

  async function verifySink(items) {
    const out = [];
    if (!Array.isArray(items) || !S.webhook_secret) return out;
    if (!items.length) {
      out.push(['Aún no se ha recibido ningún aviso de este vínculo', 'webhook_deliveries', 'info']);
      return out;
    }
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(S.webhook_secret), { name: 'HMAC', hash: 'SHA-256' },
      false, ['sign']);
    for (const item of items.slice(-4)) {
      const parts = Object.fromEntries((item.signature || '').split(',').map((kv2) => kv2.split('=')));
      const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${parts.t}.${item.body}`));
      const hex = [...new Uint8Array(mac)].map((b) => b.toString(16).padStart(2, '0')).join('');
      const valid = hex === parts.v1;
      out.push([`Aviso ${item.event}: firma ${valid ? 'válida' : 'no válida'}`,
        'X-WellQ-Signature · HMAC-SHA256', valid ? 'ok' : 'fail']);
    }
    return out;
  }

  async function advance() {
    if (busy) return;
    if (cursor.step === -1 || (cursor.idx >= STEPS[cursor.step].reqs.length && cursor.step + 1 < STEPS.length)) {
      cursor = { step: cursor.step + 1, idx: 0 };
      showStepIntro(cursor.step);
      stepState[cursor.step] = 'running';
    }
    await run();
  }

  async function run() {
    busy = true;
    showStepIntro(cursor.step);
    banner('');
    refreshButtons();
    try {
      for (;;) {
        const s = STEPS[cursor.step];
        while (cursor.idx < s.reqs.length) {
          await runRequest(cursor.step, cursor.idx);
          cursor.idx += 1;
          refreshButtons();
          if (mode() === 'peticion') break;
          if (cursor.idx < s.reqs.length) await sleep(2200 * speed());
        }
        if (cursor.idx >= s.reqs.length) {
          stepState[cursor.step] = 'done';
          $('req-now').hidden = true;
          if (cursor.step === STEPS.length - 1) {
            banner('Recorrido completado.', 'ok');
            break;
          }
          if (mode() !== 'auto') break;
          await sleep(4000 * speed());
          cursor = { step: cursor.step + 1, idx: 0 };
          showStepIntro(cursor.step);
          stepState[cursor.step] = 'running';
          renderSteps();
          continue;
        }
        break;
      }
    } catch (err) {
      stepState[cursor.step] = 'failed';
      banner(`Paso ${cursor.step + 1} detenido: ${err.message} Use «Repetir paso» para reintentar.`);
    } finally {
      busy = false;
      refreshButtons();
    }
  }

  async function repeat() {
    if (busy || cursor.step < 0) return;
    const i = cursor.step;
    for (let k = i; k < STEPS.length; k += 1) stepState[k] = 'todo';
    cursor = { step: i, idx: 0 };
    stepState[i] = 'running';
    showStepIntro(i);
    await run();
  }

  function reset() {
    if (busy) return;
    for (const k of Object.keys(S)) delete S[k];
    entries.length = 0;
    totals = { up: 0, down: 0 };
    cursor = { step: -1, idx: 0 };
    stepState.fill('todo');
    $('timeline').replaceChildren();
    updateTotals();
    $('step-kicker').textContent = 'Antes de empezar';
    $('step-title').textContent = 'Del dispositivo a la clínica';
    $('step-lead').textContent = INTRO_LEAD;
    $('req-now').hidden = true;
    $('send-body').replaceChildren(el('p', { class: 'placeholder', text: 'Método, ruta, cabeceras y cuerpo de la petición.' }));
    $('recv-body').replaceChildren(el('p', { class: 'placeholder', text: 'Código HTTP, tiempo y datos de la respuesta.' }));
    $('what-body').replaceChildren(el('p', { class: 'placeholder', text: 'Comprobaciones realizadas por la API.' }));
    clearWires();
    setActors(null);
    banner('');
    refreshButtons();
  }

  let INTRO_LEAD = '';

  function init() {
    INTRO_LEAD = $('step-lead').textContent;
    try {
      const saved = JSON.parse(localStorage.getItem('wq-presentacion') || '{}');
      if (saved.mode) $('mode').value = saved.mode;
      if (saved.speed) $('speed').value = saved.speed;
    } catch { /* sin almacenamiento local */ }
    const save = () => {
      try { localStorage.setItem('wq-presentacion', JSON.stringify({ mode: $('mode').value, speed: $('speed').value })); } catch { /* nada */ }
      document.body.classList.toggle('travel-slow', speed() > 1.2);
      document.body.classList.toggle('travel-fast', speed() < 0.8);
      refreshButtons();
    };
    $('mode').addEventListener('change', save);
    $('speed').addEventListener('change', save);
    $('next').addEventListener('click', advance);
    $('repeat').addEventListener('click', repeat);
    $('reset').addEventListener('click', reset);
    document.addEventListener('keydown', (e) => {
      if (e.target.closest('select, input, textarea') || e.ctrlKey || e.metaKey || e.altKey) return;
      if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); advance(); }
      if (e.key === 'r' || e.key === 'R') repeat();
    });
    save();
    reset();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
