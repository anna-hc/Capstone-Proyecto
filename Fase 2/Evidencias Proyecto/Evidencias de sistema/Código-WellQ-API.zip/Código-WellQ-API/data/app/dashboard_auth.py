"""Login con usuario y contraseña para las páginas web del despliegue: la demo, /docs y las herramientas de desarrollo.

La API de fabricantes, pacientes y clínicos sigue con su propia autenticación (OAuth/JWT); /health y los cron
quedan fuera. La sesión vive en una cookie firmada (sin estado en el servidor, apto para Vercel) y deja de valer
al cambiar la contraseña o el secreto.
"""
import base64
import hashlib
import hmac
import html
import os
import secrets
import time
from urllib.parse import quote

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

import app.config as conf
from app.logging_conf import get_logger
from app.services.partner import ratelimit
from app.services.partner.audit import client_ip

log = get_logger("DASHBOARD")

SESSION_COOKIE = "wq_dash"
CSRF_COOKIE = "wq_dash_csrf"
PBKDF2_ITERATIONS = 600_000

# secciones web protegidas; el resto de /api/v1/partner/* usa los tokens de la Partner API
PROTECTED_EXACT = ("/", "/docs", "/docs/oauth2-redirect", "/openapi.json")
PROTECTED_PREFIXES = ("/api/v1/partner-demo", "/api/v1/partner-dev")
# el receptor de webhooks de prueba lo llama el propio servidor al entregar avisos, sin sesión
PUBLIC_EXCEPTIONS = (("POST", "/api/v1/partner-dev/webhook-sink"),)


# ───────────────────────────── contraseñas ─────────────────────────────

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def hash_password(password: str, iterations: int = PBKDF2_ITERATIONS) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"pbkdf2_sha256${iterations}${_b64(salt)}${_b64(digest)}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algo, iterations, salt, expected = encoded.split("$")
        if algo != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), _unb64(salt), int(iterations))
        return hmac.compare_digest(digest, _unb64(expected))
    except (ValueError, TypeError):
        return False


# ───────────────────────────── estado de la configuración ─────────────────────────────

def _cfg(name: str) -> str:
    # tolera los errores de copia más comunes en Vercel: espacios, saltos de línea y comillas envolventes
    valor = str(getattr(conf, name, "") or "").strip()
    while len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in "\"'":
        valor = valor[1:-1].strip()
    return valor


def _user() -> str:
    return _cfg("DASHBOARD_USER")


def _password_hash() -> str:
    return _cfg("DASHBOARD_PASSWORD_HASH")


def _secret() -> str:
    return _cfg("DASHBOARD_SESSION_SECRET")


def config_problems() -> list[str]:
    # solo nombres y motivos, nunca valores: sirve para diagnosticar el despliegue sin exponer secretos
    problemas = []
    if not _user():
        problemas.append("DASHBOARD_USER no está definida")
    h = _password_hash()
    partes = h.split("$")
    if not h:
        problemas.append("DASHBOARD_PASSWORD_HASH no está definida")
    elif len(partes) != 4 or partes[0] != "pbkdf2_sha256" or not partes[1].isdigit():
        problemas.append(f"DASHBOARD_PASSWORD_HASH con formato inválido ({len(partes)} partes; se espera "
                         "pbkdf2_sha256$iteraciones$sal$hash, generado con python -m app.scripts.hash_password)")
    s = _secret()
    if not s:
        problemas.append("DASHBOARD_SESSION_SECRET no está definida")
    elif len(s) < 32:
        problemas.append(f"DASHBOARD_SESSION_SECRET tiene {len(s)} caracteres; necesita al menos 32")
    return problemas


def configured() -> bool:
    return not config_problems()


def _no_configurado() -> HTMLResponse:
    problemas = config_problems()
    log.warning("[DASHBOARD] acceso cerrado: %s", "; ".join(problemas), extra={"tag": "DASHBOARD"})
    texto = "<p>El acceso al panel no está configurado en este despliegue.</p>"
    if conf.APP_ENV in conf.DEV_APP_ENVS:
        # en entornos de desarrollo se muestran los nombres (nunca los valores) para poder corregirlo
        items = "".join(f"<li>{html.escape(p)}</li>" for p in problemas)
        texto += f"<p>Revisa en Vercel (Settings → Environment Variables) y vuelve a desplegar:</p><ul>{items}</ul>"
    return _page("Acceso no configurado", texto, 503)


def login_disabled() -> bool:
    # la excepción solo vale en local: nunca en Vercel ni fuera de los APP_ENV de desarrollo
    return conf.DASHBOARD_LOGIN_DISABLED and conf.APP_ENV in conf.DEV_APP_ENVS and not os.getenv("VERCEL")


def is_protected(method: str, path: str) -> bool:
    if (method, path.rstrip("/") or "/") in PUBLIC_EXCEPTIONS:
        return False
    return path in PROTECTED_EXACT or any(path == p or path.startswith(p + "/") for p in PROTECTED_PREFIXES)


def section_enabled(path: str) -> bool:
    # si la sección no existe en este despliegue (p. ej. producción sin demo) se deja responder su 404 habitual
    from app.services.partner.deps import demo_enabled, dev_tools_enabled
    if path.startswith("/api/v1/partner-demo") or path == "/":
        return demo_enabled()
    if path.startswith("/api/v1/partner-dev"):
        return dev_tools_enabled()
    return conf.APP_ENV in conf.DEV_APP_ENVS  # /docs y /openapi.json


# ───────────────────────────── sesión ─────────────────────────────

def _key() -> bytes:
    # la clave depende del hash: cambiar la contraseña invalida todas las sesiones abiertas
    return hmac.new(_secret().encode(), b"dashboard-session|" + _password_hash().encode(),
                    hashlib.sha256).digest()


def make_session(user: str, now: float | None = None) -> str:
    exp = int((time.time() if now is None else now) + conf.DASHBOARD_SESSION_HOURS * 3600)
    payload = _b64(f"{user}|{exp}|{secrets.token_urlsafe(12)}".encode())
    return payload + "." + _b64(hmac.new(_key(), payload.encode(), hashlib.sha256).digest())


def read_session(token: str | None) -> dict | None:
    if not token or not configured() or token.count(".") != 1:
        return None
    payload, sig = token.split(".")
    expected = _b64(hmac.new(_key(), payload.encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(sig, expected):
        return None
    try:
        user, exp, sid = _unb64(payload).decode().split("|")
        exp = int(exp)
    except (ValueError, UnicodeDecodeError):
        return None
    if exp < time.time() or not hmac.compare_digest(user.encode(), _user().encode()):
        return None
    return {"user": user, "exp": exp, "sid": sid}


def logout_token(session: dict) -> str:
    return _b64(hmac.new(_key(), b"logout|" + session["sid"].encode(), hashlib.sha256).digest())


def _secure(request: Request) -> bool:
    host = (request.url.hostname or "").lower()
    return request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https" or host not in (
        "localhost", "127.0.0.1", "testserver")


def _safe_next(target: str | None) -> str:
    # solo rutas locales: evita redirecciones a otros dominios (//, \\ o esquemas)
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target or "\n" in target:
        return "/"
    return target


# ───────────────────────────── middleware ─────────────────────────────

def _wants_html(request: Request) -> bool:
    return request.method == "GET" and "text/html" in request.headers.get("accept", "")


async def guard(request: Request, call_next):
    path = request.url.path
    if not is_protected(request.method, path) or login_disabled() or not section_enabled(path):
        return await call_next(request)
    if not configured():
        return _no_configurado()
    if read_session(request.cookies.get(SESSION_COOKIE)):
        response = await call_next(request)
        response.headers.setdefault("Cache-Control", "no-store")
        return response
    if _wants_html(request):
        destino = request.url.path + (f"?{request.url.query}" if request.url.query else "")
        return RedirectResponse(url=f"/login?next={quote(destino, safe='')}", status_code=303)
    return JSONResponse({"type": "about:blank", "title": "Unauthorized", "status": 401, "detail": "Inicia sesión en /login"},
                        status_code=401, media_type="application/problem+json")


# ───────────────────────────── páginas ─────────────────────────────

_CSS = """
:root{--bg:#f6f7f9;--panel:#fff;--text:#1d2330;--muted:#5d6676;--line:#dfe3ea;--accent:#2b59c3;--accent-text:#fff;--err:#b3261e}
@media (prefers-color-scheme:dark){:root{--bg:#11151c;--panel:#1a202a;--text:#e6e9ef;--muted:#a2abba;--line:#2c3442;--accent:#7aa2ff;--accent-text:#0b1020;--err:#ff8a80}}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--text);
font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;padding:16px}
.card{width:100%;max-width:360px;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:24px}
h1{font-size:1.25rem;margin:0 0 .25rem}.sub{color:var(--muted);margin:0 0 1.2rem;font-size:.88rem}
label{display:block;margin:.8rem 0 .3rem;font-size:.9rem}
input{font:inherit;color:var(--text);background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:.5rem .6rem;width:100%}
button{font:inherit;width:100%;margin-top:1.2rem;border:1px solid var(--accent);background:var(--accent);color:var(--accent-text);
border-radius:8px;padding:.55rem .8rem;cursor:pointer}
input:focus-visible,button:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
.error{color:var(--err);margin:.6rem 0 0;font-size:.9rem}a{color:var(--accent)}
""".strip()
_CSS_HASH = base64.b64encode(hashlib.sha256(_CSS.encode()).digest()).decode()
_CSP = (f"default-src 'none'; style-src 'sha256-{_CSS_HASH}'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")


def _page(title: str, body: str, status: int = 200) -> HTMLResponse:
    doc = (f'<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
           f'<meta name="referrer" content="no-referrer"><title>{html.escape(title)} · WellQ Partner API</title><style>{_CSS}</style></head>'
           f'<body><main class="card"><h1>WellQ Partner API</h1><p class="sub">{html.escape(title)}</p>{body}</main></body></html>')
    return HTMLResponse(doc, status_code=status, headers={
        "Content-Security-Policy": _CSP, "Cache-Control": "no-store", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer"})


def _login_form(csrf: str, destino: str, error: str = "", status: int = 200) -> HTMLResponse:
    aviso = f'<p class="error" role="alert">{html.escape(error)}</p>' if error else ""
    body = (f'<form method="post" action="/login">'
            f'<input type="hidden" name="csrf" value="{html.escape(csrf)}"><input type="hidden" name="next" value="{html.escape(destino)}">'
            f'<label for="u">Usuario</label><input id="u" name="username" autocomplete="username" required maxlength="128" autofocus>'
            f'<label for="p">Contraseña</label><input id="p" name="password" type="password" autocomplete="current-password" required maxlength="256">'
            f'{aviso}<button type="submit">Iniciar sesión</button></form>')
    return _page("Iniciar sesión", body, status)


def _with_csrf_cookie(request: Request, response: Response, token: str) -> Response:
    response.set_cookie(CSRF_COOKIE, token, max_age=3600, path="/", httponly=True, secure=_secure(request), samesite="strict")
    return response


router = APIRouter(include_in_schema=False)


@router.get("/login")
def login_page(request: Request, next: str = "/"):
    destino = _safe_next(next)
    if not configured() and not login_disabled():
        return _no_configurado()
    if read_session(request.cookies.get(SESSION_COOKIE)):
        return RedirectResponse(url=destino, status_code=303)
    token = secrets.token_urlsafe(32)
    return _with_csrf_cookie(request, _login_form(token, destino), token)


@router.post("/login")
async def login_submit(request: Request):
    if not configured():
        return _no_configurado()
    count, _, reset = ratelimit.hit(f"dashboard-login:{client_ip(request)}", conf.DASHBOARD_LOGIN_RPM_PER_IP, 60)
    form = await request.form()
    destino = _safe_next(str(form.get("next") or "/"))
    nuevo_csrf = secrets.token_urlsafe(32)
    if count > conf.DASHBOARD_LOGIN_RPM_PER_IP:
        response = _login_form(nuevo_csrf, destino, "Demasiados intentos. Espera un minuto y vuelve a probar.", 429)
        response.headers["Retry-After"] = str(reset)  # segundos que faltan para que se abra la ventana
        return _with_csrf_cookie(request, response, nuevo_csrf)
    csrf_cookie = request.cookies.get(CSRF_COOKIE) or ""
    csrf_form = str(form.get("csrf") or "")
    if not csrf_cookie or not hmac.compare_digest(csrf_cookie.encode(), csrf_form.encode()):
        return _with_csrf_cookie(request, _login_form(nuevo_csrf, destino, "La sesión del formulario caducó. Vuelve a intentarlo.", 403), nuevo_csrf)
    usuario = str(form.get("username") or "")[:128]
    password = str(form.get("password") or "")[:256]
    # se calcula siempre el hash para no revelar por el tiempo si el usuario existe
    password_ok = verify_password(password, _password_hash())
    usuario_ok = hmac.compare_digest(usuario.encode(), _user().encode())
    if not (password_ok and usuario_ok):
        log.info("[DASHBOARD] login fallido desde %s", client_ip(request), extra={"tag": "DASHBOARD"})
        return _with_csrf_cookie(request, _login_form(nuevo_csrf, destino, "Usuario o contraseña incorrectos.", 401), nuevo_csrf)
    response = RedirectResponse(url=destino, status_code=303)
    response.set_cookie(SESSION_COOKIE, make_session(_user()), max_age=conf.DASHBOARD_SESSION_HOURS * 3600,
                        path="/", httponly=True, secure=_secure(request), samesite="lax")
    response.delete_cookie(CSRF_COOKIE, path="/")
    log.info("[DASHBOARD] login correcto desde %s", client_ip(request), extra={"tag": "DASHBOARD"})
    return response


@router.get("/logout")
def logout_page(request: Request):
    session = read_session(request.cookies.get(SESSION_COOKIE))
    if not session:
        return RedirectResponse(url="/login", status_code=303)
    body = (f'<form method="post" action="/logout"><input type="hidden" name="csrf" value="{logout_token(session)}">'
            f'<p>¿Quieres cerrar la sesión del panel?</p><button type="submit">Cerrar sesión</button></form>'
            f'<p class="sub"><a href="/">Volver al panel</a></p>')
    return _page("Cerrar sesión", body)


@router.post("/logout")
async def logout_submit(request: Request):
    session = read_session(request.cookies.get(SESSION_COOKIE))
    form = await request.form()
    if session and not hmac.compare_digest(str(form.get("csrf") or "").encode(), logout_token(session).encode()):
        return _page("Cerrar sesión", '<p class="error" role="alert">No se pudo cerrar la sesión. Vuelve a intentarlo.</p>'
                                      '<p class="sub"><a href="/logout">Volver</a></p>', 403)
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie(SESSION_COOKIE, path="/")
    return response
