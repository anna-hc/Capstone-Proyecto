from fastapi import FastAPI

import app.config as conf
from app.logging_conf import get_logger

log = get_logger("PARTNER")


def include_partner_routers(app: FastAPI) -> bool:
    if not conf.PARTNER_API_ENABLED:
        return False
    from app.services.partner.security import configuration_errors
    errors = configuration_errors()
    if errors:
        # falla cerrado: con la configuración incompleta no se monta nada
        log.error("[PARTNER][DISABLED] %s", "; ".join(errors), extra={"tag": "PARTNER"})
        return False
    from app.api.v1.routers import (partner_admin, partner_capabilities, partner_clinician, partner_data, partner_ingest,
                                    partner_links, partner_oauth, partner_onboarding, partner_patient, partner_read,
                                    partner_sandbox, partner_webhooks)
    for router in (partner_onboarding.router, partner_oauth.router, partner_capabilities.router, partner_links.router,
                   partner_ingest.router, partner_read.router, partner_webhooks.router, partner_sandbox.router,
                   partner_admin.router, partner_patient.router, partner_clinician.router,
                   partner_data.patient_router, partner_data.clinician_router):
        app.include_router(router, prefix="/api/v1")
    from app.services.partner.deps import demo_enabled, dev_tools_enabled
    from app.api.v1.routers import partner_dev
    if dev_tools_enabled():
        app.include_router(partner_dev.dev_router, prefix="/api/v1")
        log.warning("[PARTNER][DEV_TOOLS] herramientas de desarrollo activas (APP_ENV=%s)", conf.APP_ENV,
                    extra={"tag": "PARTNER"})
    if demo_enabled():
        app.include_router(partner_dev.demo_router, prefix="/api/v1")
    log.info("[PARTNER] Partner API montada", extra={"tag": "PARTNER"})
    return True


def _ensure_indexes() -> None:
    try:
        import app.db as dbmod
        dbmod.ensure_partner_indexes(dbmod.central_db)
        dbmod.ensure_partner_tenant_indexes(dbmod._central_client[conf.PARTNER_SANDBOX_DB])
        log.info("[PARTNER][INDEXES] índices de la Partner API verificados", extra={"tag": "PARTNER"})
    except Exception as exc:
        log.error("[PARTNER][INDEXES][FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})


def register_partner_scheduler(scheduler) -> None:
    from app.tasks.partner_jobs import PARTNER_JOB_IDS, register_partner_jobs
    from app.services.partner.security import configuration_errors
    if conf.PARTNER_API_ENABLED and not configuration_errors():
        register_partner_jobs(scheduler)
        import threading
        threading.Thread(target=_ensure_indexes, daemon=True).start()
        return
    # el jobstore de Mongo persiste los jobs: al apagar el flag hay que quitarlos o seguirían ejecutándose
    for job_id in PARTNER_JOB_IDS:
        try:
            scheduler.remove_job(job_id)
        except Exception:
            log.debug("[PARTNER] job %s no estaba programado", job_id, extra={"tag": "PARTNER"})
