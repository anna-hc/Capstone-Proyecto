from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Body, Depends, Request
from pymongo.errors import DuplicateKeyError

import app.config as conf
from app.logging_conf import get_logger
from app.models.partner import (AppCreate, AppUpdate, DeveloperLogin, DeveloperRegistration, DeveloperVerify,
                                PromotionRequestIn, RotateSecret)
from app.repositories import partner as repo
from app.services.partner import catalog, ratelimit
from app.services.partner.audit import client_ip, record_event
from app.services.partner.deps import dev_tools_enabled, owned_app, portal_developer, portal_or_partner_app, public_rate_limit
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit, trace_id_var
from app.services.partner.security import (hash_opaque, hash_secret, issue_portal_token, new_client_secret, new_id,
                                           new_verification_token)

log = get_logger("PARTNER")
router = APIRouter(prefix="/partner", tags=["Developer Onboarding"], route_class=PartnerRoute)
VERIFICATION_TTL = timedelta(hours=24)
# si el correo del alta no llega, el camino es repetir el alta con el mismo correo (reenvía un código nuevo si la
# cuenta sigue sin verificar) o pedir POST /developers/login-code; la respuesta es siempre la misma, exista o no
APP_FIELDS = ("app_id", "client_id", "name", "description", "logo_url", "privacy_policy_url", "requested_scopes",
              "granted_scopes", "environment", "status", "promotion_status", "rate_limit", "created_at")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def public_app(doc: dict) -> dict:
    return {k: doc.get(k) for k in APP_FIELDS}


def _send_verification(email: str, developer_id: str, token: str) -> bool:
    try:
        from app.services.mailer import send_email_html
        link = f"{conf.PARTNER_PORTAL_BASE_URL.rstrip('/')}/verify?developer_id={developer_id}&token={token}" \
            if conf.PARTNER_PORTAL_BASE_URL else None
        text = ("Confirma tu cuenta de desarrollador de WellQ con este código de un solo uso, válido 24 h:\n\n"
                f"developer_id: {developer_id}\ncódigo: {token}\n" + (f"\nO abre: {link}\n" if link else ""))
        send_email_html("WellQ Partner API: verifica tu correo", email, "<pre>" + text + "</pre>", text)
        return True
    except Exception as exc:
        log.warning("[PARTNER][REGISTER][MAIL_FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})
        return False


@router.post("/developers/register", status_code=202, dependencies=[Depends(public_rate_limit("register", 10))])
def register_developer(data: DeveloperRegistration):
    if not data.accept_terms:
        raise PartnerProblem(422, slug="terms-not-accepted", detail="Debes aceptar los Developer Terms")
    email_norm = str(data.contact_email).strip().lower()
    existing = repo.developers().find_one({"contact_email_norm": email_norm},
                                          {"developer_id": 1, "email_verified": 1, "contact_email": 1})
    if existing:
        # misma respuesta que un alta nueva: no se revela si el correo ya tiene cuenta. Si la cuenta sigue sin
        # verificar (p. ej. falló el correo del alta), repetir el alta reenvía un código nuevo a ese correo
        record_event("partner.register_duplicate", trace_id_var.get() or None, developer_id=existing["developer_id"])
        body = {"developer_id": existing["developer_id"], "status": "pending_verification"}
        if not existing.get("email_verified"):
            try:
                ratelimit.enforce(f"register-resend:{existing['developer_id']}", 5, 3600, detail="Demasiados reenvíos")
            except PartnerProblem:
                return body
            token = new_verification_token()
            repo.email_verifications().insert_one({"developer_id": existing["developer_id"],
                                                   "token_hash": hash_opaque(token, "email-verify"),
                                                   "expires_at": _now() + VERIFICATION_TTL, "used_at": None,
                                                   "created_at": _now(), "purpose": "register_resend"})
            sent = _send_verification(existing["contact_email"], existing["developer_id"], token)
            if dev_tools_enabled() and not sent:
                body["verification_token"] = token
        return body
    developer_id = new_id("dev")
    try:
        repo.developers().insert_one({
            "developer_id": developer_id, "company_name": data.company_name, "contact_email": str(data.contact_email),
            "contact_email_norm": email_norm, "contact_name": data.contact_name, "country": data.country,
            "website": str(data.website) if data.website else None, "status": "pending_verification",
            "email_verified": False, "terms_accepted_at": _now(), "created_at": _now(),
        })
    except DuplicateKeyError:
        return {"developer_id": developer_id, "status": "pending_verification"}
    token = new_verification_token()
    repo.email_verifications().insert_one({"developer_id": developer_id, "token_hash": hash_opaque(token, "email-verify"),
                                           "expires_at": _now() + VERIFICATION_TTL, "used_at": None, "created_at": _now()})
    sent = _send_verification(str(data.contact_email), developer_id, token)
    set_audit(developer_id=developer_id, event="partner.developer_registered")
    if not sent:
        record_event("partner.register_mail_failed", trace_id_var.get() or None, developer_id=developer_id)
    body = {"developer_id": developer_id, "status": "pending_verification"}
    if dev_tools_enabled() and not sent:
        body["verification_token"] = token
    return body


@router.post("/developers/login-code", status_code=202, dependencies=[Depends(public_rate_limit("login-code", 5))])
def request_login_code(data: DeveloperLogin):
    # misma respuesta exista o no la cuenta; el código llega solo al correo registrado
    email_norm = str(data.contact_email).strip().lower()
    dev = repo.developers().find_one({"contact_email_norm": email_norm}, {"developer_id": 1, "contact_email": 1})
    body = {"status": "sent_if_registered"}
    if dev:
        ratelimit.enforce(f"login-code-dev:{dev['developer_id']}", 5, 3600, detail="Demasiados códigos pedidos")
        token = new_verification_token()
        repo.email_verifications().insert_one({"developer_id": dev["developer_id"],
                                               "token_hash": hash_opaque(token, "email-verify"),
                                               "expires_at": _now() + timedelta(minutes=15), "used_at": None,
                                               "created_at": _now(), "purpose": "login"})
        sent = _send_verification(dev["contact_email"], dev["developer_id"], token)
        if dev_tools_enabled() and not sent:
            body.update({"developer_id": dev["developer_id"], "verification_token": token})
    return body


@router.post("/developers/verify", dependencies=[Depends(public_rate_limit("verify", 10))])
def verify_developer(data: DeveloperVerify):
    ratelimit.enforce(f"verify-dev:{data.developer_id}", 10, 3600, detail="Demasiados intentos de verificación")
    now = _now()
    match = repo.find_one_and_update(
        repo.email_verifications(),
        {"developer_id": data.developer_id, "token_hash": hash_opaque(data.verification_token, "email-verify"),
         "used_at": None, "expires_at": {"$gt": now}},
        {"$set": {"used_at": now}})
    if not match:
        raise PartnerProblem(400, slug="verification-invalid", detail="Código de verificación inválido o expirado")
    repo.developers().update_one({"developer_id": data.developer_id},
                                 {"$set": {"status": "verified", "email_verified": True, "verified_at": now}})
    token, expires_in = issue_portal_token(data.developer_id)
    set_audit(developer_id=data.developer_id, event="partner.developer_verified")
    return {"developer_id": data.developer_id, "portal_token": token, "expires_in": expires_in}


@router.post("/apps", status_code=201)
def create_app(data: AppCreate, developer: dict = Depends(portal_developer)):
    if repo.apps().count_documents({"developer_id": developer["developer_id"]}) >= 20:
        raise PartnerProblem(409, slug="app-limit", detail="Límite de 20 apps por desarrollador")
    secret = new_client_secret()
    requested = sorted(set(data.requested_scopes)) or list(catalog.CONSENT_SCOPES)
    doc = {
        "app_id": new_id("app"), "client_id": new_id("cli"), "developer_id": developer["developer_id"],
        "name": data.name, "description": data.description,
        "logo_url": str(data.logo_url) if data.logo_url else None,
        "privacy_policy_url": str(data.privacy_policy_url) if data.privacy_policy_url else None,
        "requested_scopes": requested, "granted_scopes": requested + list(catalog.APP_LEVEL_SCOPES),
        "environment": "sandbox", "status": "active", "promotion_status": None,
        "client_secret_hashes": [{"hash": hash_secret(secret), "valid_until": None, "created_at": _now()}],
        "rate_limit": {"requests_per_minute": conf.PARTNER_DEFAULT_RPM,
                       "samples_per_day": conf.PARTNER_DEFAULT_SAMPLES_PER_DAY},
        "created_at": _now(),
    }
    repo.apps().insert_one(dict(doc))
    set_audit(app_id=doc["app_id"], event="partner.app_created")
    return {**public_app(doc), "client_secret": secret}


@router.get("/apps")
def list_apps(developer: dict = Depends(portal_developer)):
    return [public_app(d) for d in repo.apps().find({"developer_id": developer["developer_id"]}, {"_id": 0})
            .sort("created_at", 1).limit(100)]


@router.get("/apps/{app_id}")
def get_app(app_doc: dict = Depends(portal_or_partner_app)):
    return public_app(app_doc)


@router.patch("/apps/{app_id}")
def update_app(app_id: str, data: AppUpdate, developer: dict = Depends(portal_developer)):
    app_doc = owned_app(app_id, developer)
    changes = data.model_dump(exclude_unset=True)
    # name y requested_scopes no se pueden borrar: null significa "sin cambios" (antes dejaba la app sin nombre
    # o sin scopes de consentimiento). description, logo_url y privacy_policy_url sí admiten null para quitarlos.
    for key in ("name", "requested_scopes"):
        if changes.get(key, ...) is None:
            changes.pop(key)
    for key in ("logo_url", "privacy_policy_url"):
        if changes.get(key) is not None:
            changes[key] = str(changes[key])
    if "requested_scopes" in changes:
        changes["requested_scopes"] = sorted(set(changes["requested_scopes"] or []))
        # en producción ampliar scopes exige una nueva revisión; en sandbox se conceden directamente
        if app_doc["environment"] == "sandbox":
            changes["granted_scopes"] = changes["requested_scopes"] + list(catalog.APP_LEVEL_SCOPES)
    if changes:
        changes["updated_at"] = _now()
        app_doc = repo.find_one_and_update(repo.apps(), {"app_id": app_id}, {"$set": changes})
    return public_app(app_doc)


@router.post("/apps/{app_id}/secrets/rotate")
def rotate_secret(app_id: str, data: Optional[RotateSecret] = Body(default=None),
                  developer: dict = Depends(portal_developer)):
    # solo desde el portal: un access_token robado no puede quedarse con la app
    app_doc = owned_app(app_id, developer)
    data = data or RotateSecret()
    now = _now()
    grace_until = now + timedelta(seconds=data.grace_period_seconds)
    previous = []
    for entry in app_doc.get("client_secret_hashes", []):
        valid_until = entry.get("valid_until")
        if valid_until is not None and valid_until.tzinfo is None:
            valid_until = valid_until.replace(tzinfo=timezone.utc)
        if valid_until is not None and valid_until < now:
            continue
        if data.grace_period_seconds:
            previous.append({**entry, "valid_until": min(valid_until or grace_until, grace_until)})
    secret = new_client_secret()
    update = {"client_secret_hashes": previous + [{"hash": hash_secret(secret), "valid_until": None, "created_at": now}],
              "production_credentials_pending": False, "secret_rotated_at": now}
    change = {"$set": update}
    if not data.grace_period_seconds:
        change["$inc"] = {"token_generation": 1}
    repo.apps().update_one({"app_id": app_doc["app_id"]}, change)
    set_audit(event="partner.secret_rotated")
    return {"client_id": app_doc["client_id"], "client_secret": secret,
            "previous_secret_valid_until": grace_until.isoformat().replace("+00:00", "Z") if previous else None}


def promotion_checklist(app_doc: dict, dpa_accepted: bool) -> dict:
    """Requisitos para pasar a producción. La aprobación se bloquea mientras alguno sea False."""
    app_id = app_doc["app_id"]
    return {
        "device_models_declared": repo.device_models().count_documents({"app_id": app_id}) > 0,
        "webhook_tested": repo.webhook_deliveries().count_documents({"app_id": app_id, "event_type": "ping",
                                                                     "status": "delivered"}) > 0,
        "privacy_policy_url": bool(app_doc.get("privacy_policy_url")),
        "dpa_accepted": bool(dpa_accepted),
    }


@router.post("/apps/{app_id}/promotion-requests", status_code=202)
def request_promotion(app_id: str, data: PromotionRequestIn, request: Request,
                      developer: dict = Depends(portal_developer)):
    app_doc = owned_app(app_id, developer)
    if not data.dpa_accepted:
        raise PartnerProblem(422, slug="dpa-required", detail="Hay que aceptar el DPA para pasar a producción")
    if app_doc["environment"] == "production":
        raise PartnerProblem(409, detail="La app ya está en producción")
    if repo.promotion_requests().find_one({"app_id": app_id, "status": "under_review"}):
        raise PartnerProblem(409, detail="Ya hay una solicitud en revisión")
    checklist = promotion_checklist(app_doc, dpa_accepted=True)
    req = {"request_id": new_id("req"), "app_id": app_id, "developer_id": developer["developer_id"],
           "status": "under_review", "dpa_accepted_at": _now(), "dpa_ip": client_ip(request),
           "security_contact_email": str(data.security_contact_email),
           "expected_monthly_volume": data.expected_monthly_volume, "notes": data.notes, "checklist": checklist,
           "requested_scopes": list(app_doc.get("requested_scopes") or []),
           "created_at": _now()}
    repo.promotion_requests().insert_one(dict(req))
    # la app sigue activa en sandbox mientras se revisa
    repo.apps().update_one({"app_id": app_id}, {"$set": {"promotion_status": "under_review",
                                                         "security_contact_email": str(data.security_contact_email)}})
    set_audit(event="partner.promotion_requested")
    # la solicitud se acepta aunque falte algo, pero WellQ no podrá aprobarla hasta que el checklist esté completo
    missing = sorted(k for k, ok in checklist.items() if not ok)
    return {"request_id": req["request_id"], "status": "under_review", "checklist": checklist,
            "checklist_complete": not missing, "missing": missing}
