from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Query, Response

from app.models.partner import WebhookCreate
from app.repositories import partner as repo
from app.services.partner import ratelimit, ssrf, webhooks
from app.services.partner.deps import require_scopes
from app.services.partner.problems import PartnerProblem, PartnerRoute, add_response_headers
from app.services.partner.security import encrypt_secret, new_id, new_webhook_secret

router = APIRouter(prefix="/partner/apps/{app_id}/webhooks", tags=["Webhooks"], route_class=PartnerRoute)
manage = require_scopes("webhooks:manage")
PUBLIC_FIELDS = ("webhook_id", "url", "events", "description", "status", "failure_count", "created_at")


def _own(app_id: str, app_doc: dict) -> None:
    if app_doc["app_id"] != app_id:
        raise PartnerProblem(404, detail="App no encontrada")


def _webhook(app_id: str, webhook_id: str) -> dict:
    hook = repo.webhook_subscriptions().find_one({"webhook_id": webhook_id, "app_id": app_id}, {"_id": 0})
    if not hook:
        raise PartnerProblem(404, detail="Webhook no encontrado")
    return hook


@router.post("", status_code=201)
def create_webhook(app_id: str, data: WebhookCreate, app_doc: dict = Depends(manage)):
    _own(app_id, app_doc)
    try:
        _, host, port, _ = ssrf.validate_webhook_url(data.url)
        ssrf.resolve_public_ip(host, port)
    except ssrf.UnsafeUrl as exc:
        raise PartnerProblem(422, slug="webhook-url-rejected", detail=str(exc)) from None
    if repo.webhook_subscriptions().count_documents({"app_id": app_id, "status": "active"}) >= 10:
        raise PartnerProblem(409, detail="Máximo 10 webhooks activos por app")
    secret = new_webhook_secret()
    doc = {"webhook_id": new_id("whk"), "app_id": app_id, "url": data.url, "events": sorted(set(data.events)),
           "description": data.description, "secret_enc": encrypt_secret(secret), "status": "active",
           "failure_count": 0, "created_at": datetime.now(timezone.utc)}
    repo.webhook_subscriptions().insert_one(dict(doc))
    return {**{k: doc.get(k) for k in PUBLIC_FIELDS}, "secret": secret}


@router.get("")
def list_webhooks(app_id: str, app_doc: dict = Depends(manage)):
    _own(app_id, app_doc)
    return [{k: d.get(k) for k in PUBLIC_FIELDS}
            for d in repo.webhook_subscriptions().find({"app_id": app_id, "status": {"$ne": "deleted"}}, {"_id": 0}).limit(50)]


@router.delete("/{webhook_id}", status_code=204)
def delete_webhook(app_id: str, webhook_id: str, app_doc: dict = Depends(manage)):
    _own(app_id, app_doc)
    _webhook(app_id, webhook_id)
    repo.webhook_subscriptions().update_one({"webhook_id": webhook_id},
                                            {"$set": {"status": "deleted", "secret_enc": None,
                                                      "deleted_at": datetime.now(timezone.utc)}})
    repo.webhook_deliveries().update_many({"webhook_id": webhook_id, "status": "pending"},
                                          {"$set": {"status": "cancelled", "next_retry_at": None}})
    return Response(status_code=204)


@router.post("/{webhook_id}/test")
def test_webhook(app_id: str, webhook_id: str, app_doc: dict = Depends(manage)):
    _own(app_id, app_doc)
    hook = _webhook(app_id, webhook_id)
    if hook["status"] != "active":
        raise PartnerProblem(409, detail="El webhook no está activo")
    add_response_headers(ratelimit.enforce(f"webhook-test:{app_id}", 10, 60))
    payload = webhooks.envelope(app_id, "ping", {"message": "Webhook de prueba de WellQ"})
    status_code, error, latency = webhooks.send(hook, payload)
    now = datetime.now(timezone.utc)
    delivered = status_code is not None and 200 <= status_code < 300
    repo.webhook_deliveries().insert_one({
        "delivery_id": new_id("dlv"), "webhook_id": webhook_id, "app_id": app_id, "event_id": payload["event_id"],
        "event_type": "ping", "payload": payload, "status": "delivered" if delivered else "failed", "attempt": 1,
        "attempts": [{"attempt": 1, "at": now, "status_code": status_code, "error": error, "latency_ms": latency}],
        "status_code": status_code, "delivered_at": now if delivered else None, "next_retry_at": None,
        "created_at": now, "expires_at": now + timedelta(days=30)})
    return {"delivered": delivered, "status_code": status_code, "latency_ms": latency,
            "error": ("unsafe_url" if error.startswith("unsafe_url") else "delivery_failed") if error else None}


@router.get("/{webhook_id}/deliveries")
def list_webhook_deliveries(app_id: str, webhook_id: str, cursor: Optional[str] = Query(default=None, max_length=64),
                            limit: int = Query(default=50, ge=1, le=200), app_doc: dict = Depends(manage)):
    _own(app_id, app_doc)
    _webhook(app_id, webhook_id)
    flt: dict = {"webhook_id": webhook_id}
    if cursor:
        flt["delivery_id"] = {"$lt": cursor}
    docs = list(repo.webhook_deliveries().find(flt, {"_id": 0, "payload": 0}).sort("delivery_id", -1).limit(limit + 1))
    more = len(docs) > limit
    docs = docs[:limit]
    return {"items": [webhooks.public_delivery(d) for d in docs],
            "next_cursor": docs[-1]["delivery_id"] if more and docs else None}
