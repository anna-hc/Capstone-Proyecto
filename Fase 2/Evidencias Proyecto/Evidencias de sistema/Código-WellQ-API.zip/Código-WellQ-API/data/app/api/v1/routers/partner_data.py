from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Callable, Literal, Optional

from fastapi import APIRouter, Depends, Query

import app.db as dbmod
from app.repositories import partner as repo
from app.services.partner import catalog
from app.services.partner.deps import clinician_patient, current_patient
from app.services.partner.links import DEFAULT_SOURCE_PRIORITY
from app.services.partner.problems import PartnerProblem, PartnerRoute

DAILY_TYPES = {
    "steps": ("steps", "sum"), "distance": ("distance_m", "sum"), "calories_active": ("calories_active_kcal", "sum"),
    "active_minutes": ("active_minutes", "sum"), "heart_rate_avg": ("avg_heart_rate_bpm", "avg"),
    "heart_rate_resting": ("resting_heart_rate_bpm", "avg"), "heart_rate_max": ("max_heart_rate_bpm", "max"),
    "hrv_rmssd": ("hrv_rmssd_ms", "avg"), "spo2": ("spo2_avg_pct", "avg"), "breathing_rate": ("respiratory_rate_avg_bpm", "avg"),
    "sleep_duration": ("sleep_total_minutes", "sum"), "weight": ("weight_kg", "avg"), "body_fat": ("body_fat_pct", "avg"),
    "wear_time": ("wear_time_minutes", "sum"),
}
SERIES_TYPES = {"steps": "steps", "heart_rate": "heart_rate", "hrv_rmssd": "hrv_rmssd", "spo2": "spo2",
                "breathing_rate": "respiratory_rate", "distance": "distance", "skin_temperature": "skin_temperature"}
MERGE_METHODS = ("select_highest_priority_source", "merge_all_samples")
RECORDS_LIMIT, SLEEPS_LIMIT, WORKOUTS_LIMIT, DAILY_DOCS_LIMIT, SERIES_DOCS_LIMIT, POINTS_LIMIT = (
    2000, 1000, 1000, 5000, 2000, 100_000)
MSK_LIMIT = 2000
DEVICE_TYPES = ("phone", "watch", "ring", "fitness_band", "chest_strap", "scale", "head_mounted", "smart_display",
                "accessory", "unknown")


def _csv(value: Optional[str], allowed=None, name: str = "", required: bool = False) -> Optional[set[str]]:
    items = {v.strip() for v in (value or "").split(",") if v.strip()}
    if not items:
        if required:
            raise PartnerProblem(422, slug="validation", title="Validation failed",
                                 errors=[{"path": name, "message": "debe indicar al menos un valor"}])
        return None
    if allowed is not None and not items <= set(allowed):
        raise PartnerProblem(422, slug="validation", title="Validation failed",
                             errors=[{"path": name, "message": f"valores admitidos: {', '.join(sorted(allowed))}"}])
    return items


def _iso(v):
    return v.astimezone(timezone.utc).isoformat().replace("+00:00", "Z") if isinstance(v, datetime) else v


def _range(start: Optional[datetime], end: Optional[datetime], max_days: int) -> tuple[datetime, datetime]:
    end = end or datetime.now(timezone.utc)
    start = start or end - timedelta(days=7)
    if start.tzinfo is None or end.tzinfo is None:
        raise PartnerProblem(422, slug="validation", title="Validation failed",
                             errors=[{"path": "from_timestamp", "message": "usa timestamps UTC con zona (Z)"}])
    if end <= start or end - start > timedelta(days=max_days):
        raise PartnerProblem(422, slug="range-too-large", detail=f"Rango inválido o mayor de {max_days} días")
    return start, end


def _date_range(from_date: date, to_date: date, max_days: int = 90) -> None:
    if to_date < from_date or (to_date - from_date).days + 1 > max_days:
        raise PartnerProblem(422, slug="range-too-large", detail=f"Rango inválido o mayor de {max_days} días")


def _capped(cursor, limit: int) -> tuple[list, bool]:
    # se pide uno más para saber si el límite cortó la respuesta y avisarlo (truncated)
    docs = list(cursor.limit(limit + 1))
    return docs[:limit], len(docs) > limit


def _sources(patient: dict, providers: Optional[set[str]], device_types: Optional[set[str]]) -> dict[str, dict]:
    out = {}
    for link in repo.links().find({"patient_id": patient["patient_id"], "tenant_db": patient["tenant_db"]},
                                  {"_id": 0, "link_id": 1, "app_id": 1, "model_code": 1, "provider_slug": 1,
                                   "source_priority": 1}).limit(100):
        model = repo.device_models().find_one({"app_id": link["app_id"], "model_code": link.get("model_code")},
                                              {"form_factor": 1}) or {}
        app_doc = repo.apps().find_one({"app_id": link["app_id"]}, {"name": 1}) or {}
        device_type = catalog.FORM_FACTOR_DEVICE_TYPES.get(model.get("form_factor"), "unknown")
        provider = link.get("provider_slug") or f"partner_{link['app_id']}"
        if providers and provider not in providers and link["app_id"] not in providers:
            continue
        if device_types and device_type not in device_types:
            continue
        out[link["link_id"]] = {"provider": provider, "provider_name": app_doc.get("name"), "device_type": device_type,
                                "source_priority": link.get("source_priority", DEFAULT_SOURCE_PRIORITY)}
    return out


def _rank(sources: dict, link_id: str, quality: float | None) -> tuple:
    # orden entre fuentes del mismo día: primero la prioridad que fija la clínica (sin tocar código, por vínculo)
    # y, a igualdad, la calidad de la fuente (resumen final y más horas de uso)
    return ((sources.get(link_id) or {}).get("source_priority", DEFAULT_SOURCE_PRIORITY), quality or 0)


def _metrics(patient: dict):
    return repo.tenant_collection(patient["db"], dbmod.TBL_METRICS)


def build_router(prefix: str, patient_dep: Callable, tag: str) -> APIRouter:
    router = APIRouter(prefix=prefix, tags=[tag], route_class=PartnerRoute)

    @router.get("/records")
    def list_records(from_timestamp: Optional[datetime] = None, to_timestamp: Optional[datetime] = None,
                     providers: Optional[str] = Query(default=None, max_length=512),
                     metrics: Optional[str] = Query(default=None, max_length=512),
                     include_provider_specific_metrics: bool = False, include_samples: bool = False,
                     patient: dict = Depends(patient_dep)):
        start, end = _range(from_timestamp, to_timestamp, 31)
        sources = _sources(patient, _csv(providers), None)
        wanted = _csv(metrics)
        kinds = ["daily_summary", "sleep_session"] + (["samples"] if include_samples else [])
        out = []
        docs, truncated = _capped(_metrics(patient).find({"link_id": {"$in": list(sources)}, "partner_kind": {"$in": kinds},
                                                          "from_ts": {"$gte": start, "$lt": end}}, {"_id": 0})
                                  .sort("from_ts", 1), RECORDS_LIMIT)
        for doc in docs:
            sensors = {k: v for k, v in (doc.get("sensors") or {}).items() if not wanted or k in wanted}
            if wanted and not sensors:
                continue
            item = {"record_id": doc["record_id"], "kind": doc["partner_kind"], "start_time": _iso(doc["from_ts"]),
                    "end_time": _iso(doc.get("to_ts")), "local_date": doc.get("metric_date"),
                    "device_id": doc.get("device_id"), "source_quality": doc.get("source_quality"),
                    **sources[doc["link_id"]], "metrics": sensors}
            if include_provider_specific_metrics:
                item["provider_specific"] = doc.get("partner_informational") or {}
            out.append(item)
        return {"items": out, "truncated": truncated, "limit": RECORDS_LIMIT}

    @router.get("/sleeps")
    def list_sleeps(from_date: date, to_date: date, providers: Optional[str] = Query(default=None, max_length=512),
                    include_stages: bool = False, patient: dict = Depends(patient_dep)):
        _date_range(from_date, to_date)
        sources = _sources(patient, _csv(providers), None)
        out = []
        docs, truncated = _capped(_metrics(patient).find(
            {"link_id": {"$in": list(sources)}, "partner_kind": "sleep_session",
             "metric_date": {"$gte": from_date.isoformat(), "$lte": to_date.isoformat()}}, {"_id": 0}).sort("from_ts", 1),
            SLEEPS_LIMIT)
        for doc in docs:
            s = doc["sensors"]["sleep_session"]
            item = {"sleep_id": doc["record_id"], "local_date": doc["metric_date"], "start_time": _iso(doc["from_ts"]),
                    "end_time": _iso(doc["to_ts"]), "duration_seconds": s.get("duration"), "is_nap": s.get("is_nap"),
                    "summary": s.get("summary") or {}, **sources[doc["link_id"]]}
            if include_stages:
                item["stages"] = [{"stage": st["stage"], "start_time": _iso(st["start"]) if isinstance(st["start"], datetime)
                                   else st["start"], "end_time": _iso(st["end"]) if isinstance(st["end"], datetime) else st["end"]}
                                  for st in s.get("stages") or []]
            out.append(item)
        return {"items": out, "truncated": truncated, "limit": SLEEPS_LIMIT}

    @router.get("/workouts")
    def list_workouts(from_timestamp: Optional[datetime] = None, to_timestamp: Optional[datetime] = None,
                      providers: Optional[str] = Query(default=None, max_length=512),
                      activity_types: Optional[str] = Query(default=None, max_length=512),
                      include_sessions: bool = False, patient: dict = Depends(patient_dep)):
        start, end = _range(from_timestamp, to_timestamp, 90)
        sources = _sources(patient, _csv(providers), None)
        flt = {"link_id": {"$in": list(sources)}, "start_at": {"$gte": start, "$lt": end}}
        types = _csv(activity_types)
        if types:
            flt["workout_type"] = {"$in": sorted(types)}
        out = []
        docs, truncated = _capped(repo.tenant_collection(patient["db"], dbmod.TBL_PATIENT_WEARABLE_WORKOUTS)
                                  .find(flt, {"_id": 0}).sort("start_at", 1), WORKOUTS_LIMIT)
        for doc in docs:
            item = {"workout_id": doc["record_id"], "activity_type": doc.get("workout_type"),
                    "start_time": _iso(doc["start_at"]), "end_time": _iso(doc["end_at"]),
                    "local_date": doc.get("local_date"), "duration_seconds": doc.get("duration_seconds"), "calories_kcal": doc.get("calories_burned"),
                    "avg_heart_rate_bpm": doc.get("avg_heart_rate"), "max_heart_rate_bpm": doc.get("max_heart_rate"),
                    "distance_m": (doc.get("metrics") or {}).get("distance_m"),
                    "wellq_exercise_code": doc.get("wellq_exercise_code"), **sources[doc["link_id"]]}
            if include_sessions:
                item["sets"] = doc.get("sets") or []
            out.append(item)
        return {"items": out, "truncated": truncated, "limit": WORKOUTS_LIMIT}

    @router.get("/msk-measurements")
    def list_msk_measurements(from_timestamp: Optional[datetime] = None, to_timestamp: Optional[datetime] = None,
                              providers: Optional[str] = Query(default=None, max_length=512),
                              measurement_types: Optional[str] = Query(default=None, max_length=512),
                              body_regions: Optional[str] = Query(default=None, max_length=512),
                              patient: dict = Depends(patient_dep)):
        # mediciones musculoesqueléticas (movilidad, fuerza, marcha, equilibrio...) ya normalizadas a la unidad
        # canónica; es lo que pinta el panel clínico junto a las sesiones de ejercicio de /workouts
        start, end = _range(from_timestamp, to_timestamp, 90)
        sources = _sources(patient, _csv(providers), None)
        flt: dict = {"link_id": {"$in": list(sources)}, "timestamp": {"$gte": start, "$lt": end}}
        types = _csv(measurement_types, set(catalog.MSK_TYPE_UNITS), "measurement_types")
        if types:
            flt["measurement_type"] = {"$in": sorted(types)}
        regions = _csv(body_regions, catalog.BODY_REGIONS, "body_regions")
        if regions:
            flt["body_region"] = {"$in": sorted(regions)}
        docs, truncated = _capped(repo.tenant_collection(patient["db"], dbmod.TBL_MSK_MEASUREMENTS)
                                  .find(flt, {"_id": 0}).sort("timestamp", 1), MSK_LIMIT)
        items = [{"measurement_id": d["record_id"], "timestamp": _iso(d["timestamp"]), "local_date": d.get("local_date"),
                  "measurement_type": d.get("measurement_type"), "body_region": d.get("body_region"),
                  "side": d.get("side"), "value": d.get("value"), "unit": d.get("unit"),
                  "context": d.get("context"), "wellq_exercise_code": d.get("wellq_exercise_code"),
                  "protocol": d.get("protocol"), "confidence": d.get("confidence"), "device_id": d.get("device_id"),
                  **sources[d["link_id"]]} for d in docs]
        return {"items": items, "truncated": truncated, "limit": MSK_LIMIT}

    @router.get("/statistics/daily")
    def daily_statistics(from_date: date, to_date: date, types: str = Query(..., min_length=1, max_length=512),
                         providers: Optional[str] = Query(default=None, max_length=512),
                         device_types: Optional[str] = Query(default=None, max_length=256),
                         include_record_ids: bool = False, patient: dict = Depends(patient_dep)):
        _date_range(from_date, to_date)
        wanted = _csv(types, DAILY_TYPES, "types", required=True)
        sources = _sources(patient, _csv(providers), _csv(device_types, DEVICE_TYPES, "device_types"))
        by_day: dict[str, list] = defaultdict(list)
        docs, truncated = _capped(_metrics(patient).find(
            {"link_id": {"$in": list(sources)}, "partner_kind": "daily_summary",
             "metric_date": {"$gte": from_date.isoformat(), "$lte": to_date.isoformat()}},
            {"_id": 0, "metric_date": 1, "partner_summary": 1, "source_quality": 1, "record_id": 1, "link_id": 1}),
            DAILY_DOCS_LIMIT)
        for doc in docs:
            by_day[doc["metric_date"]].append(doc)
        out = []
        current = from_date
        while current <= to_date:
            docs = sorted(by_day.get(current.isoformat(), []),
                          key=lambda d: _rank(sources, d["link_id"], d.get("source_quality")), reverse=True)
            day = {"local_date": current.isoformat()}
            for t in sorted(wanted):
                field = DAILY_TYPES[t][0]
                # una fuente por día (la de mayor prioridad) para no sumar dos veces el mismo día
                best = next((d for d in docs if (d.get("partner_summary") or {}).get(field) is not None), None)
                day[t] = (best or {}).get("partner_summary", {}).get(field) if best else None
                if best:
                    day.setdefault("sources", {})[t] = sources[best["link_id"]]["provider"]
                if include_record_ids and best:
                    day.setdefault("record_ids", {})[t] = best["record_id"]
            out.append(day)
            current += timedelta(days=1)
        return {"items": out, "truncated": truncated, "limit": DAILY_DOCS_LIMIT}

    def _series_points(patient, sources, metric, start, end, flags: dict | None = None):
        docs, truncated = _capped(_metrics(patient).find(
            {"link_id": {"$in": list(sources)}, "partner_kind": "samples", f"sensors.{metric}": {"$exists": True},
             "from_ts": {"$lt": end}, "to_ts": {"$gte": start}},
            {"_id": 0, "link_id": 1, "from_ts": 1, "sensors": 1, "source_quality": 1}), SERIES_DOCS_LIMIT)
        if truncated and flags is not None:
            flags["truncated"] = True
        for doc in docs:
            s = doc["sensors"][metric]
            base = doc["from_ts"] if doc["from_ts"].tzinfo else doc["from_ts"].replace(tzinfo=timezone.utc)
            for off, value in zip(s.get("offsets") or [], s.get("values") or [], strict=False):
                ts = base + timedelta(seconds=off)
                if start <= ts < end:
                    yield ts, value, doc["link_id"], doc.get("source_quality") or 0

    @router.get("/statistics/interval")
    def interval_statistics(types: str = Query(..., min_length=1, max_length=256), interval: Literal["hourly", "daily"] = "hourly",
                            from_timestamp: Optional[datetime] = None, to_timestamp: Optional[datetime] = None,
                            providers: Optional[str] = Query(default=None, max_length=512),
                            device_types: Optional[str] = Query(default=None, max_length=256),
                            patient: dict = Depends(patient_dep)):
        start, end = _range(from_timestamp, to_timestamp, 31)
        wanted = _csv(types, SERIES_TYPES, "types", required=True)
        sources = _sources(patient, _csv(providers), _csv(device_types, DEVICE_TYPES, "device_types"))
        buckets: dict = defaultdict(lambda: defaultdict(list))
        flags = {"truncated": False}
        for t in wanted:
            for ts, value, link_id, _ in _series_points(patient, sources, SERIES_TYPES[t], start, end, flags):
                key = ts.replace(minute=0, second=0, microsecond=0) if interval == "hourly" else \
                    ts.replace(hour=0, minute=0, second=0, microsecond=0)
                buckets[key][t].append((value, link_id))
        out = []
        for key in sorted(buckets):
            row = {"start_time": _iso(key)}
            for t in sorted(wanted):
                pairs = buckets[key].get(t) or []
                if t in ("steps", "distance") and pairs:
                    per_link = defaultdict(float)
                    for value, lid in pairs:
                        per_link[lid] += value
                    best = max(per_link, key=lambda lid: (_rank(sources, lid, None)[0], per_link[lid]))
                    pairs = [p for p in pairs if p[1] == best]
                vals = [v for v, _ in pairs]
                if not vals:
                    row[t] = None
                elif t in ("steps", "distance"):
                    row[t] = round(sum(vals), 3)
                else:
                    row[t] = {"avg": round(sum(vals) / len(vals), 2), "min": min(vals), "max": max(vals), "count": len(vals)}
            out.append(row)
        return {"interval": interval, "items": out, "truncated": flags["truncated"]}

    @router.get("/timeseries")
    def timeseries(metric: str = Query(..., max_length=32), from_timestamp: Optional[datetime] = None,
                   to_timestamp: Optional[datetime] = None, providers: Optional[str] = Query(default=None, max_length=512),
                   device_types: Optional[str] = Query(default=None, max_length=256),
                   merge_method: Literal["select_highest_priority_source", "merge_all_samples"] = "select_highest_priority_source",
                   include_record_ids: bool = False, patient: dict = Depends(patient_dep)):
        if metric not in SERIES_TYPES:
            raise PartnerProblem(422, slug="validation", title="Validation failed",
                                 errors=[{"path": "metric", "message": f"admitidas: {', '.join(sorted(SERIES_TYPES))}"}])
        start, end = _range(from_timestamp, to_timestamp, 31)
        sources = _sources(patient, _csv(providers), _csv(device_types, DEVICE_TYPES, "device_types"))
        flags = {"truncated": False}
        points = list(_series_points(patient, sources, SERIES_TYPES[metric], start, end, flags))
        if merge_method == "select_highest_priority_source" and points:
            # se queda con la fuente de mayor calidad y, a igualdad, con la que más muestras aporta
            counts = defaultdict(int)
            quality = {}
            for _, _, link_id, q in points:
                counts[link_id] += 1
                quality[link_id] = max(quality.get(link_id, 0), q)
            best = max(counts, key=lambda lid: (*_rank(sources, lid, quality[lid]), counts[lid]))
            points = [p for p in points if p[2] == best]
        points.sort(key=lambda p: p[0])
        truncated = flags["truncated"] or len(points) > POINTS_LIMIT
        return {"metric": metric, "merge_method": merge_method, "truncated": truncated, "limit": POINTS_LIMIT,
                "points": [{"timestamp": _iso(ts), "value": value, "provider": sources[lid]["provider"],
                            **({"link_id": lid} if include_record_ids else {})}
                           for ts, value, lid, _ in points[:POINTS_LIMIT]]}

    return router


patient_router = build_router("/wearables/data", current_patient, "Patient App (internal)")
clinician_router = build_router("/maindash/patient/{patient_id}/wearables/data", clinician_patient, "Patient App (internal)")
