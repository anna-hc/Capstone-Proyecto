from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query, Request, Response
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from pymongo.errors import DuplicateKeyError

import app.db as dbmod
from app.models.partner import LinkCreate
from app.repositories import partner as repo
from app.services.partner import links as link_service, ratelimit, webhooks
from app.services.partner.audit import client_ip
from app.services.partner.deps import require_scopes
from app.services.partner.problems import PartnerProblem, PartnerRoute, set_audit
from app.services.partner.security import hash_pairing_code, new_id, normalize_pairing_code
from app.services.partner.tenancy import link_db

router = APIRouter(prefix="/partner/links", tags=["Links (Pairing)"], route_class=PartnerRoute)
manage = require_scopes("links:manage")
PAIRING_FAILURES_PER_10_MIN = 20


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _pairing_invalid() -> PartnerProblem:
    return PartnerProblem(404, slug="pairing-code-invalid", title="Pairing code invalid or expired",
                          detail="Código de emparejamiento inexistente, expirado o ya usado")


@router.post("", status_code=201)
def create_link(data: LinkCreate, request: Request, app_doc: dict = Depends(manage)):
    app_id = app_doc["app_id"]
    ip = client_ip(request)
    for bucket in (f"pair-fail-app:{app_id}", f"pair-fail-ip:{ip}"):
        if ratelimit.peek(bucket, 600) >= PAIRING_FAILURES_PER_10_MIN:
            raise PartnerProblem(429, slug="pairing-attempts-exceeded", detail="Demasiados intentos fallidos de canje",
                                 headers={"Retry-After": "600"})
    if data.model_code and not repo.device_models().find_one({"app_id": app_id, "model_code": data.model_code}):
        raise PartnerProblem(422, slug="unknown-model-code", detail="model_code no declarado en los device-models")
    normalized = normalize_pairing_code(data.pairing_code)
    now = _now()
    code = None
    if normalized:
        # reanudación: si un canje anterior de este mismo código ya creó el vínculo (p. ej. se cortó la conexión
        # antes de recibir la respuesta), se devuelve ese vínculo en vez de responder "código ya usado"
        resumed = repo.links().find_one({"pairing_code_hash": hash_pairing_code(normalized), "app_id": app_id,
                                         "external_user_id": data.external_user_id, "status": "active"}, {"_id": 0})
        if resumed:
            set_audit(link_id=resumed["link_id"], event="link.resumed")
            return JSONResponse(jsonable_encoder(link_service.public_link(resumed)), status_code=200)
        # canje atómico: solo una petición puede marcar el código como usado
        code = repo.find_one_and_update(
            repo.pairing_codes(),
            {"code_hash": hash_pairing_code(normalized), "used_at": None, "expires_at": {"$gt": now},
             "environment": app_doc["environment"], "$or": [{"app_id": None}, {"app_id": app_id}]},
            {"$set": {"used_at": now, "used_by_app_id": app_id}})
    if not code:
        ratelimit.hit(f"pair-fail-app:{app_id}", PAIRING_FAILURES_PER_10_MIN, 600)
        ratelimit.hit(f"pair-fail-ip:{ip}", PAIRING_FAILURES_PER_10_MIN, 600)
        raise _pairing_invalid()
    try:
        return _create_link_from_code(app_doc, data, code, now)
    except Exception:
        # cualquier fallo antes de dejar el vínculo creado devuelve el código: el paciente no lo gasta dos veces
        if not repo.links().find_one({"pairing_code_hash": code["code_hash"], "status": "active"}, {"_id": 1}):
            repo.pairing_codes().update_one({"_id": code["_id"]}, {"$set": {"used_at": None, "used_by_app_id": None}})
        raise


def _create_link_from_code(app_doc: dict, data: LinkCreate, code: dict, now: datetime) -> dict:
    app_id = app_doc["app_id"]
    conflict = repo.links().find_one({"app_id": app_id, "external_user_id": data.external_user_id, "status": "active"},
                                     {"patient_id": 1, "tenant_db": 1, "link_id": 1})
    if conflict and (conflict["patient_id"], conflict["tenant_db"]) != (code["patient_id"], code["tenant_db"]):
        repo.pairing_codes().update_one({"_id": code["_id"]}, {"$set": {"used_at": None, "used_by_app_id": None}})
        raise PartnerProblem(409, slug="external-user-linked",
                             detail="Ese external_user_id ya tiene un vínculo activo con otro paciente")
    granted = sorted(set(code.get("scopes", [])) & set(app_doc.get("granted_scopes", [])))
    link = {
        "link_id": new_id("lnk"), "app_id": app_id, "environment": app_doc["environment"], "status": "active",
        "external_user_id": data.external_user_id, "device_id": data.device_id, "model_code": data.model_code,
        "timezone": data.timezone, "granted_scopes": granted,
        # qué aceptó el paciente, de qué versión y cuándo; revoked_at se rellena al revocar
        "consent": {"doc_version": code.get("consent_doc_version"), "granted_at": code.get("created_at"),
                    "doc_verified": code.get("consent_doc_verified", False), "scopes": sorted(code.get("scopes", [])),
                    "linked_at": now, "revoked_at": None},
        "pairing_code_hash": code["code_hash"],
        "patient_id": code["patient_id"], "patient_oid": code.get("patient_oid"), "tenant_slug": code.get("tenant_slug"),
        "tenant_db": code["tenant_db"], "provider_slug": f"partner_{app_id}", "source_quality": 0.5,
        "created_at": now, "revoked_at": None, "revoked_by": None, "last_received": {},
    }
    if conflict:
        link_service.revoke(repo.links().find_one({"link_id": conflict["link_id"]}, {"_id": 0}), "partner", False)
    link["active_key"] = f"{app_id}:{data.external_user_id}"
    try:
        repo.links().insert_one(dict(link))
    except DuplicateKeyError:
        # otra petición concurrente creó el vínculo activo: se devuelve el código y se informa del conflicto
        repo.pairing_codes().update_one({"_id": code["_id"]}, {"$set": {"used_at": None, "used_by_app_id": None}})
        raise PartnerProblem(409, slug="external-user-linked",
                             detail="Ese external_user_id ya tiene un vínculo activo") from None
    link.pop("active_key", None)
    link_service.ensure_tenant_indexes(link)
    try:
        repo.tenant_collection(link_db(link), dbmod.TBL_PATIENTS).update_one(
            {"patient_id": link["patient_id"]}, {"$addToSet": {"wearable_links": link["link_id"]}})
    except PartnerProblem:
        pass
    set_audit(link_id=link["link_id"], event="link.created")
    webhooks.dispatch(app_id, "link.created", {"link_id": link["link_id"], "external_user_id": data.external_user_id,
                                               "granted_scopes": granted})
    return link_service.public_link(link)


@router.get("")
def list_links(external_user_id: Optional[str] = Query(default=None, max_length=128),
               status: Optional[Literal["active", "revoked", "suspended"]] = None,
               cursor: Optional[str] = Query(default=None, max_length=64),
               limit: int = Query(default=50, ge=1, le=200), app_doc: dict = Depends(manage)):
    flt: dict = {"app_id": app_doc["app_id"], "environment": app_doc["environment"]}
    if external_user_id:
        flt["external_user_id"] = external_user_id
    if status:
        flt["status"] = status
    if cursor:
        flt["link_id"] = {"$gt": cursor}
    docs = list(repo.links().find(flt, {"_id": 0}).sort("link_id", 1).limit(limit + 1))
    more = len(docs) > limit
    docs = docs[:limit]
    return {"items": [link_service.public_link(d) for d in docs],
            "next_cursor": docs[-1]["link_id"] if more and docs else None}


@router.get("/{link_id}")
def get_link(link_id: str, app_doc: dict = Depends(manage)):
    return link_service.public_link(link_service.get_owned_link(app_doc, link_id))


@router.delete("/{link_id}", status_code=204)
def revoke_link(link_id: str, app_doc: dict = Depends(manage)):
    link = link_service.get_owned_link(app_doc, link_id)
    if link["status"] == "active":
        link_service.revoke(link, "partner", delete_data=False)
    return Response(status_code=204)


@router.get("/{link_id}/sync-state")
def get_sync_state(link_id: str, app_doc: dict = Depends(manage)):
    # por métrica: hasta dónde llegaron los datos; huecos calculados en el momento, con el motivo de cada uno,
    # para que el fabricante sepa exactamente qué reenviar (y qué no, si el dispositivo estaba quitado)
    from app.tasks.partner_jobs import compute_gaps
    link = link_service.get_owned_link(app_doc, link_id)
    iso = lambda v: v.isoformat().replace("+00:00", "Z") if hasattr(v, "isoformat") else v  # noqa: E731
    last = {k: {"latest_timestamp": iso(v.get("latest_timestamp")), "received_at": iso(v.get("received_at"))}
            for k, v in (link.get("last_received") or {}).items()}
    per_metric = {k: {"latest_timestamp": iso(v.get("latest_timestamp")), "received_at": iso(v.get("received_at")),
                      "kind": v.get("kind")}
                  for k, v in sorted((link.get("last_received_by_metric") or {}).items())}
    checked_at = datetime.now(timezone.utc)
    try:
        raw_gaps = compute_gaps(link, checked_at)
    except PartnerProblem:
        raw_gaps, checked_at = link.get("gaps", []), link.get("gaps_checked_at")
    gaps = [{"metric": g["metric"], "from": iso(g["from"]), "to": iso(g["to"]), "reason": g.get("reason", "no_data"),
             **({"local_date": g["local_date"]} if g.get("local_date") else {}),
             **({"open": True} if g.get("open") else {})} for g in raw_gaps]
    return {"link_id": link_id, "last_received": last, "metrics": per_metric, "gaps": gaps,
            "gaps_checked_at": iso(checked_at)}


@router.get("/{link_id}/config")
def get_link_config(link_id: str, app_doc: dict = Depends(manage)):
    link = link_service.get_owned_link(app_doc, link_id)
    return {"link_id": link_id, "ingest_config": link_service.effective_config(link)}
