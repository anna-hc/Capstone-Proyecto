from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends
from pymongo.errors import DuplicateKeyError

from app.models.partner import DeviceModel
from app.repositories import partner as repo
from app.services.partner import catalog
from app.services.partner.deps import current_partner_app
from app.services.partner.problems import PartnerProblem, PartnerRoute

router = APIRouter(prefix="/partner", tags=["Capabilities"], route_class=PartnerRoute)


def _own(app_id: str, app_doc: dict) -> None:
    if app_doc["app_id"] != app_id:
        raise PartnerProblem(404, detail="App no encontrada")


@router.get("/capabilities/metrics")
def list_metric_definitions(category: Optional[Literal["activity", "sleep", "vitals", "body", "exercise", "msk",
                                                        "device"]] = None,
                            app_doc: dict = Depends(current_partner_app)):
    return [m for m in catalog.METRICS_CATALOG if not category or m["category"] == category]


@router.get("/capabilities/limits")
def list_limits(app_doc: dict = Depends(current_partner_app)):
    # límites reales del despliegue: lo que se publica aquí es lo que se acepta (un envío dentro del límite no se
    # rechaza). El tamaño se mide sobre los bytes que viajan: si el cuerpo va con Content-Encoding: gzip, cuenta
    # el tamaño comprimido; el descomprimido tiene su propio tope.
    import app.config as conf
    from app.api.v1.routers.partner_ingest import MAX_BATCH
    rate = app_doc.get("rate_limit") or {}
    return {
        "body_bytes": {"default": conf.PARTNER_MAX_BODY_BYTES, "samples": conf.PARTNER_MAX_SAMPLES_BODY_BYTES,
                       "decompressed": conf.PARTNER_MAX_DECOMPRESSED_BYTES, "measured_on": "wire",
                       "note": "Con gzip cuenta el tamaño comprimido; Vercel corta cualquier cuerpo de más de 4,5 MB"},
        "batch_items": dict(MAX_BATCH, series=100),
        "points_per_series": 50000,
        "requests_per_minute": int(rate.get("requests_per_minute") or conf.PARTNER_DEFAULT_RPM),
        "samples_per_day": int(rate.get("samples_per_day") or conf.PARTNER_DEFAULT_SAMPLES_PER_DAY),
    }


@router.post("/apps/{app_id}/device-models", status_code=201)
def create_device_model(app_id: str, data: DeviceModel, app_doc: dict = Depends(current_partner_app)):
    _own(app_id, app_doc)
    unknown = sorted({c.metric for c in data.capabilities} - catalog.KNOWN_METRICS - {"exercise", "device_wear"})
    if unknown:
        raise PartnerProblem(422, slug="validation", title="Validation failed",
                             errors=[{"path": "capabilities", "message": f"métricas no reconocidas: {', '.join(unknown)}"}])
    if repo.device_models().count_documents({"app_id": app_id}) >= 200:
        raise PartnerProblem(409, detail="Límite de 200 modelos por app")
    doc = {"app_id": app_id, **data.model_dump(by_alias=True, exclude_none=True), "created_at": datetime.now(timezone.utc)}
    try:
        repo.device_models().insert_one(dict(doc))
    except DuplicateKeyError:
        raise PartnerProblem(409, detail="Ya existe un modelo con ese model_code") from None
    return data.model_dump(by_alias=True, exclude_none=True)


@router.get("/apps/{app_id}/device-models")
def list_device_models(app_id: str, app_doc: dict = Depends(current_partner_app)):
    _own(app_id, app_doc)
    return list(repo.device_models().find({"app_id": app_id}, {"_id": 0, "app_id": 0, "created_at": 0}).limit(200))
