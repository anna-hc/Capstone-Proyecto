import json
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Header, Request
from starlette.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from pydantic import ValidationError

import app.config as conf
from app.models.partner import DailySummaryBatch, DeviceEventBatch, MskMeasurementBatch, SampleBatch, SampleSeries, SessionBatch
from app.repositories import partner as repo
from app.services.partner import idempotency, ingest, links as link_service, ratelimit
from app.services.partner.deps import current_partner_app, require_scopes
from app.services.partner.problems import PartnerProblem, PartnerRoute, body_limit, set_audit
from app.services.partner.security import new_id
from app.tasks import partner_jobs

router = APIRouter(prefix="/partner", tags=["Ingest"], route_class=PartnerRoute)
MAX_BATCH = {"summaries": 100, "sessions": 200, "measurements": 500, "events": 500}


def _active_link(app_doc: dict, link_id: str, any_scope: tuple[str, ...]) -> dict:
    link = link_service.get_owned_link(app_doc, link_id)
    link_service.require_active(link)
    link_service.require_patient_active(link)
    if not set(link.get("granted_scopes", [])).intersection(any_scope):
        raise PartnerProblem(403, slug="insufficient-scope", title="Insufficient scope",
                             detail=f"El vínculo {link_id} no concede ninguno de: {' '.join(any_scope)}",
                             required_scope=" ".join(any_scope))
    set_audit(link_id=link_id)
    return link


def _check_batch(name: str, raw: bytes) -> None:
    # se cuenta antes de validar el esquema para responder 413 como pide el contrato
    try:
        count = len((json.loads(raw) or {}).get(name) or [])
    except (ValueError, AttributeError):
        return
    if count > MAX_BATCH[name]:
        raise PartnerProblem(413, slug="batch-too-large", detail=f"Máximo {MAX_BATCH[name]} elementos en {name}")


@router.post("/links/{link_id}/daily-summaries")
async def ingest_daily_summaries(link_id: str, request: Request,
                                 idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
                                 app_doc: dict = Depends(require_scopes("ingest:activity", "ingest:sleep", "ingest:vitals",
                                                                        "ingest:body"))):
    raw = await request.body()
    return await run_in_threadpool(_batch, app_doc, link_id, raw, idempotency_key, request.url.path, "summaries",
                                   DailySummaryBatch, ("ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:body"),
                                   ingest.ingest_daily_summaries)


@router.post("/links/{link_id}/sessions")
async def ingest_sessions(link_id: str, request: Request,
                          idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
                          app_doc: dict = Depends(require_scopes("ingest:sleep", "ingest:activity"))):
    raw = await request.body()
    return await run_in_threadpool(_batch, app_doc, link_id, raw, idempotency_key, request.url.path, "sessions",
                                   SessionBatch, ("ingest:sleep", "ingest:activity"), ingest.ingest_sessions)


@router.post("/links/{link_id}/msk-measurements")
async def ingest_msk_measurements(link_id: str, request: Request,
                                  idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
                                  app_doc: dict = Depends(require_scopes("ingest:msk"))):
    raw = await request.body()
    return await run_in_threadpool(_batch, app_doc, link_id, raw, idempotency_key, request.url.path, "measurements",
                                   MskMeasurementBatch, ("ingest:msk",), ingest.ingest_msk)


@router.post("/links/{link_id}/device-events")
async def ingest_device_events(link_id: str, request: Request,
                               idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
                               app_doc: dict = Depends(require_scopes("ingest:device"))):
    raw = await request.body()
    return await run_in_threadpool(_batch, app_doc, link_id, raw, idempotency_key, request.url.path, "events",
                                   DeviceEventBatch, ("ingest:device",), ingest.ingest_device_events)


def _batch(app_doc, link_id, raw, key, path, name, model, scopes, writer):
    # E/S de Mongo bloqueante: se ejecuta en el threadpool, nunca en el event loop
    _check_batch(name, raw)
    data = _parse(model, raw)
    link = _active_link(app_doc, link_id, scopes)
    return idempotency.run(key, app_doc["app_id"], idempotency.fingerprint("POST", path, raw), link_id,
                           lambda: (200, writer(app_doc, link, getattr(data, name))))


def _parse(model, raw: bytes):
    try:
        return model.model_validate_json(raw or b"{}")
    except ValidationError as exc:
        from fastapi.exceptions import RequestValidationError
        raise RequestValidationError(exc.errors()) from None


def _parse_samples(raw: bytes, content_type: str) -> SampleBatch:
    ctype = (content_type or "application/json").split(";")[0].strip().lower()
    if ctype == "application/x-ndjson":
        series = []
        for n, line in enumerate(raw.splitlines()):
            if not line.strip():
                continue
            try:
                series.append(SampleSeries.model_validate_json(line))
            except ValidationError as exc:
                from fastapi.exceptions import RequestValidationError
                raise RequestValidationError([{**e, "loc": ("series", n, *e["loc"])} for e in exc.errors()]) from None
        if not series or len(series) > 100:
            raise PartnerProblem(422, slug="validation", title="Validation failed",
                                 errors=[{"path": "series", "message": "entre 1 y 100 series por petición"}])
        return SampleBatch.model_construct(series=series)
    if ctype != "application/json":
        raise PartnerProblem(415, detail="Content-Type admitido: application/json o application/x-ndjson")
    return _parse(SampleBatch, raw)


@router.post("/links/{link_id}/samples", status_code=202)
@body_limit(conf.PARTNER_MAX_SAMPLES_BODY_BYTES)
async def ingest_samples(link_id: str, request: Request,
                         idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key"),
                         app_doc: dict = Depends(require_scopes("ingest:vitals", "ingest:activity"))):
    raw = await request.body()
    return await run_in_threadpool(_samples, app_doc, link_id, raw, request.headers.get("content-type"),
                                   idempotency_key, request.url.path)


def _samples(app_doc, link_id, raw, content_type, idempotency_key, path):
    data = _parse_samples(raw, content_type)
    link = _active_link(app_doc, link_id, ("ingest:vitals", "ingest:activity"))

    def action():
        scopes = ingest.effective_scopes(app_doc, link)
        declared = ingest.declared_metrics(link)
        intervals = ingest.effective_intervals(link)
        accepted, errors, rejected_points = [], [], 0
        for i, series in enumerate(data.series):
            s = series.model_dump(mode="json", exclude_none=True)
            errs, normalized = ingest.validate_series(i, s, scopes, declared, intervals)
            if errs:
                errors.append({"series_index": i, "message": "; ".join(f"{e['path']}: {e['message']}" for e in errs)})
                rejected_points += len(s["values"])
            else:
                accepted.append(normalized)
        if not accepted:
            raise PartnerProblem(422, slug="validation", title="Validation failed",
                                 errors=[{"path": f"series[{e['series_index']}]", "message": e["message"]} for e in errors])
        points = sum(len(s["values"]) for s in accepted)
        limit = int((app_doc.get("rate_limit") or {}).get("samples_per_day") or conf.PARTNER_DEFAULT_SAMPLES_PER_DAY)
        ratelimit.enforce(f"samples:{app_doc['app_id']}", limit, 86400, cost=points, slug="quota-exceeded",
                          detail=f"Cuota diaria de {limit} muestras superada")
        now = datetime.now(timezone.utc)
        job_id = new_id("job")
        # el 202 solo sale con el payload y el job ya persistidos
        partner_jobs.store_payload(job_id, accepted)
        job = {"job_id": job_id, "status": "queued", "app_id": app_doc["app_id"], "link_id": link_id,
               "received_at": now, "completed_at": None, "attempts": 0, "lease_until": None,
               "summary": {"series": len(data.series), "points_accepted": 0, "points_rejected": rejected_points},
               "errors": errors}
        repo.ingest_jobs().insert_one(dict(job))
        partner_jobs.enqueue(job_id)
        return 202, _public_job(job)

    return idempotency.run(idempotency_key, app_doc["app_id"], idempotency.fingerprint("POST", path, raw),
                           link_id, action)


def _public_job(job: dict) -> dict:
    iso = lambda v: v.isoformat().replace("+00:00", "Z") if hasattr(v, "isoformat") else v  # noqa: E731
    return {"job_id": job["job_id"], "status": job["status"], "link_id": job["link_id"],
            "received_at": iso(job.get("received_at")), "completed_at": iso(job.get("completed_at")),
            "summary": job.get("summary"), "errors": job.get("errors") or []}


@router.get("/ingest/jobs/{job_id}")
def get_ingest_job(job_id: str, app_doc: dict = Depends(current_partner_app)):
    job = repo.ingest_jobs().find_one({"job_id": job_id, "app_id": app_doc["app_id"]}, {"_id": 0})
    if not job:
        raise PartnerProblem(404, detail="Job no encontrado")
    return JSONResponse(_public_job(job))
