import hmac
import threading
import time
import uuid
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException as StarletteHTTPException

import app.config as conf
from app import dashboard_auth
from app.api.v1.partner_registry import include_partner_routers
from app.logging_conf import get_logger
from app.middleware.tenant_middleware import TenantMiddleware
from app.services.partner.problems import _SLUGS, _TITLES, new_trace_id, problem_response, trace_id_var

log = get_logger("PARTNER")


def _jobs():
    from app.services.partner import alerts, links, webhooks
    from app.tasks import partner_jobs
    return {
        "deliver-webhooks": (webhooks.deliver_due, 30),
        "sweep-ingest": (partner_jobs.sweep_ingest_jobs, 60),
        "run-deletions": (links.run_due_deletions, 120),
        "detect-goals": (partner_jobs.detect_goal_changes, 900),
        "detect-gaps": (partner_jobs.detect_sync_gaps, 3600),
        "check-overdue": (alerts.check_overdue, 900),
        "ensure-indexes": (_ensure_indexes, 86400),
    }


def _ensure_indexes():
    try:
        import app.db as dbmod
        dbmod.ensure_partner_indexes(dbmod.central_db)
        dbmod.ensure_partner_tenant_indexes(dbmod._central_client[conf.PARTNER_SANDBOX_DB])
    except Exception as exc:
        log.error("[PARTNER][INDEXES][FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})


def _local_scheduler(stop: threading.Event):
    # solo fuera de Vercel (uvicorn en un servidor): en serverless no hay procesos vivos entre peticiones
    last: dict[str, float] = {}
    while not stop.wait(5):
        for name, (fn, every) in _jobs().items():
            if time.time() - last.get(name, 0) >= every:
                last[name] = time.time()
                try:
                    fn()
                except Exception as exc:
                    log.error("[PARTNER][JOB][%s] %s", name, type(exc).__name__, extra={"tag": "PARTNER"})


@asynccontextmanager
async def lifespan(_app: FastAPI):
    stop = threading.Event()
    if mounted:
        threading.Thread(target=_ensure_indexes, daemon=True).start()
        if conf.PARTNER_LOCAL_SCHEDULER:
            threading.Thread(target=_local_scheduler, args=(stop,), daemon=True).start()
    yield
    stop.set()


app = FastAPI(title=conf.APP_NAME, version="1.0.0-alpha.2", lifespan=lifespan,
              docs_url="/docs" if conf.APP_ENV in conf.DEV_APP_ENVS else None, redoc_url=None,
              openapi_url="/openapi.json" if conf.APP_ENV in conf.DEV_APP_ENVS else None)
app.add_middleware(TenantMiddleware)
if conf.CORS_ALLOW_ORIGINS:
    # la API de máquina no necesita CORS; solo se abre a los orígenes del front que se declaren
    app.add_middleware(CORSMiddleware, allow_origins=conf.CORS_ALLOW_ORIGINS, allow_credentials=False,
                       allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
                       allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "x-tenant"])


# login de las páginas web (demo, /docs, herramientas de desarrollo); va antes de security_headers para que
# las redirecciones y la página de login también lleven las cabeceras de seguridad
app.middleware("http")(dashboard_auth.guard)
app.include_router(dashboard_auth.router)

# Swagger UI (solo con APP_ENV de desarrollo) carga sus recursos de jsDelivr y arranca con un script en línea
_DOCS_CSP = ("default-src 'none'; script-src https://cdn.jsdelivr.net 'unsafe-inline'; "
             "style-src https://cdn.jsdelivr.net; img-src https://fastapi.tiangolo.com data:; "
             "connect-src 'self'; frame-ancestors 'none'")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    # CORP evita que otros sitios incrusten las respuestas de la API (alerta de ZAP, defecto D-08)
    response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
    if "content-security-policy" not in response.headers:
        response.headers["Content-Security-Policy"] = (
            _DOCS_CSP if request.url.path == "/docs" else "default-src 'none'; frame-ancestors 'none'")
    return response


@app.middleware("http")
async def trace_id_header(request: Request, call_next):
    # X-Trace-Id en todas las respuestas, también en /health, cron y 404 fuera de /partner (defecto D-04);
    # las rutas /partner reutilizan este mismo identificador
    trace_id = new_trace_id(request.headers.get("x-request-id"))
    token = trace_id_var.set(trace_id)
    try:
        response = await call_next(request)
    finally:
        trace_id_var.reset(token)
    response.headers.setdefault("X-Trace-Id", trace_id)
    return response


@app.exception_handler(StarletteHTTPException)
async def http_problem(request: Request, exc: StarletteHTTPException):
    # los errores HTTP fuera de las rutas /partner (cron, rutas inexistentes) también salen como problem+json
    # el detalle por defecto de Starlette es la frase HTTP ("Not Found"): no aporta nada y se omite
    default = HTTPStatus(exc.status_code).phrase if exc.status_code in HTTPStatus._value2member_map_ else None
    detail = exc.detail if isinstance(exc.detail, str) and exc.detail != default else None
    headers = dict(getattr(exc, "headers", None) or {})
    if exc.status_code == 405:
        # Starlette solo anuncia los métodos de la primera ruta que coincide con la URL; GET y PATCH de
        # /partner/apps/{app_id} están en rutas distintas y Allow quedaba incompleto (Schemathesis ST205)
        headers["Allow"] = ", ".join(_allowed_methods(request.scope)) or headers.get("Allow", "")
    return problem_response(exc.status_code, _SLUGS.get(exc.status_code, "error"),
                            _TITLES.get(exc.status_code, "Error"), detail, headers or None)


def _allowed_methods(scope) -> list[str]:
    # se pregunta a cada ruta si acepta la URL con cada método (FULL = ruta y método coinciden); así funciona
    # también con los routers incluidos, que FastAPI envuelve y no expone como lista plana
    from starlette.routing import Match
    allowed = []
    for method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
        probe = {**scope, "method": method}
        if any(route.matches(probe)[0] == Match.FULL for route in app.router.routes):
            allowed.append(method)
    return allowed


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    error_id = uuid.uuid4().hex[:12]
    log.error("[UNHANDLED][%s] %s %s: %s", error_id, request.method, request.url.path, type(exc).__name__,
              extra={"tag": "UNHANDLED"})
    return JSONResponse({"detail": "Error interno", "error_id": error_id}, status_code=500)


@app.get("/api/v1/health")
@app.get("/health")
async def health():
    return {"status": "ok", "partner_api": mounted}


@app.get("/api/v1/internal/cron/{job}", include_in_schema=False)
async def run_cron(job: str, authorization: str | None = Header(default=None)):
    # Vercel Cron envía "Authorization: Bearer <CRON_SECRET>"; sin secreto configurado la ruta no existe
    expected = f"Bearer {conf.CRON_SECRET}"
    if not mounted or not conf.CRON_SECRET or not hmac.compare_digest((authorization or "").encode(), expected.encode()):
        raise HTTPException(status_code=404)
    jobs = _jobs()
    if job not in jobs:
        raise HTTPException(status_code=404)
    result = await run_in_threadpool(jobs[job][0])
    return {"job": job, "result": result}


mounted = include_partner_routers(app)


@app.get("/", include_in_schema=False)
async def root():
    from app.services.partner.deps import demo_enabled
    if mounted and demo_enabled():
        return RedirectResponse(url="/api/v1/partner-demo/", status_code=307)
    return {"service": conf.APP_NAME, "status": "ok" if mounted else "disabled"}
