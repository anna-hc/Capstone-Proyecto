import logging
import os


class _TagAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        extra = {**self.extra, **(kwargs.get("extra") or {})}
        kwargs["extra"] = extra
        return f"[{extra.get('tag', 'API')}] {msg}", kwargs


logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s %(message)s")


def get_logger(name: str | None = None) -> logging.LoggerAdapter:
    return _TagAdapter(logging.getLogger(name or "partner_api"), {"tag": "API"})
