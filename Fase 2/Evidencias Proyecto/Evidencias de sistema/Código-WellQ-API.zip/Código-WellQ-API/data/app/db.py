from contextvars import ContextVar
from datetime import timezone as _tz

from pymongo import MongoClient

import app.config as conf
from app.logging_conf import get_logger

# MongoClient no conecta hasta la primera operación: importar este módulo no abre red (importante en Vercel)
_client = MongoClient(conf.MONGO_URI, tz_aware=True, tzinfo=_tz.utc, serverSelectionTimeoutMS=5000)
_central_client = _client if conf.MONGO_CENTRAL_URI == conf.MONGO_URI else MongoClient(
    conf.MONGO_CENTRAL_URI, tz_aware=True, tzinfo=_tz.utc, serverSelectionTimeoutMS=5000)
db = _client[conf.MONGO_DB]
central_db = _central_client[conf.MONGODB_CENTRAL_DB]
_tenant_db: ContextVar = ContextVar("tenant_db", default=db)

TBL_METRICS = "metrics"
TBL_PATIENTS = "patients"
TBL_USERS = "users"
TBL_PATIENT_GOALS = "patient_goals"
TBL_PATIENT_PROGRAMS = "patient_programs"
TBL_PROGRAM_TEMPLATES = "program_templates"
TBL_EXERCISES_CATALOG = "exercises_catalog"
TBL_LEGAL_DOCS = "legal_docs"
TBL_PATIENT_WEARABLE_WORKOUTS = "patient_wearable_workouts"
TBL_TENANTS = "tenants"
KEY_CARE_CLINICIAN_ID = "care_clinician_id"
KEY_STATE = "state"


def safe_create_index(collection, keys, name=None, **kwargs):
    try:
        if name and any(ix.get("name") == name for ix in collection.list_indexes()):
            return
        collection.create_index(keys, name=name, **kwargs)
    except Exception as exc:
        get_logger("PARTNER").warning("[INDEXES] %s en %s: %s", name, collection.name, type(exc).__name__)


def tenants_registry_collection():
    return central_db[TBL_TENANTS]


def users_collection():
    return _tenant_db.get()[TBL_USERS]


# Partner API. Identidad, vínculos y colas viven en central_db (son del fabricante,
# no de una clínica); los datos de salud van a la base del tenant del paciente.
TBL_PARTNER_DEVELOPERS = "partner_developers"
TBL_PARTNER_EMAIL_VERIFICATIONS = "partner_email_verifications"
TBL_PARTNER_APPS = "partner_apps"
TBL_PARTNER_PROMOTION_REQUESTS = "partner_promotion_requests"
TBL_PARTNER_DEVICE_MODELS = "partner_device_models"
TBL_PAIRING_CODES = "pairing_codes"
TBL_PARTNER_LINKS = "partner_links"
TBL_INGEST_JOBS = "ingest_jobs"
TBL_PARTNER_INGEST_PAYLOADS = "partner_ingest_payloads"
TBL_WEBHOOK_SUBSCRIPTIONS = "webhook_subscriptions"
TBL_WEBHOOK_DELIVERIES = "webhook_deliveries"
TBL_PARTNER_AUDIT_LOG = "partner_audit_log"
TBL_PARTNER_IDEMPOTENCY = "partner_idempotency_keys"
TBL_PARTNER_DELETION_REQUESTS = "partner_deletion_requests"
TBL_PARTNER_SANDBOX_PATIENTS = "partner_sandbox_patients"
TBL_MSK_MEASUREMENTS = "msk_measurements"
TBL_DEVICE_EVENTS = "device_events"

PARTNER_CENTRAL_TABLES = (
    TBL_PARTNER_DEVELOPERS, TBL_PARTNER_EMAIL_VERIFICATIONS, TBL_PARTNER_APPS,
    TBL_PARTNER_PROMOTION_REQUESTS, TBL_PARTNER_DEVICE_MODELS, TBL_PAIRING_CODES,
    TBL_PARTNER_LINKS, TBL_INGEST_JOBS, TBL_PARTNER_INGEST_PAYLOADS, TBL_WEBHOOK_SUBSCRIPTIONS,
    TBL_WEBHOOK_DELIVERIES, TBL_PARTNER_AUDIT_LOG, TBL_PARTNER_IDEMPOTENCY,
    TBL_PARTNER_DELETION_REQUESTS, TBL_PARTNER_SANDBOX_PATIENTS,
)


def partner_collection(name: str):
    if name not in PARTNER_CENTRAL_TABLES:
        raise ValueError(f"colección partner desconocida: {name}")
    return central_db[name]


def ensure_partner_indexes(central=None):
    c = central if central is not None else central_db
    safe_create_index(c[TBL_PARTNER_DEVELOPERS], "developer_id", unique=True, name="ux_pdev_id")
    safe_create_index(c[TBL_PARTNER_DEVELOPERS], "contact_email_norm", unique=True, name="ux_pdev_email")
    safe_create_index(c[TBL_PARTNER_EMAIL_VERIFICATIONS], "token_hash", unique=True, name="ux_pver_token")
    safe_create_index(c[TBL_PARTNER_EMAIL_VERIFICATIONS], "expires_at", expireAfterSeconds=0, name="ttl_pver_exp")
    safe_create_index(c[TBL_PARTNER_APPS], "app_id", unique=True, name="ux_papp_id")
    safe_create_index(c[TBL_PARTNER_APPS], "client_id", unique=True, name="ux_papp_client")
    safe_create_index(c[TBL_PARTNER_APPS], "developer_id", name="ix_papp_dev")
    safe_create_index(c[TBL_PARTNER_PROMOTION_REQUESTS], "request_id", unique=True, name="ux_ppromo_id")
    safe_create_index(c[TBL_PARTNER_PROMOTION_REQUESTS], [("status", 1), ("created_at", 1)], name="ix_ppromo_status")
    safe_create_index(c[TBL_PARTNER_DEVICE_MODELS], [("app_id", 1), ("model_code", 1)], unique=True, name="ux_pdm_app_model")
    safe_create_index(c[TBL_PAIRING_CODES], "code_hash", unique=True, name="ux_pair_hash")
    safe_create_index(c[TBL_PAIRING_CODES], "expires_at", expireAfterSeconds=0, name="ttl_pair_exp")
    safe_create_index(c[TBL_PARTNER_LINKS], "link_id", unique=True, name="ux_plink_id")
    safe_create_index(c[TBL_PARTNER_LINKS], [("app_id", 1), ("external_user_id", 1), ("status", 1)], name="ix_plink_app_ext")
    safe_create_index(c[TBL_PARTNER_LINKS], "active_key", unique=True, sparse=True, name="ux_plink_active")
    safe_create_index(c[TBL_PARTNER_LINKS], [("app_id", 1), ("link_id", 1)], name="ix_plink_app_cursor")
    safe_create_index(c[TBL_PARTNER_LINKS], [("tenant_db", 1), ("patient_id", 1)], name="ix_plink_patient")
    safe_create_index(c[TBL_INGEST_JOBS], "job_id", unique=True, name="ux_ijob_id")
    safe_create_index(c[TBL_INGEST_JOBS], [("app_id", 1), ("received_at", -1)], name="ix_ijob_app")
    safe_create_index(c[TBL_INGEST_JOBS], [("status", 1), ("lease_until", 1)], name="ix_ijob_status")
    safe_create_index(c[TBL_PARTNER_INGEST_PAYLOADS], "job_id", unique=True, name="ux_ipay_job")
    safe_create_index(c[TBL_PARTNER_INGEST_PAYLOADS], "expires_at", expireAfterSeconds=0, name="ttl_ipay_exp")
    safe_create_index(c[TBL_WEBHOOK_SUBSCRIPTIONS], "webhook_id", unique=True, name="ux_whs_id")
    safe_create_index(c[TBL_WEBHOOK_SUBSCRIPTIONS], [("app_id", 1), ("status", 1)], name="ix_whs_app")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], "delivery_id", unique=True, name="ux_whd_id")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], [("webhook_id", 1), ("created_at", -1)], name="ix_whd_webhook")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], [("status", 1), ("next_retry_at", 1)], name="ix_whd_due")
    safe_create_index(c[TBL_WEBHOOK_DELIVERIES], "expires_at", expireAfterSeconds=0, name="ttl_whd_30d")
    safe_create_index(c[TBL_PARTNER_AUDIT_LOG], [("app_id", 1), ("ts", -1)], name="ix_paudit_app_ts")
    safe_create_index(c[TBL_PARTNER_AUDIT_LOG], "ts", expireAfterSeconds=365 * 86400, name="ttl_paudit_12m")
    safe_create_index(c[TBL_PARTNER_IDEMPOTENCY], [("app_id", 1), ("key", 1)], unique=True, name="ux_pidem_app_key")
    safe_create_index(c[TBL_PARTNER_IDEMPOTENCY], "created_at", expireAfterSeconds=86400, name="ttl_pidem_24h")
    safe_create_index(c[TBL_PARTNER_DELETION_REQUESTS], "request_id", unique=True, name="ux_pdel_id")
    safe_create_index(c[TBL_PARTNER_DELETION_REQUESTS], [("status", 1), ("next_attempt_at", 1)], name="ix_pdel_due")
    safe_create_index(c[TBL_PARTNER_SANDBOX_PATIENTS], "patient_id", unique=True, name="ux_psbx_patient")


def ensure_partner_tenant_indexes(target_db):
    # el filtro parcial deja fuera los documentos legados de metrics, que no traen link_id
    only_partner = {"partialFilterExpression": {"link_id": {"$exists": True}}}
    safe_create_index(target_db[TBL_METRICS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_metrics_link_record", **only_partner)
    safe_create_index(target_db[TBL_METRICS], [("link_id", 1), ("metric_date", 1)], name="ix_metrics_link_date", **only_partner)
    safe_create_index(target_db[TBL_PATIENT_WEARABLE_WORKOUTS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_wearable_workouts_link_record", **only_partner)
    safe_create_index(target_db[TBL_MSK_MEASUREMENTS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_msk_link_record")
    safe_create_index(target_db[TBL_MSK_MEASUREMENTS], [("patient_id", 1), ("timestamp", 1)], name="ix_msk_patient_ts")
    safe_create_index(target_db[TBL_MSK_MEASUREMENTS], "body_region", name="ix_msk_body_region")
    safe_create_index(target_db[TBL_DEVICE_EVENTS], [("link_id", 1), ("record_key", 1)], unique=True, name="ux_devev_link_record")
    safe_create_index(target_db[TBL_DEVICE_EVENTS], [("patient_id", 1), ("timestamp", 1)], name="ix_devev_patient_ts")
    safe_create_index(target_db[TBL_DEVICE_EVENTS], [("link_id", 1), ("timestamp", -1)], name="ix_devev_link_ts")
