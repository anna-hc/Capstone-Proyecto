import gzip
import json
import threading
import time
from datetime import datetime, timedelta, timezone

from bson import Binary

import app.db as dbmod
from app.logging_conf import get_logger
from app.repositories import partner as repo
from app.services.partner import ingest, links as link_service, webhooks
from app.services.partner.problems import PartnerProblem
from app.services.partner.tenancy import link_db

log = get_logger("PARTNER_JOBS")
JOB_LEASE = timedelta(minutes=5)
MAX_JOB_ATTEMPTS = 5
PAYLOAD_RETENTION = timedelta(days=7)
GAP_THRESHOLD = timedelta(hours=6)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def store_payload(job_id: str, series: list[dict]) -> None:
    data = gzip.compress(json.dumps(series, default=str).encode(), compresslevel=5)
    repo.ingest_payloads().insert_one({"job_id": job_id, "data": Binary(data), "size": len(data),
                                       "created_at": _now(), "expires_at": _now() + PAYLOAD_RETENTION})


_redis_down_until = 0.0


def _enqueue_or_process(job_id: str) -> None:
    global _redis_down_until
    from app.services.partner.ratelimit import redis_available
    if time.time() >= _redis_down_until and redis_available():
        try:
            from app.utils.rq_queue import get_queue
            get_queue("wellq_ingest").enqueue("app.tasks.partner_jobs.process_ingest_job", job_id, job_timeout=600)
            return
        except Exception as exc:
            _redis_down_until = time.time() + 60
            log.warning("[PARTNER][INGEST][ENQUEUE_FAIL] job=%s err=%s", job_id, type(exc).__name__,
                        extra={"tag": "PARTNER"})
    # sin Redis el job (ya persistido) se procesa en este proceso; si se cae, lo recoge el barrido programado
    process_ingest_job(job_id)


def enqueue(job_id: str) -> None:
    # fuera del hilo de la petición: una caída de Redis tarda más de un minuto en fallar y no debe retrasar el 202
    threading.Thread(target=_enqueue_or_process, args=(job_id,), daemon=True).start()


def process_ingest_job(job_id: str) -> dict | None:
    now = _now()
    job = repo.find_one_and_update(
        repo.ingest_jobs(),
        {"job_id": job_id, "status": {"$in": ["queued", "processing"]},
         "$or": [{"lease_until": None}, {"lease_until": {"$lt": now}}]},
        {"$set": {"status": "processing", "lease_until": now + JOB_LEASE, "started_at": now},
         "$inc": {"attempts": 1}},
    )
    if not job:
        return None
    link = repo.links().find_one({"link_id": job["link_id"]}, {"_id": 0})
    payload = repo.ingest_payloads().find_one({"job_id": job_id})
    try:
        if not link or link.get("status") != "active":
            raise PartnerProblem(403, slug="link-revoked", detail="vínculo revocado antes de procesar el job")
        if not payload:
            raise RuntimeError("payload no encontrado")
        series = json.loads(gzip.decompress(bytes(payload["data"])))
        accepted = [(i, s) for i, s in enumerate(series)]
        points = ingest.write_series(link, job_id, accepted)
        summary = dict(job.get("summary") or {})
        summary["points_accepted"] = points
        rejected = summary.get("points_rejected", 0)
        status = "completed" if not rejected else ("partially_completed" if points else "failed")
        repo.ingest_jobs().update_one({"job_id": job_id}, {"$set": {
            "status": status, "summary": summary, "completed_at": _now(), "lease_until": None}})
        repo.ingest_payloads().delete_one({"job_id": job_id})
        event = "ingest.job.failed" if status == "failed" else "ingest.job.completed"
        webhooks.dispatch(job["app_id"], event, {"job_id": job_id, "link_id": job["link_id"], "status": status,
                                                 "summary": summary, "errors": job.get("errors") or []})
        return repo.ingest_jobs().find_one({"job_id": job_id}, {"_id": 0})
    except Exception as exc:
        final = isinstance(exc, PartnerProblem) or job.get("attempts", 1) >= MAX_JOB_ATTEMPTS
        update = {"lease_until": None, "last_error": type(exc).__name__}
        if final:
            update.update({"status": "failed", "completed_at": _now()})
            repo.ingest_payloads().delete_one({"job_id": job_id})
            webhooks.dispatch(job["app_id"], "ingest.job.failed", {
                "job_id": job_id, "link_id": job["link_id"], "status": "failed",
                "errors": [{"series_index": None, "message": str(exc) if isinstance(exc, PartnerProblem) else "error interno"}]})
        else:
            update["status"] = "queued"
        repo.ingest_jobs().update_one({"job_id": job_id}, {"$set": update})
        log.error("[PARTNER][INGEST][JOB_FAIL] job=%s final=%s err=%s", job_id, final, type(exc).__name__,
                  extra={"tag": "PARTNER"})
        return None


def sweep_ingest_jobs(limit: int = 50) -> int:
    stale = _now() - timedelta(minutes=2)
    count = 0
    for job in repo.ingest_jobs().find({"status": {"$in": ["queued", "processing"]}, "received_at": {"$lte": stale},
                                        "$or": [{"lease_until": None}, {"lease_until": {"$lt": _now()}}]},
                                       {"job_id": 1}).limit(limit):
        if process_ingest_job(job["job_id"]):
            count += 1
    return count


GAP_WINDOW_DAYS = 14


def _day(value) -> datetime:
    return datetime.combine(value, datetime.min.time(), tzinfo=timezone.utc)


def _worn_state_by_day(tdb, link: dict, since: datetime) -> dict[str, str]:
    """worn / not_worn por día local según los eventos del dispositivo (el último evento del día manda)."""
    state: dict[str, str] = {}
    for ev in repo.tenant_collection(tdb, dbmod.TBL_DEVICE_EVENTS).find(
            {"link_id": link["link_id"], "event_type": {"$in": ["worn", "removed"]}, "timestamp": {"$gte": since}},
            {"timestamp": 1, "event_type": 1, "local_date": 1}).sort("timestamp", 1).limit(5000):
        day = ev.get("local_date") or ingest.patient_local_date(link, ev["timestamp"])
        state[day] = "worn" if ev["event_type"] == "worn" else "not_worn"
    return state


def compute_gaps(link: dict, now: datetime | None = None, window_days: int = GAP_WINDOW_DAYS) -> list[dict]:
    """Huecos por métrica en los últimos `window_days` días.

    Cada hueco dice qué métrica falta, desde y hasta cuándo, y por qué:
    - metric_missing: ese día llegaron otras métricas del vínculo pero no esta (reenviar la métrica).
    - no_data: ese día no llegó nada del vínculo y no hay constancia de que el dispositivo estuviera quitado
      (reenviar el día completo).
    - not_worn: no llegó nada pero el dispositivo informó de que estaba quitado (removed / wear_time 0); no hay
      nada que reenviar.
    Los días sin datos al final del período, hasta ayer, también se marcan.
    """
    now = now or _now()
    tdb = link_db(link)
    metrics = repo.tenant_collection(tdb, dbmod.TBL_METRICS)
    since = now - timedelta(days=window_days)
    gaps: list[dict] = []

    # series de alta frecuencia: huecos dentro de cada métrica mayores que GAP_THRESHOLD
    spans_by_metric: dict[str, list] = {}
    for d in metrics.find({"link_id": link["link_id"], "partner_kind": "samples", "to_ts": {"$gte": since}},
                          {"from_ts": 1, "to_ts": 1, "sensors": 1}).sort("from_ts", 1).limit(5000):
        for metric in (d.get("sensors") or {}):
            spans_by_metric.setdefault(metric, []).append((d["from_ts"], d.get("to_ts") or d["from_ts"]))
    for metric, spans in spans_by_metric.items():
        last_end = None
        for s_from, s_to in spans:
            if last_end is not None and s_from - last_end > GAP_THRESHOLD:
                gaps.append({"metric": f"samples:{metric}", "from": last_end, "to": s_from, "reason": "no_data"})
            last_end = max(last_end, s_to) if last_end else s_to
        # la serie dejó de llegar: hueco abierto hasta ahora
        if last_end is not None and now - last_end > GAP_THRESHOLD:
            gaps.append({"metric": f"samples:{metric}", "from": last_end, "to": now, "reason": "no_data",
                         "open": True})

    # resúmenes diarios: por cada campo que el vínculo suele enviar, qué días faltan
    fields_by_day: dict[str, set[str]] = {}
    wear_zero: set[str] = set()
    for d in metrics.find({"link_id": link["link_id"], "partner_kind": "daily_summary",
                           "metric_date": {"$gte": since.date().isoformat()}},
                          {"metric_date": 1, "partner_summary": 1}).limit(5000):
        summary = d.get("partner_summary") or {}
        fields_by_day.setdefault(d["metric_date"], set()).update(summary)
        if summary.get("wear_time_minutes") == 0:
            wear_zero.add(d["metric_date"])
    if fields_by_day:
        worn = _worn_state_by_day(tdb, link, since)
        expected = set().union(*fields_by_day.values())
        cursor = datetime.fromisoformat(min(fields_by_day)).date()
        today = datetime.fromisoformat(ingest.patient_local_date(link, now)).date()
        while cursor < today:
            day = cursor.isoformat()
            present = fields_by_day.get(day, set())
            start = _day(cursor)
            if not present:
                reason = "not_worn" if (worn.get(day) == "not_worn" or day in wear_zero) else "no_data"
                gaps.append({"metric": "daily_summary", "from": start, "to": start + timedelta(days=1),
                             "reason": reason, "local_date": day})
            else:
                for field in sorted(expected - present):
                    gaps.append({"metric": f"daily:{field}", "from": start, "to": start + timedelta(days=1),
                                 "reason": "metric_missing", "local_date": day})
            cursor += timedelta(days=1)
    gaps.sort(key=lambda g: (g["from"], g["metric"]))
    return gaps[-200:]


def detect_sync_gaps(limit: int = 0) -> int:
    emitted = 0
    for link in repo.links().find({"status": "active"}, {"_id": 0}).limit(limit):
        try:
            gaps = compute_gaps(link)
        except PartnerProblem:
            continue
        known = {(g["metric"], g["from"].isoformat() if hasattr(g["from"], "isoformat") else g["from"])
                 for g in link.get("gaps", [])}
        new = [g for g in gaps if (g["metric"], g["from"].isoformat()) not in known and g["reason"] != "not_worn"]
        repo.links().update_one({"link_id": link["link_id"]}, {"$set": {"gaps": gaps, "gaps_checked_at": _now()}})
        if new:
            webhooks.dispatch(link["app_id"], "sync.gap_detected", {"link_id": link["link_id"], "gaps": [
                {"metric": g["metric"], "from": g["from"].isoformat(), "to": g["to"].isoformat(),
                 "reason": g["reason"]} for g in new[:50]]})
            emitted += 1
    return emitted


def detect_goal_changes(limit: int = 0) -> int:
    emitted = 0
    for link in repo.links().find({"status": "active", "granted_scopes": "read:goals"}, {"_id": 0}).limit(limit):
        try:
            goals = repo.tenant_collection(link_db(link), dbmod.TBL_PATIENT_GOALS).find_one(
                {"patient_id": link["patient_id"]}, {"updated_at": 1})
        except PartnerProblem:
            continue
        updated = (goals or {}).get("updated_at")
        if updated and updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        seen = link.get("goals_seen_at")
        if seen and seen.tzinfo is None:
            seen = seen.replace(tzinfo=timezone.utc)
        if updated and (seen is None or updated > seen):
            repo.links().update_one({"link_id": link["link_id"]}, {"$set": {"goals_seen_at": updated}})
            if seen is not None:
                webhooks.dispatch(link["app_id"], "goals.updated", {"link_id": link["link_id"],
                                                                    "updated_at": updated.isoformat()})
                emitted += 1
    return emitted


def _run(fn) -> None:
    try:
        fn()
    except Exception as exc:
        log.error("[PARTNER][JOB][%s] %s", fn.__name__, type(exc).__name__, extra={"tag": "PARTNER"})


def job_deliver_webhooks() -> None:
    _run(webhooks.deliver_due)


def job_sweep_ingest() -> None:
    _run(sweep_ingest_jobs)


def job_run_deletions() -> None:
    _run(link_service.run_due_deletions)


def job_detect_goal_changes() -> None:
    _run(detect_goal_changes)


def job_detect_sync_gaps() -> None:
    _run(detect_sync_gaps)


PARTNER_JOB_SCHEDULE = (("job_deliver_webhooks", 30), ("job_sweep_ingest", 60), ("job_run_deletions", 120),
                        ("job_detect_goal_changes", 900), ("job_detect_sync_gaps", 3600))
PARTNER_JOB_IDS = tuple(f"partner_{name}" for name, _ in PARTNER_JOB_SCHEDULE)


def register_partner_jobs(scheduler) -> None:
    # referencias textuales: el jobstore de Mongo serializa los jobs y no admite closures
    from apscheduler.triggers.interval import IntervalTrigger
    for name, seconds in PARTNER_JOB_SCHEDULE:
        scheduler.add_job(f"app.tasks.partner_jobs:{name}", trigger=IntervalTrigger(seconds=seconds),
                          id=f"partner_{name}", name=f"partner_{name}", replace_existing=True,
                          max_instances=1, coalesce=True)
