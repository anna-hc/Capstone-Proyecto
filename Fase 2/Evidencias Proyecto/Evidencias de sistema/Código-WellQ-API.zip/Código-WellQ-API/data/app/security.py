from datetime import datetime, timedelta, timezone

import jwt

import app.config as conf


def decode_jwt(token: str) -> tuple[dict, bool]:
    # mismas reglas que app/security.py de WellQ: así un token de la app vale aquí y viceversa
    if not conf.JWT_SECRET:
        return {}, False
    try:
        payload = jwt.decode(token, conf.JWT_SECRET, algorithms=[conf.JWT_ALG], options={"require": ["exp", "iat"]})
        return payload, True
    except jwt.PyJWTError:
        return {}, False


def create_access_jwt(sub: str, extra: dict | None = None, minutes: int = 30) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": sub, "iat": int(now.timestamp()), "exp": int((now + timedelta(minutes=minutes)).timestamp()),
               "iss": "WELLQ", "type": "access", **(extra or {})}
    return jwt.encode(payload, conf.JWT_SECRET, algorithm=conf.JWT_ALG)
