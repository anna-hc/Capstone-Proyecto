ALL_SCOPES = (
    "links:manage", "ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:body",
    "ingest:msk", "ingest:device", "read:goals", "read:scores", "webhooks:manage",
)
CONSENT_SCOPES = (
    "ingest:activity", "ingest:sleep", "ingest:vitals", "ingest:body", "ingest:msk",
    "ingest:device", "read:goals", "read:scores",
)
APP_LEVEL_SCOPES = ("links:manage", "webhooks:manage")

SCOPE_DESCRIPTIONS_ES = {
    "ingest:activity": "Enviar tu actividad: pasos, distancia, calorías y sesiones de ejercicio",
    "ingest:sleep": "Enviar tu sueño: duración, fases y eficiencia",
    "ingest:vitals": "Enviar constantes: frecuencia cardiaca, variabilidad, oxígeno en sangre, respiración y temperatura",
    "ingest:body": "Enviar medidas corporales: peso y grasa corporal",
    "ingest:msk": "Enviar mediciones musculoesqueléticas: movilidad, fuerza, marcha y equilibrio",
    "ingest:device": "Enviar el estado del dispositivo: puesto, quitado, batería y sincronización",
    "read:goals": "Leer tus objetivos y ejercicios prescritos (sin diagnóstico ni notas)",
    "read:scores": "Leer tus puntuaciones diarias de actividad, sueño, adherencia y estabilidad",
}

# campo de daily-summary -> (scope del vínculo, clave en metrics.sensors, unidad, métrica de catálogo)
DAILY_FIELDS = {
    "steps": ("ingest:activity", "steps", "count", "steps"),
    "distance_m": ("ingest:activity", "distance", "m", "distance"),
    "active_minutes": ("ingest:activity", "active_minutes", "min", "active_minutes"),
    "calories_active_kcal": ("ingest:activity", "calories", "kcal", "calories_active"),
    "calories_total_kcal": ("ingest:activity", "calories_total", "kcal", "calories_total"),
    "floors_climbed": ("ingest:activity", "floors_climbed", "count", "floors_climbed"),
    "wear_time_minutes": ("ingest:device", "wear_time", "min", "device_wear"),
    "resting_heart_rate_bpm": ("ingest:vitals", "resting_heart_rate", "bpm", "resting_heart_rate"),
    "avg_heart_rate_bpm": ("ingest:vitals", "heart_rate", "bpm", "heart_rate"),
    "max_heart_rate_bpm": ("ingest:vitals", "max_heart_rate", "bpm", "heart_rate"),
    "hrv_rmssd_ms": ("ingest:vitals", "hrv", "ms", "hrv_rmssd"),
    "hrv_sdnn_ms": ("ingest:vitals", "hrv_sdnn", "ms", "hrv_sdnn"),
    "spo2_avg_pct": ("ingest:vitals", "spo2", "%", "spo2"),
    "respiratory_rate_avg_bpm": ("ingest:vitals", "respiratory_rate", "brpm", "respiratory_rate"),
    "skin_temperature_deviation_c": ("ingest:vitals", "temperature_deviation", "°C", "skin_temperature_deviation"),
    "sleep_total_minutes": ("ingest:sleep", "sleep", "min", "sleep"),
    "sleep_efficiency_pct": ("ingest:sleep", "sleep_efficiency", "%", "sleep"),
    "weight_kg": ("ingest:body", "weight", "kg", "weight"),
    "body_fat_pct": ("ingest:body", "body_fat", "%", "body_fat"),
}
# informativos del fabricante: se guardan pero nunca entran en los scores
INFORMATIONAL_FIELDS = ("recovery_score", "strain_score", "vendor_specific")

PLAUSIBLE_RANGES = {
    "steps": (0, 150_000), "distance_m": (0, 300_000), "active_minutes": (0, 1440),
    "calories_active_kcal": (0, 15_000), "calories_total_kcal": (0, 20_000), "floors_climbed": (0, 2000),
    "wear_time_minutes": (0, 1440), "resting_heart_rate_bpm": (25, 250), "avg_heart_rate_bpm": (20, 300),
    "max_heart_rate_bpm": (30, 300), "hrv_rmssd_ms": (1, 500), "hrv_sdnn_ms": (1, 500), "spo2_avg_pct": (50, 100),
    "respiratory_rate_avg_bpm": (4, 60), "skin_temperature_deviation_c": (-10, 10), "sleep_total_minutes": (0, 1440),
    "sleep_efficiency_pct": (0, 100), "weight_kg": (1, 500), "body_fat_pct": (1, 75),
}

# métrica de serie -> (scope, unidad canónica, rango, conversiones aceptadas)
SAMPLE_METRICS = {
    "heart_rate": ("ingest:vitals", "bpm", (20, 300), {"bpm": 1.0}),
    "hrv_rmssd": ("ingest:vitals", "ms", (1, 500), {"ms": 1.0, "s": 1000.0}),
    "spo2": ("ingest:vitals", "%", (50, 100), {"%": 1.0}),
    "respiratory_rate": ("ingest:vitals", "brpm", (4, 60), {"brpm": 1.0, "bpm": 1.0}),
    "skin_temperature": ("ingest:vitals", "°C", (20, 45), {"°C": 1.0}),
    "steps": ("ingest:activity", "count", (0, 5000), {"count": 1.0}),
    "distance": ("ingest:activity", "m", (0, 10_000), {"m": 1.0, "km": 1000.0, "mi": 1609.344}),
}

MSK_UNITS = {
    "deg": ("deg", 1.0), "rad": ("deg", 57.29577951308232), "N": ("N", 1.0), "kgf": ("N", 9.80665),
    "kg": ("N", 9.80665), "steps/min": ("steps/min", 1.0), "%": ("%", 1.0), "ms": ("ms", 1.0), "s": ("ms", 1000.0),
    "cm": ("cm", 1.0), "m": ("cm", 100.0), "mm2": ("mm2", 1.0), "cm2": ("mm2", 100.0), "uV": ("uV", 1.0),
    "mV": ("uV", 1000.0), "N/s": ("N/s", 1.0), "index": ("index", 1.0),
}
MSK_TYPE_UNITS = {
    "range_of_motion_flexion": ("deg", (0, 360)), "range_of_motion_extension": ("deg", (0, 360)),
    "range_of_motion_abduction": ("deg", (0, 360)), "range_of_motion_rotation": ("deg", (0, 360)),
    "isometric_force": ("N", (0, 10_000)), "peak_force": ("N", (0, 20_000)),
    "rate_of_force_development": ("N/s", (0, 100_000)), "emg_rms": ("uV", (0, 10_000)),
    "emg_activation_pct": ("%", (0, 100)), "muscle_oxygenation_smo2": ("%", (0, 100)),
    "joint_load_index": ("index", (0, 1000)), "limb_symmetry_index": ("%", (0, 200)),
    "gait_cadence": ("steps/min", (0, 400)), "gait_step_length": ("cm", (0, 300)),
    "gait_asymmetry_pct": ("%", (0, 100)), "balance_sway_area": ("mm2", (0, 100_000)),
    "reaction_time": ("ms", (0, 10_000)), "vendor_specific": (None, None),
}

# vocabulario de regiones alineado con el body chart; ampliable sin romper el contrato
BODY_REGIONS = {
    "neck", "cervical_spine", "thoracic_spine", "lumbar_spine", "lower_back", "upper_back", "shoulder", "elbow",
    "wrist", "hand", "hip", "knee", "ankle", "foot", "thigh", "calf", "forearm", "upper_arm", "pelvis",
    "chest", "abdomen", "full_body",
}

METRICS_CATALOG = [
    {"metric": "steps", "category": "activity", "canonical_unit": "count", "accepted_units": ["count"], "value_type": "integer", "range": {"min": 0, "max": 150000}, "accepted_by": ["daily-summaries", "samples"], "maps_to": "metrics.sensors.steps"},
    {"metric": "distance", "category": "activity", "canonical_unit": "m", "accepted_units": ["m", "km", "mi"], "value_type": "number", "range": {"min": 0, "max": 300000}, "accepted_by": ["daily-summaries", "samples"], "maps_to": "metrics.sensors.distance"},
    {"metric": "active_minutes", "category": "activity", "canonical_unit": "min", "accepted_units": ["min"], "value_type": "integer", "range": {"min": 0, "max": 1440}, "accepted_by": ["daily-summaries"], "maps_to": "metrics.sensors.active_minutes"},
    {"metric": "calories_active", "category": "activity", "canonical_unit": "kcal", "accepted_units": ["kcal"], "value_type": "number", "range": {"min": 0, "max": 15000}, "accepted_by": ["daily-summaries"], "maps_to": "metrics.sensors.calories"},
    {"metric": "heart_rate", "category": "vitals", "canonical_unit": "bpm", "accepted_units": ["bpm"], "value_type": "integer", "range": {"min": 20, "max": 300}, "accepted_by": ["samples", "daily-summaries", "sessions"], "maps_to": "metrics.sensors.heart_rate"},
    {"metric": "resting_heart_rate", "category": "vitals", "canonical_unit": "bpm", "accepted_units": ["bpm"], "value_type": "integer", "range": {"min": 25, "max": 250}, "accepted_by": ["daily-summaries"], "maps_to": "metrics.sensors.resting_heart_rate"},
    {"metric": "hrv_rmssd", "category": "vitals", "canonical_unit": "ms", "accepted_units": ["ms", "s"], "value_type": "number", "range": {"min": 1, "max": 500}, "accepted_by": ["daily-summaries", "samples"], "maps_to": "metrics.sensors.hrv"},
    {"metric": "spo2", "category": "vitals", "canonical_unit": "%", "accepted_units": ["%"], "value_type": "number", "range": {"min": 50, "max": 100}, "accepted_by": ["daily-summaries", "samples"], "maps_to": "metrics.sensors.spo2"},
    {"metric": "respiratory_rate", "category": "vitals", "canonical_unit": "brpm", "accepted_units": ["brpm", "bpm"], "value_type": "number", "range": {"min": 4, "max": 60}, "accepted_by": ["daily-summaries", "samples"], "maps_to": "metrics.sensors.respiratory_rate"},
    {"metric": "skin_temperature", "category": "vitals", "canonical_unit": "°C", "accepted_units": ["°C"], "value_type": "number", "range": {"min": 20, "max": 45}, "accepted_by": ["samples"], "maps_to": "metrics.sensors.skin_temperature"},
    {"metric": "skin_temperature_deviation", "category": "vitals", "canonical_unit": "°C", "accepted_units": ["°C"], "value_type": "number", "range": {"min": -10, "max": 10}, "accepted_by": ["daily-summaries"], "daily_field": "skin_temperature_deviation_c", "maps_to": "metrics.sensors.temperature_deviation"},
    {"metric": "hrv_sdnn", "category": "vitals", "canonical_unit": "ms", "accepted_units": ["ms"], "value_type": "number", "range": {"min": 1, "max": 500}, "accepted_by": ["daily-summaries"], "daily_field": "hrv_sdnn_ms", "maps_to": "metrics.sensors.hrv_sdnn"},
    {"metric": "sleep_efficiency", "category": "sleep", "canonical_unit": "%", "accepted_units": ["%"], "value_type": "number", "range": {"min": 0, "max": 100}, "accepted_by": ["daily-summaries", "sessions"], "daily_field": "sleep_efficiency_pct", "maps_to": "metrics.sensors.sleep_efficiency"},
    {"metric": "wear_time", "category": "device", "canonical_unit": "min", "accepted_units": ["min"], "value_type": "integer", "range": {"min": 0, "max": 1440}, "accepted_by": ["daily-summaries"], "daily_field": "wear_time_minutes", "maps_to": "metrics.sensors.wear_time"},
    {"metric": "sleep", "category": "sleep", "canonical_unit": "min", "accepted_units": ["min"], "value_type": "duration_ms", "range": {"min": 0, "max": 1440}, "accepted_by": ["daily-summaries", "sessions"], "maps_to": "metrics.sensors.sleep"},
    {"metric": "exercise", "category": "exercise", "canonical_unit": "session", "accepted_units": ["session"], "value_type": "enum", "accepted_by": ["sessions"], "maps_to": "patient_wearable_workouts"},
    {"metric": "weight", "category": "body", "canonical_unit": "kg", "accepted_units": ["kg"], "value_type": "number", "range": {"min": 1, "max": 500}, "accepted_by": ["daily-summaries"], "maps_to": "metrics.sensors.weight"},
    {"metric": "body_fat", "category": "body", "canonical_unit": "%", "accepted_units": ["%"], "value_type": "number", "range": {"min": 1, "max": 75}, "accepted_by": ["daily-summaries"], "maps_to": "metrics.sensors.body_fat"},
    {"metric": "range_of_motion_flexion", "category": "msk", "canonical_unit": "deg", "accepted_units": ["deg", "rad"], "value_type": "number", "range": {"min": 0, "max": 360}, "accepted_by": ["msk-measurements"], "maps_to": "msk_measurements"},
    {"metric": "isometric_force", "category": "msk", "canonical_unit": "N", "accepted_units": ["N", "kgf", "kg"], "value_type": "number", "range": {"min": 0, "max": 10000}, "accepted_by": ["msk-measurements"], "maps_to": "msk_measurements"},
    {"metric": "gait_cadence", "category": "msk", "canonical_unit": "steps/min", "accepted_units": ["steps/min"], "value_type": "number", "range": {"min": 0, "max": 400}, "accepted_by": ["msk-measurements"], "maps_to": "msk_measurements"},
    {"metric": "device_wear", "category": "device", "canonical_unit": "event", "accepted_units": ["event"], "value_type": "enum", "accepted_by": ["device-events"], "maps_to": "device_events"},
]
# qué significa cada valor: lo necesita el fabricante para mandar lo mismo que WellQ entiende
MISSING_VS_ZERO = ("Si no hay dato, omite el campo (o no envíes el registro); nunca mandes 0 ni null para decir "
                   "'sin dato'. Un 0 se guarda como medido.")
SEMANTICS = {
    "steps": {"description": "Pasos del día local completo (o hasta la hora del envío si completeness=partial).",
              "zero_meaning": "El dispositivo estuvo puesto y no registró pasos."},
    "sleep": {"description": "Minutos dormidos de la noche que termina en local_date (sin contar tiempo despierto en "
                             "cama). En sesiones, la duración sale de start/end y las fases de stages.",
              "zero_meaning": "Se midió la noche y no hubo sueño. Si el dispositivo no estuvo puesto, omite el campo "
                              "y envía un evento removed."},
    "sleep_efficiency": {"description": "Porcentaje del tiempo en cama que se pasó dormido (0-100).",
                         "zero_meaning": "Ningún minuto dormido en cama; casi siempre es un error: omítelo si no se midió."},
    "hrv_rmssd": {"description": "Variabilidad de la frecuencia cardíaca, RMSSD en milisegundos, medida durante el "
                               "sueño (media de la noche). Si tu dispositivo solo da SDNN, usa hrv_sdnn_ms.",
                  "zero_meaning": "No es un valor válido (el mínimo es 1 ms): omite el campo si no hay medida."},
    "hrv_sdnn": {"description": "Variabilidad de la frecuencia cardíaca, SDNN en milisegundos, media de la noche.",
                 "zero_meaning": "No es un valor válido (el mínimo es 1 ms): omite el campo si no hay medida."},
    "skin_temperature": {"description": "Temperatura absoluta de la piel en °C (series de /samples).",
                         "zero_meaning": "No es un valor válido (rango 20-45 °C)."},
    "skin_temperature_deviation": {"description": "Desviación de la temperatura de la piel durante el sueño respecto "
                                                  "a la línea base del propio paciente, en °C (positiva = más alta).",
                                   "zero_meaning": "Igual que la línea base. Si no hay medida, omite el campo."},
    "heart_rate": {"description": "Pulsaciones por minuto. En el resumen diario, media del día con el dispositivo puesto.",
                   "zero_meaning": "No es un valor válido (mínimo 20 bpm)."},
    "resting_heart_rate": {"description": "Frecuencia cardíaca en reposo del día, en bpm, tal como la calcula el "
                                          "dispositivo (normalmente durante el sueño).",
                           "zero_meaning": "No es un valor válido (mínimo 25 bpm)."},
    "spo2": {"description": "Saturación de oxígeno media, en %, durante el sueño.",
             "zero_meaning": "No es un valor válido (mínimo 50 %)."},
    "respiratory_rate": {"description": "Respiraciones por minuto, media durante el sueño.",
                         "zero_meaning": "No es un valor válido (mínimo 4)."},
    "wear_time": {"description": "Minutos del día local con el dispositivo puesto.",
                  "zero_meaning": "El dispositivo no se llevó ese día: WellQ lo marca como 'sin uso' (not_worn), "
                                  "no como datos que faltan."},
}
for _m in METRICS_CATALOG:
    _m.setdefault("missing_value", MISSING_VS_ZERO)
    _m.update(SEMANTICS.get(_m["metric"], {}))

KNOWN_METRICS = {m["metric"] for m in METRICS_CATALOG} | set(SAMPLE_METRICS) | set(MSK_TYPE_UNITS) | {
    "calories_total", "floors_climbed", "hrv_sdnn", "max_heart_rate"}

FORM_FACTOR_DEVICE_TYPES = {
    "watch": "watch", "band": "fitness_band", "ring": "ring", "chest_strap": "chest_strap", "patch": "accessory",
    "sleeve": "accessory", "insole": "accessory", "scale": "scale", "other": "unknown",
}
