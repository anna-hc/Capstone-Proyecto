import http.client
import ipaddress
import socket
import ssl
import time
from urllib.parse import urlsplit

import app.config as conf

MAX_RESPONSE_BYTES = 65_536
CONNECT_TIMEOUT = 5
TOTAL_TIMEOUT = 10
_BLOCKED_HOSTNAMES = {"localhost", "metadata.google.internal", "metadata", "instance-data"}


class UnsafeUrl(ValueError):
    pass


def private_targets_allowed() -> bool:
    return conf.PARTNER_WEBHOOK_ALLOW_PRIVATE and (conf.APP_ENV or "").lower() in conf.DEV_APP_ENVS


def _ip_is_public(ip: ipaddress._BaseAddress) -> bool:
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    if isinstance(ip, ipaddress.IPv6Address) and ip.sixtofour:
        ip = ip.sixtofour
    return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved
                or ip.is_unspecified or not ip.is_global)


def validate_webhook_url(url: str) -> tuple[str, str, int, str]:
    if len(url or "") > 2048:
        raise UnsafeUrl("URL demasiado larga")
    parts = urlsplit(url)
    allow_private = private_targets_allowed()
    if parts.scheme != "https" and not (allow_private and parts.scheme == "http"):
        raise UnsafeUrl("El webhook debe usar https")
    if parts.username or parts.password:
        raise UnsafeUrl("La URL no puede llevar credenciales")
    host = (parts.hostname or "").rstrip(".").lower()
    if not host:
        raise UnsafeUrl("URL sin host")
    if not allow_private and (host in _BLOCKED_HOSTNAMES or host.endswith((".localhost", ".internal", ".local"))):
        raise UnsafeUrl("Host no permitido")
    try:
        port = parts.port or (443 if parts.scheme == "https" else 80)
    except ValueError:
        raise UnsafeUrl("Puerto inválido") from None
    path = parts.path or "/"
    if parts.query:
        path += "?" + parts.query
    return parts.scheme, host, port, path


def resolve_public_ip(host: str, port: int) -> str:
    try:
        literal = ipaddress.ip_address(host)
        candidates = [literal]
    except ValueError:
        try:
            infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        except socket.gaierror:
            raise UnsafeUrl("No se pudo resolver el host") from None
        candidates = [ipaddress.ip_address(info[4][0].split("%")[0]) for info in infos]
    if not candidates:
        raise UnsafeUrl("No se pudo resolver el host")
    if private_targets_allowed():
        return str(candidates[0])
    # si alguna dirección es interna se rechaza todo: evita que el DNS elija la interna
    for ip in candidates:
        if not _ip_is_public(ip):
            raise UnsafeUrl("El host resuelve a una dirección interna")
    return str(candidates[0])


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, ip, port, timeout, context):
        super().__init__(host, port=port, timeout=timeout, context=context)
        self._pinned_ip = ip

    def connect(self):
        sock = socket.create_connection((self._pinned_ip, self.port), timeout=CONNECT_TIMEOUT)
        sock.settimeout(self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


class _PinnedHTTPConnection(http.client.HTTPConnection):
    def __init__(self, host, ip, port, timeout):
        super().__init__(host, port=port, timeout=timeout)
        self._pinned_ip = ip

    def connect(self):
        self.sock = socket.create_connection((self._pinned_ip, self.port), timeout=CONNECT_TIMEOUT)
        self.sock.settimeout(self.timeout)


def post_json(url: str, body: bytes, headers: dict) -> tuple[int | None, str | None, int]:
    started = time.monotonic()
    try:
        scheme, host, port, path = validate_webhook_url(url)
        ip = resolve_public_ip(host, port)
    except UnsafeUrl as exc:
        return None, f"unsafe_url: {exc}", int((time.monotonic() - started) * 1000)
    # se conecta a la IP ya validada (sin re-resolver), así un rebinding de DNS no cambia el destino
    if scheme == "https":
        conn = _PinnedHTTPSConnection(host, ip, port, TOTAL_TIMEOUT, ssl.create_default_context())
    else:
        conn = _PinnedHTTPConnection(host, ip, port, TOTAL_TIMEOUT)
    try:
        conn.request("POST", path, body=body, headers={**headers, "Host": host if port in (80, 443) else f"{host}:{port}",
                                                       "User-Agent": "WellQ-Webhooks/1.0", "Connection": "close"})
        resp = conn.getresponse()
        resp.read(MAX_RESPONSE_BYTES)
        return resp.status, None, int((time.monotonic() - started) * 1000)
    except (OSError, http.client.HTTPException, ssl.SSLError) as exc:
        return None, type(exc).__name__, int((time.monotonic() - started) * 1000)
    finally:
        conn.close()
