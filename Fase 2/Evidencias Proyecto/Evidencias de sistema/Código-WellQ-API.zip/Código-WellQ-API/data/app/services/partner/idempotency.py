import hashlib
import time
import uuid
from datetime import datetime, timezone
from typing import Callable, Optional

from fastapi.responses import JSONResponse
from pymongo.errors import DuplicateKeyError

from app.repositories import partner as repo
from app.services.partner.problems import PartnerProblem


def _validate(key: Optional[str]) -> Optional[str]:
    if key is None:
        return None
    try:
        return str(uuid.UUID(key.strip()))
    except (ValueError, AttributeError):
        raise PartnerProblem(400, slug="invalid-idempotency-key", detail="Idempotency-Key debe ser un UUID") from None


def run(key: Optional[str], app_id: str, request_fingerprint: str, link_id: Optional[str],
        action: Callable[[], tuple[int, dict]]) -> JSONResponse:
    key = _validate(key)
    if key is None:
        status, body = action()
        return JSONResponse(body, status_code=status)
    coll = repo.idempotency()
    now = datetime.now(timezone.utc)
    try:
        # la reserva atómica con índice único (app_id, key) hace que solo una petición concurrente ejecute
        coll.insert_one({"app_id": app_id, "key": key, "fingerprint": request_fingerprint, "link_id": link_id,
                         "state": "processing", "created_at": now})
    except DuplicateKeyError:
        existing = None
        for _ in range(20):
            existing = coll.find_one({"app_id": app_id, "key": key}, {"_id": 0})
            if not existing or existing.get("state") != "processing":
                break
            time.sleep(0.05)
        if not existing:
            raise PartnerProblem(409, slug="idempotency-conflict", detail="Reintenta la petición") from None
        if existing.get("fingerprint") != request_fingerprint:
            raise PartnerProblem(422, slug="idempotency-key-reused",
                                 detail="La Idempotency-Key ya se usó con otra petición") from None
        created = existing.get("created_at")
        if created is not None and created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        if existing.get("state") == "processing" and created and (now - created).total_seconds() > 120:
            # el proceso que la reservó murió: se libera para que el cliente pueda reintentar
            coll.delete_one({"app_id": app_id, "key": key, "state": "processing"})
            raise PartnerProblem(409, slug="idempotency-in-progress", detail="Reintenta la petición") from None
        if existing.get("state") != "completed":
            raise PartnerProblem(409, slug="idempotency-in-progress",
                                 detail="Hay una petición con esta Idempotency-Key en curso") from None
        return JSONResponse(existing["response_body"], status_code=existing["status_code"],
                            headers={"Idempotency-Replayed": "true"})
    try:
        status, body = action()
    except Exception:
        coll.delete_one({"app_id": app_id, "key": key, "state": "processing"})
        raise
    if status >= 500:
        coll.delete_one({"app_id": app_id, "key": key})
    else:
        coll.update_one({"app_id": app_id, "key": key},
                        {"$set": {"state": "completed", "status_code": status, "response_body": body}})
    return JSONResponse(body, status_code=status)


def fingerprint(method: str, path: str, body: bytes) -> str:
    return hashlib.sha256(method.encode() + b" " + path.encode() + b"\n" + body).hexdigest()
