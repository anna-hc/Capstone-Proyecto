import json
import os
import threading
import uuid
import time
from datetime import datetime, timedelta, timezone

from app.logging_conf import get_logger
from app.repositories import partner as repo
from app.services.partner import ssrf
from app.services.partner.security import decrypt_secret, new_id, sign_webhook

log = get_logger("PARTNER")

# primer intento inmediato y reintentos 1m, 5m, 15m, 1h, 3h, 6h y 13h: algo menos de 24 h en total
RETRY_SCHEDULE_SECONDS = [60, 300, 900, 3600, 10800, 21600, 46800]
MAX_ATTEMPTS = 1 + len(RETRY_SCHEDULE_SECONDS)
DISABLE_AFTER_CONSECUTIVE_FAILURES = 50
DELIVERY_RETENTION = timedelta(days=30)
LEASE_SECONDS = 60


def _now() -> datetime:
    return datetime.now(timezone.utc)


def envelope(app_id: str, event_type: str, data: dict) -> dict:
    return {"event_id": new_id("evt"), "event_type": event_type,
            "occurred_at": _now().isoformat().replace("+00:00", "Z"), "app_id": app_id, "data": data}


def dispatch(app_id: str, event_type: str, data: dict) -> list[str]:
    # se guarda el payload completo: los reintentos reenvían exactamente lo mismo
    env = envelope(app_id, event_type, data)
    ids = []
    for sub in repo.webhook_subscriptions().find({"app_id": app_id, "status": "active", "events": event_type},
                                                 {"_id": 0, "webhook_id": 1}):
        delivery_id = new_id("dlv")
        repo.webhook_deliveries().insert_one({
            "delivery_id": delivery_id, "webhook_id": sub["webhook_id"], "app_id": app_id,
            "event_id": env["event_id"], "event_type": event_type, "payload": env, "status": "pending",
            "attempt": 0, "attempts": [], "status_code": None, "delivered_at": None, "next_retry_at": _now(),
            "created_at": _now(), "expires_at": _now() + DELIVERY_RETENTION,
        })
        ids.append(delivery_id)
    if ids:
        if _serverless():
            # en Vercel un hilo en segundo plano se congela al terminar la respuesta y puede reanudarse más tarde,
            # cuando el cron ya reclamó la misma entrega: se enviaba dos veces. Aquí se entrega dentro de la petición.
            deliver_ids(ids)
        else:
            kick()
    return ids


def _serverless() -> bool:
    return bool(os.getenv("VERCEL") or os.getenv("AWS_LAMBDA_FUNCTION_NAME"))


def _claim(flt: dict) -> dict | None:
    """Reclama una entrega con un lease y un token propio; solo quien tiene el token puede enviarla y cerrarla."""
    now = _now()
    return repo.find_one_and_update(
        repo.webhook_deliveries(),
        {**flt, "status": "pending", "next_retry_at": {"$lte": now},
         "$or": [{"lease_until": None}, {"lease_until": {"$lt": now}}, {"lease_until": {"$exists": False}}]},
        {"$set": {"lease_until": now + timedelta(seconds=LEASE_SECONDS), "lease_token": uuid.uuid4().hex}},
        sort=[("next_retry_at", 1)],
    )


def deliver_ids(ids: list[str]) -> int:
    processed = 0
    for delivery_id in ids:
        claimed = _claim({"delivery_id": delivery_id})
        if not claimed:
            continue
        try:
            attempt(claimed)
        except Exception as exc:
            log.error("[PARTNER][WEBHOOK][ATTEMPT_ERR] %s", type(exc).__name__, extra={"tag": "PARTNER"})
        processed += 1
    return processed


_kick_lock = threading.Lock()


def kick() -> None:
    # entrega inmediata en segundo plano; el job programado cubre lo que quede pendiente
    if not _kick_lock.acquire(blocking=False):
        return

    def run():
        try:
            deliver_due(limit=20)
        except Exception as exc:
            log.warning("[PARTNER][WEBHOOK][KICK_FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})
        finally:
            _kick_lock.release()
    threading.Thread(target=run, daemon=True).start()


def send(webhook: dict, payload: dict) -> tuple[int | None, str | None, int]:
    body = json.dumps(payload, separators=(",", ":"), default=str).encode()
    ts = int(time.time())
    signature = sign_webhook(decrypt_secret(webhook["secret_enc"]), body, ts)
    return ssrf.post_json(webhook["url"], body, {
        "Content-Type": "application/json",
        "X-WellQ-Signature": f"t={ts},v1={signature}",
        "X-WellQ-Event": payload["event_type"],
        "X-WellQ-Delivery": payload.get("event_id", ""),
    })


def _notify_disabled(webhook: dict) -> None:
    try:
        app_doc = repo.apps().find_one({"app_id": webhook["app_id"]}, {"developer_id": 1, "security_contact_email": 1})
        dev = repo.developers().find_one({"developer_id": (app_doc or {}).get("developer_id")}, {"contact_email": 1})
        recipient = (app_doc or {}).get("security_contact_email") or (dev or {}).get("contact_email")
        if not recipient:
            return
        from app.services.mailer import send_email_html
        text = (f"Tu webhook {webhook['webhook_id']} se desactivó tras {DISABLE_AFTER_CONSECUTIVE_FAILURES} "
                "entregas fallidas seguidas. Revisa el endpoint y vuelve a registrarlo.")
        send_email_html("WellQ: webhook desactivado", recipient, f"<p>{text}</p>", text)
    except Exception as exc:
        log.warning("[PARTNER][WEBHOOK][NOTIFY_FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})


def attempt(delivery: dict) -> dict:
    webhook = repo.webhook_subscriptions().find_one({"webhook_id": delivery["webhook_id"]}, {"_id": 0})
    now = _now()
    if not webhook or webhook.get("status") != "active":
        repo.webhook_deliveries().update_one({"delivery_id": delivery["delivery_id"]},
                                             {"$set": {"status": "cancelled", "next_retry_at": None, "lease_until": None}})
        return {**delivery, "status": "cancelled"}
    token = delivery.get("lease_token")
    if token:
        # justo antes de enviar se confirma que el lease sigue siendo nuestro: si este proceso estuvo congelado y
        # otro reclamó la entrega mientras tanto, se abandona sin enviar (evita la entrega duplicada)
        still_mine = repo.find_one_and_update(
            repo.webhook_deliveries(),
            {"delivery_id": delivery["delivery_id"], "lease_token": token, "status": "pending",
             "lease_until": {"$gt": now}},
            {"$set": {"lease_until": now + timedelta(seconds=LEASE_SECONDS)}})
        if not still_mine:
            log.warning("[PARTNER][WEBHOOK][LEASE_LOST] delivery=%s", delivery["delivery_id"], extra={"tag": "PARTNER"})
            return {**delivery, "status": "lease_lost"}
    try:
        status_code, error, latency = send(webhook, delivery["payload"])
    except Exception as exc:
        status_code, error, latency = None, f"internal: {type(exc).__name__}", 0
    number = delivery.get("attempt", 0) + 1
    ok = status_code is not None and 200 <= status_code < 300
    record = {"attempt": number, "at": now, "status_code": status_code, "error": error, "latency_ms": latency}
    if ok:
        update = {"status": "delivered", "delivered_at": now, "next_retry_at": None}
        repo.webhook_subscriptions().update_one({"webhook_id": webhook["webhook_id"]},
                                                {"$set": {"failure_count": 0, "last_success_at": now}})
    else:
        finished = number >= MAX_ATTEMPTS
        update = {"status": "failed" if finished else "pending",
                  "next_retry_at": None if finished else now + timedelta(seconds=RETRY_SCHEDULE_SECONDS[number - 1])}
        sub = repo.find_one_and_update(repo.webhook_subscriptions(), {"webhook_id": webhook["webhook_id"]},
                                       {"$inc": {"failure_count": 1}, "$set": {"last_failure_at": now}})
        if sub and sub.get("failure_count", 0) >= DISABLE_AFTER_CONSECUTIVE_FAILURES and sub.get("status") == "active":
            repo.webhook_subscriptions().update_one({"webhook_id": webhook["webhook_id"], "status": "active"},
                                                    {"$set": {"status": "disabled_failures", "disabled_at": now}})
            _notify_disabled(webhook)
    update.update({"attempt": number, "status_code": status_code, "lease_until": None, "lease_token": None})
    flt = {"delivery_id": delivery["delivery_id"]}
    if token:
        flt["lease_token"] = token
    repo.webhook_deliveries().update_one(flt,
                                         {"$set": update, "$push": {"attempts": {"$each": [record], "$slice": -20}}})
    return {**delivery, **update}


def deliver_due(limit: int = 100) -> int:
    processed = 0
    for _ in range(limit):
        # el lease evita que dos procesos (varios workers de uvicorn) entreguen lo mismo
        claimed = _claim({})
        if not claimed:
            break
        try:
            attempt(claimed)
        except Exception as exc:
            log.error("[PARTNER][WEBHOOK][ATTEMPT_ERR] %s", type(exc).__name__, extra={"tag": "PARTNER"})
        processed += 1
    return processed


def public_delivery(doc: dict) -> dict:
    return {k: doc.get(k) for k in ("delivery_id", "event_id", "event_type", "attempt", "status", "status_code",
                                    "delivered_at", "next_retry_at", "created_at")}
