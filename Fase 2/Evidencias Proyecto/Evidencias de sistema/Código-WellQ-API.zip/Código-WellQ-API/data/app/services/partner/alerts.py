"""Alertas de operación: lo que debía salir y no salió a tiempo.

Plazos (configurables en app.config):
- Borrado de datos: PARTNER_DELETION_DEADLINE_HOURS (72 h por defecto) desde que el paciente lo pide.
- Aviso (webhook): 8 intentos en algo menos de 24 h; si el último falla, la entrega queda "failed" y se alerta.
- Carga asíncrona (samples): PARTNER_INGEST_JOB_ALERT_MINUTES (60 min) en cola o procesándose.

Cada alerta se anota una sola vez en el registro de auditoría (evento partner.alert.*), se escribe en el log con
nivel ERROR y, si hay PARTNER_ALERT_EMAIL, se manda un correo a operaciones. Los avisos que no se entregaron
también se notifican al contacto del fabricante.
"""
from datetime import datetime, timedelta, timezone

import app.config as conf
from app.logging_conf import get_logger
from app.repositories import partner as repo
from app.services.partner.audit import record_event

log = get_logger("PARTNER")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _mail(recipient: str | None, subject: str, text: str) -> bool:
    if not recipient:
        return False
    try:
        from app.services.mailer import send_email_html
        send_email_html(subject, recipient, f"<p>{text}</p>", text)
        return True
    except Exception as exc:
        log.warning("[PARTNER][ALERT][MAIL_FAIL] %s", type(exc).__name__, extra={"tag": "PARTNER"})
        return False


def _raise_alert(kind: str, detail: str, **fields) -> None:
    log.error("[PARTNER][ALERT][%s] %s", kind, detail, extra={"tag": "PARTNER"})
    record_event(f"partner.alert.{kind}", None, detail=detail, **fields)
    _mail(conf.PARTNER_ALERT_EMAIL, f"WellQ Partner API: alerta {kind}", detail)


def _developer_contact(app_id: str) -> str | None:
    app_doc = repo.apps().find_one({"app_id": app_id}, {"developer_id": 1, "security_contact_email": 1}) or {}
    dev = repo.developers().find_one({"developer_id": app_doc.get("developer_id")}, {"contact_email": 1}) or {}
    return app_doc.get("security_contact_email") or dev.get("contact_email")


def check_overdue(limit: int = 200) -> dict:
    now = _now()
    counts = {"deletions": 0, "webhooks": 0, "ingest_jobs": 0}

    for req in repo.deletion_requests().find({"status": {"$ne": "done"}, "deadline_at": {"$lt": now},
                                              "overdue": {"$ne": True}}, {"_id": 0}).limit(limit):
        repo.deletion_requests().update_one({"request_id": req["request_id"]},
                                            {"$set": {"overdue": True, "overdue_alerted_at": now}})
        _raise_alert("deletion_overdue", f"El borrado {req['request_id']} del vínculo {req['link_id']} superó su plazo "
                     f"(estado {req.get('status')}, {req.get('attempts', 0)} intentos)",
                     request_id=req["request_id"], link_id=req["link_id"], app_id=req.get("app_id"))
        counts["deletions"] += 1

    for dlv in repo.webhook_deliveries().find({"status": "failed", "alerted_at": None}, {"_id": 0}).limit(limit):
        repo.webhook_deliveries().update_one({"delivery_id": dlv["delivery_id"]}, {"$set": {"alerted_at": now}})
        detail = (f"El aviso {dlv.get('event_type')} ({dlv.get('event_id')}) no se pudo entregar tras "
                  f"{dlv.get('attempt', 0)} intentos")
        _raise_alert("webhook_undelivered", detail, delivery_id=dlv["delivery_id"], app_id=dlv.get("app_id"),
                     event_type=dlv.get("event_type"))
        _mail(_developer_contact(dlv.get("app_id")), "WellQ: aviso no entregado",
              detail + ". Puedes consultar el historial en GET /partner/apps/{app_id}/webhooks/{webhook_id}/deliveries.")
        counts["webhooks"] += 1

    stuck_before = now - timedelta(minutes=conf.PARTNER_INGEST_JOB_ALERT_MINUTES)
    for job in repo.ingest_jobs().find({"status": {"$in": ["queued", "processing"]}, "received_at": {"$lt": stuck_before},
                                        "alerted_at": None}, {"_id": 0}).limit(limit):
        repo.ingest_jobs().update_one({"job_id": job["job_id"]}, {"$set": {"alerted_at": now}})
        _raise_alert("ingest_job_stuck", f"La carga {job['job_id']} lleva más de {conf.PARTNER_INGEST_JOB_ALERT_MINUTES} "
                     f"min en estado {job['status']}", job_id=job["job_id"], app_id=job.get("app_id"),
                     link_id=job.get("link_id"))
        counts["ingest_jobs"] += 1
    return counts


def open_alerts(limit: int = 200) -> dict:
    """Lo que sigue pendiente ahora mismo, para la pantalla de operación."""
    iso = lambda v: v.isoformat().replace("+00:00", "Z") if hasattr(v, "isoformat") else v  # noqa: E731
    deletions = [{"request_id": r["request_id"], "link_id": r["link_id"], "status": r.get("status"),
                  "requested_at": iso(r.get("requested_at")), "deadline_at": iso(r.get("deadline_at")),
                  "attempts": r.get("attempts", 0), "last_error": r.get("last_error"), "overdue": bool(r.get("overdue"))}
                 for r in repo.deletion_requests().find({"status": {"$ne": "done"}}, {"_id": 0}).limit(limit)]
    webhooks = [{"delivery_id": d["delivery_id"], "app_id": d.get("app_id"), "event_type": d.get("event_type"),
                 "status": d.get("status"), "attempt": d.get("attempt"), "created_at": iso(d.get("created_at"))}
                for d in repo.webhook_deliveries().find({"status": "failed"}, {"_id": 0})
                .sort("created_at", -1).limit(limit)]
    jobs = [{"job_id": j["job_id"], "app_id": j.get("app_id"), "status": j.get("status"),
             "received_at": iso(j.get("received_at"))}
            for j in repo.ingest_jobs().find({"status": {"$in": ["queued", "processing"]},
                                              "received_at": {"$lt": _now() - timedelta(
                                                  minutes=conf.PARTNER_INGEST_JOB_ALERT_MINUTES)}},
                                             {"_id": 0}).limit(limit)]
    return {"deletions": deletions, "undelivered_webhooks": webhooks, "stuck_ingest_jobs": jobs}
