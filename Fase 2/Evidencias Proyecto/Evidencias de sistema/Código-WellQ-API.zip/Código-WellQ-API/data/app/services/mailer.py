import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import app.config as conf


def send_email_html(subject: str, recipient: str, html_body: str, text_body: str | None = None) -> None:
    if not (conf.SMTP_SERVER and conf.SMTP_SENDER_EMAIL and conf.SMTP_PASSWORD):
        raise RuntimeError("SMTP no configurado")
    msg = MIMEMultipart("alternative")
    msg["From"] = f"{conf.SMTP_SENDER_NAME} <{conf.SMTP_SENDER_EMAIL}>"
    msg["To"] = recipient
    msg["Subject"] = subject
    msg.attach(MIMEText(text_body or "", "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))
    with smtplib.SMTP(conf.SMTP_SERVER, conf.SMTP_PORT, timeout=10) as server:
        if conf.SMTP_USE_TLS:
            server.starttls()
        server.login(conf.SMTP_SENDER_EMAIL, conf.SMTP_PASSWORD)
        server.sendmail(conf.SMTP_SENDER_EMAIL, recipient, msg.as_string())
