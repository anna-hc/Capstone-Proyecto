"""Genera el valor de DASHBOARD_PASSWORD_HASH (PBKDF2-SHA256) para el login del dashboard.

python -m app.scripts.hash_password      # pide la contraseña dos veces sin mostrarla
"""
import getpass
import sys

from app.dashboard_auth import hash_password


def main() -> None:
    password = getpass.getpass("Contraseña del dashboard: ")
    if len(password) < 12:
        sys.exit("Usa al menos 12 caracteres.")
    if getpass.getpass("Repítela: ") != password:
        sys.exit("Las contraseñas no coinciden.")
    print(hash_password(password))


if __name__ == "__main__":
    main()
