from bson import ObjectId
from fastapi import HTTPException

from app.db import users_collection
from app.security import decode_jwt


def decode_authorization(authorization: str | None) -> dict | None:
    if not authorization or not authorization.lower().startswith("bearer "):
        return None
    payload, ok = decode_jwt(authorization.split(" ", 1)[1].strip())
    return payload if ok else None


def get_clinician_oid_from_token(authorization: str | None) -> ObjectId:
    payload = decode_authorization(authorization)
    if not payload:
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")
    subject_id = (payload.get("subject") or {}).get("id")
    if subject_id and ObjectId.is_valid(subject_id):
        return ObjectId(subject_id)
    sub = payload.get("sub")
    if not sub or not ObjectId.is_valid(sub):
        raise HTTPException(status_code=401, detail="Clinician id not found in token")
    user = users_collection().find_one({"_id": ObjectId(sub)}, {"subject": 1})
    subject_id = ((user or {}).get("subject") or {}).get("id")
    if not subject_id or not ObjectId.is_valid(str(subject_id)):
        raise HTTPException(status_code=401, detail="Clinician id not found in token")
    return ObjectId(str(subject_id))
