def get_queue(name: str = "wellq_ingest"):
    # sin worker RQ en el despliegue autónomo: los jobs se procesan en el proceso y el cron recoge lo pendiente
    raise RuntimeError("cola RQ no disponible en el despliegue autónomo")
