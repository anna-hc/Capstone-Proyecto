import time

import jwt
from cryptography.fernet import Fernet
from pymongo import MongoClient
from starlette.concurrency import run_in_threadpool
from starlette.middleware.base import BaseHTTPMiddleware

import app.config as conf
import app.db as dbmod
from app.logging_conf import get_logger
from app.repositories import tenant_repo

log = get_logger("TENANT")
CACHE_TTL = 300
_tenant_cache: dict[str, tuple] = {}
_client_cache: dict[str, MongoClient] = {}
_client = dbmod._client


def _resolve_secret(ref: str) -> str:
    if not ref.startswith("fernet:"):
        return ref
    try:
        return Fernet(conf.TENANT_DB_ENCRYPTION_KEY.encode()).decrypt(ref[len("fernet:"):].encode()).decode()
    except Exception:
        log.error("[TENANT] no se pudo descifrar mongo_uri del tenant", extra={"tag": "TENANT"})
        return ""


def get_tenant_client(tenant_cfg):
    uri_ref = (tenant_cfg or {}).get("mongo_uri")
    if not uri_ref:
        return _client
    if uri_ref not in _client_cache:
        plain = _resolve_secret(uri_ref)
        if not plain:
            return _client
        _client_cache[uri_ref] = MongoClient(plain, tz_aware=True, serverSelectionTimeoutMS=5000)
    return _client_cache[uri_ref]


def resolve_tenant_database(tenant_client, expected_db_name):
    return tenant_client[expected_db_name]


def clear_tenant_caches():
    _tenant_cache.clear()


def _lookup(slug):
    cached = _tenant_cache.get(slug)
    if cached and time.time() - cached[1] < CACHE_TTL:
        return cached[0]
    cfg = tenant_repo.get_by_slug(slug, active_only=True)
    if cfg:
        _tenant_cache[slug] = (cfg, time.time())
    return cfg


class TenantMiddleware(BaseHTTPMiddleware):
    # mismo criterio que la app WellQ: cabecera x-tenant y, si falta, el tenant_slug del JWT (solo para enrutar;
    # la firma se comprueba en las dependencias y allí se exige que ambos coincidan)
    async def dispatch(self, request, call_next):
        slug = request.headers.get("x-tenant")
        auth = request.headers.get("authorization") or ""
        if not slug and auth.lower().startswith("bearer "):
            try:
                slug = jwt.decode(auth.split(" ", 1)[1].strip(), options={"verify_signature": False}).get("tenant_slug")
            except jwt.PyJWTError:
                slug = None
        tdb, db_name, resolved = dbmod.db, conf.MONGO_DB, "default"
        if slug:
            cfg = await run_in_threadpool(_lookup, slug)
            if cfg and cfg.get("mongo_db"):
                tdb = resolve_tenant_database(get_tenant_client(cfg), cfg["mongo_db"])
                db_name, resolved = cfg["mongo_db"], slug
        dbmod._tenant_db.set(tdb)
        request.state.tenant_slug = resolved
        request.state.tenant_db_name = db_name
        return await call_next(request)
